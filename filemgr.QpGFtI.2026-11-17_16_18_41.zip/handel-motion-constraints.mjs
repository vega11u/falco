/** Handel temporal lattice constraints v1.
 * Calibrated only to body-relative 3D landmarks; preserves original observations.
 * This is conservative constrained inverse-kinematics refinement, not a neural 3D scan.
 */
export const HANDEL_CONSTRAINTS_VERSION='handel-motion-v1';
const PAIRS=[[11,13],[13,15],[12,14],[14,16],[23,25],[25,27],[24,26],[26,28],[11,23],[12,24],[11,12],[23,24]];
const finite=Number.isFinite;
const usable=p=>Array.isArray(p)&&p.length>=4&&p.slice(0,3).every(finite)&&(p[3]??0)>.15;
const length=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1],a[2]-b[2]);
const clamp=(x,lo,hi)=>Math.max(lo,Math.min(hi,x));
const med=a=>{const s=a.filter(finite).sort((x,y)=>x-y);return s.length?s[Math.floor(s.length/2)]:null;};
const copy=f=>({...f,render_w:(f.render_w||f.w||[]).map(p=>Array.isArray(p)?p.slice():p)});
/** Enforces fixed body proportions per shot, with robust temporal residuals and bounded corrections.
 * It rejects outliers rather than smoothing verified fast motion. Returns a separate rendered view.
 */
export function handelConstrainSequence(frames,identity,{iterations=4,maxShift=.018}={}){
 if(!Array.isArray(frames)||!frames.length)return {frames:[],quality:{status:'empty'}};
 const out=frames.map(copy),targets=identity?.segment_lengths||{};
 let corrections=0,rejected=0,maxDisplacement=0;
 const shot=(a,b)=>a&&b&&(a.camera_segment_id??0)===(b.camera_segment_id??0)&&finite(a.t)&&finite(b.t)&&(b.t-a.t)>0&&(b.t-a.t)<.18;
 const before=[];
 for(const f of out)for(const [a,b] of PAIRS){const x=f.render_w[a],y=f.render_w[b],target=targets[a+'-'+b];if(usable(x)&&usable(y)&&target>.015)before.push(Math.abs(length(x,y)/target-1));}
 for(let pass=0;pass<Math.min(8,Math.max(1,Math.floor(iterations)));pass++){
  for(let i=0;i<out.length;i++){
   const f=out[i];
   for(const [a,b] of PAIRS){
    const x=f.render_w[a],y=f.render_w[b],target=targets[a+'-'+b];
    if(!usable(x)||!usable(y)||!(target>.015))continue;
    const dist=length(x,y);if(dist<.002)continue;
    const residual=(dist-target)/target;
    if(Math.abs(residual)<.025)continue;
    // Large deviations are likely occlusion or invalid depth, not a reliable limb observation.
    const confidenceA=clamp(x[3],0,1),confidenceB=clamp(y[3],0,1);
    const mobilityA=.02+Math.pow(1-confidenceA,2),mobilityB=.02+Math.pow(1-confidenceB,2);
    const weight=Math.min(1,.15+Math.abs(residual)*2);
    const shift=clamp((dist-target)*.18*weight,-maxShift,maxShift);
    const total=mobilityA+mobilityB;
    if(Math.abs(residual)>.65&&confidenceA>.85&&confidenceB>.85){rejected++;continue;}
    for(let k=0;k<3;k++){
     const axis=(y[k]-x[k])/dist;
     x[k]+=axis*shift*mobilityA/total;y[k]-=axis*shift*mobilityB/total;
    }
    maxDisplacement=Math.max(maxDisplacement,Math.abs(shift));corrections++;
   }
  }
 }
 // Isolated low confidence spikes: anchor to two neighboring observations *only when*
 // both neighbor frames are slow-moving and in the same camera segment.
 let spikeRepairs=0;
 for(let i=1;i<out.length-1;i++){
  const prev=out[i-1],cur=out[i],next=out[i+1];if(!shot(prev,cur)||!shot(cur,next))continue;
  for(let j=0;j<33;j++){
   const a=prev.render_w[j],b=cur.render_w[j],c=next.render_w[j];if(!usable(a)||!usable(c)||!usable(b)||b[3]>=.35)continue;
   const travel=length(a,c);if(travel>.06)continue;
   const d=next.t-prev.t,ratio=(cur.t-prev.t)/d;
   const expected=[0,1,2].map(k=>a[k]*(1-ratio)+c[k]*ratio);
   const delta=Math.hypot(...expected.map((v,k)=>v-b[k]));
   if(delta<.012||delta>.19)continue;
   const fraction=Math.min(.65,.008/delta);
   for(let k=0;k<3;k++)b[k]+=clamp((expected[k]-b[k])*(1-fraction),-.018,.018);
   spikeRepairs++;
  }
 }
 const after=[];
 for(const f of out)for(const [a,b] of PAIRS){const x=f.render_w[a],y=f.render_w[b],target=targets[a+'-'+b];if(usable(x)&&usable(y)&&target>.015)after.push(Math.abs(length(x,y)/target-1));}
 return {frames:out,quality:{schema:HANDEL_CONSTRAINTS_VERSION,method:'bounded geometric graph constraints, not neural SMPL',frames:out.length,bones:PAIRS.length,iterations:Math.min(8,Math.max(1,Math.floor(iterations))),corrections,rejected,spike_repairs:spikeRepairs,median_relative_bone_error_before:med(before),median_relative_bone_error_after:med(after),max_per_constraint_shift:maxDisplacement,source_observations_mutated:false,metric_3d_guarantee:false}};
}
