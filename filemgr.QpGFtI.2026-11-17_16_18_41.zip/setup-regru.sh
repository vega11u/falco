#!/usr/bin/env bash
# Falco Jugger v23.0.0 — PHP server learning + browser video compute for REG.RU shared hosting.
# No administrator privileges, system package changes, Node.js or server FFmpeg required.
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
cd "$ROOT"

# Verify the complete release layout before downloading or changing any runtime assets.
# This makes a partial FTP/ZIP extraction fail early with an actionable path.
for required_test in \
  tests/.htaccess \
  tests/intelligence-data-smoke.php \
  tests/release-smoke.php \
  tests/v22-smoke.sh \
  tests/purcell-core-smoke.mjs \
  tests/purcell-and-report-api-smoke.sh \
  tests/downloader-install-smoke.sh \
  tests/media-adapters-smoke.php \
  tests/v22-2-studio-smoke.sh \
  setup-lux-fallback.sh \
  falco-jugger-ui.css \
  media-import-adapters.php \
  setup-social-adapters.sh \
  tests/purcell-baseline-smoke.mjs \
  tests/v23-frutiger-aero-smoke.sh \
  assets/aero-landscape.svg \
  assets/aero-motion.svg; do
  if [[ ! -s "$ROOT/$required_test" ]]; then
    printf 'ERROR: Не найден обязательный файл %s.
' "$ROOT/$required_test" >&2
    printf '%s\n' 'Распакуйте ПОЛНЫЙ архив целиком: каталог tests/ должен находиться рядом с index.php и setup-regru.sh. Запускайте bash setup-release.sh из корня сайта.' >&2
    exit 1
  fi
done

log(){ printf '\n\033[1;36m== %s ==\033[0m\n' "$*"; }
die(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }
warn(){ printf 'NOTE: %s\n' "$*"; }

log 'Falco Jugger v23.0.0 — REG.RU shared-hosting setup (PHP server learning + browser video compute)'

# Host prerequisites are checked, never installed globally.
for c in php curl tar openssl sha256sum; do
  command -v "$c" >/dev/null 2>&1 || die "Не найдена команда $c. Обратитесь в поддержку REG.RU; установщик не требует root и не меняет системное ПО."
done
php -r 'exit(version_compare(PHP_VERSION,"8.1.0",">=")?0:1);' || die 'Нужен PHP CLI версии 8.1 или новее.'
php -r 'foreach (["json","session","mbstring","curl","xml","zip","openssl"] as $e) { if (!extension_loaded($e)) { fwrite(STDERR,"Missing PHP extension: $e\\n"); exit(2); } }' || die 'В PHP CLI отсутствует обязательное расширение.'

# Keep a safe disk reserve for the user's own videos and personal learning archive.
FREE_KB="$(df -Pk "$ROOT" | awk 'NR==2 {print $4}')"
[[ "$FREE_KB" =~ ^[0-9]+$ ]] || die 'Не удалось определить свободное место на диске.'
FREE_GB="$(awk -v kb="$FREE_KB" 'BEGIN {printf "%.2f", kb/1024/1024}')"
awk -v kb="$FREE_KB" 'BEGIN {exit !(kb >= 2*1024*1024)}' || die "Недостаточно места: сейчас ${FREE_GB} GiB свободно, нужно не менее 2 GiB."
printf 'Свободное место: %s GiB\n' "$FREE_GB"

# Fail early if the browser-side analysis cores were omitted from an FTP/ZIP deployment.
for module in index.php uppurcell.php Memories.php server-learning.php purcell-core.mjs biomechanics-core.mjs kata-recognition-core.mjs device-profile.mjs device-benchmark-worker.js pose-worker.js depth-worker.js depth-reconstruction-core.mjs avatar-render-core.mjs technique-planner.mjs player-zoom-core.mjs data/purcell-knowledge.json; do
  [[ -s "$ROOT/$module" ]] || die "Не найден обязательный браузерный модуль $module. Повторно загрузите полный комплект исходников."
done

# Do not erase any existing data. The install is repeatable and only refreshes vendor assets.
mkdir -p "$ROOT/vendor" "$ROOT/data"

ASSET_INSTALL_OK=1
MEDIAPIPE_INSTALL_OK=1
FFMPEG_INSTALL_OK=1
MEDIA_IMPORT_INSTALL_OK=0
LUX_INSTALL_OK=0
log 'Installing local MediaPipe, pose/hand models and Mediabunny'
if ! bash "$ROOT/setup-assets.sh"; then
  die 'Не удалось установить локальные MediaPipe/Mediabunny ресурсы. Релиз не будет помечен готовым без обязательных моделей и покадрового декодера. Проверьте HTTPS-доступ/место и повторите установку.'
fi

log 'Installing browser-side FFmpeg.wasm fallback'
if ! bash "$ROOT/setup-ffmpeg-wasm.sh"; then
  ASSET_INSTALL_OK=0
  FFMPEG_INSTALL_OK=0
  warn 'Локальный FFmpeg.wasm не установлен. Основная обработка остаётся доступной через Mediabunny; расширенный резерв FFmpeg.wasm будет недоступен.'
fi

log 'Installing primary YouTube / Instagram import (yt-dlp + QuickJS-NG runtime)'
if bash "$ROOT/setup-media-import.sh"; then
  MEDIA_IMPORT_INSTALL_OK=1
else
  warn 'Primary yt-dlp/QuickJS could not be installed. Existing valid binaries are untouched; attempting the independent Lux fallback.'
fi

log 'Installing independent Go Lux fallback (never replaces yt-dlp)'
if bash "$ROOT/setup-lux-fallback.sh"; then
  LUX_INSTALL_OK=1
else
  warn 'Lux could not run or GitHub was unavailable. Retry with bash setup-lux-fallback.sh. Primary yt-dlp remains unaffected.'
fi

log 'Preparing optional PHP social adapters (metadata / owner-configured Cobalt)'
bash "$ROOT/setup-social-adapters.sh"
# One independent extractor is sufficient to import media, including CRON-only mode.
# Never silently claim the social importer is available when both installers fail.
if [[ "$MEDIA_IMPORT_INSTALL_OK" != 1 && "$LUX_INSTALL_OK" != 1 ]]; then
  die 'Не удалось подготовить ни yt-dlp, ни Lux. Локальные файлы можно анализировать без них; для серверных ссылок проверьте исходящий HTTPS/ограничения хостинга.'
fi

log 'Protecting non-public project resources'
mkdir -p "$ROOT/training-data"
cat > "$ROOT/training-data/.htaccess" <<'HT'
Require all denied
<IfModule !mod_authz_core.c>
Deny from all
</IfModule>
HT
chmod 700 "$ROOT/training-data" 2>/dev/null || true

# The capability marker is written only after compatibility checks pass.
# Browser ESM is deliberately not parsed by a server-side JS runtime here: the host's
# system Node is unrelated to the app and may be obsolete. Dedicated developer QA uses Node 22.

log 'Running compatibility checks'
php -l "$ROOT/index.php"
php -l "$ROOT/uppurcell.php"
php -l "$ROOT/Memories.php"
php -l "$ROOT/server-learning.php"
php "$ROOT/tests/intelligence-data-smoke.php"
php "$ROOT/tests/release-smoke.php"
php "$ROOT/tests/media-adapters-smoke.php"
bash "$ROOT/tests/downloader-install-smoke.sh"
bash "$ROOT/tests/v22-2-studio-smoke.sh"
bash "$ROOT/tests/v23-frutiger-aero-smoke.sh"
bash -n "$ROOT/setup-release.sh" "$ROOT/setup-regru.sh" "$ROOT/setup-assets.sh" "$ROOT/setup-video-runtime.sh" "$ROOT/setup-ffmpeg-wasm.sh" "$ROOT/setup-media-import.sh" "$ROOT/setup-lux-fallback.sh" "$ROOT/setup-social-adapters.sh" "$ROOT/setup-media-resilience.sh" "$ROOT/media-import-cron.sh" "$ROOT/tests/downloader-install-smoke.sh" "$ROOT/tests/javascript-syntax-smoke.sh" "$ROOT/tests/optimizer-smoke.sh" "$ROOT/tests/v22-smoke.sh" "$ROOT/tests/purcell-and-report-api-smoke.sh" "$ROOT/tests/v23-frutiger-aero-smoke.sh"

for f in \
  vendor/mediapipe/vision_bundle.mjs \
  vendor/mediapipe/wasm/vision_wasm_internal.js \
  vendor/models/pose_landmarker_lite.task \
  vendor/models/pose_landmarker_full.task \
  vendor/models/hand_landmarker.task \
  vendor/mediabunny/mediabunny.mjs \
  vendor/mediabunny-prores/mediabunny-prores.mjs \
  vendor/ffmpeg/ffmpeg/esm/index.js \
  vendor/ffmpeg/core/umd/ffmpeg-core.js \
  vendor/ffmpeg/core/umd/ffmpeg-core.wasm; do
  if [[ ! -s "$ROOT/$f" ]]; then
    case "$f" in
      vendor/ffmpeg/*) FFMPEG_INSTALL_OK=0; warn "Не установлен необязательный резервный FFmpeg WASM ресурс: $f" ;;
      *) die "Обязательный ресурс отсутствует после установки: $f" ;;
    esac
  fi
done
MEDIAPIPE_JSON=false; [[ "$MEDIAPIPE_INSTALL_OK" == '1' ]] && MEDIAPIPE_JSON=true
FFMPEG_JSON=false; [[ "$FFMPEG_INSTALL_OK" == '1' ]] && FFMPEG_JSON=true
MEDIA_IMPORT_JSON=false; [[ "$MEDIA_IMPORT_INSTALL_OK" == '1' || "$LUX_INSTALL_OK" == '1' ]] && MEDIA_IMPORT_JSON=true
LUX_JSON=false; [[ "$LUX_INSTALL_OK" == '1' ]] && LUX_JSON=true
cat > "$ROOT/data/hosting-runtime.json" <<EOF
{
  "profile": "regru-shared-hosting",
  "release": "23.0.0",
  "server_analysis": false,
  "server_learning": true,
  "server_classifier": "incremental supervised numeric prototypes",
  "browser_pose_runtime": true,
  "browser_video_compute": true,
  "browser_engine_fallbacks": ["WebGPU", "WebGL2", "WebAssembly SIMD", "WebAssembly CPU"],
  "local_mediapipe_assets": ${MEDIAPIPE_JSON},
  "local_ffmpeg_wasm": ${FFMPEG_JSON},
  "social_import_downloaders_installed": ${MEDIA_IMPORT_JSON},
  "independent_lux_installed": ${LUX_JSON},
  "personal_learning_archive": "private PHP library outside DOCUMENT_ROOT; Lully data remains in library.json and classifier-model.json",
  "purcell_archive": "private KATA_LEARNING_DIR/purcell (separate from Lully)",
  "lully_sync": "idempotent; exact confirmed-example SHA-256 source hash",
  "report_archive": "browser gzip + sequential 2 MiB chunks + PHP streaming",
  "application_stack": "PHP + browser JavaScript",
  "installed_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
EOF
chmod 644 "$ROOT/data/hosting-runtime.json"

printf '\n%s\n' 'Falco Jugger v23.0.0 — REG.RU setup завершён.'
printf '%s\n' 'Видео декодируется и анализируется на устройстве; PHP-сервер хранит численные примеры и обучает классификатор ката/паттернов.'
printf '%s\n' 'Системные пакеты, sudo, Python/pip и Node.js не требуются. Серверная часть — PHP; inference — JavaScript в браузере.'
printf '%s\n' 'Системные Node.js и Deno не используются. QuickJS-NG Cosmopolitan/native binary выполняет YouTube EJS challenge.'
printf '%s\n' 'Если веб-PHP блокирует proc_open, добавьте media-import-cron.sh в CRON REG.RU (каждую минуту) для обработки очереди YouTube/Instagram.'
printf '%s\n' 'Импорт: yt-dlp + QuickJS-NG, затем при наличии Lux (независимый Go CLI). Локальная обработка: Mediabunny + ProRes.'
printf '%s\n' 'Обязательные локальные inference-модели, Mediabunny и ProRes проверены. FFmpeg.wasm устанавливается как резервный конвертер.'
printf '%s\n' 'Откройте сайт по HTTPS. Не удаляйте соседний каталог .kata-biomechanics-* — там находится персональное обучение.'
printf '%s\n' 'Повторный запуск безопасен: личная обучающая библиотека и пользовательские файлы не удаляются.'
