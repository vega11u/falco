# Falco Jugger 23.0.0 — architecture and compatibility

## Release intent

v23 is a safe overlay upgrade of v22.5.0. It changes the presentation system, expands shipped Purcell subject knowledge, and adds bounded public-social URL support. It does not migrate the database or private learning stores.

## Compatibility invariants

Unchanged:
- PHP API names, HTTP methods, payload shapes, response shapes, and report archive format.
- Private storage roots and files: Lully `library.json`, `classifier-model.json`, Purcell library/feedback, report archive and media-import queue.
- Q16 feature packing, confirmed-only Lully learning, Purcell feedback and reference example schemas.
- DOM IDs, event handlers, trim range representation, video player controls, canvas IDs, worker message contracts and report ownership cookie.
- Mediabunny frame demuxing, every-source-sample pose inference, pose worker backpressure/recovery, sparse independent depth worker and local browser inference.
- Existing YouTube/Instagram extractor profile order, QuickJS-NG proof, Lux fallback, CRON worker, bounded file transfer, hash/ACK and cleanup.

## Frutiger Aero presentation

`aero-workbench-v23.css` is loaded after the legacy structural CSS on `index.php` (including `uppurcell.php`) and `Memories.php`. It overrides presentation only. The old `baroque-workbench-v22-5.css` remains in the package for rollback and external references but is no longer loaded by the application.

The design uses layered sky/water/grass colour fields, translucent acrylic panels, specular highlights, glossy tactile controls, rounded glass surfaces, saturated aqua/turquoise/green accents, depth, soft shadows and a high-contrast dark video chamber. `backdrop-filter` has a solid-glass fallback; reduced-motion is respected. No JS animation framework or build step is introduced.

## Purcell knowledge

`data/purcell-knowledge.json` retains schema `purcell-knowledge-v1` and all existing fields. Additive knowledge blocks describe seven movement phases, trajectory-level optimization, functional anatomy, evidence levels, confidence factors, concise recommendation language and the separate roles of Lully/Purcell. `purcell-core.mjs` now attaches the phase model, trajectory objective, candidate change space, hard constraints, soft objectives and counterfactual policy to each recommendation. It also adds a concise full-trajectory reminder to the Russian explanation. The additions are local decision/report fields; API and storage payload contracts are unchanged.

The theory does not claim that monocular video measures EMG, muscle force, joint moments, ground reaction forces, ligament strain, tendon energy return or injury risk. Personal examples remain observations, not universal correctness labels.

## Processing and performance findings

The current analyzer already demuxes source samples with Mediabunny and sends every decoded sample through MediaPipe VIDEO-mode temporal inference. It deliberately does not thin frames by duration. Pose inference runs in a module Worker when available with bounded request backpressure and recovery; main-thread inference is a compatibility fallback. Depth Anything is an independent sparse pass (roughly 0.52 s cadence on WebGPU, 1.35 s otherwise), overlapped with pose work and bounded to avoid GPU/RAM queue growth. Avatar display interpolation is separate from measured source frames and adapts canvas pixel density when render FPS falls.

v23 deliberately does not increase depth cadence or drop pose frames: either could make a benchmark look faster while degrading coverage or exhausting shared-device memory. No universal device FPS can be promised; source decode, model delegate, thermal state, browser and display rate remain limiting factors.

## Public video importers

Existing YouTube and Instagram paths are unchanged. Additional host allowlist support routes individual public videos from TikTok, VK, VK Video, Rutube, X/Twitter and Facebook/FB Watch through generic yt-dlp format profiles, followed by the already-existing independent Lux fallback when installed. No cookies, credentials, private posts, playlists or profile pages are enabled. Actual extractor availability depends on the installed yt-dlp/Lux version and hosting egress; provider support is best-effort, not a guarantee.

## Hosting

PHP + browser JavaScript on REG.RU Host-0. No Python, Node runtime, database migration, new daemon, npm build or server-side inference service is added. Node is used only by developer regression tests, not production hosting.
