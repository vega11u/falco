import {trainHypothesis,trainHypothesisPopulation} from './purcell-evolution-core.mjs?v=23.0.27';
let abort=false,running=false;
self.onmessage=async ({data})=>{
 if(data?.type==='cancel'){abort=true;return;}
 if(!['train','population'].includes(data?.type)||running)return;
 running=true;abort=false;const id=data.id;
 try{
  const fn=data.type==='population'?trainHypothesisPopulation:trainHypothesis;
  const result=await fn({...data.payload,onProgress:progress=>self.postMessage({id,type:'progress',progress}),shouldStop:()=>abort});
  self.postMessage({id,type:'result',result});
 }catch(error){self.postMessage({id,type:'error',error:String(error?.message||error).slice(0,300)});}finally{running=false;}
};
