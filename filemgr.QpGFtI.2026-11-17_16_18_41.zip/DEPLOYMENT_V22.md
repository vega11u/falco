# Falco Jugger 22.0.0 — deployment on REG.RU Host-0

## Before uploading

1. Make a copy of the public project directory.
2. Back up the private Lully directory (`KATA_LEARNING_DIR`, commonly
   `.kata-biomechanics-*`) and private report directory (`KATA_REPORTS_DIR`,
   commonly `.kata-reports-*`). These are not inside the deployment ZIP.
3. Confirm that both private directories are outside `DOCUMENT_ROOT`. Do not
   move them into the public web directory to make the new Purcell folder.

## Upload

Upload the v22 ZIP as an overlay into the existing project directory. Do not use
a mirror/synchronise mode that deletes files absent from the ZIP. In particular,
do not delete or replace:

- `library.json` — Lully confirmed examples;
- `classifier-model.json` — existing Lully classifier;
- `taxonomy-custom.json` — custom labels;
- report archive files in `.kata-reports-*`.

The release adds `uppurcell.php`, `purcell-core.mjs` and
`data/purcell-knowledge.json`. It updates `index.php`, `Memories.php`,
`server-learning.php`, tests and deployment scripts.

## Run the release checks

From the project directory:

```bash
bash setup-release.sh
```

If you use the REG.RU-specific installer:

```bash
bash setup-regru.sh
```

The release does not require Python, Node, npm, a GPU process or a permanently
running worker on the hosting account. Node >=22 is used only by developer
regression tests; it is not required by the deployed website.

## Verify after upload

1. Open `/index.php?api=health`; expect `ok: true`.
2. Open `/index.php?api=purcell-status`; expect an empty or existing Purcell
   count, not a PHP warning.
3. Open `/index.php`; verify the live server dot turns green, upload a short
   clip and check the 2D player, current-frame legend and timeline.
4. Open `/uppurcell.php`; use the same uploader and player, analyze a short
   movement example, rate it, select body regions and save. The Purcell count
   should increase.
5. Open `/Memories.php`; open an existing report in continuation mode and save
   a new test report. New report uploads use 2 MiB gzip chunks and should not
   require a 768 MiB PHP memory limit.
6. Confirm that a saved Purcell example appears only in
   `KATA_LEARNING_DIR/purcell/`, and that Lully's existing library/model files
   have not been replaced.

## Storage boundaries

- Lully: existing `KATA_LEARNING_DIR/library.json` and
  `KATA_LEARNING_DIR/classifier-model.json`.
- Purcell: `KATA_LEARNING_DIR/purcell/library.json` and
  `feedback.json`, created on first save.
- Reports: separate `KATA_REPORTS_DIR` with gzip archives and small metadata
  sidecars.

Purcell examples and votes are not report attachments. Deleting a report does
not delete either learning database. The ZIP intentionally contains no personal
models, training examples, reports or original videos.
