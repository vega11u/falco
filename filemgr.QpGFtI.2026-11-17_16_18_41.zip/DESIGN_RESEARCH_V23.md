# Design research — Falco Jugger v23.0.0

## Frutiger Aero references reviewed

- https://frutigeraero.org/resources — historical visual vocabulary: Web 2.0 gloss, Windows Aero, glass, nature, water, bubbles, humanist typography and optimistic light.
- https://github.com/biagio-scaglia/frutiger-js — CSS design system reference for glass materials, specular surfaces, glossy controls and theme tokens. Not imported as a dependency.
- https://github.com/Zakintaliban/frutiger-aero — independent no-build concept reference for sky, waterline, grass, bubbles, frosted surfaces and reduced-motion behavior.
- https://github.com/AamirrH/FrutigerAero — vanilla HTML/CSS/JS reference for Windows 7-era glass and skeuomorphic interaction.
- https://github.com/TheAgencyMGE/frutiger-aero-everywhere — palette reference for sky, aqua, turquoise, ocean, grass and dark blue ink.

## Application-specific design decisions

The project is a high-density motion-analysis tool, not a marketing landing page. The Aero material language is applied to controls, work panels, upload areas, trim tools, report surfaces and navigation. Video and canvas analysis areas retain a dark aquatic contrast chamber so pose overlays, depth colours and comparison trajectories remain legible. Decorative effects are CSS-only, never cover interaction areas, respect reduced-motion, and fall back to opaque acrylic where backdrop filters are unavailable.

Palette uses pale sky/cyan glass, saturated ocean blue, turquoise and organic green. Controls have glossy convex highlights and pressed states. Panels use translucent acrylic, light edges, layered shadows and rounded geometry. The project name remains the only brand mark.

## Performance considerations

No framework, animation package, remote UI dependency or image-heavy wallpaper was added. Aero surfaces use CSS gradients and pseudo-elements; backdrop blur is a progressive enhancement. The application still works if external font/CDN resources are unavailable.
