#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
PROJECT_HASH="$(printf '%s' "$ROOT" | sha256sum | awk '{print substr($1,1,12)}')"
MEDIA_DIR="${KATA_MEDIA_IMPORT_DIR:-$(dirname "$ROOT")/.kata-media-import-${PROJECT_HASH}}"
[[ -d "$MEDIA_DIR" ]] || exit 0
YTDLP_READY=0; [[ -x "$MEDIA_DIR/bin/yt-dlp" ]] && YTDLP_READY=1
[[ "$YTDLP_READY" == '1' || -x "$MEDIA_DIR/bin/lux" || ( -s "$MEDIA_DIR/adapters.json" && -s "$ROOT/media-import-adapters.php" ) ]] || exit 0
command -v nohup >/dev/null 2>&1 || exit 0
LOCK="$MEDIA_DIR/.cron-worker-lock"
ACTIVE_LOCK="$MEDIA_DIR/.active-job-lock"

# One dispatcher and one actual download per hosting account, including jobs
# started directly by PHP in another browser session.
if ! mkdir "$LOCK" 2>/dev/null; then
  LOCK_PID="$(cat "$LOCK/pid" 2>/dev/null || true)"
  LOCK_TIME="$(stat -c %Y "$LOCK" 2>/dev/null || echo 0)"
  if [[ "$LOCK_PID" =~ ^[0-9]+$ ]] && kill -0 "$LOCK_PID" 2>/dev/null; then exit 0; fi
  if (( $(date +%s) - LOCK_TIME < 21600 )); then exit 0; fi
  rm -f "$LOCK/pid" 2>/dev/null || true
  rmdir "$LOCK" 2>/dev/null || exit 0
  mkdir "$LOCK" 2>/dev/null || exit 0
fi
cleanup_dispatch(){ rm -f "$LOCK/pid" 2>/dev/null || true; rmdir "$LOCK" 2>/dev/null || true; }
trap cleanup_dispatch EXIT INT TERM

clear_stale_active_lock(){
  [[ -d "$ACTIVE_LOCK" ]] || return 0
  local active_id active_dir active_pid activity now age
  active_id="$(cat "$ACTIVE_LOCK/job-id" 2>/dev/null || true)"
  [[ "$active_id" =~ ^[a-f0-9]{24}$ ]] || {
    age=$(( $(date +%s) - $(stat -c %Y "$ACTIVE_LOCK" 2>/dev/null || echo 0) ))
    (( age > 21600 )) || return 1
    rm -f "$ACTIVE_LOCK/job-id" 2>/dev/null || true
    rmdir "$ACTIVE_LOCK" 2>/dev/null || true
    return 0
  }
  active_dir="$MEDIA_DIR/$active_id"
  if [[ ! -d "$active_dir" || -f "$active_dir/exit-code.txt" ]]; then
    rm -f "$ACTIVE_LOCK/job-id" 2>/dev/null || true
    rmdir "$ACTIVE_LOCK" 2>/dev/null || true
    return 0
  fi
  active_pid="$(cat "$active_dir/.started" 2>/dev/null || true)"
  if [[ "$active_pid" =~ ^[0-9]+$ ]] && kill -0 "$active_pid" 2>/dev/null; then return 1; fi
  now="$(date +%s)"
  activity="$(stat -c %Y "$active_dir" 2>/dev/null || echo 0)"
  for f in "$active_dir/job.json" "$active_dir/downloader.log" "$active_dir/.started"; do
    [[ -f "$f" ]] || continue
    stamp="$(stat -c %Y "$f" 2>/dev/null || echo 0)"
    (( stamp > activity )) && activity="$stamp"
  done
  age=$(( now - activity ))
  # A detached runner that vanished is retried only after a short quiet window.
  (( age > 180 )) || return 1
  rm -f "$active_dir/.worker-lock" "$active_dir/.started" "$ACTIVE_LOCK/job-id" 2>/dev/null || true
  rmdir "$ACTIVE_LOCK" 2>/dev/null || true
  : > "$active_dir/.queued"
  chmod 600 "$active_dir/.queued" 2>/dev/null || true
  return 0
}

for QUEUED in "$MEDIA_DIR"/*/.queued; do
  [[ -f "$QUEUED" ]] || continue
  JOB_DIR="$(dirname "$QUEUED")"
  JOB_ID="$(basename "$JOB_DIR")"
  [[ "$JOB_ID" =~ ^[a-f0-9]{24}$ ]] || continue
  [[ -x "$JOB_DIR/run.sh" && -f "$JOB_DIR/job.json" && ! -f "$JOB_DIR/exit-code.txt" ]] || continue

  # An active direct-PHP or CRON job owns this global slot.
  if [[ -d "$ACTIVE_LOCK" ]]; then
    clear_stale_active_lock || exit 0
  fi
  CLAIM="$JOB_DIR/.worker-lock"
  mkdir "$CLAIM" 2>/dev/null || continue
  if ! mkdir "$ACTIVE_LOCK" 2>/dev/null; then
    rmdir "$CLAIM" 2>/dev/null || true
    continue
  fi
  if ! printf '%s\n' "$JOB_ID" > "$ACTIVE_LOCK/job-id"; then
    rmdir "$ACTIVE_LOCK" 2>/dev/null || true
    rmdir "$CLAIM" 2>/dev/null || true
    continue
  fi
  chmod 600 "$ACTIVE_LOCK/job-id" 2>/dev/null || true
  rm -f "$QUEUED"
  printf '%s\n' 'starting' > "$JOB_DIR/.started"
  chmod 600 "$JOB_DIR/.started" 2>/dev/null || true
  nohup /bin/sh "$JOB_DIR/run.sh" </dev/null >/dev/null 2>&1 &
  RUNNER_PID=$!
  if [[ ! "$RUNNER_PID" =~ ^[0-9]+$ ]]; then
    rm -f "$ACTIVE_LOCK/job-id" "$JOB_DIR/.started" 2>/dev/null || true
    rmdir "$ACTIVE_LOCK" "$CLAIM" 2>/dev/null || true
    : > "$QUEUED"
    continue
  fi
  printf '%s\n' "$RUNNER_PID" > "$JOB_DIR/.started"
  printf '%s\n' "$RUNNER_PID" > "$LOCK/pid"
  chmod 600 "$JOB_DIR/.started" "$LOCK/pid" 2>/dev/null || true
  # run.sh removes both account-level locks when the job reaches a terminal state.
  trap - EXIT INT TERM
  exit 0
done
