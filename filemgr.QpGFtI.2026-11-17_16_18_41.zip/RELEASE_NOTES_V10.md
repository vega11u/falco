# v10 — Karate technique context and optimizer research release

- Corrected requested style set: Shotokan, Shito-ryu, Goju-ryu, Ryuei-ryu (not Uechi-ryu).
- Added reference research dossier for WKF rules/kata list, open karate motion-capture resources, and peer-reviewed biomechanics.
- Clarified that taxonomy is a starter vocabulary, not a trained recognition model or biomechanics reference.
- Clarified the optimizer output: bounded athlete-specific kinematic candidate + WebM overlay, not a validated maximum-efficiency or photorealistic re-animation.
- Added one-command installer wrapper and release checks.
