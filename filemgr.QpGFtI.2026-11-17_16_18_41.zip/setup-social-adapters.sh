#!/usr/bin/env bash
# Two additive PHP download adapters. No executable or service is downloaded.
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
PROJECT_HASH="$(printf '%s' "$ROOT" | sha256sum | awk '{print substr($1,1,12)}')"
MEDIA_DIR="${KATA_MEDIA_IMPORT_DIR:-$(dirname "$ROOT")/.kata-media-import-${PROJECT_HASH}}"
command -v php >/dev/null || { echo 'ERROR: PHP CLI is required.' >&2; exit 1; }
php -r 'foreach(["curl","dom","json","openssl"] as $e)if(!extension_loaded($e)){fwrite(STDERR,"Missing CLI extension: $e\n");exit(1);}'
php -l "$ROOT/media-import-adapters.php" >/dev/null
# Validate actual paths, including symlinks; never place API credentials under the website.
php -r '
$root=realpath($argv[1]);$dir=$argv[2];
if($dir===""||$dir[0]!=="/"||is_link($dir))throw new RuntimeException("KATA_MEDIA_IMPORT_DIR must be an absolute private path, not a symlink.");
if(!is_dir($dir)&&!mkdir($dir,0700,true))throw new RuntimeException("Cannot create private adapter directory.");
$dir=realpath($dir);if($dir===$root||str_starts_with($dir,$root.DIRECTORY_SEPARATOR))throw new RuntimeException("Adapter configuration must be outside the public project.");
chmod($dir,0700);$file=$dir."/adapters.json";
if(is_link($file))throw new RuntimeException("Refusing symlink adapters.json.");
if(is_file($file)){
 $config=json_decode((string)file_get_contents($file),true,32,JSON_THROW_ON_ERROR);
 if(!is_array($config))throw new RuntimeException("Invalid adapter configuration; preserved unchanged.");
 echo "Existing adapters.json preserved unchanged.\n";
}else{
 $config=["schema"=>"falco-media-adapters-v1","public_metadata_enabled"=>true,"cobalt_enabled"=>false,"cobalt_endpoint"=>"","cobalt_api_key"=>"","cobalt_media_hosts"=>[],"php_cli_path"=>PHP_BINARY];
 $f=fopen($file,"x");if(!$f)throw new RuntimeException("Cannot create adapters.json.");
 $json=json_encode($config,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n";
 if(fwrite($f,$json)!==strlen($json)){fclose($f);throw new RuntimeException("Incomplete adapter configuration write.");}fclose($f);chmod($file,0600);
 echo "Public metadata adapter enabled; Cobalt disabled until you configure a trusted instance.\n";
}
echo "Private configuration: ".$file."\n";
' "$ROOT" "$MEDIA_DIR"
echo 'Existing yt-dlp, QuickJS-NG and Lux are unchanged. See docs/MEDIA_IMPORT_V23.md.'
