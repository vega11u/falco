/** Kime timing index v23.0.21. Video-derived coordination proxy, not impact/force measurement. */
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const good=p=>Array.isArray(p)&&p.length>=3&&p.slice(0,2).every(Number.isFinite)&&(p[3]??1)>=.35;
const dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
function velocity(frames,id,i){if(i<1||i>=frames.length)return null;const a=frames[i-1],b=frames[i],dt=Number(b.t)-Number(a.t);if(!(dt>0&&dt<.2)||!good(a.im?.[id])||!good(b.im?.[id]))return null;return dist(a.im[id],b.im[id])/dt;}
function localPeakEnd(frames,id,at,lo,hi){let peak=0,peakI=-1;for(let i=lo+1;i<=hi;i++){const v=velocity(frames,id,i);if(v!=null&&v>peak){peak=v;peakI=i;}}if(peakI<0||peak<.35)return null;const threshold=Math.max(.12,peak*.22);for(let i=peakI+1;i<=hi;i++){const v=velocity(frames,id,i);if(v!=null&&v<=threshold)return {index:i,time:Number(frames[i].t),peak};}return null;}
/** events: [{start,end,type,side,fast}] from existing action detector. */
export function evaluateKimeEvents(frames,events,{maxWindowMs=180}={}){
 const results=[];for(const e of events||[]){if(e.fast===false)continue;const start=Math.max(1,Math.trunc(e.start??0)),end=Math.min(frames.length-1,Math.trunc(e.end??0));if(end-start<2)continue;
  const ids=e.type==='kick'?(e.side==='left'?[27,23,11,12]:[28,24,11,12]):(e.side==='left'?[15,23,24,27,28]:[16,23,24,27,28]);
  const ends=ids.map(id=>({id,hit:localPeakEnd(frames,id,null,start,end)})).filter(x=>x.hit);if(ends.length<3){results.push({event_id:e.id??null,eligible:true,measurable:false,reason:'Недостаточно надёжных точек'});continue;}
  const times=ends.map(x=>x.hit.time),spread=(Math.max(...times)-Math.min(...times))*1000,score=clamp(100*(1-spread/maxWindowMs),0,100);
  results.push({event_id:e.id??null,type:e.type,eligible:true,measurable:true,coordination_score:+score.toFixed(1),spread_ms:+spread.toFixed(1),within_window:spread<=maxWindowMs,terminal_times:ends.map(x=>({landmark:x.id,time_s:x.hit.time}))});
 }
 const measured=results.filter(x=>x.measurable);return {schema:'kime-timing-v1',events:results,measured:measured.length,fast_events:results.length,within_window:measured.filter(x=>x.within_window).length,overall_percent:measured.length?+(100*measured.filter(x=>x.within_window).length/measured.length).toFixed(1):null,limitations:['Видео оценивает кинематическую согласованность, но не силу контакта, мышечную активацию или реальный удар по цели.','Порог 180 мс — стартовая настраиваемая эвристика, не универсальный норматив каратэ.']};
}
