# Falco Jugger v22.0.0 — architecture and migration notes

## Runtime boundaries

- Browser: video decoding, MediaPipe pose/hand inference, 2D avatar, kinematics,
  pattern candidate generation, Lully matching, Purcell decision logic and local
  playback. No Python service or model server is introduced.
- PHP: authenticated report archive, existing Lully library/classifier APIs,
  separate Purcell example/feedback storage and social-media import endpoints.
- Shared hosting target: REG.RU Host-0 profile. No long-lived worker, GPU, Node,
  Python, pip, npm or server-side video inference is required.

## Lully is preserved

The existing private learning directory remains the single source of truth:

- `library.json` — confirmed feature examples and feedback;
- `classifier-model.json` — incremental statistical prototypes;
- `taxonomy-custom.json` — user-entered labels where present.

The v22 update does not migrate the example data or replace existing classifier
prototypes. It may add source-hash metadata to the classifier JSON without
changing its learned values. `model-sync` is an idempotent verification/rebuild operation: it compares both the confirmed
training-example count and a SHA-256 hash of the canonical classifier-relevant projection of valid
confirmed examples (not feedback-only notes or source filenames). If both match, it does nothing. If a legacy model has no
source hash but its count matches, v22 adopts the hash without changing the
trained prototypes. If the model is behind or the feature-library hash differs,
it rebuilds from the same library under the existing file locks. If the library
is missing while a non-empty classifier exists, the endpoint refuses to rebuild
and preserves the classifier. Duplicate card saves are idempotent and do not
increment classifier prototypes a second time.

Every confirmed pattern card continues to call the existing `learn` endpoint
immediately. The explicit **Обновить модель Lully** action checks for missing
confirmed examples and synchronizes only what is absent. The **Повторный поиск
паттернов** action writes the current yes/no decisions to the learning feedback
archive, runs the idempotent Lully sync, clears every current card, and performs
a fresh discovery pass. Each pass has its own feedback batch key so previous
passes are not overwritten.

## Purcell is a separate, additive layer

Files shipped in the release:

- `purcell-core.mjs` — nearest reviewed-example matching, conservative
  biomechanical decision gating and bounded 2D avatar correction;
- `data/purcell-knowledge.json` — qualitative anatomy, functional chains,
  karate-specific principles and explicit observability limits;
- `uppurcell.php` — mode entry point that includes the same analyzer page.

Personal Purcell data is created outside the public document root at:

`KATA_LEARNING_DIR/purcell/`

- `library.json` — reviewed biomechanical examples and Q16 feature vectors;
- `feedback.json` — user votes on Purcell recommendations;
- `purcell.lock` — shared/exclusive file lock;
- `.htaccess` and `index.html` — additional protection if the configured
  learning directory is accidentally placed below the document root.

Purcell reads Lully's current pattern context at analysis time; it does not own
or duplicate Lully's classifier weights. The theory catalog loads the existing
anatomy functional model and karate taxonomy already shipped in `data/`.

## What Purcell can and cannot infer

Purcell does not smooth coordinates, denoise tracks or rewrite source metrics.
It selects only actionable, high-confidence biomechanical cues, matches them
against reviewed positive/counterexample clips, and only synthesizes a changed
2D avatar when a sufficiently similar positive reference exists. The correction
is local to selected body regions and a short time window; event order and
timestamps remain unchanged. If there is no reliable reference, it explains
why no synthetic correction is offered.

The system does not claim to measure EMG, muscle force, joint moments, tendon or
ligament strain, ground reaction forces, injury risk or real-world efficiency
from a monocular RGB video. These remain explicitly qualitative anatomical
context, not measured outputs.

## Reports

The report archive remains separate from both learning stores. The existing
owner-cookie scope, atomic writes, gzip storage, report list/read/delete APIs
and frame-store restoration are retained. New uploads use chunked streaming;
new archives list from sidecars, and legacy list metadata is extracted from a
small gzip stream without decoding the entire old report. `Memories.php` now shares the main
page's design system and provides both report continuation and the Purcell
training route. No report deletion operation can remove Lully or Purcell data.

## Upgrade procedure

1. Back up the existing website and private `.kata-biomechanics-*` and
   `.kata-reports-*` directories.
2. Upload this archive as an overlay; never mirror-delete existing data.
3. Run `bash setup-release.sh`.
4. Check `/index.php?api=health` and `/index.php?api=purcell-status`.
5. Open `/uppurcell.php`, run a short sample, save one reviewed example and
   verify the Purcell count changes.
6. Open the report library and continue an existing report.

The deployment archive intentionally excludes all private trained models,
personal examples, reports and source videos.
