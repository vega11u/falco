#!/usr/bin/env bash
# Install self-hosted Mediabunny + official ProRes decoder bundles for browser-local video.
# PHP + curl + tar + OpenSSL only. No Node.js, Python, npm CLI, root access or global packages.
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
VERSION='1.65.0'
VENDOR_DIR="$ROOT/vendor/mediabunny"
BUNDLE="$VENDOR_DIR/mediabunny.mjs"
VERSION_FILE="$VENDOR_DIR/VERSION"
PRORES_DIR="$ROOT/vendor/mediabunny-prores"
PRORES_BUNDLE="$PRORES_DIR/mediabunny-prores.mjs"
PRORES_VERSION_FILE="$PRORES_DIR/VERSION"
TMP="$(mktemp -d)"
cleanup(){ rm -rf "$TMP"; }
trap cleanup EXIT

die(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }
for c in curl tar php openssl; do command -v "$c" >/dev/null 2>&1 || die "Required command is missing: $c"; done
php -r 'exit(extension_loaded("openssl") && extension_loaded("json") ? 0 : 1);' || die 'PHP CLI requires OpenSSL and JSON extensions.'
mkdir -p "$VENDOR_DIR"
if [[ -s "$BUNDLE" && -s "$VERSION_FILE" && -s "$PRORES_BUNDLE" && -s "$PRORES_VERSION_FILE" ]] && [[ "$(cat "$VERSION_FILE")" == "$VERSION" && "$(cat "$PRORES_VERSION_FILE")" == "$VERSION" ]]; then
  if [[ "$(wc -c < "$BUNDLE")" -ge 100000 && "$(wc -c < "$PRORES_BUNDLE")" -ge 10000 ]] \
    && php -r '$s=file_get_contents($argv[1]); foreach(["Input","BlobSource","VideoSampleSink","ALL_FORMATS","Conversion","WebMOutputFormat"] as $n){if(!str_contains($s,$n))exit(2);}' "$BUNDLE" \
    && grep -q 'registerProresDecoder' "$PRORES_BUNDLE"; then
    printf 'Mediabunny + ProRes %s already installed and locally validated.\n' "$VERSION"
    exit 0
  fi
  printf 'WARNING: existing Mediabunny/ProRes assets are incomplete; reinstalling.\n' >&2
  rm -f "$BUNDLE" "$VERSION_FILE" "$PRORES_BUNDLE" "$PRORES_VERSION_FILE"
fi
META_URL="https://registry.npmjs.org/mediabunny/${VERSION}"
TARBALL_URL="https://registry.npmjs.org/mediabunny/-/mediabunny-${VERSION}.tgz"
printf 'Fetching Mediabunny %s registry metadata...\n' "$VERSION"
curl --fail --location --retry 3 --connect-timeout 20 --max-time 120 "$META_URL" -o "$TMP/metadata.json"
EXPECTED="$(php -r '$j=json_decode(file_get_contents($argv[1]),true); $v=$j["dist"]["integrity"]??""; foreach(preg_split("/\\s+/",$v) as $s){if(str_starts_with($s,"sha512-")){echo $s; exit;}}' "$TMP/metadata.json")"
[[ "$EXPECTED" =~ ^sha512-[A-Za-z0-9+/=]+$ ]] || die 'npm registry did not provide a valid SHA-512 integrity value.'
printf 'Downloading Mediabunny package...\n'
curl --fail --location --retry 4 --connect-timeout 20 --max-time 300 "$TARBALL_URL" -o "$TMP/mediabunny.tgz"
ACTUAL="$(php -r 'echo "sha512-".base64_encode(hash_file("sha512",$argv[1],true));' "$TMP/mediabunny.tgz")"
[[ "$ACTUAL" == "$EXPECTED" ]] || die 'Mediabunny npm integrity check failed; package was not installed.'
tar -tzf "$TMP/mediabunny.tgz" >/dev/null || die 'Mediabunny package archive is not a valid gzip tarball.'
mkdir -p "$TMP/package"
tar -xzf "$TMP/mediabunny.tgz" -C "$TMP/package"
PACKAGE_ROOT="$TMP/package/package"
BUNDLE_SOURCE=''
for candidate in \
  "$PACKAGE_ROOT/dist/bundles/mediabunny.mjs" \
  "$PACKAGE_ROOT/dist/mediabunny.mjs" \
  "$PACKAGE_ROOT/dist/bundles/mediabunny.min.mjs" \
  "$PACKAGE_ROOT/dist/mediabunny.min.mjs"; do
  if [[ -s "$candidate" ]]; then BUNDLE_SOURCE="$candidate"; break; fi
done
if [[ -z "$BUNDLE_SOURCE" ]]; then
  BUNDLE_SOURCE="$(find "$PACKAGE_ROOT/dist" -type f \( -name 'mediabunny.mjs' -o -name 'mediabunny.min.mjs' \) 2>/dev/null | head -n1 || true)"
fi
[[ -n "$BUNDLE_SOURCE" && -s "$BUNDLE_SOURCE" ]] || die 'No self-contained Mediabunny ESM bundle was found in the pinned package.'
[[ "$(wc -c < "$BUNDLE_SOURCE")" -ge 100000 ]] || die 'Mediabunny bundle is suspiciously small; refusing partial installation.'
# Install atomically: never leave a truncated ESM file visible to the browser.
cp "$BUNDLE_SOURCE" "$TMP/mediabunny.mjs"
php -r '$s=file_get_contents($argv[1]); foreach(["Input","BlobSource","VideoSampleSink","ALL_FORMATS","Conversion","WebMOutputFormat"] as $n){if(!str_contains($s,$n)){fwrite(STDERR,"Missing Mediabunny API: $n\\n");exit(2);}}' "$TMP/mediabunny.mjs" || die 'The downloaded bundle is missing required demux/decode/convert APIs.'
cp "$TMP/mediabunny.mjs" "$BUNDLE.tmp"
chmod 644 "$BUNDLE.tmp"
mv -f "$BUNDLE.tmp" "$BUNDLE"
if [[ -s "$PACKAGE_ROOT/LICENSE" ]]; then cp "$PACKAGE_ROOT/LICENSE" "$VENDOR_DIR/LICENSE-MEDIABUNNY.txt"; fi
printf '%s\n' "$VERSION" > "$VERSION_FILE.tmp"
mv -f "$VERSION_FILE.tmp" "$VERSION_FILE"

# Official @mediabunny/prores extension (TurboRes WASM decoder) enables browser-side
# decode of Apple ProRes MOV, which standard WebCodecs implementations do not expose.
PRORES_META_URL="https://registry.npmjs.org/%40mediabunny%2Fprores/${VERSION}"
curl --fail --location --retry 3 --connect-timeout 20 --max-time 120 "$PRORES_META_URL" -o "$TMP/prores-metadata.json"
PRORES_EXPECTED="$(php -r '$j=json_decode(file_get_contents($argv[1]),true); foreach(preg_split("/\\s+/",$j["dist"]["integrity"]??"") as $s){if(str_starts_with($s,"sha512-")){echo $s;exit;}}' "$TMP/prores-metadata.json")"
[[ "$PRORES_EXPECTED" =~ ^sha512-[A-Za-z0-9+/=]+$ ]] || die 'npm did not provide a SHA-512 integrity for @mediabunny/prores.'
PRORES_TARBALL="$(php -r '$j=json_decode(file_get_contents($argv[1]),true); echo $j["dist"]["tarball"]??"";' "$TMP/prores-metadata.json")"
[[ "$PRORES_TARBALL" == https://registry.npmjs.org/* ]] || die 'Unexpected ProRes package tarball URL.'
curl --fail --location --retry 4 --connect-timeout 20 --max-time 300 "$PRORES_TARBALL" -o "$TMP/prores.tgz"
PRORES_ACTUAL="$(php -r 'echo "sha512-".base64_encode(hash_file("sha512",$argv[1],true));' "$TMP/prores.tgz")"
[[ "$PRORES_ACTUAL" == "$PRORES_EXPECTED" ]] || die 'ProRes package SHA-512 integrity verification failed.'
mkdir -p "$TMP/prores-package"
tar -xzf "$TMP/prores.tgz" -C "$TMP/prores-package"
PRORES_PACKAGE="$TMP/prores-package/package"
PRORES_SOURCE=''
for candidate in \
  "$PRORES_PACKAGE/dist/bundles/mediabunny-prores.mjs" \
  "$PRORES_PACKAGE/dist/mediabunny-prores.min.mjs"; do
  if [[ -s "$candidate" ]]; then PRORES_SOURCE="$candidate"; break; fi
done
if [[ -z "$PRORES_SOURCE" ]]; then PRORES_SOURCE="$(find "$PRORES_PACKAGE" -type f \( -name 'mediabunny-prores.mjs' -o -name 'mediabunny-prores.min.mjs' \) ! -name '*.d.ts' 2>/dev/null | head -n1 || true)"; fi
[[ -n "$PRORES_SOURCE" && -s "$PRORES_SOURCE" ]] || die 'No browser ProRes bundle found in @mediabunny/prores package.'
grep -q 'registerProresDecoder' "$PRORES_SOURCE" || die 'ProRes bundle does not expose registerProresDecoder().'
mkdir -p "$PRORES_DIR"
cp "$PRORES_SOURCE" "$PRORES_BUNDLE.tmp"
mv -f "$PRORES_BUNDLE.tmp" "$PRORES_BUNDLE"
if [[ -s "$PRORES_PACKAGE/LICENSE" ]]; then cp "$PRORES_PACKAGE/LICENSE" "$PRORES_DIR/LICENSE-MEDIABUNNY-PRORES.txt"; fi
printf '%s\n' "$VERSION" > "$PRORES_VERSION_FILE.tmp"
mv -f "$PRORES_VERSION_FILE.tmp" "$PRORES_VERSION_FILE"
chmod 755 "$VENDOR_DIR" "$PRORES_DIR"
chmod 644 "$BUNDLE" "$VERSION_FILE" "$PRORES_BUNDLE" "$PRORES_VERSION_FILE"
printf 'Mediabunny %s installed (%s bytes).\n' "$VERSION" "$(wc -c < "$BUNDLE" | tr -d ' ')"
printf 'ProRes decoder ESM %s installed (%s bytes; SHA-512 verified).\n' "$VERSION" "$(wc -c < "$PRORES_BUNDLE" | tr -d ' ')"
printf '%s\n' 'Mediabunny + TurboRes ProRes ESM assets are same-origin. Without cross-origin isolation the upstream decoder uses its slower fallback path.'
