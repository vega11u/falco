# v9 — Biomechanics Optimizer release

- Adds a post-analysis “Оптимизировать!” panel with style context (Shotokan, Shito-ryu, Goju-ryu, Uechi-ryu), optimization emphasis and full-video/range scope.
- Produces bounded athlete-specific kinematic candidate tracks while preserving event labels, order and anchored endpoints.
- Exports optimized pose trajectories as JSON and a WebM guide containing the original footage plus synchronized optimized skeleton overlay.
- Adds a curated karate technique vocabulary JSON for stance/strike/kick/block labels. This is a recognition vocabulary, not a style-specific pose target dataset.
- Adds methodological documentation and references, explicitly distinguishing kinematic proxies from EMG, force plates and musculoskeletal optimal control.
- One-command installer: `bash setup-release.sh`.

This release does not claim a validated biomechanical optimum or photorealistic video retargeting. It provides an auditable coaching candidate. Multi-view capture and musculoskeletal optimal control remain a later research-grade stage.
