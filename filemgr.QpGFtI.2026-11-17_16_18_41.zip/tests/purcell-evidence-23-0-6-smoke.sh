#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
php -l index.php >/dev/null
php -l purcell-evidence.php >/dev/null
php -l models.php >/dev/null
python3 -m py_compile research/build_evidence_index.py
php -r 'require "purcell-evidence.php"; $r=fj_evidence_search(["patterns"=>[["id"=>"test","kind"=>"stance","label"=>"санчин","observations"=>"пятка опора колено таз"]]],"data/trained/purcell-evidence-index.json"); if(!($r["ok"]??false)||!count($r["results"][0]["matches"]??[])){fwrite(STDERR,"retrieval FAIL\n");exit(1);} echo "Purcell evidence retrieval: PASS\n";'
node tests/purcell-core-smoke.mjs
node tests/purcell-baseline-smoke.mjs
