import assert from 'node:assert/strict';
import {fitMonteverdiThreshold} from '../monteverdi-kime-learning.mjs';
const rows=[];for(let i=0;i<40;i++){const spread=i<20?80+i*3:210+(i-20)*4;const pred=spread<=180?'yes':'no',actual=i<20?'yes':'no';rows.push({spread_ms:spread,prediction:pred,choice:pred===actual?'yes':'no',event_id:'e'+i,source_report:'r'+i,time_s:i});}
const result=fitMonteverdiThreshold(rows);assert.equal(result.reviewed,40);assert.equal(result.active,true);assert.ok(result.threshold_ms>=60&&result.threshold_ms<=340);
const insufficient=fitMonteverdiThreshold(rows.slice(0,4));assert.equal(insufficient.active,false);assert.equal(insufficient.threshold_ms,180);
console.log('PASS Monteverdi calibration holdout, balanced labels, safe fallback');
