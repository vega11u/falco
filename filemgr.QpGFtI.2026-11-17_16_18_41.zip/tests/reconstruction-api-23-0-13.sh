#!/usr/bin/env bash
set -Eeuo pipefail
SITE="$(CDPATH= cd -- "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
TMP="$(mktemp -d /tmp/falco-recon-http-XXXXXX)"
PORT=18463
cleanup(){ [[ -n "${SERVER_PID:-}" ]] && kill "$SERVER_PID" 2>/dev/null || true; rm -rf "$TMP"; }
trap cleanup EXIT
mkdir -p "$TMP/learning/purcell"
export TEST_LEARNING_ROOT="$TMP/learning"
python - <<'PY'
import os,json,struct,base64,pathlib
root=pathlib.Path(os.environ['TEST_LEARNING_ROOT']);vec=[.01]*384
b=base64.b64encode(struct.pack('<384H',*(round((v+8)/16*65535) for v in vec))).decode('ascii')
old={'id':'legacy-original','source_session':'legacy-session-1','unit_name':'Sanchin','unit_type':'kata','style':'shotokan','kind':'stance','label':'old_stance','confirmed':True,'feature_version':'pose-window-v4-dtw-angle','feature_count':384,'features_q16':b,'start_s':0,'end_s':1}
(root/'library.json').write_text(json.dumps({'version':3,'examples':[old],'feedback':[]},ensure_ascii=False))
old_p={'id':'old-purcell','label':'legacy example','kind':'movement','style':'unspecified','rating':4,'features_q16':b,'feature_count':384,'source_session':'purcell-old','start_s':0,'end_s':1}
(root/'purcell/library.json').write_text(json.dumps({'version':1,'examples':[old_p],'feedback':[]},ensure_ascii=False))
PY
KATA_LEARNING_DIR="$TMP/learning" php -S "127.0.0.1:$PORT" -t "$SITE" >"$TMP/http.log" 2>&1 &
SERVER_PID=$!
for _ in $(seq 1 25); do if curl -fsS "http://127.0.0.1:$PORT/index.php?api=reconstruction-memory-status" >/dev/null 2>&1; then break; fi; sleep 0.12; done
export TEST_PORT="$PORT"
python - <<'PY'
import json,os,urllib.request,pathlib,math
port=os.environ['TEST_PORT'];url=f'http://127.0.0.1:{port}/index.php?api=';root=pathlib.Path(os.environ['TEST_LEARNING_ROOT'])
def api(route,data=None):
 req=urllib.request.Request(url+route,data=json.dumps(data,ensure_ascii=False).encode() if data is not None else None,headers={'Content-Type':'application/json'} if data is not None else {},method='POST' if data is not None else 'GET')
 try:
  with urllib.request.urlopen(req,timeout=25) as r:return json.load(r)
 except urllib.error.HTTPError as e:raise RuntimeError(f'{route} {e.code}: {e.read().decode()[:700]}')
first=api('reconstruction-memory-status');assert first['lully']['legacy_only']==1 and first['purcell']['legacy_only']==1,first
sample={'kind':'stance','label':'new_stance','style':'shotokan','confirmed':True,'feature_version':'pose-window-v4-dtw-angle','features':[.20]*384,'features_2d':[.3]*384,'features_3d':[.4]*384,'reconstruction_quality':{'2d':.92,'3d':.75},'reconstruction_clip_2d':[.22]*1056,'reconstruction_clip_3d':[.18]*1056,'start_s':1.0,'end_s':2.0,'source_name':'video.mp4'}
body={'unit_name':'Sanchin','unit_type':'kata','style':'shotokan','source_session':'qa-session-1234','examples':[sample]}
learn=api('learn',body);assert learn['ok'],learn
pc={'label':'new-space','kind':'movement','style':'unspecified','rating':4,'features':[.2]*384,'features_2d':[.3]*384,'features_3d':[.4]*384,'reconstruction_quality':{'2d':.91,'3d':.78},'reconstruction_clip_2d':[.22]*1056,'reconstruction_clip_3d':[.18]*1056,'source_session':'qa-session-1234','start_s':1,'end_s':2}
pur=api('purcell-save',pc);assert pur['ok'],pur
second=api('reconstruction-memory-status');assert second['lully']['legacy_only']==1 and second['lully']['reconstructed_3d']==1,second
assert second['purcell']['legacy_only']==1 and second['purcell']['reconstructed_3d']==1,second
assert second['lully']['reconstructed_clips_3d']==1 and second['purcell']['reconstructed_clips_2d']==1,second
library=api('library');rows=library['examples'];assert len(rows)==2 and next(x for x in rows if x['id']=='legacy-original')['features_q16'],library
assert any(x.get('features_3d_q16') for x in rows),rows
assert all('reconstruction_clip_3d_q16' not in x for x in rows),'Full clips must not be serialized back over API' 
purLibrary=api('purcell-library');assert len(purLibrary['examples'])==2 and any(x.get('features_3d_q16') for x in purLibrary['examples'])
# Older clients can update the same example without stripping its optional reconstruction features.
api('learn',{**body,'examples':[{k:v for k,v in sample.items() if k not in ('features_2d','features_3d','reconstruction_clip_2d','reconstruction_clip_3d','reconstruction_quality')}]})
api('purcell-save',{k:v for k,v in pc.items() if k not in ('features_2d','features_3d','reconstruction_clip_2d','reconstruction_clip_3d','reconstruction_quality')})
l=json.loads((root/'library.json').read_text());p=json.loads((root/'purcell/library.json').read_text())
assert any(x.get('features_3d_q16') for x in l['examples']);assert any(x.get('features_3d_q16') for x in p['examples'])
assert any(x.get('reconstruction_clip_3d_q16') for x in l['examples']);assert any(x.get('reconstruction_clip_3d_q16') for x in p['examples'])
assert next(x for x in l['examples'] if x['id']=='legacy-original')['features_q16']
assert next(x for x in p['examples'] if x['id']=='old-purcell')['features_q16']
print('PASS live PHP endpoints: Lully/Purcell legacy+new reconstructed optional Q16 features, independent 3D, optional full-motion clips, old-client rewrite retains extras, original labels and Q16 intact')
PY
