#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
source "$ROOT/tests/js-runtime.sh"

if ! js_runtime_detect "$ROOT"; then
  LEGACY='not installed'
  if command -v node >/dev/null 2>&1; then LEGACY="$(node --version 2>/dev/null || echo unknown)"; fi
  echo "ERROR: no compatible JavaScript test runtime. The host has ${LEGACY}; developer syntax tests require Node >=22. This is not an application or installer dependency." >&2
  echo 'The production installer does not execute this developer-only test and does not use system Node.' >&2
  exit 2
fi
js_runtime_report
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

php -r '
$s=file_get_contents($argv[1]);
if (!preg_match("~<script type=\\\"module\\\">(.*?)</script>~s", $s, $m)) { fwrite(STDERR,"Main JS module not found.\n"); exit(2); }
$js=preg_replace("~<\\?php.*?\\?>~s", "({})", $m[1]);
file_put_contents($argv[2], $js);
' "$ROOT/index.php" "$TMP/index.mjs"

# Node --check parses source without executing browser ESM imports.
js_runtime_check \
  "$TMP/index.mjs" \
  "$ROOT/pose-worker.js" \
  "$ROOT/biomechanics-core.mjs" \
  "$ROOT/kata-recognition-core.mjs" \
  "$ROOT/device-profile.mjs" \
  "$ROOT/technique-planner.mjs" \
  "$ROOT/purcell-core.mjs" \
  "$ROOT/player-zoom-core.mjs" \
  "$ROOT/scene-perspective-core.mjs" \
  "$ROOT/avatar-render-core.mjs" \
  "$ROOT/depth-reconstruction-core.mjs" \
  "$ROOT/depth-worker.js" \
  "$ROOT/device-benchmark-worker.js" \
  "$ROOT/trajectory-intelligence.mjs" \
  "$ROOT/depth-map-core.mjs" \
  "$ROOT/player-trim-core.mjs"

# These are real logic tests, not just parser checks. In particular the
# biomechanics test covers the historical footLift ReferenceError regression.
js_runtime_run "$ROOT/tests/device-profile-smoke.mjs"
js_runtime_run "$ROOT/tests/biomechanics-core-smoke.mjs"
js_runtime_run "$ROOT/tests/technique-planner-smoke.mjs"
js_runtime_run "$ROOT/tests/player-zoom-core-smoke.mjs"
js_runtime_run "$ROOT/tests/purcell-core-smoke.mjs"
js_runtime_run "$ROOT/tests/scene-perspective-core-smoke.mjs"
js_runtime_run "$ROOT/tests/avatar-render-core-smoke.mjs"
js_runtime_run "$ROOT/tests/depth-reconstruction-smoke.mjs"
js_runtime_run "$ROOT/tests/kata-recognition-core-smoke.mjs"
js_runtime_run "$ROOT/tests/report-render-regression-smoke.mjs"
js_runtime_run "$ROOT/tests/trajectory-intelligence-smoke.mjs"
js_runtime_run "$ROOT/tests/player-trim-core-smoke.mjs"
echo 'JavaScript syntax + device profile + biomechanics + avatar + monocular-depth fusion + recognition + report-render smoke tests: PASS.'
