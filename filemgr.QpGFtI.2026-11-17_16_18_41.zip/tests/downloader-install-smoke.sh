#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
PROJECT_HASH="$(printf '%s' "$ROOT" | sha256sum | awk '{print substr($1,1,12)}')"
MEDIA_DIR="${KATA_MEDIA_IMPORT_DIR:-$(dirname "$ROOT")/.kata-media-import-${PROJECT_HASH}}"
YT="$MEDIA_DIR/bin/yt-dlp"
QJS="$MEDIA_DIR/bin/qjs"
fail(){ echo "FAIL: $*" >&2; exit 1; }
[[ -x "$YT" ]] || fail "yt-dlp executable is missing: $YT"
[[ -x "$QJS" ]] || fail "QuickJS-NG executable is missing: $QJS"
[[ -s "$MEDIA_DIR/bin/yt-dlp-stable-version.txt" ]] || fail 'yt-dlp version stamp is missing.'
[[ -s "$MEDIA_DIR/bin/yt-dlp-sha256.txt" ]] || fail 'yt-dlp SHA-256 stamp is missing.'
[[ -s "$MEDIA_DIR/bin/qjs-version.txt" ]] || fail 'QuickJS-NG version stamp is missing.'
[[ -s "$MEDIA_DIR/bin/qjs-runtime-ok.txt" && -s "$MEDIA_DIR/bin/qjs-sha256.txt" ]] || fail 'QuickJS-NG execution-proof or SHA-256 stamp is missing.'
YT_STAMP="$(tr -d '\r\n' < "$MEDIA_DIR/bin/yt-dlp-stable-version.txt")"
QJS_STAMP="$(tr -d '\r\n' < "$MEDIA_DIR/bin/qjs-version.txt")"
QJS_PROOF="$(tr -d '\r\n' < "$MEDIA_DIR/bin/qjs-runtime-ok.txt")"
QJS_HASH_STAMP="$(tr -d '\r\n' < "$MEDIA_DIR/bin/qjs-sha256.txt")"
QJS_HASH_ACTUAL="$(sha256sum "$QJS" | awk '{print $1}')"
YT_ACTUAL="$("$YT" --version 2>&1 | tail -n1)" || fail 'yt-dlp executable did not start.'
YT_HASH_STAMP="$(tr -d '\r\n' < "$MEDIA_DIR/bin/yt-dlp-sha256.txt")"
YT_HASH_ACTUAL="$(sha256sum "$YT" | awk '{print $1}')"
QJS_ACTUAL="$("$QJS" --version 2>&1 | tail -n1 | tr -d '\r')" || fail 'QuickJS-NG executable did not start.'
[[ "$YT_ACTUAL" == "$YT_STAMP" && "$YT_ACTUAL" =~ ^20[0-9]{2}\.[0-9]{2}\.[0-9]{2}$ ]] || fail "yt-dlp version mismatch (stamp=$YT_STAMP binary=$YT_ACTUAL)."
[[ "$YT_HASH_STAMP" =~ ^[a-fA-F0-9]{64}$ && "$YT_HASH_STAMP" == "$YT_HASH_ACTUAL" ]] || fail 'yt-dlp binary SHA-256 does not match its stamp.'
[[ "$QJS_ACTUAL" == "$QJS_STAMP" && "$QJS_ACTUAL" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || fail "QuickJS-NG version mismatch (stamp=$QJS_STAMP binary=$QJS_ACTUAL)."
[[ "$QJS_HASH_STAMP" =~ ^[a-fA-F0-9]{64}$ && "$QJS_HASH_STAMP" == "$QJS_HASH_ACTUAL" ]] || fail 'QuickJS-NG binary SHA-256 does not match its stamp.'
[[ "$QJS_PROOF" == "quickjs-ng:$QJS_ACTUAL:$QJS_HASH_ACTUAL" ]] || fail 'QuickJS-NG runtime proof does not match the installed binary and version.'
HELP="$("$YT" --help 2>&1)" || fail 'yt-dlp --help failed.'
for option in --js-runtimes --progress-template --fragment-retries --extractor-args; do
  grep -Fq -- "$option" <<<"$HELP" || fail "yt-dlp is missing required option $option."
done
EXTRACTORS="$("$YT" --list-extractors 2>&1)" || fail 'yt-dlp --list-extractors failed.'
grep -Fxq 'Youtube' <<<"$EXTRACTORS" || grep -Fxq 'youtube' <<<"$EXTRACTORS" || fail 'yt-dlp YouTube extractor is missing.'
grep -Fxq 'Instagram' <<<"$EXTRACTORS" || grep -Fxq 'instagram' <<<"$EXTRACTORS" || fail 'yt-dlp Instagram extractor is missing.'
# Prove the installed QuickJS-NG can execute JavaScript; a --version string alone is insufficient.
"$QJS" -e 'if (1 + 1 !== 2) throw new Error("runtime failure")' >/dev/null 2>&1 || fail 'QuickJS-NG could not execute a local JavaScript expression.'
# Ensure production setup never invokes the system Node executable or Node test parser.
if grep -E '(^|[;&|[:space:]])node([[:space:]]|$)' "$ROOT/setup-regru.sh" "$ROOT/setup-release.sh" "$ROOT/setup-media-import.sh" || grep -E 'bash[[:space:]]+[^-].*tests/(javascript-syntax-smoke|optimizer-smoke)\.sh' "$ROOT/setup-regru.sh" "$ROOT/setup-release.sh" "$ROOT/setup-media-import.sh"; then
  fail 'Production installer still invokes Node or developer-only JavaScript parser tests.'
fi
printf 'Downloader installation smoke passed: yt-dlp %s, QuickJS-NG %s (execution + SHA-256 verified), YouTube + Instagram extractors, EJS CLI support, no V8/Deno/system Node dependency.\n' "$YT_ACTUAL" "$QJS_ACTUAL"
