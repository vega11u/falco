#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
source "$ROOT/tests/js-runtime.sh"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
php -l "$ROOT/index.php" >/dev/null
php -r '
$root=$argv[1]; $_GET=[]; $_SERVER["DOCUMENT_ROOT"]=$root; ob_start(); require $root."/index.php"; $page=ob_get_clean();
if(!preg_match("~<script\\s+type=\"module\"\\s*>(.*?)</script>~is",$page,$m)) {fwrite(STDERR,"embedded JavaScript module missing\n");exit(1);}
foreach(["id=\"optimizeBtn\"","async function buildOptimizedMotion()","async function runPurcellOptimizer()","buildPurcellDecisionLayer","applyPurcellRecommendations","optimizeKinematicTrajectory(","poseQualityPanel","constrained-dtw-posture-motion-v6-foot-aware","timestamps_unchanged:true","detected_support_foot_joints_anchored:true","optimizerPlayerTick(","function renderOptimizerPlayerFrame(","patternEvidenceDetails(","leftHeelInferred","optimizer-score-grid","installSynchronizedVideoZoom","playerZoom","installPlayerMetricSeekHandler","data-optimizer-moment","renderOptimizerMomentSnapshots","rethinkMovementPatterns","draftLabel","loadAnatomyFunctionalModel","biomech-knowledge","biomechanics_phase_anchors_preserved:true","biomechanicsAnchorTimes","phasePeakTimes","buildBiomechanicalSequencePlan"] as $needle) if(!str_contains($page,$needle)) {fwrite(STDERR,"missing optimizer/quality contract: {$needle}\n");exit(1);}
if(!preg_match("~async function runPurcellOptimizer\\(\\)(.*?)\\nfunction optimizerNearestFrameIndex~s",$m[1],$run)||str_contains($run[1],"optimizeKinematicTrajectory(")||!str_contains($run[1],"noise_smoothing:false")) {fwrite(STDERR,"Purcell must only produce evidence-gated local avatar proposals, not smooth numeric tracks\\n");exit(1);}
file_put_contents($argv[2],$m[1]); echo "Optimizer UI / biomechanical constraints smoke test: PASS\n";
' "$ROOT" "$TMP/app.mjs"

if ! js_runtime_detect "$ROOT"; then
  LEGACY='not installed'; if command -v node >/dev/null 2>&1; then LEGACY="$(node --version 2>/dev/null || echo unknown)"; fi
  echo "ERROR: developer optimizer checks require Node >=22; found ${LEGACY}. This is not a production runtime dependency." >&2
  exit 2
fi
js_runtime_report
js_runtime_check "$TMP/app.mjs" "$ROOT/biomechanics-core.mjs" "$ROOT/pose-worker.js" "$ROOT/player-zoom-core.mjs" "$ROOT/technique-planner.mjs" "$ROOT/purcell-core.mjs"
js_runtime_run "$ROOT/tests/biomechanics-core-smoke.mjs"
js_runtime_run "$ROOT/tests/player-zoom-core-smoke.mjs"
echo 'JavaScript syntax and biomechanics core tests: PASS.'
