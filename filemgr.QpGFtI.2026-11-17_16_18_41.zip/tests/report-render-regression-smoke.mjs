import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { temporalSignatureDistance, poseVectorAtTime } from '../kata-recognition-core.mjs';

const source = readFileSync(new URL('../index.php', import.meta.url), 'utf8');
// 23.0.27 removed an obsolete local foot-volume path. Preserve observed-foot gates.
assert.match(source, /const inferredHeel=.*stable&&!q\.heelVisible&&q\.toeVisible&&q\.ankleVisible/);
assert.match(source, /track\.push\(\{side:current,leftScore:l,rightScore:r,confidence:/,
  'support track must retain numeric left/right support scores');
assert.match(source, /stable&&!q\.heelVisible&&q\.toeVisible&&q\.ankleVisible[\s\S]*q\.plantarContact[\s\S]*>=\.68/, 'an occluded heel may be inferred only from stable forefoot/ankle and plantar evidence');
assert.match(source, /stable&&q\.heelVisible&&q\.toeVisible[\s\S]*>=\.58/, 'a fully supported foot requires a directly observed heel and toe');
assert.match(source, /[Vv]isible raised heel is never overridden/, 'a visible raised heel must not be flattened by inference');
assert.match(source, /buildAvatarRootReferences\(frames,state\.videoAspect\)/, '3D renderer must restore camera-relative pelvis translation across frames');
assert.match(source, /rootShift=clamp\(dx,-rootRef\.maxShift,rootRef\.maxShift\)/, '3D root translation must be robustly bounded');
assert.doesNotMatch(source, /Обновлять 3D во время воспроизведения/, 'Purcell must not restore the global optimizer playback dock');
assert.match(source, /data-biomech-replay/ , 'Purcell findings must expose card-scoped replay controls');
assert.match(source, /data-duration="\$\{inferredReplayDuration\}"/, 'each finding replay must carry its bounded duration');
assert.match(source, /id="player3dPlayback" type="checkbox"/, 'main 3D playback must have an explicit disabled-by-default toggle');
assert.ok(source.includes('Что модель сочла похожим') && source.includes("label:'Пятки и носки'"), 'pattern evidence must explain concrete body regions including heel/toe');
assert.match(source, /leftVisibility:feet\[i\]\.left\.visibility/,
  'support metadata must read visibility from the per-foot records');
assert.match(source, /const footAxisL=heelL&&toeL\?line2\(heelL,toeL\)/,
  'foot axis must be measured heel-to-forefoot, not ankle-to-toe');
assert.match(source, /const ankleFlexL=angleBetween2\(kl,al,heelL\|\|toeL\)/,
  'ankle angle must use knee-ankle-heel geometry');
assert.match(source, /id="currentPanel"[\s\S]*id="currentMetrics"/,
  'the current-frame numeric panel must be present in the player dock source');
assert.match(source, /function updateCurrentPanel\(presentedMediaTime=null\)/,
  'current-frame metrics must update from the presented media time');
assert.match(source, /data-kata-rating="technique"[\s\S]*data-kata-rating="power"[\s\S]*data-kata-rating="speed"[\s\S]*data-kata-rating="balance"/,
  'subjective rating UI must retain the named feedback dimensions');

const base = Array.from({length:33},()=>[0,0,0,1]);
for (const [id,p] of Object.entries({11:[-.2,-.3,0],12:[.2,-.3,0],13:[-.3,-.1,0],14:[.3,-.1,0],15:[-.4,0,0],16:[.4,0,0],23:[-.1,0,0],24:[.1,0,0],25:[-.1,.3,0],26:[.1,.3,0],27:[-.1,.6,0],28:[.1,.6,0],29:[-.13,.62,0],30:[.13,.62,0],31:[-.2,.63,0],32:[.2,.63,0]})) base[+id]=[...p,.95];
const a={t:0,w:base,im:base.map(p=>p.slice()),background:{wall:[0,0,1],floor:[99,99,99]}};
const b={...a,background:{wall:[-100,900,1],floor:[-800,300,0]},w:base.map(p=>p.slice()),im:base.map(p=>p.slice())};
const va=poseVectorAtTime([a],0),vb=poseVectorAtTime([b],0);
assert.ok(va&&vb&&temporalSignatureDistance(va,vb)<1e-9,
  'pattern signatures must be invariant to arbitrary background/room metadata');
console.log('Report rendering, foot geometry, current metrics, rating UI and pose-only pattern smoke tests: PASS');
