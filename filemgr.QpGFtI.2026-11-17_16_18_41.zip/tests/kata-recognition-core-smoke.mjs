import assert from 'node:assert/strict';
import { POSE_FRAME_DIM, poseVectorAtTime, temporalSignatureDistance, temporalSignatureSimilarity, mirrorSignature } from '../kata-recognition-core.mjs';

function frame(t,phase=0){
  const im=Array.from({length:33},()=>[NaN,NaN,NaN,0]),w=Array.from({length:33},()=>[NaN,NaN,NaN,0]);
  const pts={11:[-.12,-.25,0],12:[.12,-.25,0],13:[-.24,-.10,.02],14:[.24,-.10,-.02],15:[-.30+.05*Math.sin(phase)+.04*phase/Math.PI,.05,.02],16:[.30-.05*Math.sin(phase)-.04*phase/Math.PI,.05,-.02],23:[-.08,0,0],24:[.08,0,0],25:[-.10,.30,.02],26:[.10,.30,-.02],27:[-.11,.62,.02],28:[.11,.62,-.02],29:[-.12,.65,.02],30:[.12,.65,-.02],31:[-.13,.67,.02],32:[.13,.67,-.02]};
  for(const [id,p] of Object.entries(pts)){im[+id]=[.5+p[0],.4+p[1],p[2],.95];w[+id]=p.concat(.95);}
  return {t,im,w};
}
const frames=Array.from({length:12},(_,i)=>frame(i/30,i/11*Math.PI));
const occluded=frames.map(f=>({t:f.t,im:f.im.map(p=>p.slice()),w:f.w.map(p=>p.slice())}));
for(const id of [13,14,15,16,25,26,27,28])occluded[5].w[id]=[NaN,NaN,NaN,0];
const recovered=poseVectorAtTime(occluded,5/30);
assert(recovered&&recovered.length===48,'short occlusions must be interpolated for recognition features');
assert(poseVectorAtTime(occluded,5/30,{mirror:true})?.length===48,'mirror signature must preserve feature dimensions');
const partialWorld=frames.map(f=>({t:f.t,im:f.im.map(p=>p.slice()),w:f.w.map(p=>p.slice())}));
partialWorld[5].w[11]=[NaN,NaN,NaN,0];
assert.equal(poseVectorAtTime(partialWorld,5/30)?.length,48,'incomplete world anchors must fall back to image-space landmarks');
const tooLong=occluded.map(f=>({t:f.t,im:f.im,w:f.w}));
for(let i=2;i<=8;i++)for(const id of [13,14,15,16,25,26,27,28]){tooLong[i].w[id]=[NaN,NaN,NaN,0];tooLong[i].im[id]=[NaN,NaN,NaN,0];}
assert.equal(poseVectorAtTime(tooLong,5/30),null,'long occlusion must not be hallucinated');
const a=frames.map((f,i)=>poseVectorAtTime(frames,f.t)).filter(Boolean).flat();
const reversed=frames.slice().reverse().map(f=>poseVectorAtTime(frames,f.t)).filter(Boolean).flat();
assert.equal(temporalSignatureSimilarity(a,a).similarity,100);
assert(temporalSignatureDistance(a,reversed)>temporalSignatureDistance(a,a),'temporal direction should affect matching');
assert.equal(mirrorSignature(a).length,a.length);
const raisedHeel=frames.map(f=>({t:f.t,im:f.im.map(p=>p.slice()),w:f.w.map(p=>p.slice())}));
for(const f of raisedHeel)for(const id of [29,30]){f.w[id][1]-=.13;f.im[id][1]-=.13;}
const flatFootSignature=frames.map(f=>poseVectorAtTime(frames,f.t)).filter(Boolean).flat();
const raisedHeelSignature=raisedHeel.map(f=>poseVectorAtTime(raisedHeel,f.t)).filter(Boolean).flat();
assert.equal(flatFootSignature.length,raisedHeelSignature.length,'foot-aware matcher must keep the persisted feature-vector dimension');
assert(temporalSignatureDistance(flatFootSignature,raisedHeelSignature)>.015,'raised heel geometry must affect temporal pattern similarity');
assert.equal(POSE_FRAME_DIM,48,'persisted per-frame feature schema must remain 48D');
console.log('Karate temporal recognition smoke tests: PASS (occlusion recovery, long-gap rejection, mirror handling, motion direction, heel/toe sensitivity, unchanged 48D schema).');
