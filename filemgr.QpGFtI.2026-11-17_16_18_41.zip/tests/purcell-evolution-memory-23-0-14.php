<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/purcell-evolution-memory.php';
$dir=sys_get_temp_dir().'/falco-evolve-'.bin2hex(random_bytes(5));mkdir($dir,0700,true);
try{
 $replicas=[];for($i=0;$i<4;$i++)$replicas[]=['coherence'=>89.6+$i,'overall'=>67.1+$i,'attempted'=>22,'accepted'=>3,'reached'=>false];
 $input=['action'=>'save','modality'=>'3d','source_candidate_id'=>'hyp-0031','source_run_id'=>'test-run','kata_name'=>'Bassai Dai','copies'=>4,'steps'=>55,'seed'=>42,'replicas'=>$replicas,'aggregate_qualified'=>false,'consolidated_genome'=>[],'result_score'=>['overall'=>70,'coherence'=>91]];
 $saved=fj_purcell_evolution_memory($dir,'POST',$input);if(empty($saved['ok'])||!empty($saved['aggregate_qualified']))throw new RuntimeException('Save rejected or mislabeled');
 $status=fj_purcell_evolution_memory($dir,'GET');if($status['count']!==1||$status['runs'][0]['modality']!=='3d'||$status['runs'][0]['consolidated_genome']!==[])throw new RuntimeException('Roundtrip failed');
 $input['replicas'][0]['reached']=true;$input['aggregate_qualified']=true;
 $didReject=false;try{fj_purcell_evolution_memory($dir,'POST',$input);}catch(InvalidArgumentException $e){$didReject=true;}
 if(!$didReject)throw new RuntimeException('Unqualified 100% attempt was accepted');
 echo "PASS private evolution history, previous memory intact, fake 100% qualification rejected\n";
}finally{foreach(glob($dir.'/*')?:[] as $file)@unlink($file);@rmdir($dir);}
