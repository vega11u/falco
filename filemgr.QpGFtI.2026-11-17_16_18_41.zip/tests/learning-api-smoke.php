<?php
declare(strict_types=1);
$root = dirname(__DIR__);
if (!function_exists('proc_open') || in_array('proc_open', array_map('trim', explode(',', (string)ini_get('disable_functions'))), true)) { echo "SKIP: proc_open is disabled in this PHP CLI; learning API was validated in the build environment.\n"; exit(0); }
$tmp = sys_get_temp_dir() . '/falco-learning-smoke-' . bin2hex(random_bytes(5));
mkdir($tmp, 0700, true);
$store = $tmp . '/store';
$media = $tmp . '/media';
putenv('KATA_LEARNING_DIR=' . $store);
putenv('KATA_MEDIA_IMPORT_DIR=' . $media);
$socket = stream_socket_server('tcp://127.0.0.1:0', $errno, $errstr);
if (!$socket) throw new RuntimeException("Cannot reserve test port: {$errstr}");
$address = stream_socket_get_name($socket, false);
fclose($socket);
$port = (int)substr(strrchr((string)$address, ':'), 1);
$base = "http://127.0.0.1:{$port}/index.php";
$log = $tmp . '/server.log';
$proc = proc_open([PHP_BINARY, '-S', "127.0.0.1:{$port}", '-t', $root, $root . '/index.php'], [0=>['pipe','r'], 1=>['file',$log,'a'], 2=>['file',$log,'a']], $pipes, $root);
if (!is_resource($proc)) throw new RuntimeException('Could not start PHP development server.');
fclose($pipes[0]);
$cookie = '';
$fail = static function (string $message) use ($log, $tmp): never { fwrite(STDERR, "FAIL: {$message}\n"); fwrite(STDERR, (string)@file_get_contents($log)); exit(1); };
// Keep cleanup simple and deterministic even on assertions.
register_shutdown_function(static function () use (&$proc, $tmp): void {
    if (is_resource($proc)) { proc_terminate($proc); proc_close($proc); }
    $remove = static function (string $path) use (&$remove): void {
        if (is_link($path) || is_file($path)) { @unlink($path); return; }
        if (!is_dir($path)) return;
        foreach (scandir($path) ?: [] as $name) if ($name !== '.' && $name !== '..') $remove($path . '/' . $name);
        @rmdir($path);
    };
    $remove($tmp);
});
function apiRequest(string $url, string $method = 'GET', ?array $payload = null, string $cookie = ''): array {
    $headers = ['Accept: application/json'];
    if ($cookie !== '') $headers[] = 'Cookie: ' . $cookie;
    if ($payload !== null) { $headers[] = 'Content-Type: application/json'; $headers[] = 'Origin: ' . parse_url($url, PHP_URL_SCHEME) . '://' . parse_url($url, PHP_URL_HOST) . (parse_url($url, PHP_URL_PORT) ? ':' . parse_url($url, PHP_URL_PORT) : ''); }
    $context = stream_context_create(['http'=>[
        'method'=>$method, 'header'=>implode("\r\n", $headers),
        'content'=>$payload === null ? '' : json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
        'ignore_errors'=>true, 'timeout'=>20,
    ]]);
    $body = @file_get_contents($url, false, $context);
    $headersOut = $http_response_header ?? [];
    $status = 0;
    foreach ($headersOut as $header) if (preg_match('~^HTTP/\S+\s+(\d+)~', $header, $m)) $status = (int)$m[1];
    $newCookie = $cookie;
    foreach ($headersOut as $header) if (stripos($header, 'Set-Cookie: PHPSESSID=') === 0) { $newCookie = explode(';', substr($header, 11), 2)[0]; break; }
    return ['status'=>$status, 'body'=>(string)$body, 'json'=>json_decode((string)$body, true), 'cookie'=>$newCookie];
}
$health = null;
for ($i=0; $i<50; $i++) {
    $health = apiRequest($base . '?api=health', 'GET', null, $cookie);
    if ($health['status'] === 200 && is_array($health['json'])) { $cookie = $health['cookie']; break; }
    usleep(100000);
}
if (!is_array($health['json'] ?? null) || empty($health['json']['ok']) || empty($health['json']['server_learning']) || empty($health['json']['numeric_data_exchange'])) throw new RuntimeException('Health API did not start or server-learning contract is missing: ' . ($health['body'] ?? ''));
$features = array_fill(0, 384, 0.0);
$learn = [
    'unit_name'=>'Sequence fragment A','kata_name'=>'Sequence fragment A','unit_type'=>'sequence','style'=>'shitoryu',
    'parent_kata'=>'Heian Shodan','source_session'=>'session_12345678','source_name'=>'test.webm','duration_s'=>3,
    'examples'=>[
        ['kind'=>'stance','label'=>'test stance','confirmed'=>true,'feature_version'=>'pose-window-v1','features'=>$features,'start_s'=>0.5,'end_s'=>1.2],
        ['kind'=>'hand_strike','label'=>'gyaku-zuki','confirmed'=>true,'feature_version'=>'pose-window-v1','features'=>array_fill(0,384,0.05),'start_s'=>0.5,'end_s'=>1.2],
        ['kind'=>'movement','label'=>'unconfirmed candidate','confirmed'=>false,'feature_version'=>'pose-window-v1','features'=>array_fill(0,384,0.1),'start_s'=>1.5,'end_s'=>2.2],
    ],
];
$write = apiRequest($base . '?api=learn', 'POST', $learn, $cookie); $cookie = $write['cookie'];
if ($write['status'] !== 200 || ($write['json']['stored'] ?? null) !== 2) throw new RuntimeException('Learning write/filter failed: ' . $write['body']);
$library = apiRequest($base . '?api=library', 'GET', null, $cookie);
if ($library['status'] !== 200 || ($library['json']['total_examples'] ?? null) !== 2 || ($library['json']['labelled_examples'] ?? null) !== 2) throw new RuntimeException('Personal library read failed: ' . $library['body']);
$modelStatus = apiRequest($base . '?api=model-status', 'GET', null, $cookie);
if ($modelStatus['status'] !== 200 || ($modelStatus['json']['training_examples'] ?? null) !== 2 || ($modelStatus['json']['class_count'] ?? null) !== 2) throw new RuntimeException('Server classifier did not learn confirmed numeric examples: ' . $modelStatus['body']);
$predict = apiRequest($base . '?api=model-predict', 'POST', ['items'=>[['id'=>'probe-1','kind'=>'stance','style'=>'shitoryu','unit_type'=>'sequence','feature_version'=>'pose-window-v1','features'=>$features]]], $cookie);
if ($predict['status'] !== 200 || ($predict['json']['results'][0]['matches'][0]['label'] ?? null) !== 'test stance') throw new RuntimeException('Server classifier prediction failed: ' . $predict['body']);

$correction = apiRequest($base . '?api=learn', 'POST', [
    'unit_name'=>'Sequence fragment A','unit_type'=>'sequence','style'=>'shitoryu','source_session'=>'session_12345678',
    'examples'=>[['kind'=>'stance','label'=>'zenkutsu-dachi','confirmed'=>true,'feature_version'=>'pose-window-v1','features'=>$features,'start_s'=>0.5,'end_s'=>1.2]],
], $cookie);
if ($correction['status'] !== 200 || ($correction['json']['total_examples'] ?? null) !== 2 || empty($correction['json']['server_model']['rebuilt'])) throw new RuntimeException('Relabelling an existing observation did not replace/rebuild the classifier: ' . $correction['body']);
$correctedPrediction = apiRequest($base . '?api=model-predict', 'POST', ['items'=>[['id'=>'probe-corrected','kind'=>'stance','style'=>'shitoryu','unit_type'=>'sequence','feature_version'=>'pose-window-v1','features'=>$features]]], $cookie);
if (($correctedPrediction['json']['results'][0]['matches'][0]['label'] ?? null) !== 'zenkutsu-dachi') throw new RuntimeException('Classifier retained a stale label after correction.');

$first = $library['json']['examples'][0];
if (($first['feature_count'] ?? null) !== 384 || isset($first['features']) || strlen(base64_decode($first['features_q16'] ?? '', true) ?: '') !== 768) throw new RuntimeException('Q16 encoding contract failed.');

$feedback = [
    'unit_name'=>'Heian Shodan','unit_type'=>'kata','style'=>'shotokan','source_session'=>'session_feedback_1',
    'source_name'=>'kata.webm','duration_s'=>12.5,'confirmed_identity'=>true,
    'scores'=>['technique'=>8,'biomechanics'=>4,'power'=>7,'speed'=>9,'balance'=>8],
    'patterns'=>[
        ['kind'=>'stance','label'=>'zenkutsu-dachi','decision'=>'confirmed','occurrences'=>3],
        ['kind'=>'movement','label'=>'false candidate','decision'=>'rejected','occurrences'=>1],
    ],
    'examples'=>[['features'=>array_fill(0,1152,0.0),'start_s'=>0,'end_s'=>12.5]],
];
$feedbackWrite = apiRequest($base . '?api=feedback', 'POST', $feedback, $cookie); $cookie = $feedbackWrite['cookie'];
if ($feedbackWrite['status'] !== 200 || ($feedbackWrite['json']['stored_examples'] ?? null) !== 1 || empty($feedbackWrite['json']['confirmed_identity'])) throw new RuntimeException('Full-kata feedback write failed: ' . $feedbackWrite['body']);
$library = apiRequest($base . '?api=library', 'GET', null, $cookie);
if (($library['json']['feedback_count'] ?? null) !== 1 || ($library['json']['total_examples'] ?? null) !== 3) throw new RuntimeException('Feedback and kata exemplar missing.');
$modelAfterKata = apiRequest($base . '?api=model-status', 'GET', null, $cookie);
if (($modelAfterKata['json']['training_examples'] ?? null) !== 3 || ($modelAfterKata['json']['class_count'] ?? null) !== 3) throw new RuntimeException('Confirmed full-kata sequence was not added to the server model.');
$kataPredict = apiRequest($base . '?api=model-predict', 'POST', ['items'=>[['id'=>'kata-probe','kind'=>'kata','style'=>'shotokan','unit_type'=>'kata','feature_version'=>'pose-window-v4-dtw-angle','features'=>array_fill(0,1152,0.0)]]], $cookie);
if (($kataPredict['json']['results'][0]['matches'][0]['label'] ?? null) !== 'Heian Shodan') throw new RuntimeException('Full-kata server classifier prediction failed: ' . $kataPredict['body']);

$row = $library['json']['feedback'][0] ?? [];
if (empty($row['ratings_are_subjective']) || !empty($row['affects_objective_biomechanics']) || empty($row['preference_score_excludes_biomechanics'])) throw new RuntimeException('Subjective ratings leaked into objective biomechanics.');

// Seed a large valid archive directly, then verify that the PHP API returns it without truncation.
$path = $store . '/library.json';
$data = json_decode((string)file_get_contents($path), true);
$packed = base64_encode(pack('v*', ...array_fill(0,384,32768)));
for ($i=0; $i<3002; $i++) {
    $data['examples'][] = ['id'=>'bulk_' . $i,'created_at'=>'2026-10-31T00:00:00Z','kata_name'=>'bulk kata','unit_name'=>'bulk kata','unit_type'=>'kata','style'=>'shotokan','source_session'=>sprintf('bulk_session_%06d',$i),'kind'=>'stance','label'=>'bulk stance','confirmed'=>true,'feature_version'=>'pose-window-v4-dtw-angle','feature_count'=>384,'features_q16'=>$packed,'source_name'=>'bulk_' . $i . '.webm','duration_s'=>10];
}
for ($i=0; $i<1001; $i++) {
    $data['feedback'][] = ['id'=>'bulk_feedback_' . $i,'unit_name'=>'bulk kata','unit_type'=>'kata','style'=>'shotokan','source_session'=>sprintf('bulk_feedback_session_%06d',$i),'scores'=>['technique'=>8,'biomechanics'=>2,'power'=>8,'speed'=>8,'balance'=>8],'patterns'=>[],'ratings_are_subjective'=>true,'affects_objective_biomechanics'=>false,'preference_score_excludes_biomechanics'=>true];
}
file_put_contents($path, json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
$bulk = apiRequest($base . '?api=library', 'GET', null, $cookie);
if (($bulk['json']['labelled_examples'] ?? null) !== 3005 || count($bulk['json']['examples'] ?? []) !== 3005 || ($bulk['json']['feedback_count'] ?? null) !== 1002 || count($bulk['json']['feedback'] ?? []) !== 1002) throw new RuntimeException('Large archive was truncated: ' . json_encode([$bulk['json']['labelled_examples'] ?? null, count($bulk['json']['examples'] ?? []), $bulk['json']['feedback_count'] ?? null, count($bulk['json']['feedback'] ?? [])]));
$bad = ['unit_name'=>'False full kata','unit_type'=>'kata','style'=>'shotokan','source_session'=>'session_bad_001','confirmed_identity'=>true,'scores'=>[],'examples'=>[['features'=>array_fill(0,24,0.0)]]];
$badWrite = apiRequest($base . '?api=feedback', 'POST', $bad, $cookie);
if ($badWrite['status'] !== 400 || !empty($badWrite['json']['ok'])) throw new RuntimeException('Truncated kata signature was not rejected.');
printf("Learning API smoke passed: Q16, confirmed-only pattern storage, subjective feedback isolation, full-kata validation, and complete 3,005-example / 1,002-feedback archive.\n");
