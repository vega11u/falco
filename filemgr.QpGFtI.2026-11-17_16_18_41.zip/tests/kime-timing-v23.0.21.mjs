import assert from 'node:assert/strict';
import {evaluateKimeEvents} from '../kime-analysis-core.mjs';
const frames=Array.from({length:30},(_,i)=>({t:i/30,im:Array.from({length:33},(_,j)=>[.5+j*.001,.5,0,.9]),w:[]}));
// Minimal synthetic trajectory: ensure empty/insufficient event sets are safe and never claim a hit.
const r=evaluateKimeEvents(frames,[{id:'x',type:'punch',start:2,end:20,fast:true}]);
assert.equal(r.schema,'kime-timing-v1');assert.equal(r.measured,0);assert.equal(r.overall_percent,null);
const slow=evaluateKimeEvents(frames,[{id:'slow',type:'punch',start:2,end:20,fast:false}]);assert.equal(slow.fast_events,0);
console.log('kime timing contract: ok');
