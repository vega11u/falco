#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
php -l "$ROOT/index.php" >/dev/null
php -l "$ROOT/uppurcell.php" >/dev/null
php -l "$ROOT/Memories.php" >/dev/null
php -r '
$r=$argv[1];$_GET=[];$_SERVER["DOCUMENT_ROOT"]=$r;ob_start();require $r."/index.php";$h=ob_get_clean();
foreach(["data-mode=","Обучение Purcell","Отчёты","serverStatusText","currentMetricLegend","Средняя согласованность движений","Обновить модель Lully","Повторный поиск паттернов","id=\"purcellTrainingPanel\"","data-purcell-good","data-purcell-problem","data-optimizer-vote=\"good\"","data-optimizer-vote=\"acceptable\"","data-optimizer-vote=\"wrong\"","reports-upload-begin","reports-upload-chunk","reports-upload-commit","CompressionStream","purcell-core.mjs?v=26.2.0","metric-guide-details","analysis-settings"] as $x)if(!str_contains($h,$x)){fwrite(STDERR,"Missing v22 interface/API contract: $x\n");exit(1);}
$i=file_get_contents($r."/index.php");$css=file_get_contents($r."/falco-jugger-ui.css");
foreach(["body[data-mode=\"analyzer\"] #resultsSection:not(.hidden)","body[data-mode=\"purcell\"] #resultsSection"] as $x)if(!str_contains($css,$x)){fwrite(STDERR,"Missing mode display rule: $x\n");exit(1);}
if(!str_contains($i,"window.setInterval(async()=>")||!str_contains($i,"gzread(\$gz, 1048576)")||!str_contains($i,"DIRECTORY_SEPARATOR . '\''purcell'\''")){fwrite(STDERR,"Missing server heartbeat / streaming archive / private Purcell store.\n");exit(1);}
echo "v22 UI and server architecture contracts: PASS\n";
' "$ROOT"
node --check "$ROOT/purcell-core.mjs" >/dev/null
bash "$ROOT/tests/purcell-and-report-api-smoke.sh"
