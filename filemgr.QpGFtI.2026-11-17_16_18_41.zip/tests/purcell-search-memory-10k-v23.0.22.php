<?php
declare(strict_types=1);
require_once __DIR__.'/../purcell-search-memory.php';
$dir=sys_get_temp_dir().'/fj-purcell-10k-'.bin2hex(random_bytes(4));mkdir($dir,0700,true);
try{
 $cases=[];foreach([1,10000] as $n)$cases[]=['id'=>'hyp-'.str_pad((string)$n,5,'0',STR_PAD_LEFT),'family'=>'left_arm:arc_up','score'=>75,'passed'=>true,'objective_scores'=>['economy'=>70,'speed'=>80,'coherence'=>75],'personalized_surface_score'=>92.5,'personalized_surface_fit'=>['available'=>true,'passed'=>true,'space'=>'3d','mean_log_drift'=>.04,'p90_log_drift'=>.08,'observations'=>18,'segments'=>['torso','left_arm_upper']]];
 $saved=fj_purcell_search_memory($dir,'POST',['action'=>'save_run','schema'=>'purcell-wide-search-v3-10000','modality'=>'2d','total_evaluated'=>10000,'passed_total'=>8700,'candidates'=>$cases]);
 if(($saved['stored']??0)!==2)throw new RuntimeException('10k top archive was not stored');
 $runs=fj_purcell_search_memory($dir,'GET');$run=$runs['runs'][0]??null;
 if(($run['total_evaluated']??0)!==10000||($run['passed_total']??0)!==8700)throw new RuntimeException('Population metadata was not preserved');
 if(($run['candidates'][1]['personalized_surface_score']??null)!==92.5||($run['candidates'][1]['personalized_surface_fit']['space']??null)!=='3d')throw new RuntimeException('Personalized body-fit evidence was not preserved in the evolution memory');
 $sel=fj_purcell_search_memory($dir,'POST',['action'=>'select','run_id'=>$saved['run_id'],'candidate_id'=>'hyp-10000']);
 if(($sel['selected_candidate']??'')!=='hyp-10000')throw new RuntimeException('Five-digit candidate selection failed');
 echo "PASS: server memory stores 10k-search top archive and five-digit IDs\n";
}finally{foreach(glob($dir.'/*')?:[] as $f)@unlink($f);@rmdir($dir);}
