#!/usr/bin/env bash
# Synthetic offline integration: only independent Lux is installed, web proc_open is disabled.
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
command -v php >/dev/null && command -v curl >/dev/null && command -v sha256sum >/dev/null || { echo 'Lux test skipped (missing PHP/curl/sha256sum)'; exit 0; }
TMP="$(mktemp -d)"; PID=''
cleanup(){ [[ -z "$PID" ]] || { kill "$PID" 2>/dev/null || true; wait "$PID" 2>/dev/null || true; }; rm -rf "$TMP"; }
trap cleanup EXIT
PORT="$(php -r '$s=stream_socket_server("tcp://127.0.0.1:0",$e,$m);$a=stream_socket_get_name($s,false);echo (int)substr(strrchr($a,":"),1);fclose($s);')"
MEDIA="$TMP/.kata-private"; mkdir -p "$MEDIA/bin"
cat > "$MEDIA/bin/lux" <<'LUX'
#!/usr/bin/env bash
set -Eeuo pipefail
[[ "${1:-}" != '-v' ]] || { printf 'lux 0.24.1\n'; exit 0; }
out=''; prefix='video'; link=''
while (($#)); do
 case "$1" in
   -o) out="$2"; shift 2;;
   -O) prefix="$2"; shift 2;;
   -retry|-n) shift 2;;
   https://*) link="$1"; shift;;
   *) shift;;
 esac
done
[[ -n "$out" && -n "$link" && "$prefix" == 'video' ]] || exit 19
mkdir -p "$out"
printf '\000\000\000\030ftypisom' > "$out/$prefix.mp4"
dd if=/dev/zero bs=4084 count=1 status=none >> "$out/$prefix.mp4"
echo 'Downloading 100.0% [4096/4096]'
LUX
chmod 700 "$MEDIA/bin/lux"; printf '0.24.1\n' > "$MEDIA/bin/lux-version.txt"; sha256sum "$MEDIA/bin/lux" | awk '{print $1}' > "$MEDIA/bin/lux-sha256.txt"
export KATA_MEDIA_IMPORT_DIR="$MEDIA"
php -d disable_functions=proc_open -S "127.0.0.1:$PORT" -t "$ROOT" "$ROOT/index.php" > "$TMP/http.log" 2>&1 & PID=$!
BASE="http://127.0.0.1:$PORT/index.php"; ORIGIN="http://127.0.0.1:$PORT"; COOKIE="$TMP/cookie"
for _ in $(seq 1 80); do curl -fsS -c "$COOKIE" -b "$COOKIE" "$BASE?api=health" > "$TMP/health" 2>/dev/null && break || true; sleep .1; done
php -r '$x=json_decode(file_get_contents($argv[1]),true);$m=$x["media_import"]??[];if(empty($m["ready"])||empty($m["youtube_ready"])||empty($m["instagram_ready"])||($m["mode"]??"")!=="cron-queue"||($m["lux"]??"")!=="installed"||($m["independent_downloaders"]??[])!==["lux"]) {fwrite(STDERR,"Lux-only health rejected: ".json_encode($m)."\n");exit(2);}' "$TMP/health"
START="$(curl -fsS -c "$COOKIE" -b "$COOKIE" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' -d '{"url":"https://www.instagram.com/reel/ABCDEF12345/"}' "$BASE?api=media-import-start")"
ID="$(php -r '$x=json_decode($argv[1],true);echo $x["id"]??"";' "$START")"
[[ "$ID" =~ ^[a-f0-9]{24}$ && -f "$MEDIA/$ID/.queued" ]] || { echo "Lux job failed to queue: $START"; exit 3; }
# No yt-dlp installed; CRON still must dispatch Lux.
KATA_MEDIA_IMPORT_DIR="$MEDIA" bash "$ROOT/media-import-cron.sh"
STATUS=''; OK=0
for _ in $(seq 1 200); do
 STATUS="$(curl -fsS -c "$COOKIE" -b "$COOKIE" "$BASE?api=media-import-status&id=$ID" 2>/dev/null || true)"
 st="$(php -r '$x=json_decode($argv[1],true);echo $x["status"]??"";' "$STATUS")"
 [[ "$st" != complete ]] || { OK=1; break; }
 [[ "$st" != error && "$st" != failed ]] || { echo "Lux job status error: $STATUS"; exit 4; }
 sleep .12
done
[[ "$OK" == 1 ]] || { echo "Lux-only CRON job not complete: $STATUS"; cat "$MEDIA/$ID/downloader.log"; exit 5; }
curl -fsS -c "$COOKIE" -b "$COOKIE" -H 'Range: bytes=0-4095' "$BASE?api=media-import-file&id=$ID" -o "$TMP/video.mp4"
[[ $(wc -c < "$TMP/video.mp4") == 4096 ]] || { echo 'Lux transfer size mismatch'; exit 6; }
SHA="$(sha256sum "$TMP/video.mp4" | awk '{print $1}')"
ACK="$(curl -fsS -c "$COOKIE" -b "$COOKIE" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' -d "{\"id\":\"$ID\",\"sha256\":\"$SHA\"}" "$BASE?api=media-import-ack")"
php -r '$x=json_decode($argv[1],true); if(empty($x["verified"])||empty($x["deleted"]))exit(7);' "$ACK"
[[ ! -d "$MEDIA/$ID" ]] || { echo 'Lux temp job not removed after ACK'; exit 8; }
echo 'Lux-only CRON integration: PASS (yt-dlp absent, no PHP proc_open, bounded job, transfer SHA-256, cleanup)'
