import assert from 'node:assert/strict';
import {buildPurcellBaselineFindings,buildPurcellDecisionLayer,applyPurcellRecommendations} from '../purcell-core.mjs';
const policy={baseline_rules:{projected_balance:{margin_below:-.12,min_pose_confidence:.72,min_duration_s:.38,min_samples:10,min_reliable_fraction:.75}}};
const mk=(n,{margin=-.24,confidence=.91,reliable=true,splitAt=-1}={})=>{
  const frames=Array.from({length:n},(_,i)=>{const im=Array.from({length:33},()=>[.5,.5,0,1]);im[0]=[.5,.12,0,1];im[29]=[.45,.85,0,1];im[30]=[.53,.85,0,1];im[31]=[.43,.86,0,1];im[32]=[.56,.86,0,1];return {t:i/30,camera_segment_id:i>=splitAt&&splitAt>=0?1:0,im};});
  const metrics=frames.map(f=>({t:f.t,bos_margin_body_heights:margin,bos_reliable:reliable,pose_confidence:confidence,com_x:.77}));
  return {frames,metrics};
};
const example=mk(40);
const cues=buildPurcellBaselineFindings({...example,knowledge:policy});
assert.equal(cues.length,1,'sustained significant projection offset must be reported even without training');
assert.match(cues[0].why,/1\.30 с/);
const advice=buildPurcellDecisionLayer({plan:{available:true,recommendations:[]},examples:[],windows:[],feedback:[],...example,knowledge:policy});
assert.equal(advice.recommendations.length,1,'baseline reasoning works with zero Lully patterns and no examples');
assert.equal(advice.recommendations[0].correctionAvailable,false,'training-free diagnostics must not fabricate corrected avatar');
assert.match(advice.recommendations[0].purcell_explanation,/проверьте/i);
assert.equal(applyPurcellRecommendations(example.frames,advice.recommendations).frames,example.frames,'no synthetic example = immutable measured trajectory');
assert.equal(buildPurcellBaselineFindings({...mk(40,{margin:-.05}),knowledge:policy}).length,0,'small BOS margins are ignored');
const normal=mk(40);normal.metrics.forEach(m=>m.com_x=.5);assert.equal(buildPurcellBaselineFindings({...normal,knowledge:policy}).length,0,'normal center above feet must not be mistaken for imbalance due to image Y perspective');
assert.equal(buildPurcellBaselineFindings({...mk(40,{confidence:.45}),knowledge:policy}).length,0,'low-quality landmarks are ignored');
assert.equal(buildPurcellBaselineFindings({...mk(40,{reliable:false}),knowledge:policy}).length,0,'unreliable visible support is ignored');
assert.equal(buildPurcellBaselineFindings({...mk(12),knowledge:policy}).length,0,'short events are ignored');
assert.equal(buildPurcellBaselineFindings({...mk(20,{splitAt:10}),knowledge:policy}).length,0,'camera cuts break continuity');
const wellSampled=mk(100,{margin:.04});
const strikes=[
  {start_time_s:.2,end_time_s:.55,duration_s:.35,sequencing_index:.06,pose_confidence_mean:.91,world_landmark_fraction:.88,segment_id:1},
  {start_time_s:1.2,end_time_s:1.55,duration_s:.35,sequencing_index:.08,pose_confidence_mean:.90,world_landmark_fraction:.87,segment_id:1}
];
const timing=buildPurcellBaselineFindings({...wellSampled,strikes,knowledge:policy});
assert.equal(timing.length,1,'two confirmed low-SI strike windows should yield training-independent timing cue');
assert.match(timing[0].why,/SI/);
const noSupport=mk(100,{reliable:false});
assert.equal(buildPurcellBaselineFindings({...noSupport,strikes,knowledge:policy}).length,1,
  'high-confidence repeated strike timing must not be gated by unrelated projected BOS');
const badCamera=strikes.map((w,i)=>({...w,segment_id:i+1}));
assert.equal(buildPurcellBaselineFindings({...wellSampled,strikes:badCamera,knowledge:policy}).length,0,
  'different camera plans must not be interpreted as one kinetic chain');
const timingDecision=buildPurcellDecisionLayer({plan:{available:true,recommendations:[]},examples:[],windows:[],feedback:[],...wellSampled,strikes,knowledge:policy});
assert.equal(timingDecision.recommendations.length,1,'built-in repeated strike observation does not require user examples');
assert.equal(timingDecision.recommendations[0].correctionAvailable,false,'no reference = no fake trajectory');
assert.equal(buildPurcellBaselineFindings({...wellSampled,strikes,strikeFallback:true,knowledge:policy}).length,0,'fallback strike detector is not enough evidence');
assert.equal(buildPurcellBaselineFindings({...wellSampled,strikes:[strikes[0]],knowledge:policy}).length,0,'isolated low SI is not serious evidence');
assert.equal(buildPurcellBaselineFindings({...wellSampled,strikes:strikes.map(w=>({...w,pose_confidence_mean:.4})),knowledge:policy}).length,0,'low confidence suppression for timing');
const learning=buildPurcellDecisionLayer({plan:{available:true,recommendations:[]},feedback:[{title:cues[0].title,kind:'stance',decision:'wrong'},{title:cues[0].title,kind:'stance',decision:'wrong'}],examples:[],windows:[],...example,knowledge:policy});
assert.equal(learning.recommendations.length,0,'a repeated wrong vote suppresses matching built-in advice');
console.log('Purcell independent conservative biomechanics baseline: PASS');
