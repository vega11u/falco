import assert from 'node:assert/strict';
import {inspectPoseForDepthReview,REVIEW_REASONS} from '../depth-review-core.mjs';
const make=()=>{
 const p=Array.from({length:33},(_,i)=>[.48+(i%3)*.025,.15+(i%7)*.065,0,.95]);
 p[11]=[.42,.28,0,.95];p[12]=[.58,.28,0,.95];p[23]=[.44,.58,0,.95];p[24]=[.56,.58,0,.95];
 p[13]=[.35,.40,0,.95];p[15]=[.33,.53,0,.95];p[14]=[.65,.40,0,.95];p[16]=[.67,.53,0,.95];
 p[25]=[.43,.73,0,.95];p[27]=[.43,.90,0,.95];p[29]=[.42,.94,0,.95];p[31]=[.45,.96,0,.95];
 p[26]=[.57,.73,0,.95];p[28]=[.56,.90,0,.95];p[30]=[.56,.94,0,.95];p[32]=[.60,.96,0,.95];return p;
};
const base=make();const okay=inspectPoseForDepthReview(base);assert.equal(okay.uncertain,false,JSON.stringify(okay));
const tribune=make();tribune[15]=[2.3,-.4,0,.93];const bad=inspectPoseForDepthReview(tribune,base);assert(bad.reasons.includes('off_body_limb'));assert(bad.reasons.includes('out_of_frame'));
const heel=make();heel[29]=[.42,.76,0,.92];const toes=inspectPoseForDepthReview(heel);assert(toes.reasons.includes('toe_only'));
const jump=make();jump[16]=[.99,.02,0,.95];const motion=inspectPoseForDepthReview(jump,base,1/30);assert(motion.reasons.includes('sudden_jump'));
const lost=make();lost[29]=[NaN,NaN,0,0];assert(inspectPoseForDepthReview(lost).reasons.includes('missing_heel'));
assert.equal(!!REVIEW_REASONS.depth_discontinuity,true);
console.log('Depth review rules PASS');
