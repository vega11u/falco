<?php
declare(strict_types=1);
$root=dirname(__DIR__);$fail=[];
$need=static function(bool $ok,string $why)use(&$fail):void{if(!$ok)$fail[]=$why;};
$index=(string)file_get_contents($root.'/index.php');
$need(str_contains($index,'falco-jugger-ui.css?v=27.2.0-C.D2'),'D2 stylesheet version missing');
$need(str_contains($index,'value="consensus" selected'),'Full Consensus is not default');
$worker=(string)file_get_contents($root.'/body-reconstruction-worker.js');$need(str_contains($worker,'optimizeResearchSequence(result.tracks'),'Temporal optimizer not integrated into reconstruction worker');
$need(str_contains($index,"./body-reconstruction-worker.js?v=27.2.1"),'Body reconstruction worker cache key is stale');
$need(str_contains($index,"{type:'module',name:'falco-body-reconstruction-fixed'}"),'Body reconstruction worker must run as an ES module');
$need(str_contains($index,'buildCanonicalReconstructionV3(frames'),'Canonical V3 not built from final frames');
$need(str_contains($index,'beginResearchRun(state.researchRunManifest)'),'Run manifest not persisted');
$need(str_contains($index,'finalizeResearchRun(state.researchRunId'),'Run finalization not persisted');
$need(str_contains($index,'athlete_silhouette_dimensions_per_frame'),'Per-frame mask dimensions not archived');
$need(str_contains($index,"Math.min(1.0,depthModelInfo.consensus_budget"),'Accuracy-first depth cadence missing');
$need(is_file($root.'/tools/falco-gc.sh'),'Conservative GC script missing');
$need(is_file($root.'/research-c-temporal-optimizer.mjs'),'Temporal optimizer missing');
$need(is_file($root.'/research-c-checkpoint-store.mjs'),'Checkpoint store missing');
$need(is_file($root.'/research-c-evidence-v3.mjs'),'Evidence schema missing');
foreach(['index.php','lully.php','Memories.php','models.php','purcell-lab.php'] as $file){$text=(string)file_get_contents($root.'/'.$file);$need(str_contains($text,'falco-jugger-ui.css?v=27.2.0-C.D2'),"D2 stylesheet mismatch: $file");}
$manifest=json_decode((string)file_get_contents($root.'/FALCO_C_D2_RELEASE.json'),true);$need(is_array($manifest)&&($manifest['release']??'')==='27.2.1-C.D2','Release manifest invalid');
if($fail){foreach($fail as $f)fwrite(STDERR,"FAIL: $f\n");exit(1);}echo "Falco C/D2 27.2.1 integration smoke: PASS\n";
