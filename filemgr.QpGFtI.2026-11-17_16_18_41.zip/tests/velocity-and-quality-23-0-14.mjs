import assert from 'node:assert/strict';
import {measureRelativeSpeeds,summarizeVelocityQuality} from '../motion-velocity-core.mjs';
import {evaluateMovementQuality} from '../movement-quality-core.mjs';
const pos={0:[0,-.68,0],11:[-.20,-.29,0],12:[.20,-.29,0],13:[-.33,-.08,0],14:[.33,-.08,0],15:[-.42,.06,0],16:[.42,.06,0],23:[-.12,.19,0],24:[.12,.19,0],25:[-.12,.57,0],26:[.12,.57,0],27:[-.13,.88,0],28:[.13,.88,0],29:[-.13,.94,.01],30:[.13,.94,.01],31:[-.13,.96,-.10],32:[.13,.96,-.10]};
function pose(t){const w=Array.from({length:33},()=>[0,.10,0,1]);for(const [id,p] of Object.entries(pos))w[+id]=[...p,1];w[15][0]+=.10*Math.sin(t*7);w[16][0]+=.12*Math.sin(t*9);return w;}
const source=Array.from({length:135},(_,i)=>{const t=i/60,w=pose(t),im=w.map(p=>[.5+p[0]*.5,.2+p[1]*.5,p[2],1]);return {t,im,w,camera_segment_id:0};});
const baseline=measureRelativeSpeeds(source);const usable=baseline.slice(10,-10).map(x=>x.values[15]).filter(Number.isFinite);
assert.ok(usable.length>75,`measured rows ${usable.length}`);const mx=Math.max(...usable);assert.ok(mx>.3&&mx<2.0,`speed expected <2, got ${mx}`);
const jumped=source.map(f=>({...f,w:f.w.map(p=>p.slice()),im:f.im.map(p=>p.slice())}));jumped[60].w[15][0]+=3.5;jumped[60].im[15][0]+=.4;
const after=measureRelativeSpeeds(jumped);assert.ok(Math.max(...after.map(r=>r.values[15]).filter(Number.isFinite))<5,'single-frame teleport must not yield 20-30m/s');
const q=summarizeVelocityQuality(after);assert.ok(q.usable>100);
const cut=source.map(f=>({...f}));for(let i=80;i<cut.length;i++){cut[i]={...cut[i],camera_segment_id:1,w:cut[i].w.map(x=>x.slice())};cut[i].w[15][0]+=1.0;}
const cutRates=measureRelativeSpeeds(cut);assert.ok(cutRates[80].values[15]==null||cutRates[80].values[15]<6,'camera cut must be isolated');
const score0=evaluateMovementQuality({frames:source}),broken=evaluateMovementQuality({frames:jumped});
assert.equal(score0.measurable,false,'Trajectory-only evidence cannot be advertised as complete kata assessment');assert.ok(evaluateMovementQuality({frames:source,allowPartial:true}).measurable,'Available partial trajectory data retained for exploratory optimization');assert.ok(broken.value!==39||broken.value!==40,'no hard middle-score plateau');
const staticFrames=source.slice(0,3);assert.equal(evaluateMovementQuality({frames:staticFrames}).value,null,'missing data must not default to 50');
assert.ok(!score0.breakdown.some(x=>x.key.includes('ke')||x.key.includes('velocity')),'absolute speed and KE must not reward score');
console.log('PASS velocity 3D multi-sample regression, isolated jump rejection, camera cut, non-saturating score, no KE/speed reward');
