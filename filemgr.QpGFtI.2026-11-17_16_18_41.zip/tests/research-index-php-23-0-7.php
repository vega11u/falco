<?php
require __DIR__.'/../research/build_evidence_index.php';
$root=sys_get_temp_dir().'/fj-index-'.bin2hex(random_bytes(4));
$dir=$root.'/data/trained/research-sources/open-sim';
mkdir($dir,0700,true);
// parent already created
file_put_contents($root.'/data/purcell-knowledge.json',json_encode(['principles'=>[['id'=>'stance','name_ru'=>'Опора','body'=>'Роль опоры и устойчивости корпуса при смене стойки']]],JSON_UNESCAPED_UNICODE));
file_put_contents($dir.'/test.csv',"technique,notes\nstance,ground support foot hip knee\nkick,chamber retraction of the knee\n");
file_put_contents($dir.'/test.osim','<OpenSimDocument><Body name="pelvis"/><Muscle name="gluteus_maximus"/></OpenSimDocument>');
try{
 $x=fj_build_evidence_index($root);
 $db=json_decode((string)file_get_contents($root.'/data/trained/purcell-evidence-index.json'),true);
 if($x['count']<4)throw new RuntimeException('Missing indexed content');
 if(!isset($x['sources']['open-sim'])||!isset($x['sources']['purcell_builtin']))throw new RuntimeException('Missing source attribution');
 if(!array_filter($db['items'],static fn($e)=>$e['kind']==='anatomy_structure'&&$e['title']==='gluteus_maximus'))throw new RuntimeException('Missing XML anatomical structure');
 if(!array_filter($db['items'],static fn($e)=>$e['kind']==='dataset_observation'))throw new RuntimeException('Missing CSV observations');
 echo "PASS PHP-only indexer: theory, CSV, OpenSim XML, provenance, atomic file\n";
}finally{
 $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
 foreach($it as $f){if($f->isDir())rmdir($f->getPathname());else unlink($f->getPathname());}rmdir($root);
}
