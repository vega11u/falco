#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
TMP="$(mktemp -d)"
PORT="$((19000 + ($$ % 10000)))"
BASE="http://127.0.0.1:${PORT}"
PID=''
cleanup(){ [[ -z "$PID" ]] || kill "$PID" 2>/dev/null || true; rm -rf "$TMP"; }
trap cleanup EXIT
mkdir -p "$TMP/learning" "$TMP/reports"
KATA_LEARNING_DIR="$TMP/learning" KATA_REPORTS_DIR="$TMP/reports" php -S "127.0.0.1:${PORT}" -t "$ROOT" >"$TMP/php.log" 2>&1 &
PID=$!
for _ in $(seq 1 40); do
  if curl -fsS "$BASE/index.php?api=health" -c "$TMP/cookies" -b "$TMP/cookies" >/dev/null 2>&1; then break; fi
  sleep .15
done
curl -fsS "$BASE/index.php?api=health" -c "$TMP/cookies" -b "$TMP/cookies" >/dev/null

php -r '$f=array_fill(0,384,0.25);$p=["label"=>"Gyaku-zuki smoke","kind"=>"hand_strike","style"=>"shotokan","rating"=>5,"good_parts"=>["arms","trunk"],"problem_parts"=>["feet"],"notes"=>"Опора стабильна, таз начинает разворот до ускорения руки.","features"=>$f,"source_session"=>"purcell-smoke-0001","source_name"=>"smoke.mp4","duration_s"=>1.2,"start_s"=>0.1,"end_s"=>0.9];file_put_contents($argv[1],json_encode($p));' "$TMP/purcell.json"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" -H "Origin: $BASE" -H 'Content-Type: application/json' --data-binary @"$TMP/purcell.json" "$BASE/index.php?api=purcell-save" >"$TMP/purcell-save.json"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" "$BASE/index.php?api=purcell-library" >"$TMP/purcell-library.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true);if(($d["ok"]??false)!==true||count($d["examples"]??[])!==1||($d["examples"][0]["feature_count"]??0)!==384||empty($d["examples"][0]["features_q16"]))exit(1);' "$TMP/purcell-library.json"

# General body biomechanics is a first-class Purcell sample. It must not enter Lully.
php -r '$f=array_fill(0,384,0.37);$p=["label"=>"Образец биомеханики: опора → таз", "kind"=>"biomechanics", "style"=>"unspecified", "rating"=>1, "good_parts"=>["trunk"], "problem_parts"=>["legs"], "notes"=>"Антипример: движение таза преждевременно", "features"=>$f,"source_session"=>"purcell-smoke-generic-0002", "source_name"=>"example.mp4", "duration_s"=>2.0,"start_s"=>0.0,"end_s"=>1.8];file_put_contents($argv[1],json_encode($p));' "$TMP/purcell-generic.json"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" -H "Origin: $BASE" -H 'Content-Type: application/json' --data-binary @"$TMP/purcell-generic.json" "$BASE/index.php?api=purcell-save" >"$TMP/purcell-generic-save.json"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" "$BASE/index.php?api=purcell-library" >"$TMP/purcell-with-generic.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true);if(($d["ok"]??false)!==true||count($d["examples"]??[])!==2)exit(1); $g=array_values(array_filter($d["examples"],fn($x)=>($x["kind"]??"")==="biomechanics")); if(count($g)!==1||($g[0]["quality_class"]??"")!=="counterexample")exit(1);' "$TMP/purcell-with-generic.json"

php -r '$p=["decision"=>"good","title"=>"Проверить траекторию ударной руки","kind"=>"hand_strike","unit_name"=>"Smoke kata","style"=>"shotokan","time_s"=>0.5,"rationale"=>"Пояснение smoke test"];file_put_contents($argv[1],json_encode($p));' "$TMP/vote.json"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" -H "Origin: $BASE" -H 'Content-Type: application/json' --data-binary @"$TMP/vote.json" "$BASE/index.php?api=purcell-feedback" >"$TMP/vote-result.json"

php -r '$f=array_fill(0,384,0.15);$p=["unit_name"=>"Smoke kata","style"=>"shotokan","source_session"=>"pattern-review-smoke-p1","source_name"=>"smoke.mp4","duration_s"=>1.2,"reviews"=>[["kind"=>"hand_strike","label"=>"Gyaku-zuki","decision"=>"confirmed","start_s"=>0.1,"end_s"=>0.8,"signature"=>$f],["kind"=>"kick","label"=>"Mae-geri","decision"=>"rejected","start_s"=>0.8,"end_s"=>1.1,"signature"=>$f]]];file_put_contents($argv[1],json_encode($p));' "$TMP/reviews.json"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" -H "Origin: $BASE" -H 'Content-Type: application/json' --data-binary @"$TMP/reviews.json" "$BASE/index.php?api=pattern-reviews" >"$TMP/reviews-result.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true);$l=json_decode(file_get_contents($argv[2]),true);$p=$l["feedback"][0]["patterns"]??[];if(($d["stored"]??0)!==2||empty($p[0]["signature_q16"])||empty($p[1]["signature_q16"]))exit(1);' "$TMP/reviews-result.json" "$TMP/learning/library.json"

php -r '$f=array_fill(0,384,0.1);$p=["unit_name"=>"Smoke kata","unit_type"=>"kata","style"=>"shotokan","source_session"=>"lully-smoke-0001","source_name"=>"smoke.mp4","duration_s"=>1.2,"examples"=>[["kind"=>"hand_strike","label"=>"Gyaku-zuki","style"=>"shotokan","confirmed"=>true,"feature_version"=>"pose-window-v4-dtw-angle","features"=>$f,"start_s"=>0.1,"end_s"=>0.9]]];file_put_contents($argv[1],json_encode($p));' "$TMP/learn.json"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" -H "Origin: $BASE" -H 'Content-Type: application/json' --data-binary @"$TMP/learn.json" "$BASE/index.php?api=learn" >"$TMP/learn-result.json"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" -H "Origin: $BASE" -H 'Content-Type: application/json' --data-binary @"$TMP/learn.json" "$BASE/index.php?api=learn" >"$TMP/learn-duplicate.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true);if(($d["stored"]??-1)!==0)exit(1);' "$TMP/learn-duplicate.json"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" -H "Origin: $BASE" -H 'Content-Type: application/json' --data-binary '{}' "$BASE/index.php?api=model-sync" >"$TMP/model-sync.json"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" "$BASE/index.php?api=model-status" >"$TMP/model-status.json"
php -r 'require $argv[5];$d=json_decode(file_get_contents($argv[1]),true);$m=json_decode(file_get_contents($argv[2]),true);$l=json_decode(file_get_contents($argv[3]),true);$model=json_decode(file_get_contents($argv[4]),true);$hash=fj_model_source_library_hash_from_rows($l["examples"]);if(($d["ok"]??false)!==true||($m["training_examples"]??0)!==1||($model["source_library_hash"]??"")!==$hash)exit(1);' "$TMP/model-sync.json" "$TMP/model-status.json" "$TMP/learning/library.json" "$TMP/learning/classifier-model.json" "$ROOT/server-learning.php"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" -H "Origin: $BASE" -H 'Content-Type: application/json' --data-binary '{}' "$BASE/index.php?api=model-sync" >"$TMP/model-sync-again.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true);if(($d["already_current"]??false)!==true)exit(1);' "$TMP/model-sync-again.json"

php -r '
$bundle=["app"=>"Kata Biomechanics Analyzer","archive_version"=>1,"created_at"=>gmdate("c"),"kata_name"=>"Streaming smoke kata","report"=>["created_at"=>gmdate("c"),"source"=>["file_name"=>"stream-smoke.mp4","duration_s"=>1.2,"sample_count"=>1],"final_score"=>["value"=>88]],"frame_store"=>["count"=>1,"pose_base64"=>base64_encode(pack("f*",0.1,0.2,0.3,1.0)),"times_base64"=>base64_encode(pack("f*",0.0))],"pattern_groups"=>[],"pattern_review_feedback"=>[],"personalized_model_3d"=>["schema"=>"falco-personalized-vivaldi-mesh-keyframes-v2","keyframe_count"=>1,"keyframes"=>[["frame_index"=>0,"test_only"=>"synthetic storage fixture; not a measured 3D mesh"]]],"test_payload"=>base64_encode(random_bytes(3*1024*1024))];
$json=json_encode($bundle,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);$gz=gzencode($json,6);file_put_contents($argv[1],$gz);file_put_contents($argv[2],json_encode(["file_name"=>"Streaming smoke kata","created_at"=>$bundle["report"]["created_at"],"duration_s"=>1.2,"final_score"=>88,"frame_count"=>1,"personalized_mesh_keyframes"=>1,"personalized_mesh_schema"=>"falco-personalized-vivaldi-mesh-keyframes-v2","compressed_bytes"=>strlen($gz),"uncompressed_bytes"=>strlen($json),"compressed_sha256"=>hash("sha256",$gz),"chunk_size"=>2097152,"chunks"=>(int)ceil(strlen($gz)/2097152)]));
' "$TMP/report.gz" "$TMP/report-meta.json"
php -r '$m=json_decode(file_get_contents($argv[1]),true);$meta=["file_name"=>$m["file_name"],"created_at"=>$m["created_at"],"duration_s"=>$m["duration_s"],"final_score"=>$m["final_score"],"frame_count"=>$m["frame_count"],"personalized_mesh_keyframes"=>$m["personalized_mesh_keyframes"],"personalized_mesh_schema"=>$m["personalized_mesh_schema"]];$b=["meta"=>$meta,"compressed_bytes"=>$m["compressed_bytes"],"uncompressed_bytes"=>$m["uncompressed_bytes"],"compressed_sha256"=>$m["compressed_sha256"],"chunk_size"=>$m["chunk_size"],"chunks"=>$m["chunks"]];file_put_contents($argv[2],json_encode($b));' "$TMP/report-meta.json" "$TMP/begin.json"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" -H "Origin: $BASE" -H 'Content-Type: application/json' --data-binary @"$TMP/begin.json" "$BASE/index.php?api=reports-upload-begin" >"$TMP/begin-result.json"
UPLOAD_ID="$(php -r '$d=json_decode(file_get_contents($argv[1]),true);echo $d["upload_id"]??"";' "$TMP/begin-result.json")"
[[ "$UPLOAD_ID" =~ ^[a-f0-9]{32}$ ]]
CHUNKS="$(php -r '$d=json_decode(file_get_contents($argv[1]),true);echo $d["chunks"]??0;' "$TMP/report-meta.json")"
CHUNK_SIZE=2097152
[[ "$CHUNKS" -ge 2 ]]
for INDEX in $(seq 0 $((CHUNKS-1))); do
  dd if="$TMP/report.gz" of="$TMP/chunk-$INDEX.bin" bs="$CHUNK_SIZE" skip="$INDEX" count=1 status=none
  curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" -H "Origin: $BASE" -H 'Content-Type: application/octet-stream' --data-binary @"$TMP/chunk-$INDEX.bin" "$BASE/index.php?api=reports-upload-chunk&upload_id=$UPLOAD_ID&index=$INDEX" >"$TMP/chunk-$INDEX-result.json"
done
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" -H "Origin: $BASE" -H 'Content-Type: application/octet-stream' --data-binary @"$TMP/chunk-0.bin" "$BASE/index.php?api=reports-upload-chunk&upload_id=$UPLOAD_ID&index=0" >"$TMP/chunk-retry.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true);if(($d["already_received"]??false)!==true)exit(1);' "$TMP/chunk-retry.json"
php -r '$p=["upload_id"=>$argv[1]];file_put_contents($argv[2],json_encode($p));' "$UPLOAD_ID" "$TMP/commit.json"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" -H "Origin: $BASE" -H 'Content-Type: application/json' --data-binary @"$TMP/commit.json" "$BASE/index.php?api=reports-upload-commit" >"$TMP/commit-result.json"
REPORT_ID="$(php -r '$d=json_decode(file_get_contents($argv[1]),true);if(($d["integrity_verified"]??false)!==true)exit(1);echo $d["id"]??"";' "$TMP/commit-result.json")"
[[ "$REPORT_ID" =~ ^[a-f0-9]{32}$ ]]
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" "$BASE/index.php?api=reports-list" >"$TMP/report-list.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true);if(($d["count"]??0)!==1||($d["items"][0]["file_name"]??"")!=="Streaming smoke kata")exit(1);' "$TMP/report-list.json"
curl -fsS -b "$TMP/other-cookies" -c "$TMP/other-cookies" "$BASE/index.php?api=reports-list" >"$TMP/other-report-list.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true);if(($d["count"]??-1)!==0)exit(1);' "$TMP/other-report-list.json"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" "$BASE/index.php?api=reports-get&id=$REPORT_ID" >"$TMP/report-get.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true);if(($d["bundle"]["frame_store"]["count"]??0)!==1||($d["bundle"]["kata_name"]??"")!=="Streaming smoke kata")exit(1);' "$TMP/report-get.json"
php -r '$p=["id"=>$argv[1]];file_put_contents($argv[2],json_encode($p));' "$REPORT_ID" "$TMP/delete.json"
curl -fsS -b "$TMP/cookies" -c "$TMP/cookies" -H "Origin: $BASE" -H 'Content-Type: application/json' --data-binary @"$TMP/delete.json" "$BASE/index.php?api=reports-delete" >"$TMP/delete-result.json"
[[ -f "$TMP/learning/library.json" && -f "$TMP/learning/classifier-model.json" && -f "$TMP/learning/purcell/library.json" ]]
if find "$TMP/learning/purcell" -type f \( -name '*.mp4' -o -name '*.mov' -o -name '*.webm' \) | grep -q .; then
  echo 'Purcell must store pose features, not uploaded source video' >&2
  exit 1
fi
echo 'Purcell storage, Lully model sync and streaming report archive API smoke test: PASS'
