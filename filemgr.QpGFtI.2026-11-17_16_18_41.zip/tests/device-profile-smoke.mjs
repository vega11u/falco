import assert from 'node:assert/strict';

Object.defineProperty(globalThis, 'navigator', { configurable: true, value: {
  userAgent: 'Mozilla/5.0 Chrome/130.0.0.0 Safari/537.36', platform: 'Linux x86_64', hardwareConcurrency: 8, deviceMemory: 8,
  userAgentData: { platform: 'Linux' }, storage: { estimate: async () => ({ quota: 2_000_000_000, usage: 100_000 }) },
  connection: { effectiveType: '4g', downlink: 25, saveData: false }
}});
Object.defineProperty(globalThis, 'document', { configurable: true, value: { createElement: () => ({ getContext: () => null }) } });
globalThis.VideoDecoder = { isConfigSupported: async ({ codec }) => ({ supported: codec.startsWith('avc1') }) };
globalThis.Worker = class {
  postMessage() { setTimeout(() => this.onmessage?.({ data: { available: true, operationsPerSecond: 1_000_000, elapsedMs: 160, method: 'test worker' } }), 0); }
  terminate() {}
};

const { collectDeviceProfile, benchmarkCompute, formatBytes, formatDuration } = await import('../device-profile.mjs');
const profile = await collectDeviceProfile();
assert.equal(profile.engine, 'Chromium / Chrome');
assert.equal(profile.logicalCores, 8);
assert.equal(profile.wasm.simd, true);
assert.equal(profile.webgl2.supported, false);
assert.equal(profile.webCodecs.h264, true);
assert.equal(profile.webCodecs.vp9, false);
const benchmark = await benchmarkCompute(100);
assert.equal(benchmark.available, true);
assert.equal(benchmark.operationsPerSecond, 1_000_000);
assert.equal(formatBytes(1024), '1.0 КБ');
assert.match(formatDuration(65), /1 мин 05 с/);
console.log('Device profile smoke passed: browser capability matrix, WASM SIMD, WebCodecs and worker benchmark.');
