<?php
declare(strict_types=1);
$root = dirname(__DIR__);
$read = static fn(string $file): string => (string)file_get_contents($root . '/' . $file);
$index = $read('index.php');
$lully = $read('lully.php');
$purcell = $read('purcell-lab.php');
$uppurcell = $read('uppurcell.php');
$hubJs = $read('falco24-learning-centers.js');
$checks = [
  'Workspace mode remains opt-in and allow-listed for legacy route compatibility' => str_contains($index, "['lully', 'purcell']"),
  'Legacy workspace stylesheet is no longer loaded' => !str_contains($index, 'falco24-workspace-mode.css?v=24.2.0'),
  'Legacy Purcell route remains available' => str_contains($uppurcell, "define('FALCO_PURCELL_MODE', true)") && str_contains($uppurcell, "require __DIR__ . '/index.php'"),
  'Lully page is a standalone library without embedded analyzer iframe' => !str_contains($lully, '<iframe') && str_contains($lully, "api('library')") === false,
  'Purcell page is a standalone library without embedded analyzer iframe' => !str_contains($purcell, '<iframe'),
  'Lully library loads the existing read-only API' => str_contains($hubJs, "api('library')"),
  'Purcell library loads the existing read-only API' => str_contains($hubJs, "api('purcell-library')"),
  'Purcell status uses existing status API' => str_contains($hubJs, "api('purcell-status')"),
  'No embedded application workspace bridge remains in library pages' => !str_contains($hubJs, 'data-workspace-frame'),
  'Main analyzer keeps the existing Purcell optimizer after analysis' => str_contains($index, "$('resultsSection')?.classList.remove('hidden')") && str_contains($index, 'renderBaroqueModelJournal(report)'),
  'Purcell hypothesis search remains available' => str_contains($index, 'purcellTrajectoryExplore') && str_contains($index, '10 000 гипотез'),
  'Purcell evolution plan remains available' => str_contains($index, 'biomechPlan') && str_contains($index, 'purcellEvolution'),
  'Lully pattern review remains on the current-video page' => str_contains($index, 'patternsSection') && str_contains($index, 'confirmMovementPattern'),
  'No new training-write API is introduced in library JavaScript' => !preg_match('/api\\([\'"](?:learn|purcell-save|model-sync)[\'"]\\)/', $hubJs),
];
$failed = 0;
foreach ($checks as $name => $ok) {
  echo ($ok ? "PASS " : "FAIL ") . $name . PHP_EOL;
  if (!$ok) $failed++;
}
exit($failed ? 1 : 0);
