import assert from 'node:assert/strict';
import { interpolateLandmarkArray, buildDisplayPoseTrack, estimateRelativeSceneDepth, assertDepthSeriesValid, estimateBodyPartDepth, estimateBodyPartDepthSeries } from '../avatar-render-core.mjs';

const points = () => Array.from({ length: 33 }, () => [0.5, 0.5, 0, 1]).map(p => [...p]);
const prev = points(), left = points(), right = points(), next = points();
prev[0] = [-0.1, 0, 0, 1]; left[0] = [0, 0, 0, 1]; right[0] = [1, 0, 0, 1]; next[0] = [1.1, 0, 0, 1];
const mid = interpolateLandmarkArray(left, right, 0.5, { previous: prev, next, dt: 1, dtPrevious: 1, dtNext: 1 });
assert.ok(Math.abs(mid[0][0] - 0.5) < 1e-6, 'monotone cubic interpolation must preserve a linear trajectory');
assert.ok(mid[0][0] >= 0 && mid[0][0] <= 1, 'display interpolation must not overshoot measured endpoints');
const missing = right.map(p => [...p]); missing[0] = [NaN, NaN, NaN, 0];
const fallback = interpolateLandmarkArray(left, missing, 0.4);
assert.equal(fallback[0][3], 0.78, 'one-sided display fallback must be confidence-damped');

// Display-only smoothing reduces isolated pose jitter while preserving raw observations.
const jitterFrames = Array.from({length:9}, (_,i) => {
  const im=points(),w=points();
  im[15]=[.50+(i===4?.018:0),.30,0,.95];w[15]=[.1+(i===4?.009:0),.2,0,.95];
  return {t:i/30,im,w,camera_segment_id:0};
});
const smoothed = buildDisplayPoseTrack(jitterFrames,{aspect:16/9,radius:2,maxWindowSeconds:.085});
assert.equal(smoothed.length,jitterFrames.length,'display track must preserve frame count');
assert.ok(smoothed[4].im[15][0] < jitterFrames[4].im[15][0], 'display smoothing should reduce an isolated image-space wrist spike');
assert.ok(smoothed[4].w[15][0] < jitterFrames[4].w[15][0], 'display smoothing should reduce an isolated world-space wrist spike');
assert.equal(jitterFrames[4].im[15][0],.518,'display smoothing must never mutate source measurements');
const cutFrames = [
  {t:0,im:points(),w:points(),camera_segment_id:0},
  {t:1/30,im:points(),w:points(),camera_segment_id:1},
  {t:2/30,im:points(),w:points(),camera_segment_id:1}
];
cutFrames[0].im[15]=[.1,.2,0,1];cutFrames[1].im[15]=[.8,.2,0,1];cutFrames[2].im[15]=[.8,.2,0,1];
const cutDisplay=buildDisplayPoseTrack(cutFrames,{radius:2,maxWindowSeconds:.085});
// Depth-fused display coordinates must remain the temporal smoothing source; do not mix
// them with untouched MediaPipe world landmarks from adjacent frames.
const depthBase = Array.from({length:33},(_,i)=>[i*.001, i<11?-.3:i<23?-.1:.2, -.2, 1]);
const depthDisplay = Array.from({length:33},(_,i)=>[i*.001, i<11?-.3:i<23?-.1:.2, .2, 1]);
const depthTrackFrames = [0,.033,.066].map(t=>({t,im:depthBase.map(p=>p.slice()),w:depthBase.map(p=>p.slice()),render_w:depthDisplay.map(p=>p.slice()),camera_segment_id:0}));
const depthDisplayTrack=buildDisplayPoseTrack(depthTrackFrames,{radius:1,maxWindowSeconds:.085});
assert.ok(depthDisplayTrack[1].w[0][2]>.19,'Display smoothing must use adjacent depth-fused render_w rather than original frame.w.');
assert.ok(Math.abs(cutDisplay[1].im[15][0]-.8)<1e-9,'display smoothing must not pull a pose across a camera cut');

function syntheticPose(scale) {
  const p = points(); const cx = 0.5, cy = 0.49;
  const put = (i, x, y) => { p[i] = [cx + (x - cx) * scale, cy + (y - cy) * scale, 0, 1]; };
  put(7, .475, .14); put(8, .525, .14);
  put(11, .425, .25); put(12, .575, .25);
  put(23, .46, .50); put(24, .54, .50);
  put(25, .455, .68); put(26, .545, .68);
  put(27, .45, .86); put(28, .55, .86);
  const w = points();
  const putWorld = (i, x, y, z = 0) => { w[i] = [x, y, z, 1]; };
  putWorld(7, -.045, -.48); putWorld(8, .045, -.48);
  putWorld(11, -.24, -.28); putWorld(12, .24, -.28);
  putWorld(23, -.13, 0); putWorld(24, .13, 0);
  putWorld(25, -.13, .43); putWorld(26, .13, .43);
  putWorld(27, -.13, .86); putWorld(28, .13, .86);
  return { im: p, w, camera_segment_id: 0 };
}
const frames = [
  ...Array.from({ length: 6 }, () => syntheticPose(.9)),
  ...Array.from({ length: 6 }, () => syntheticPose(1.1)),
  ...Array.from({ length: 4 }, () => ({ ...syntheticPose(1.55), camera_segment_id: 1 }))
];
const depth = estimateRelativeSceneDepth(frames, 1.0);
assert.equal(depth.length, frames.length, 'depth proxy must preserve frame count');
assert.ok(assertDepthSeriesValid(depth), 'all relative-depth samples must be finite and bounded');
assert.ok(depth[0].scale < 1 && depth[11].scale > 1, 'relative depth must distinguish farther and nearer phases inside a camera segment');
assert.ok(depth[0].world_features_used >= 3 && depth[11].source.includes('world-normalized'), 'matched image/world segment ratios should be preferred when present');
assert.ok(Math.abs(depth[12].scale - 1) < 1e-6 && Math.abs(depth[15].scale - 1) < 1e-6, 'a new camera segment must establish its own scale baseline');
assert.ok(depth.every((d, i) => d.camera_segment_id === frames[i].camera_segment_id), 'depth smoothing must not cross camera cuts');


// Relative depth is evaluated per limb, not by the athlete's whole-body scale.
function bodyDepthFrame(leftWristZ=0.18,leftElbowZ=.05,time=0){
  const im=points(),w=points();im[15]=[.34,.45,0,1];im[16]=[.66,.45,0,1];
  const put=(id,x,y,z)=>{w[id]=[x,y,z,1];};
  put(0,0,-.55,0);put(7,-.04,-.48,0);put(8,.04,-.48,0);
  put(11,-.22,-.30,0);put(12,.22,-.30,0);put(13,-.34,-.22,leftElbowZ);put(14,.34,-.22,0);put(15,-.40,-.12,leftWristZ);put(16,.40,-.12,0);
  put(23,-.14,0,0);put(24,.14,0,0);put(25,-.14,.30,0);put(26,.14,.30,0);put(27,-.14,.62,0);put(28,.14,.62,0);put(29,-.16,.65,0);put(30,.16,.65,0);put(31,-.10,.66,0);put(32,.10,.66,0);
  const hand=Array.from({length:21},(_,i)=>[.002*i,.001*(i%4),.002*i,1]);hand[0]=[0,0,0,1];hand[8]=[.045,.015,.12,1];hand[12]=[.025,.018,.11,1];
  return {t:time,im,w,camera_segment_id:0,hands:[{pose_side:null,landmarks:hand.map(p=>[.34+p[0],.45+p[1],p[2],p[3]]),world_landmarks:hand}]};
}
const depthFrame=bodyDepthFrame();
const partDepth=estimateBodyPartDepth(depthFrame);
assert.ok(partDepth.parts.left.wrist.depth_torso_lengths>.5,'left hikite wrist should be identified farther than the chest plane');
assert.equal(partDepth.parts.left.wrist_direction,'farther_from_camera');
assert.ok(Math.abs(partDepth.parts.right.wrist.depth_torso_lengths)<1e-6,'the right wrist should remain in the chest plane');
assert.ok(partDepth.parts.left.index_tip.depth_torso_lengths>partDepth.parts.left.wrist.depth_torso_lengths,'individual fingertips must retain their own depth, not inherit one wrist depth');
assert.ok(Number.isFinite(partDepth.parts.left.knee.depth_torso_lengths)&&Number.isFinite(partDepth.parts.left.ankle.depth_torso_lengths),'each lower-limb joint must expose its own depth relative to the pelvis');
assert.ok(Number.isFinite(partDepth.parts.left.thumb_tip.depth_torso_lengths)&&partDepth.parts.left.fingers.length===21,'each hand landmark must expose a distinct depth sample when available');
const depthSeries=estimateBodyPartDepthSeries([bodyDepthFrame(.10,.03,0),bodyDepthFrame(.16,.05,.1),bodyDepthFrame(.22,.07,.2)]);
assert.ok(depthSeries[1].parts.left.wrist.depth_velocity_torso_lengths_s>0,'per-limb depth velocity must detect a hand moving away while the torso remains still');
assert.equal(depthSeries[1].parts.right.wrist.depth_trend,'depth_stable','stationary contralateral wrist must not inherit the moving hand depth');

console.log('Avatar render core smoke tests passed.');
