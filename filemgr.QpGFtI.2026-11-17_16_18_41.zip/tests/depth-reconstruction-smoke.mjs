import assert from 'node:assert/strict';
import { sampleDepthMapAtLandmarks, fuseDepthLandmarkTrack } from '../depth-reconstruction-core.mjs';

const width = 32, height = 24;
const depth = new Float32Array(width * height);
for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) depth[y * width + x] = x / (width - 1);
const image = Array.from({ length: 33 }, (_, i) => [0.08 + (i % 11) * 0.075, 0.12 + Math.floor(i / 11) * 0.34, 0, 1]);
image[2] = [NaN, NaN, 0, 0];
const samples = sampleDepthMapAtLandmarks(depth, width, height, image);
assert.equal(samples.length, 33, 'Depth sampler returns one slot per pose landmark.');
assert.ok(Number.isFinite(samples[0]), 'Visible landmarks sample a finite local depth median.');
assert.ok(Number.isNaN(samples[2]), 'Invisible/invalid landmarks remain missing.');
assert.ok(samples[10] > samples[0], 'The sampler preserves near/far ordering across the image.');
assert.equal(sampleDepthMapAtLandmarks(new Float32Array(4), 32, 24, image), null, 'Malformed maps are rejected.');

const makeWorld = () => Array.from({ length: 33 }, (_, i) => [
  (i % 2 ? 1 : -1) * (i >= 23 ? 0.105 : 0.14),
  i < 11 ? -0.35 : i < 23 ? -0.18 : i < 25 ? 0.12 : 0.34,
  0.01 * (i % 5),
  1
]);
const obs = samples.map(v => v);
const originalWorld = makeWorld();
const frames = [
  { t: 0, camera_segment_id: 0, im: image, w: makeWorld(), depth_landmark_values: obs, depth_model: 'onnx-community/depth-anything-v2-base', depth_mode: 'base' },
  { t: 0.25, camera_segment_id: 0, im: image, w: makeWorld() },
  { t: 0.50, camera_segment_id: 0, im: image, w: makeWorld() },
  { t: 0.75, camera_segment_id: 1, im: image, w: makeWorld() }
];
const untouched = frames.map(frame => frame.w.map(point => point.slice()));
const result = fuseDepthLandmarkTrack(frames, { strength: 0.42, maxObservationGap: 0.8, maxHold: 0.6 });
assert.equal(result.available, true, 'At least the depth observation frame is fused.');
assert.ok(result.enhanced_frames >= 2, 'A nearby frame in the same camera segment receives interpolated depth.');
assert.ok(Array.isArray(frames[0].render_w), 'Fusion writes a separate display-only track.');
assert.deepEqual(frames.map(frame => frame.w), untouched, 'Original MediaPipe world landmarks remain byte-for-byte equivalent.');
assert.equal(frames[3].render_w, undefined, 'Depth is never propagated through a camera cut.');
assert.ok(frames[0].render_w[10][2] < originalWorld[10][2], 'Higher inverse depth moves the display landmark toward the camera.');
assert.match(frames[0].depth_fusion.source, /Depth Anything V2 Base · single-model depth \+ MediaPipe world landmarks/);
assert.equal(frames[0].depth_fusion.model_agreement, null, 'A single selected depth model must not claim cross-model agreement.');
assert.equal(result.mean_model_agreement, null, 'No ensemble agreement metric is reported in single-model mode.');
assert.ok(Array.isArray(frames[0].render_depth_landmark_values), 'Sparse depth is retained as its own display track.');
assert.ok(Array.isArray(frames[0].render_depth_agreement_values), 'Per-joint model agreement is retained independently.');

const smallSelected = [{ t: 0, camera_segment_id: 0, im: image, w: makeWorld(), depth_landmark_values: obs, depth_model: 'onnx-community/depth-anything-v2-small-ONNX', depth_mode: 'small' }];
fuseDepthLandmarkTrack(smallSelected);
assert.match(smallSelected[0].depth_fusion.source, /Small \(выбрана пользователем\)/, 'Small provenance is explicit and user-selected.');

const cutOnly = [
  { t: 0, camera_segment_id: 0, im: image, w: makeWorld(), depth_landmark_values: obs },
  { t: 0.25, camera_segment_id: 1, im: image, w: makeWorld() }
];
const cutResult = fuseDepthLandmarkTrack(cutOnly, { maxHold: 1 });
assert.equal(cutOnly[1].render_w, undefined, 'A camera cut resets depth interpolation.');
assert.equal(cutResult.enhanced_frames, 1);

const noWorld = [{ t: 0, camera_segment_id: 0, im: image, w: null, depth_landmark_values: obs, depth_agreement_values: samples.map(()=>.9) }];
const noWorldResult=fuseDepthLandmarkTrack(noWorld);
assert.equal(noWorldResult.available, false, 'Depth-only data must not fabricate a 3D skeleton without MediaPipe world landmarks.');
assert.ok(Array.isArray(noWorld[0].render_depth_landmark_values), 'Depth-only analysis still stores the local relative-depth track for the 2D avatar and side projection.');
assert.ok(noWorldResult.depth_available_frames===1, 'Depth track coverage is counted even when world landmarks are absent.');
console.log('Depth reconstruction smoke passed: robust sampling, camera-cut guard, display-only fusion and measurement immutability.');
