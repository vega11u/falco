<?php
require __DIR__.'/../purcell-search-memory.php';
$dir=sys_get_temp_dir().'/fj-search-test-'.bin2hex(random_bytes(5));mkdir($dir,0700,true);
try{
 $c=[];for($i=1;$i<=21;$i++)$c[]=['id'=>sprintf('hyp-%02d',$i),'family'=>'left_arm:arc_up','score'=>81+$i/25,'passed'=>true,'metrics'=>['bone_distortion'=>.001]];
 $x=fj_purcell_search_memory($dir,'POST',['action'=>'save_run','unit_name'=>'Sanchin','goal'=>'balanced','candidates'=>$c]);
 if(!isset($x['run_id'])||$x['stored']!==21)throw new RuntimeException('save failed');
 fj_purcell_search_memory($dir,'POST',['action'=>'reject_candidate','run_id'=>$x['run_id'],'candidate_id'=>'hyp-01']);
 fj_purcell_search_memory($dir,'POST',['action'=>'select','run_id'=>$x['run_id'],'candidate_id'=>'hyp-02','comment'=>'Better hip control']);
 $r=fj_purcell_search_memory($dir,'GET');$run=$r['runs'][0];
 if(count($run['candidates'])!==21||$run['selected_candidate']!=='hyp-02'||$run['comment']!=='Better hip control'||!$run['candidates'][0]['user_rejected'])throw new RuntimeException('memory incorrect');
 echo "PASS PHP search memory: 21 scores, rejection, selection, comment, private directory\n";
}finally{foreach(glob($dir.'/*')?:[] as $f)unlink($f);rmdir($dir);}
