import assert from 'node:assert/strict';
import { estimateScenePerspectiveEvidence, estimateTatamiGridEvidence } from '../scene-perspective-core.mjs';
const W=144,H=81,vp={x:70,y:35};
const line=(theta)=>{const r=theta*Math.PI/180;return {theta_deg:theta,line_angle_deg:theta-90,rho:vp.x*Math.cos(r)+vp.y*Math.sin(r),votes:22};};
const samples=Array.from({length:4},(_,i)=>({t:i,lines:[],background_lines:[line(18+i*.3),line(43-i*.2),line(19+i*.3),line(44-i*.2)]}));
const result=estimateScenePerspectiveEvidence(samples,{width:W,height:H,maxSamples:12});
assert.equal(result.detected,true);
assert.ok(result.confidence>0.1);
assert.ok(Math.abs(result.vanishing_point_image_px.x-vp.x)<2);
assert.ok(Math.abs(result.vanishing_point_image_px.y-vp.y)<2);
assert.ok(Math.abs(result.horizon_y_normalized-vp.y/H)<.03);
const empty=estimateScenePerspectiveEvidence([{background_lines:[]}]);
assert.equal(empty.detected,false);
assert.equal(empty.vanishing_point_image_px,null);
assert.match(result.runtime_budget,/12 frames/);
console.log('Scene perspective smoke: PASS');

// Four stable edge lines define a plausible lower-frame floor square. The model only treats
// this candidate as 1 m after repeated evidence across independent sparse samples.
const floorLine=(theta_deg,rho,votes=30)=>({theta_deg,line_angle_deg:theta_deg-90,rho,votes});
const tileLines=[floorLine(80,40),floorLine(80,80),floorLine(145,-40),floorLine(145,20)];
const tileSamples=Array.from({length:6},(_,i)=>({t:i,lines:tileLines.map(line=>({...line,rho:line.rho+(i%2?.15:-.15)}))}));
const tile=estimateTatamiGridEvidence(tileSamples,{width:W,height:H,maxSamples:12});
assert.equal(tile.detected,true,'A repeated, coherent quadrilateral on the floor is accepted as a tatami-cell candidate.');
assert.equal(tile.cell_size_m,1,'The user-defined tatami square is the 1×1 m scale prior.');
assert.equal(tile.image_to_floor_homography.length,9);
assert.equal(tile.floor_to_image_homography.length,9);
assert.match(tile.assumption,/1×1 m/);
const oneFrameTile=estimateTatamiGridEvidence(tileSamples.slice(0,1),{width:W,height:H,maxSamples:12});
assert.equal(oneFrameTile.detected,false,'A single-frame quadrilateral is insufficient to claim a metric tatami grid.');
console.log('Tatami grid smoke: repeated square detection, projective calibration prior, one-frame rejection PASS');
