import assert from 'node:assert/strict';
import fs from 'node:fs';
import { estimateFootLiftAtFrame } from '../biomechanics-core.mjs';

const index = fs.readFileSync(new URL('../index.php', import.meta.url), 'utf8');
function extractFunction(source, name) {
  const marker = `function ${name}(`;
  const start = source.indexOf(marker);
  assert(start >= 0, `${name} must exist in the application`);
  const endMarker = name === 'detectKickWindows' ? '\nfunction rankStrikeWindows' : null;
  assert(endMarker, `No extraction boundary configured for ${name}`);
  const end = source.indexOf(endMarker, start);
  assert(end > start, `Could not find the end of ${name}`);
  return source.slice(start, end).trim();
}
const fnSource = extractFunction(index, 'detectKickWindows');
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const mean=a=>{const v=a.filter(Number.isFinite);return v.length?v.reduce((s,x)=>s+x,0)/v.length:null;};
const percentile=(a,p)=>{const v=a.filter(Number.isFinite).sort((x,y)=>x-y);if(!v.length)return null;const q=(v.length-1)*p,l=Math.floor(q),h=Math.ceil(q);return v[l]+(v[h]-v[l])*(q-l);};
const point2=(f,id)=>{const p=f?.im?.[id];return p&&Number.isFinite(p[0])&&Number.isFinite(p[1])?{x:p[0],y:p[1],v:p[3]??1}:null;};
const angleBetween2=(a,b,c)=>{if(!a||!b||!c)return null;const u=[a.x-b.x,a.y-b.y],v=[c.x-b.x,c.y-b.y],d=Math.hypot(...u)*Math.hypot(...v);return d?Math.acos(clamp((u[0]*v[0]+u[1]*v[1])/d,-1,1))*180/Math.PI:null;};
const line2=(a,b)=>a&&b?((Math.atan2(b.y-a.y,b.x-a.x)*180/Math.PI%180)+180)%180:null;
const axialAbs=(a,b)=>{let d=((a-b+90)%180+180)%180-90;return Math.abs(d);};
const detectKickWindows = new Function('clamp','mean','percentile','point2','angleBetween2','line2','axialAbs','estimateFootLiftAtFrame',`return (${fnSource});`)(clamp,mean,percentile,point2,angleBetween2,line2,axialAbs,estimateFootLiftAtFrame);

const frames=[];
for(let i=0;i<24;i++){
  const im=Array.from({length:33},()=>[NaN,NaN,0,0]);
  const lift=i>=7&&i<=14?.12:0;
  const shift=i>=7&&i<=14?(i-6)*.018:0;
  const pts={23:[.45,.48],25:[.44,.65],27:[.43,.82],29:[.42,.84],31:[.40,.85],24:[.55,.48],26:[.56,.65],28:[.57,.82],30:[.58,.84],32:[.60,.85]};
  for(const [k,xy] of Object.entries(pts)){const id=Number(k);let x=xy[0],y=xy[1];if([27,29,31].includes(id)){x+=shift;y-=lift;}im[id]=[x,y,0,.95];}
  frames.push({t:i/30,im});
}
const metrics=frames.map((_,i)=>({toe_speed_left_m_s:i>=7&&i<=14?2.8:0,toe_speed_right_m_s:0,foot_speed_left_m_s:0,foot_speed_right_m_s:0,ankle_speed_left_m_s:1.2,ankle_speed_right_m_s:0}));
const events=detectKickWindows(frames,metrics,30);
assert(events.length>=1,'synthetic kick should produce at least one candidate window');
assert(events.every(e=>Number.isFinite(e.foot_lift_relative_to_hip)),'kick event peak foot lift must be finite and computed outside the active-predicate callback');
assert(events[0].foot_lift_relative_to_hip>.05,'kick event must report the raised peak foot');
console.log(`Kick-window smoke: PASS (${events.length} candidate event(s), peak lift ${events[0].foot_lift_relative_to_hip.toFixed(3)})`);
