#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
TMP="$(mktemp -d)"
PORT=$((19000 + RANDOM % 12000))
PID=''
cleanup(){ [[ -z "$PID" ]] || kill "$PID" 2>/dev/null || true; rm -rf "$TMP"; }
trap cleanup EXIT
mkdir -p "$TMP/reports" "$TMP/learning"
printf 'trained-model-sentinel-v1\n' > "$TMP/learning/trained-model.bin"
BEFORE="$(sha256sum "$TMP/learning/trained-model.bin" | cut -d' ' -f1)"
KATA_REPORTS_DIR="$TMP/reports" KATA_LEARNING_DIR="$TMP/learning" php -S "127.0.0.1:$PORT" -t "$ROOT" >"$TMP/php.log" 2>&1 &
PID=$!
BASE="http://127.0.0.1:$PORT/index.php"
for _ in $(seq 1 40); do if curl -fsS "$BASE?api=reports-list" -c "$TMP/owner.cookies" -o "$TMP/list.json" 2>/dev/null; then break; fi; sleep .15; done
[[ -s "$TMP/list.json" ]] || { cat "$TMP/php.log" >&2; echo 'FAIL: report API server did not start.' >&2; exit 1; }
php -r '$d=json_decode(file_get_contents($argv[1]),true); if(!is_array($d)||empty($d["ok"])||($d["count"]??-1)!==0) exit(1);' "$TMP/list.json"
# Synthetic payload tests report persistence/ownership, not 3D rendering accuracy.
cat > "$TMP/bundle.json" <<'JSON'
{"app":"Kata Biomechanics Analyzer","archive_version":1,"created_at":"2026-11-06T09:00:00Z","kata_name":"Report library smoke kata","training_style":"shotokan","training_unit_type":"kata","learning_session_id":"smoke-session","report":{"created_at":"2026-11-06T09:00:00Z","source":{"file_name":"smoke.mp4","duration_s":3.5,"sample_count":2},"final_score":{"value":87},"movement_patterns":[{"id":"p1","kind":"stance","confirmed":true}]},"frame_store":{"count":2,"encoding":"float32-base64-le","pose_base64":"AAAA","world_base64":"AAAA","times_base64":"AAAA","camera_segments_base64":"AAAA","hands_2d_base64":"AAAA","hand_sides_base64":"AAAA","metric_rows":[{"t":0,"pose_confidence":0.9},{"t":1,"pose_confidence":0.9}]},"pattern_groups":[{"id":"p1","kind":"stance","confirmed":true,"label":"зенкуцу-дачи","instances":[{"start":0.2,"end":1.0,"signature":[0.1,0.2]}]}],"pattern_review_feedback":[{"kind":"stance","decision":"yes"}],"personalized_model_3d":{"schema":"falco-personalized-vivaldi-mesh-keyframes-v2","keyframes":[{"frame_index":0,"test_only":"synthetic storage smoke fixture; not a computed mesh"}]},"video_included":false}
JSON
ORIGIN="http://127.0.0.1:$PORT"
curl -fsS -b "$TMP/owner.cookies" -c "$TMP/owner.cookies" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' --data-binary "@$TMP/bundle.json" "$BASE?api=reports-save" > "$TMP/save.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true); if(empty($d["ok"])||empty($d["learning_archive_untouched"])||!preg_match("/^[a-f0-9]{32}$/",$d["id"]??"")) exit(1); file_put_contents($argv[2],$d["id"]);' "$TMP/save.json" "$TMP/id"
ID="$(cat "$TMP/id")"
curl -fsS -b "$TMP/owner.cookies" "$BASE?api=reports-get&id=$ID" > "$TMP/get.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true);$b=$d["bundle"]??[]; if(empty($d["ok"])||($b["kata_name"]??"")!=="Report library smoke kata"||count($b["pattern_groups"]??[])!==1||($b["frame_store"]["count"]??0)!==2) exit(1);' "$TMP/get.json"
# The durable owner cookie works without the short-lived PHP session cookie.
OWNER="$(awk '$6=="kata_report_owner"{print $7}' "$TMP/owner.cookies" | tail -n1)"
[[ "$OWNER" =~ ^[a-f0-9]{64}$ ]] || { echo 'FAIL: durable report-owner cookie was not issued.' >&2; exit 1; }
curl -fsS -H "Cookie: kata_report_owner=$OWNER" "$BASE?api=reports-list" > "$TMP/no-session-list.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true); if(($d["count"]??0)!==1)exit(1);' "$TMP/no-session-list.json"
# A different browser owner must not see or read this report.
curl -fsS "$BASE?api=reports-list" -c "$TMP/other.cookies" > "$TMP/other-list.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true); if(($d["count"]??-1)!==0)exit(1);' "$TMP/other-list.json"
STATUS="$(curl -sS -o "$TMP/other-get.json" -w '%{http_code}' "$BASE?api=reports-get&id=$ID" -b "$TMP/other.cookies")"
[[ "$STATUS" == '404' ]] || { echo "FAIL: report ownership isolation returned HTTP $STATUS." >&2; exit 1; }
# Delete only the report blob; the trained-model sentinel must remain byte-identical.
curl -fsS -b "$TMP/owner.cookies" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' --data "{\"id\":\"$ID\"}" "$BASE?api=reports-delete" > "$TMP/delete.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true); if(empty($d["ok"])||empty($d["learning_archive_untouched"]))exit(1);' "$TMP/delete.json"
curl -fsS -b "$TMP/owner.cookies" "$BASE?api=reports-list" > "$TMP/after-list.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true); if(($d["count"]??-1)!==0)exit(1);' "$TMP/after-list.json"
# User-defined labels are persisted in a taxonomy overlay, not by rewriting the shipped taxonomy.
curl -fsS -b "$TMP/owner.cookies" "$BASE?api=taxonomy-custom" > "$TMP/taxonomy-before.json"
curl -fsS -b "$TMP/owner.cookies" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' --data '{"names":{"kata":["Smoke Custom Kata"],"stance":["Smoke Stance"]}}' "$BASE?api=taxonomy-custom" > "$TMP/taxonomy-save.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true);if(empty($d["ok"])||!in_array("Smoke Custom Kata",$d["names"]["kata"]??[])||!in_array("Smoke Stance",$d["names"]["stance"]??[]))exit(1);' "$TMP/taxonomy-save.json"
curl -fsS -b "$TMP/owner.cookies" "$BASE?api=taxonomy-custom" > "$TMP/taxonomy-after.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true);if(!in_array("Smoke Custom Kata",$d["names"]["kata"]??[]))exit(1);' "$TMP/taxonomy-after.json"
# Recommendation feedback is kept in the learning feedback archive, separate from pose examples.
curl -fsS -b "$TMP/owner.cookies" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' --data '{"unit_name":"Smoke Kata","style":"shotokan","recommendation_id":"smoke-cue-1","title":"Check support foot","kind":"kick","time_s":1.2,"decision":"good","rationale":"Specific cue accepted"}' "$BASE?api=optimizer-feedback" > "$TMP/optimizer-feedback.json"
php -r '$d=json_decode(file_get_contents($argv[1]),true);if(empty($d["ok"])||empty($d["stored_separately_from_pose_examples"])||($d["feedback_count"]??0)<1)exit(1);' "$TMP/optimizer-feedback.json"
AFTER="$(sha256sum "$TMP/learning/trained-model.bin" | cut -d' ' -f1)"
[[ "$BEFORE" == "$AFTER" ]] || { echo 'FAIL: deleting a report changed the training archive.' >&2; exit 1; }
[[ -z "$(find "$TMP/reports" -type f -name '*.json.gz' -print -quit)" ]] || { echo 'FAIL: deleted report archive remains on disk.' >&2; exit 1; }
echo 'Server report-library integration smoke passed: persistence beyond PHP session, owner isolation, save/get/delete, learning archive immutability, custom taxonomy sync and optimizer recommendation feedback.'
