import assert from 'node:assert/strict';
import {fitMonteverdiThreshold} from '../monteverdi-kime-learning.mjs';
import {fitMonteverdiMotionClassifier,predictMonteverdiFastMotion,MONTEVERDI_CHOICES} from '../monteverdi-motion-learning.mjs';
assert.deepEqual(MONTEVERDI_CHOICES,['fast_kime','fast_no_kime','not_fast']);
const rows=[];
for(let i=0;i<40;i++){
 const fast=i<20,choice=!fast?'not_fast':i%2?'fast_kime':'fast_no_kime';
 rows.push({source_report:'run-'+i,event_id:i,time_s:i/10,choice,spread_ms:fast?(i%2?95:265):20,
  motion_features:{duration_s:fast?.4:1.1,peak_speed_body_s:fast?8+i*.01:.1,mean_speed_body_s:fast?4:.05,travel_body:fast?2:.04,observed_pairs:12}});
}
const motion=fitMonteverdiMotionClassifier(rows);
assert.equal(motion.reviewed,40);assert.equal(motion.fast,20);assert.equal(motion.not_fast,20);assert.equal(motion.active,true);
assert.equal(predictMonteverdiFastMotion(rows[3].motion_features,motion),true);
assert.equal(predictMonteverdiFastMotion(rows[25].motion_features,motion),false);
const kime=fitMonteverdiThreshold(rows);assert.equal(kime.reviewed,20,'not_fast must NOT count as a failed kime');
assert.equal(kime.positives,10);assert.equal(kime.negatives,10);
const old=[{choice:'yes',prediction:'no',spread_ms:275,source_report:'a',event_id:'1'}, {choice:'no',prediction:'yes',spread_ms:270,source_report:'a',event_id:'2'}];
assert.equal(fitMonteverdiThreshold(old).negatives,2,'legacy yes/no interpreted as agreement/disagreement');
console.log('PASS Monteverdi 3 classes, no slow candidate injection, legacy compatibility');
