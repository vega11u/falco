import assert from 'node:assert/strict';
import {generateCandidate10000,SEARCH_10000_VERSION} from '../purcell-search-core.mjs';
import {generateSpatialCandidate10000,spatialReadiness} from '../purcell-spatial-core.mjs';
const frames=[];
for(let i=0;i<9;i++){
 const im=Array.from({length:33},(_,j)=>[.5+Math.sin(j)*.02,.5+Math.cos(j)*.02,0,1]);
 const w=Array.from({length:33},(_,j)=>[Math.sin(j)*.05,1-j*.025,Math.cos(j)*.05,1]);
 // torso/hips with enough separation and plausible depth
 w[11]=[-.18,.3,0,1];w[12]=[.18,.3,0,1];w[23]=[-.16,.0,0,1];w[24]=[.16,.0,0,1];
 im[11]=[.42,.3,0,1];im[12]=[.58,.3,0,1];im[23]=[.44,.55,0,1];im[24]=[.56,.55,0,1];
 frames.push({t:i/30,im,w});
}
const ids=new Set();let distinct=new Set();
for(const idx of [0,1,999,1000,5000,9999]){
 const c=generateCandidate10000(frames,idx);assert.match(c.id,/^hyp-\d{5}$/);assert.equal(c.frames.length,frames.length);ids.add(c.id);distinct.add(c.mode+'|'+c.amplitude+'|'+c.layer);
}
assert.equal(ids.size,6);assert.equal(SEARCH_10000_VERSION,'purcell-wide-search-v3-10000');
const ready=spatialReadiness(frames);assert.equal(ready.available,true,JSON.stringify(ready));
for(const idx of [0,999,1000,9999]){const c=generateSpatialCandidate10000(frames,idx,{readiness:ready});assert.match(c.id,/^hyp-\d{5}$/);assert.equal(c.frames.length,frames.length);}
const allIds=new Set();for(let i=0;i<10000;i++)allIds.add(generateCandidate10000(frames,i).id);assert.equal(allIds.size,10000);assert(allIds.has('hyp-00001')&&allIds.has('hyp-10000'));
const all3dIds=new Set();for(let i=0;i<10000;i++)all3dIds.add(generateSpatialCandidate10000(frames,i,{readiness:ready}).id);assert.equal(all3dIds.size,10000);assert(all3dIds.has('hyp-00001')&&all3dIds.has('hyp-10000'));
console.log('PASS: all 10,000 2D and all 10,000 3D candidate identifiers are unique; generator contracts pass');
