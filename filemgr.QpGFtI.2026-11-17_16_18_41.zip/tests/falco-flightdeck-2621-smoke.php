<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$index=(string)file_get_contents($root.'/index.php');
$css=(string)file_get_contents($root.'/falco-jugger-ui.css');
$ui=(string)file_get_contents($root.'/falco-jugger-ui.js');
$requirements=[
 'Core build remains 23.0.27' => trim((string)file_get_contents($root.'/VERSION'))==='23.0.27',
 'Fixed mesh new architecture preserved' => str_contains($index,'fixed-mesh-identity-1') && str_contains((string)file_get_contents($root.'/FALCO26_RELEASE_VERSION.txt'),'2048 vertices'),
 'Only integrated flight deck stylesheet is linked' => substr_count($index,'falco-jugger-ui.css?v=26.2.2')===1 && !str_contains($index,'f24-topbar'),
 'One current flight deck controller' => substr_count($index,'falco-jugger-ui.js?v=26.2.2')===1,
 'Player and central column are present' => str_contains($index,'id="fjWorkbench"') && str_contains($index,'id="analysisDock"') && str_contains($index,'id="fjVideoMount"'),
 'Player glyph remains compact during playback' => str_contains($index,"b.textContent='Ⅱ'") && str_contains($index,"b.textContent='▶'"),
 'Always-visible player never causes seek scroll jump' => !str_contains($index,"dock?.scrollIntoView({behavior:'smooth',block:'center'});seekToPlayers(time)"),
 'Mobile player has a dedicated collapse control' => str_contains($index,'id="fjPlayerCollapse"') && str_contains($ui,'setPlayerExpanded(false)'),
 'Mobile expansion triggers below correct breakpoint' => str_contains($ui,'window.innerWidth<900;'),
 'Single compositor not overridden with legacy layer' => !str_contains($css,'FALCO 26.2.0 — Aero surface finishing pass') && !str_contains($css,'@layer compatibility'),
 'Fixed player has no nested scroll root' => str_contains($css,'position:fixed') && str_contains($css,'overflow:clip;overscroll-behavior:none'),
 'Video remains fully contained in the stage' => str_contains($css,'object-fit:contain;object-position:center center'),
 'Purcell one global optimization remains' => str_contains($index,'const spatialRanked={overall:[]}'),
 'Journal remains an isolated drawer' => str_contains($index,'id="fjJournalDrawer"') && str_contains($ui,"journalMount.append(journal)"),
];
$fail=0;
foreach($requirements as $name=>$ok){echo ($ok?'PASS':'FAIL')." $name\n";if(!$ok)$fail++;}
foreach(['lully.php','purcell-lab.php','models.php','Memories.php'] as $name){$html=(string)file_get_contents($root.'/'.$name);$ok=substr_count($html,'falco-jugger-ui.css?v=26.2.2')===1;echo ($ok?'PASS':'FAIL')." Single stylesheet $name\n";if(!$ok)$fail++;}
exit($fail?1:0);
