import assert from 'node:assert/strict';
import {packAthleteSilhouette,pointInAthleteSilhouette,projectInsideAthleteSilhouette,silhouetteImageData,compactAthleteSilhouette,expandAthleteSilhouette} from '../athlete-silhouette-core.mjs';
import {buildVivaldiFineMesh,VIVALDI_MESH_RESOLUTIONS,paintVivaldiMesh2D} from '../vivaldi-fine-mesh.mjs';
const w=128,h=128,pixels=new Float32Array(w*h);
for(let y=9;y<121;y++)for(let x=30;x<97;x++)pixels[y*w+x]=.92;
// A distinct second person must never be included in the connected main athlete component.
for(let y=26;y<110;y++)for(let x=103;x<126;x++)pixels[y*w+x]=.99;
const landmarks=Array.from({length:33},()=>({x:.5,y:.5,visibility:1}));
for(const [i,xy] of [[0,[.5,.15]],[11,[.42,.27]],[12,[.58,.27]],[13,[.34,.4]],[14,[.66,.4]],[15,[.34,.55]],[16,[.66,.55]],[23,[.44,.57]],[24,[.56,.57]],[25,[.44,.76]],[26,[.56,.76]],[27,[.44,.90]],[28,[.56,.90]]])landmarks[i]={x:xy[0],y:xy[1],visibility:.98};
const mask=packAthleteSilhouette({width:w,height:h,getAsFloat32Array:()=>pixels},landmarks);
assert(mask&&mask.b64&&mask.b64.length<4000,'compact mask stored in base64');
assert.equal(mask.coverage>0,true);
assert(pointInAthleteSilhouette(mask,.5,.5));
assert(!pointInAthleteSilhouette(mask,.91,.5),'separated neighbor is excluded');
assert(!pointInAthleteSilhouette(mask,.03,.5),'no background included');
const restored=JSON.parse(JSON.stringify(mask));
assert(pointInAthleteSilhouette(restored,.5,.5),'serialized masks survive archive storage');
const compressed=compactAthleteSilhouette(mask);
assert.equal(compressed[0],'r','measured connected mask compresses by RLE');
assert(compressed.length < mask.b64.length / 2,'silhouette transport must be smaller than raw base64');
const restoredCompressed=expandAthleteSilhouette(compressed);
assert(restoredCompressed&&restoredCompressed.b64===mask.b64,'RLE serialization must be lossless');
assert.equal(expandAthleteSilhouette('r'+compressed.slice(1,7)),null,'truncated mask must be rejected');
const projected=projectInsideAthleteSilhouette(restored,[.5,.5],[1.25,.5]);assert(projected&&pointInAthleteSilhouette(restored,projected[0],projected[1]));
const image=silhouetteImageData(mask);assert.equal(image.length,w*h*4);assert.equal(image[(64*w+64)*4+3],255);assert.equal(image[(64*w+8)*4+3],0);
const p=landmarks.map(v=>[v.x,v.y,0,v.visibility]);const f={im:p,render_im:p,w:p,render_w:p,surface:{silhouette:restored}};
for(const [resolution,count] of Object.entries(VIVALDI_MESH_RESOLUTIONS)){
 const mesh=buildVivaldiFineMesh(f,null,{resolution,space:'2d'});assert.equal(mesh.vertex_count,count);
 assert(mesh.visible_vertices>=128,'at least some measured body surface');
 for(let i=0;i<mesh.vertex_count;i++)if(mesh.positions[i*4+3]>=.12)assert(pointInAthleteSilhouette(restored,mesh.positions[i*4],mesh.positions[i*4+1]),resolution+': visible vertex outside mask '+i);
 const world=buildVivaldiFineMesh(f,null,{resolution,space:'3d'});assert.equal(world.vertex_count,count);
}
// Unknown silhouette must prevent any synthetic 2D surface, not generate Hulk-like blobs.
assert.equal(paintVivaldiMesh2D({}, {...f,surface:{}},null),false);
const headless={save(){},restore(){},beginPath(){},moveTo(){},lineTo(){},closePath(){},fill(){},stroke(){}};
assert.equal(paintVivaldiMesh2D(headless,f,null,{width:400,height:400}),false,'without a canvas scratch renderer measured surface cannot be painted');
console.log('PASS tracked athlete mask, nearby-person rejection, serialization, all three LODs and conservative fallback');
