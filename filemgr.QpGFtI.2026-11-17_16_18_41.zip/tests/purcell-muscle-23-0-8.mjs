import assert from 'node:assert/strict';
import {assessMuscleChainDynamics} from '../purcell-muscle-dynamics.mjs';
const base=Array.from({length:45},(_,i)=>{
 const t=i/30,im=Array.from({length:33},()=>[.5,.5,0,.98]);
 for(const [id,x,y] of [[11,.4,.3],[12,.6,.3],[13,.37,.45],[14,.63,.45],[15,.33,.61],[16,.67,.61],[23,.43,.6],[24,.57,.6],[25,.43,.78],[26,.57,.78],[27,.43,.94],[28,.57,.94]])im[id]=[x+.008*Math.sin(t*8+i*.04),y+.012*Math.sin(t*4+i*.09),0,.99];
 return {t,im};
});
const original=JSON.stringify(base);
for(const chain of ['left_arm','right_arm','left_leg','right_leg','trunk']){
 const x=assessMuscleChainDynamics(base,{chain});
 assert.equal(x.available,true,`${chain}: sample adequate`);
 assert.equal(x.phase_explanations.length,5);
 assert.equal(x.relative_motion_levels.length,5);
 assert.ok(x.relative_motion_levels.every(n=>Number.isInteger(n)&&n>=0&&n<=3));
 assert.ok(x.kinematic_proxy_score>=0&&x.kinematic_proxy_score<=100);
 assert.ok(x.limitations.some(s=>s.includes('ЭМГ')));
}
assert.equal(JSON.stringify(base),original,'no input mutation');
const hidden=base.map(f=>({...f,im:f.im.map(p=>[p[0],p[1],p[2],0])}));
assert.equal(assessMuscleChainDynamics(hidden,{chain:'left_arm'}).available,false);
console.log('PASS: temporal proxy for 5 body chains, occlusion, limits and no frame mutation');
