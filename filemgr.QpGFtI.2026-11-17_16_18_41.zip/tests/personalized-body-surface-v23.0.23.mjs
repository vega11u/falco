import assert from 'node:assert/strict';
import {buildPersonalizedShapeProfile,buildPersonalizedBodyCloud,buildPersonalizedSurfaceClip,evaluatePersonalizedSurfaceFit,PERSONALIZED_BODY_SURFACE_VERSION} from '../personalized-body-surface-core.mjs';
const profileRow=()=>[[.19,.82],[.22,.84],[.24,.81],[.21,.79]];
const surface={zone_width_profile:{torso:[profileRow()],left_sleeve:[profileRow(),profileRow()],right_sleeve:[profileRow(),profileRow()],left_trouser:[profileRow(),profileRow()],right_trouser:[profileRow(),profileRow()]}};
function frame(t=0){const im=Array.from({length:33},()=>null),w=Array.from({length:33},()=>null);const xy={11:[.42,.25],12:[.58,.25],13:[.35,.38],14:[.65,.38],15:[.30,.50],16:[.70,.50],23:[.45,.52],24:[.55,.52],25:[.43,.70],26:[.57,.70],27:[.42,.90],28:[.58,.90]};for(const [id,p] of Object.entries(xy)){im[id]=[...p,0,.95];w[id]=[(p[0]-.5)*1.8,p[1]*1.8,(Number(id)%2)*.03,.95];}return {t,im,w,surface};}
const frames=Array.from({length:12},(_,i)=>frame(i/30));
const profile=buildPersonalizedShapeProfile(frames,{minObservations:8});
assert.equal(profile.schema,PERSONALIZED_BODY_SURFACE_VERSION);
assert.ok(profile.profile_confidence>.8);
const asymmetric=frames.map(f=>({...f,surface:{zone_width_profile:{...f.surface.zone_width_profile,right_sleeve:[[[.31,.9],[.32,.9],[.30,.9],[.29,.9]],[[.28,.9],[.29,.9],[.27,.9],[.26,.9]]]}}}));
const asymProfile=buildPersonalizedShapeProfile(asymmetric,{minObservations:8});
assert.ok(asymProfile.width_profile.right_arm_upper[0][0]>asymProfile.width_profile.left_arm_upper[0][0]+.08,'left/right athlete-specific asymmetry must not be averaged away');
const cloud=buildPersonalizedBodyCloud(frames[0],profile,{sides:8});
assert.ok(cloud.available);
assert.equal(cloud.point_count_2d,288);
assert.equal(cloud.point_count_3d,288);
assert.ok(cloud.points3d.every(p=>p[3]<=.48),'inferred hidden-side depth confidence must remain bounded');
const clip2=buildPersonalizedSurfaceClip(frames,profile,'2d',{samples:8,sides:4});
const clip3=buildPersonalizedSurfaceClip(frames,profile,'3d',{samples:8,sides:4});
assert.ok(clip2 && clip3);
assert.equal(clip2.frames_used,8);
assert.equal(clip3.frames_used,8);
const same=evaluatePersonalizedSurfaceFit(frames,frames,profile,{space:'3d'});
assert.ok(same.available && same.passed && same.score>99);
const altered=frames.map(f=>({...f,w:f.w.map(p=>Array.isArray(p)?p.slice():p)}));
for(const f of altered){f.w[13][0]=f.w[11][0]+(f.w[13][0]-f.w[11][0])*.45;f.w[13][1]=f.w[11][1]+(f.w[13][1]-f.w[11][1])*.45;}
const bad=evaluatePersonalizedSurfaceFit(frames,altered,profile,{space:'3d'});
assert.ok(bad.available && !bad.passed);
const withRender=frames.map(f=>({...f,render_im:f.im.map(p=>Array.isArray(p)?p.slice():p)}));
const altered2d=withRender.map(f=>({...f,im:f.im.map(p=>Array.isArray(p)?p.slice():p)}));
for(const f of altered2d){f.im[13][0]=f.im[11][0]+(f.im[13][0]-f.im[11][0])*.35;f.im[13][1]=f.im[11][1]+(f.im[13][1]-f.im[11][1])*.35;}
const bad2d=evaluatePersonalizedSurfaceFit(withRender,altered2d,profile,{space:'2d'});
assert.ok(bad2d.available && !bad2d.passed,'2D fit must evaluate canonical candidate coordinates, not stale render coordinates');
console.log('personalized-body-surface-v23.0.23: PASS',JSON.stringify({profile_confidence:profile.profile_confidence,asymmetric_right_arm_ratio:asymProfile.width_profile.right_arm_upper[0][0],cloud_points:cloud.point_count_3d,clip_points:clip3.point_count,fit:same.score,distorted_fit:bad.score,distorted_2d_fit:bad2d.score}));
