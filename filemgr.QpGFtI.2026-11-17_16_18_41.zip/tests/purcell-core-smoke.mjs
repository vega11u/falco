import assert from 'node:assert/strict';
import {
  rankPurcellExamples,
  buildPurcellDecisionLayer,
  applyPurcellRecommendations
} from '../purcell-core.mjs';

function makeSignature(wristReach=0.72) {
  const pose=[
    [-.30,-1,0],[.30,-1,0],[-.43,-.62,0],[.43,-.62,0],[-wristReach,-.42,0],[wristReach,-.42,0],
    [-.12,0,0],[.12,0,0],[-.14,.65,0],[.14,.65,0],[-.15,1.25,0],[.15,1.25,0],
    [-.17,1.30,0],[.17,1.30,0],[-.23,1.28,0],[.23,1.28,0]
  ];
  const out=[];
  for(let t=0;t<8;t++)for(const p of pose)out.push(...p);
  return out;
}
function makeFrame(t) {
  const im=Array.from({length:33},()=>[.5,.5,0,1]);
  im[11]=[.44,.35,0,1];im[12]=[.56,.35,0,1];
  im[13]=[.46,.43,0,1];im[14]=[.54,.43,0,1];
  im[15]=[.47,.50,0,1];im[16]=[.53,.50,0,1];
  im[23]=[.46,.55,0,1];im[24]=[.54,.55,0,1];
  im[25]=[.45,.70,0,1];im[26]=[.55,.70,0,1];
  im[27]=[.44,.85,0,1];im[28]=[.56,.85,0,1];
  im[29]=[.43,.86,0,1];im[30]=[.57,.86,0,1];
  im[31]=[.42,.85,0,1];im[32]=[.58,.85,0,1];
  return {t,sample_index:Math.round(t*10),im,w:[]};
}

const signature=makeSignature(.76);
const exact=rankPurcellExamples(signature,[{
  id:'good-1',label:'gyaku-zuki',kind:'hand_strike',style:'shotokan',rating:5,
  good_parts:['arms','trunk'],features:signature
}],{kind:'hand_strike',style:'shotokan',patternLabel:'gyaku-zuki'});
assert.equal(exact[0]?.similarity,100,'identical reviewed example should rank first');

const genericBiomechanics=rankPurcellExamples(signature,[{
  id:'generic-1',label:'Опора → таз → плечо',kind:'biomechanics',style:'unspecified',rating:5,
  good_parts:['hips','trunk'],features:signature
}],{kind:'hand_strike',style:'shotokan',patternLabel:'gyaku-zuki'});
assert.equal(genericBiomechanics[0]?.id,'generic-1','general biomechanics samples must be available for specialized actions');
const genericVsTechnique=rankPurcellExamples(signature,[{
  id:'special-1',label:'gyaku-zuki',kind:'hand_strike',style:'shotokan',rating:5,features:signature
},{
  id:'generic-1',label:'Опора → таз → плечо',kind:'biomechanics',style:'unspecified',rating:5,features:signature
}],{kind:'hand_strike',style:'shotokan',patternLabel:'gyaku-zuki'});
assert.equal(genericVsTechnique[0]?.id,'special-1','specific technique must outrank otherwise identical generic sample');

const cue={
  kind:'hand_strike',priority:1,confidence:.82,
  title:'Проверить траекторию ударной руки',
  why:'В текущем повторе отклонение составляет 0.52 условной длины корпуса.',
  action:'Сопоставьте плечо, локоть и кисть с направлением техники.',
  time_s:.5,pattern:'gyaku-zuki',functional_chain:'опора → таз → корпус → плечо → локоть → кисть'
};
const plan={available:true,recommendations:[cue],patterns:[],transitions:[]};
const window={time_s:.5,start_s:.2,end_s:.8,kind:'hand_strike',nextKind:'hand_strike',signature};
const decision=buildPurcellDecisionLayer({
  plan,examples:[{id:'good-1',label:'gyaku-zuki',kind:'hand_strike',style:'shotokan',rating:5,good_parts:['arms','trunk'],features:signature}],
  feedback:[],windows:[window],style:'shotokan',aspect:16/9,
  knowledge:{
    technique_mappings:[{name_ru:'Гяку-цуки',kind:'hand_strike',aliases:['gyaku-zuki'],functional_chain:['опора','таз','корпус','ударная рука'],phases:['разворот','ускорение','возврат'],muscle_groups:['glute_max','triceps'],principles:[]}],
    muscle_groups:{glute_max:{name_ru:'большая ягодичная',role:'разгибание бедра'},triceps:{name_ru:'трёхглавая мышца плеча',role:'разгибание локтя'}}
  }
});
assert.equal(decision.recommendations.length,1);
assert.equal(decision.recommendations[0].correctionAvailable,true,'high-similarity positive reference enables a correction');
assert.equal(decision.recommendations[0].technique_name,'Гяку-цуки');
assert.equal(decision.recommendations[0].muscle_context.length,2,'technique knowledge should explain typical muscle groups without claiming measured activation');
const wrongVotes=buildPurcellDecisionLayer({
  plan,examples:[{id:'good-1',label:'gyaku-zuki',kind:'hand_strike',style:'shotokan',rating:5,good_parts:['arms'],features:signature}],
  feedback:[{decision:'wrong',kind:'hand_strike',title:cue.title},{decision:'wrong',kind:'hand_strike',title:cue.title}],
  windows:[window],style:'shotokan',knowledge:{}
});
assert.equal(wrongVotes.recommendations.length,0,'repeated user error votes should suppress a similar recommendation');
const acceptableVotes=buildPurcellDecisionLayer({
  plan,examples:[{id:'good-1',label:'gyaku-zuki',kind:'hand_strike',style:'shotokan',rating:5,good_parts:['arms'],features:signature}],
  feedback:[{decision:'acceptable',kind:'hand_strike',title:cue.title}],
  windows:[window],style:'shotokan',knowledge:{}
});
assert.equal(acceptableVotes.recommendations[0].user_vote_summary.acceptable,1,'neutral/acceptable user ratings should be remembered');

const frames=Array.from({length:11},(_,i)=>makeFrame(i/10));
const originalWrist=frames[5].im[15].slice();
const originalKnee=frames[5].im[25].slice();
const applied=applyPurcellRecommendations(frames,decision.recommendations,{aspect:16/9});
assert.ok(applied.changedFrames>0,'a local reference correction should alter some frames');
assert.ok(applied.changedLandmarks>0,'a local reference correction should alter selected joints');
assert.deepEqual(frames[5].im[15],originalWrist,'source frames must remain immutable');
assert.deepEqual(applied.frames[5].im[25],originalKnee,'unselected body regions must remain unchanged');
assert.notDeepEqual(applied.frames[5].im[15],originalWrist,'selected wrist should move toward the reviewed reference');
assert.equal(applied.frames[0],frames[0],'frames outside the correction window should retain their original references');

const antiExampleOnly=buildPurcellDecisionLayer({
  plan,examples:[{id:'anti-1',label:'bad gyaku-zuki',kind:'hand_strike',style:'shotokan',rating:1,problem_parts:['arms'],notes:'Локоть уходит в сторону, корпус не связан с опорой.',features:signature}],
  feedback:[],windows:[window],style:'shotokan'
});
assert.equal(antiExampleOnly.recommendations[0].correctionAvailable,false,'an anti-example must never be used as a positive avatar target');
const noReference=buildPurcellDecisionLayer({plan,examples:[],feedback:[],windows:[window],style:'shotokan'});
assert.equal(noReference.recommendations[0].correctionAvailable,false,'no positive reference must never fabricate a pose');
const noOp=applyPurcellRecommendations(frames,noReference.recommendations,{aspect:16/9});
assert.equal(noOp.changedLandmarks,0);
assert.equal(noOp.frames,frames,'no-op should not clone or rewrite the source sequence');

const lowConfidence=buildPurcellDecisionLayer({
  plan:{available:true,recommendations:[{...cue,confidence:.2}]},
  examples:[{id:'good-1',label:'gyaku-zuki',kind:'hand_strike',style:'shotokan',rating:5,features:signature}],
  feedback:[],windows:[window],style:'shotokan'
});
assert.equal(lowConfidence.recommendations.length,0,'low-confidence generic cues must be filtered out');

console.log('Purcell core: reference ranking, correction bounds, immutability and no-fabrication gates PASS');
