<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/purcell-search-memory.php';
$dir=sys_get_temp_dir().'/falco-spatial-memory-'.bin2hex(random_bytes(5));mkdir($dir,0700,true);
try {
 $rows=[];
 for($i=1;$i<=1000;$i++)$rows[]=['id'=>'hyp-'.str_pad((string)$i,4,'0',STR_PAD_LEFT),'family'=>'trunk:counter_rotate','score'=>79.5,'passed'=>true,'engine_score'=>80.0,'objective_scores'=>['economy'=>71.3,'speed'=>83.8,'coherence'=>92.2], 'gravity_score'=>69.5, 'spatial_reliability'=>.91,'muscle_chain'=>'trunk'];
 $two=fj_purcell_search_memory($dir,'POST',['action'=>'save_run','unit_name'=>'Sanchin','modality'=>'2d','candidates'=>$rows]);
 $three=fj_purcell_search_memory($dir,'POST',['action'=>'save_run','unit_name'=>'Sanchin','modality'=>'3d','candidates'=>$rows]);
 if($three['run_id']===$two['run_id'])throw new RuntimeException('3D and 2D memory run ids must be independent');
 fj_purcell_search_memory($dir,'POST',['action'=>'select','run_id'=>$three['run_id'],'candidate_id'=>'hyp-0001','comment'=>'Устойчивый таз']);
 fj_purcell_search_memory($dir,'POST',['action'=>'reject_candidate','run_id'=>$two['run_id'],'candidate_id'=>'hyp-0001']);
 $stored=fj_purcell_search_memory($dir,'GET');
 if(count($stored['runs'])!==2)throw new RuntimeException('Both runs missing');
 [$r2,$r3]=$stored['runs'];
 if($r2['schema']!=='purcell-wide-search-v3-10000-archive-top1000'||$r2['modality']!=='2d'||$r3['schema']!=='purcell-spatial-v2-10000-archive-top1000'||$r3['modality']!=='3d')throw new RuntimeException('Modality schema crossed');
 if(($r2['candidates'][0]['user_rejected']??false)!==true||($r2['selected_candidate']??null)!==null||($r3['selected_candidate']??null)!=='hyp-0001')throw new RuntimeException('Selection or rejection crossed 2D / 3D');
 if(($r3['candidates'][0]['gravity_score']??null)!==69.5||($r3['candidates'][0]['spatial_reliability']??null)!==.91)throw new RuntimeException('3D quality data lost');
 if(count($r2['candidates'])!==1000||count($r3['candidates'])!==1000)throw new RuntimeException('Candidate count mismatch');
 echo "PASS private 2D / 3D memory isolated, 2000 candidates, selection/rejection, gravity scores preserved\n";
} finally {foreach(glob($dir.'/*')?:[] as $path)@unlink($path);@rmdir($dir);}
