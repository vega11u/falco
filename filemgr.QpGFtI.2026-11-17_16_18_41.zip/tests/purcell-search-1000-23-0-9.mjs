import assert from 'node:assert/strict';
import {generateCandidate1000,candidateDefinition1000} from '../purcell-search-core.mjs';
import {detectKataPauses,linkageAtTime} from '../kata-pause-core.mjs';
import {auditAvatarReality,safeAvatarFramePair} from '../pose-reality-core.mjs';
const base=Array.from({length:33},(_,j)=>[.2+(j%7)*.08,.15+Math.floor(j/7)*.13,0,1]);
// A plausible, non-collapsing pose fixture with the major 2D joints set explicitly.
const xy={11:[.43,.28],12:[.57,.28],13:[.38,.43],14:[.62,.43],15:[.34,.57],16:[.66,.57],23:[.46,.52],24:[.54,.52],25:[.45,.68],26:[.55,.68],27:[.44,.85],28:[.56,.85],29:[.43,.89],30:[.57,.89],31:[.42,.91],32:[.58,.91]};
for(const [id,point] of Object.entries(xy))base[Number(id)]=[...point,0,1];
const fixture=Array.from({length:81},(_,i)=>{
  const p=base.map(q=>q.slice());const moving=i>=21&&i<=41||i>=55&&i<=70;
  const amplitude=moving?.027*Math.sin((i-21)*.35):0;
  for(const j of [13,14,15,16])p[j][0]+=amplitude;
  return {t:i/30,im:p,w:[],camera_segment_id:0};
});
const original=JSON.stringify(fixture);
const pauses=detectKataPauses(fixture);
assert.ok(pauses.pauses.length>=1,`pause detection: ${JSON.stringify(pauses)}`);
assert.ok(pauses.linkages.length>=1);
assert.ok(linkageAtTime(pauses,1)?.end_s>linkageAtTime(pauses,1)?.start_s);
const reality=auditAvatarReality(fixture);
assert.equal(reality.checked,fixture.length);
assert.equal(reality.invalid_count,0);
const glitched=fixture.map(f=>({...f,im:f.im.map(p=>p.slice())}));
glitched[35].im[15][0]=.99;glitched[35].im[15][1]=.01;
const flagged=auditAvatarReality(glitched);
assert.ok(flagged.invalid_indices.includes(35),JSON.stringify(flagged.flags));
for(const i of flagged.invalid_indices)glitched[i].avatar_render_invalid=true;
assert.ok(safeAvatarFramePair(glitched,35)?.im);
const seen=new Set(),styles=new Set(),groups=new Set();let passed=0;let failed=0;
for(let i=0;i<1000;i++){
 const def=candidateDefinition1000(i);assert.ok(!seen.has(def.id));seen.add(def.id);styles.add(def.mode);groups.add(def.chain);
 const c=generateCandidate1000(fixture.slice(0,60),i);
 assert.equal(c.id,def.id);
 assert.deepEqual(c.frames[0].im,fixture[0].im);
 assert.deepEqual(c.frames.at(-1).im,fixture[59].im);
 assert.ok(c.metrics&&Number.isFinite(c.score));
 if(c.passed)passed++;else failed++;
}
assert.equal(seen.size,1000);assert.equal(groups.size,5);assert.ok(styles.size>=15);
assert.ok(passed+failed===1000);
const sample=generateCandidate1000(fixture.slice(0,60),0),biased=generateCandidate1000(fixture.slice(0,60),0,{memory:[{family:candidateDefinition1000(0).family,decision:'select'}]});
assert.notDeepEqual(sample.frames[29].im,biased.frames[29].im);
assert.equal(JSON.stringify(fixture),original);
console.log(`PASS 1000 variations, ${styles.size} trajectory modes, ${passed} passing numerical plausibility constraints, pause boundaries, pose anomaly guard, untouched original`);
