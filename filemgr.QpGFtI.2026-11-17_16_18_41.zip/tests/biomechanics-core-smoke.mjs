import assert from 'node:assert/strict';
import { assessPoseSequence, optimizeKinematicTrajectory, estimatePose3DNormalization, estimateFootLiftAtFrame, stabilizeFootLandmarkOutliers, analyzeNextMovementReadiness } from '../biomechanics-core.mjs';

function syntheticFrames(n=90) {
  const frames=[];
  for(let i=0;i<n;i++){
    const t=i/30, noise=(id)=>Math.sin(i*2.17+id*1.91)*.0018;
    const im=Array.from({length:33},(_,id)=>[NaN,NaN,NaN,0]);
    const w=Array.from({length:33},(_,id)=>[NaN,NaN,NaN,0]);
    const p={
      11:[.43,.25],12:[.57,.25],13:[.34,.34],14:[.66,.34],15:[.27,.40+.035*Math.sin(t*6)],16:[.73,.40-.035*Math.sin(t*6)],
      23:[.46,.48],24:[.54,.48],25:[.43,.65],26:[.57,.65],27:[.42,.84],28:[.58,.84],29:[.40,.86],30:[.60,.86],31:[.38,.87],32:[.62,.87]
    };
    for(const [key,xy] of Object.entries(p)){
      const id=Number(key), confidence=(id===15||id===16)?.72:.96;
      const x=xy[0]+noise(id),y=xy[1]+noise(id+1);
      im[id]=[x,y,0,confidence];
      w[id]=[(x-.5)*.6,(y-.48)*1.4,Math.sin(t*2+id)*.006,confidence];
    }
    // Explicitly preserve the support foot coordinates across stance frames.
    frames.push({t,sample_index:i,im,w});
  }
  return frames;
}


const frames=syntheticFrames();
// Regression for the reported footLift ReferenceError: the peak-event value is recomputed
// in the event scope, not leaked from the per-frame active predicate callback.
const liftFrames=frames.map((f,i)=>({ ...f, im:f.im.map(p=>p.slice()) }));
for(let i=0;i<liftFrames.length;i++){
  const lift=i>=35&&i<=55?.12:0;
  for(const id of [29,31])liftFrames[i].im[id][1]-=lift;
}
const baselineLift=estimateFootLiftAtFrame(liftFrames,10,'left');
const peakLift=estimateFootLiftAtFrame(liftFrames,45,'left');
assert(Number.isFinite(baselineLift)&&Number.isFinite(peakLift),'foot-lift proxy must always be a finite value when heel/toe/hip are visible');
assert(peakLift>baselineLift+.08,'peak foot lift must be measured from the peak frame, independently of candidate-detection callback scope');
assert(Math.abs(estimateFootLiftAtFrame(liftFrames,45,'right'))<.015,'unlifted contralateral foot should have a near-neutral lift proxy despite detector jitter');
// A single low-confidence heel/toe jump is repaired, while high-confidence fast motion is untouched.
const noisyFeet=syntheticFrames(9).map(f=>({...f,im:f.im.map(p=>p.slice()),w:f.w.map(p=>p.slice())}));
noisyFeet[4].im[31][0]+=.12; noisyFeet[4].im[31][3]=.20;
const beforeSpike=noisyFeet[4].im[31][0];
const repairStats=stabilizeFootLandmarkOutliers(noisyFeet);
assert(repairStats.repaired>=1,'isolated low-confidence foot landmark spikes should be repaired');
assert(Math.abs(noisyFeet[4].im[31][0]-beforeSpike)>.04,'outlier repair should move the isolated bad foot sample toward temporal interpolation');
const confidentFeet=syntheticFrames(9).map(f=>({...f,im:f.im.map(p=>p.slice()),w:f.w.map(p=>p.slice())}));
confidentFeet[4].im[31][0]+=.12; confidentFeet[4].im[31][3]=.99;
const confidentBefore=confidentFeet[4].im[31][0];
stabilizeFootLandmarkOutliers(confidentFeet);
assert.equal(confidentFeet[4].im[31][0],confidentBefore,'high-confidence fast foot motion must never be smoothed by the outlier filter');
const worldScale=estimatePose3DNormalization(frames,16/9);
assert(Number.isFinite(worldScale)&&worldScale>0,'3D avatar normalizer must always return a finite positive scale');
const noWorldFrames=frames.map(f=>({...f,w:null}));
const imageScale=estimatePose3DNormalization(noWorldFrames,16/9);
assert(Number.isFinite(imageScale)&&imageScale>0,'2D fallback normalizer must return a finite positive scale');
assert.equal(estimatePose3DNormalization([],16/9),1,'empty input must use neutral scale');
const partialNorm=estimatePose3DNormalization(frames.map(f=>({...f,w:Array.from({length:33},()=>[NaN,NaN,NaN,0])})),16/9);
assert(Number.isFinite(partialNorm)&&partialNorm>0,'partial/empty world landmarks must never throw');
frames[20].im[0]=[.50,.12,0,.98]; // facial landmarks are outside the biomechanical refinement target
const quality=assessPoseSequence(frames);
assert.equal(quality.frames,frames.length);
assert(quality.score>=70,`unexpected quality score ${quality.score}`);
assert.equal(quality.suitability.optimization,'candidate_allowed');
const duplicateTimeline=frames.map((f,i)=>({...f,t:i===40?frames[39].t:f.t}));
const duplicateQuality=assessPoseSequence(duplicateTimeline);
assert.equal(duplicateQuality.suitability.optimization,'blocked_or_manual_review','duplicated source timestamps must block kinematic optimization');
const failedInferenceQuality=assessPoseSequence(frames,{sourceDiagnostics:{decodedSamples:90,frameRecordsWritten:90,inferenceFailedFrames:4}});
assert.equal(failedInferenceQuality.frame_pipeline.record_count_matches_source_samples,true);
assert.equal(failedInferenceQuality.suitability.optimization,'blocked_or_manual_review','frequent MediaPipe inference failures must block trajectory refinement');
const brokenPipeline=assessPoseSequence(frames,{sourceDiagnostics:{decodedSamples:90,frameRecordsWritten:89,inferenceFailedFrames:0}});
assert.equal(brokenPipeline.frame_pipeline.record_count_matches_source_samples,false);
assert.equal(brokenPipeline.suitability.optimization,'blocked_or_manual_review','mismatched decoded/record frame counts must block optimization');
const splitTimeline=frames.map((f,i)=>({...f,t:i<45?f.t:f.t+5}));
const splitQuality=assessPoseSequence(splitTimeline,{segmentBreakBeforeTimes:[splitTimeline[45].t]});
assert.equal(splitQuality.suitability.optimization,'candidate_allowed','explicitly separated user ranges must not be misclassified as dropped frames');

const support=frames.map((f)=>({side:'left',confidence:.9}));
const eventTimes=[.5,1.0,1.5,2.0];
const originalJSON=JSON.stringify(frames);
const result=await optimizeKinematicTrajectory({frames,supportTrack:support,eventTimes,goal:'balanced',quality});
assert.equal(JSON.stringify(frames),originalJSON,'optimizer must not mutate source frames');
assert.equal(result.frames.length,frames.length);
assert(result.stats.objective_improved,'synthetic noisy signal should improve its acceleration objective');
assert(result.stats.acceleration_reduction_pct>0);
assert(result.stats.maximum_image_shift_normalized<=.0060001);
assert(result.stats.maximum_world_shift_m<=.0100001);
assert.equal(result.frames[0].t,frames[0].t);
assert.equal(result.frames.at(-1).t,frames.at(-1).t);
assert.equal(result.frames[0].im[15][0],frames[0].im[15][0]);
assert.equal(result.frames[45].im[15][0],frames[45].im[15][0]);
// Contact anchors must leave the left ankle/heel/toe exactly unchanged.
for(let i=0;i<frames.length;i++)for(const id of [27,29,31])assert.deepEqual(result.frames[i].im[id],frames[i].im[id]);
assert.deepEqual(result.frames[20].im[0],frames[20].im[0],'facial landmarks must not be altered by biomechanics refinement');
if(result.stats.objective_improved&&Number.isFinite(result.stats.bone_length_relative_mad_before)&&Number.isFinite(result.stats.bone_length_relative_mad_after))assert(result.stats.bone_length_relative_mad_after<=result.stats.bone_length_relative_mad_before*1.05+1e-6,'bone-length dispersion must remain within the acceptance tolerance');

const low=frames.map(f=>({...f,im:f.im.map((p,id)=>[p[0],p[1],p[2],id===11||id===12||id===23||id===24?.15:0])}));
const lowQ=assessPoseSequence(low);
await assert.rejects(()=>optimizeKinematicTrajectory({frames:low,supportTrack:[],quality:lowQ}),/Качество или временная целостность/);

const partial=frames.map((f,i)=>i%4===0?({...f,im:f.im.map((p,id)=>id>=25&&id<=32?[NaN,NaN,NaN,0]:p)}):f);
const partialQ=assessPoseSequence(partial);
assert(partialQ.frame_coverage.feet<quality.frame_coverage.feet,'feet visibility should be penalized independently');


// Hand joints participate in next-phase analysis and survive biomechanical refinement.
const handsFrames=frames.map((f,i)=>{
  const local=Array.from({length:21},(_,id)=>[(id%5)*.008+Math.sin(i*.17+id)*.030,Math.floor(id/5)*.009,Math.sin(i*.11+id*.2)*.018,.72]);
  local[0]=[0,0,0,.86];
  return {...f,hands:[{pose_side:null,landmarks:local.map(p=>[.27+p[0],.40+p[1],p[2],p[3]]),world_landmarks:local.map(p=>[p[0],p[1],p[2],p[3]])}]};
});
const readiness=analyzeNextMovementReadiness(handsFrames);
assert.ok(readiness.groups.hands,'next-phase analysis must include a separate hands group');
assert.ok(readiness.groups.hands.usable_future_vectors>0,'finger joints must contribute to future-motion continuity diagnostics');
assert.ok(Array.isArray(readiness.groups.hands.motion_onsets),'next-phase analysis must expose measured movement onset candidates for protected anchoring');
const handsOptimized=await optimizeKinematicTrajectory({frames:handsFrames,supportTrack:support,eventTimes,goal:'balanced',quality});
assert.equal(handsOptimized.frames[20].hands[0].landmarks.length,21,'optimized frames must preserve all hand landmarks');
assert.equal(handsOptimized.frames[20].hands[0].world_landmarks.length,21,'optimized frames must preserve all world-space finger landmarks');
assert.equal(handsOptimized.frames[20].hands[0].pose_side,'left','unassigned hands must be associated with the closest Pose wrist before refinement');
assert.ok('future_continuity_acceptable' in handsOptimized.stats,'optimizer must report its next-movement continuity guard');
assert.ok('detected_motion_onset_anchors' in handsOptimized.stats,'optimizer must report how many observed movement starts were anchored');
assert.ok(handsOptimized.stats.next_movement_readiness_before?.groups?.hands,'optimizer must include the hand/finger next-phase diagnostics in its report');
assert.equal(handsOptimized.stats.hand_geometry_acceptable,true,'hand/finger correction must pass the 3D geometry guard');
assert.ok('hand_geometry_image_relative_mad_before' in handsOptimized.stats,'optimizer must expose the 2D fallback hand-geometry check');
const imageOnlyHands=handsFrames.map(f=>({...f,hands:f.hands.map(h=>({...h,world_landmarks:[]}))}));
const imageHandsOptimized=await optimizeKinematicTrajectory({frames:imageOnlyHands,supportTrack:support,eventTimes,goal:'balanced',quality:assessPoseSequence(imageOnlyHands)});
assert.equal(imageHandsOptimized.stats.hand_geometry_acceptable,true,'2D-only hand data must still receive a geometry check when 3D hand landmarks are unavailable');
assert.ok(Number.isFinite(imageHandsOptimized.stats.hand_geometry_image_relative_mad_before),'2D-only hand geometry baseline must be measurable');

console.log(`Biomechanics core smoke tests: PASS (quality ${quality.score}/100; acceleration reduction ${result.stats.acceleration_reduction_pct}%)`);
