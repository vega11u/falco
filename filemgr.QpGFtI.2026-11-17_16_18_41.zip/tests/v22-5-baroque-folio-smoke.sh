#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
exec bash "$ROOT/tests/v23-frutiger-aero-smoke.sh"
