import assert from 'node:assert/strict';
import {reconstructBodySequence,BODY_RECONSTRUCTION_VERSION} from '../body-reconstruction-core.mjs';
const positions={11:[-.18,-.30,-.12],12:[.18,-.30,.12],13:[-.30,-.10,-.07],14:[.30,-.10,.09],15:[-.40,.12,-.10],16:[.40,.12,.14],17:[-.42,.15,-.10],18:[.42,.15,.14],19:[-.45,.17,-.12],20:[.45,.17,.16],21:[-.47,.17,-.12],22:[.47,.17,.16],23:[-.14,.08,-.08],24:[.14,.08,.06],25:[-.16,.43,-.08],26:[.16,.43,.08],27:[-.16,.77,-.07],28:[.16,.77,.08],29:[-.17,.81,-.06],30:[.17,.81,.08],31:[-.20,.83,-.14],32:[.20,.83,.16]};
const frames=Array.from({length:100},(_,i)=>{
 const w=Array.from({length:33},()=>null),im=Array.from({length:33},()=>null);const cam=i<60?0:1;
 for(const [key,p] of Object.entries(positions)){const id=Number(key),move=i>=10&&i<=20&&id===15?(i-10)*.018:i>20&&id===15?.18:0,z=p[2]+(id%3)*.015;w[id]=[p[0]+move,p[1],z,.96];im[id]=[.5+(p[0]+move)*.52+cam*.05,.28+p[1]*.52,z,.96];}
 return {t:i/30,camera_segment_id:cam,im,w,render_depth_landmark_values:w.map(p=>p?(.3+p[2]*2):NaN),render_depth_agreement_values:w.map(p=>p?.95:0)};
});
frames[25].im[15]=null;frames[26].im[15]=null;
frames[36].w[16]=null;frames[37].w[16]=null;
frames[45].im[15]=[.02,.97,0,.55];
for(let i=70;i<=80;i++){frames[i].im[17]=null;frames[i].w[17]=null;}
const original=JSON.stringify(frames);
const result=reconstructBodySequence(frames,{aspect:1,maxGap:.16});
assert.equal(result.tracks.length,frames.length);assert.equal(result.diagnostics.schema,BODY_RECONSTRUCTION_VERSION);
assert.ok(result.tracks[25].im[15]&&result.tracks[26].im[15], 'project or interpolate short visible gap');
assert.ok(result.tracks[36].w[16]&&result.tracks[37].w[16], 'recover short world landmark gap');
assert.ok(result.tracks[45].im[15][0]>.15,'single-frame wrist outlier rejected');
assert.ok(!result.tracks[75].im[17]&&!result.tracks[75].w[17], 'long occlusion never fabricated');
assert.ok(result.tracks[10].im[15]&&result.tracks[20].im[15]);
assert.ok(result.tracks[20].im[15][0]-result.tracks[10].im[15][0]>.06,'fast monotonic motion preserved');
assert.ok(result.diagnostics.camera_segments>=2);assert.ok(result.diagnostics.spikes_rejected>=1);
assert.equal(JSON.stringify(frames),original,'raw input not mutated');
const ids=Object.keys(positions).map(Number);for(const f of result.tracks){for(const id of ids){const a=f.im[id],b=f.w[id];if(a)assert.ok(a.every(Number.isFinite));if(b)assert.ok(b.every(Number.isFinite));}}
console.log(`PASS body reconstruction: ${result.diagnostics.projected2d} im, ${result.diagnostics.projected3d} world, ${result.diagnostics.interpolated} gap fills, ${result.diagnostics.spikes_rejected} spikes, same cadence, no long-gap hallucination`);
