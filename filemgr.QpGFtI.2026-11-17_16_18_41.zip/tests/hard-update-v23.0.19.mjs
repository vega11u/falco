import assert from 'node:assert/strict';
import {
  purgeFalcoOriginCaches,
  buildHardUpdateUrl,
  stripHardUpdateMarker
} from '../hard-update-core-v23.0.19.mjs';

const deleted=[];
const cacheStorage={
  async keys(){return ['falco-app-v1','transformers-cache','onnx-wasm-cache'];},
  async delete(name){deleted.push(name);return true;}
};
const unregistered=[];
const serviceWorker={async getRegistrations(){return [
  {scope:'https://example.test/falco/',async unregister(){unregistered.push(this.scope);return true;}},
  {scope:'https://example.test/other/',async unregister(){unregistered.push(this.scope);return true;}},
  {scope:'https://other.test/',async unregister(){unregistered.push(this.scope);return true;}}
];}};
const result=await purgeFalcoOriginCaches({cacheStorage,serviceWorker,currentUrl:'https://example.test/falco/index.php?x=1'});
assert.deepEqual(deleted,['falco-app-v1','transformers-cache','onnx-wasm-cache']);
assert.deepEqual(result.deletedCacheNames,deleted);
assert.equal(result.cacheCountBefore,3);
assert.equal(result.serviceWorkersRemoved,1);
assert.deepEqual(unregistered,['https://example.test/falco/']);
assert.deepEqual(result.errors,[]);
assert.equal(result.browserHttpCacheAccessible,false);
assert.equal(result.cacheStorageAvailable,true);

const fresh=buildHardUpdateUrl('https://example.test/falco/index.php?report=abc#results',12345);
const parsed=new URL(fresh);
assert.equal(parsed.searchParams.get('report'),'abc');
assert.equal(parsed.searchParams.get('__falco_hard_update'),'12345');
assert.equal(parsed.hash,'#results');
assert.equal(stripHardUpdateMarker(fresh),'https://example.test/falco/index.php?report=abc#results');

// Core returns structured errors; the UI must refuse to claim a complete purge.
const failed=await purgeFalcoOriginCaches({cacheStorage:{async keys(){return ['locked'];},async delete(){throw new Error('denied');}},serviceWorker:null,currentUrl:'https://example.test/falco/'});
assert.equal(failed.errors.length,1);
assert.match(failed.errors[0].message,/denied/);
console.log('PASS HARD UPDATE: origin Cache Storage purge, scoped Service Worker unregister, URL cache-bust, marker cleanup, partial-failure reporting');
