<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/reconstruction-memory.php';
$pack=static fn(array $values):string=>base64_encode(pack('v*',...array_map(static fn($v)=>round(((float)$v+8)/16*65535),$values)));
$old=['features_q16'=>'legacy','id'=>'old'];
$both=fj_recon_optional_features(['features_2d'=>array_fill(0,384,0.5),'features_3d'=>array_fill(0,384,-0.5),'reconstruction_quality'=>['2d'=>.90,'3d'=>.72],'reconstruction_clip_2d'=>array_fill(0,8*33*4,.15),'reconstruction_clip_3d'=>array_fill(0,8*33*4,-.20)],$pack);
if(!isset($both['features_2d_q16'],$both['features_3d_q16'],$both['reconstruction_clip_2d_q16'],$both['reconstruction_clip_3d_q16'])||strlen($both['features_2d_q16'])<900||strlen($both['reconstruction_clip_3d_q16'])<2000)throw new RuntimeException('Missing 2D/3D packed features');
$only3=fj_recon_optional_features(['features_3d'=>array_fill(0,384,.2)],$pack);
$preserved=fj_recon_preserve_extra($old,$both);if(!isset($preserved['features_3d_q16'],$preserved['reconstruction_clip_3d_q16']))throw new RuntimeException('Previous optional features erased');
$stats=fj_recon_memory_counts([$old,$both,$only3]);
if($stats['total']!==3||$stats['legacy_only']!==1||$stats['reconstructed_3d']!==2||$stats['paired_2d_3d']!==1||$stats['3d_only']!==1||$stats['reconstructed_clips_2d']!==1||$stats['reconstructed_clips_3d']!==1)throw new RuntimeException('Legacy and new 3D memories not counted '.json_encode($stats));
try{fj_recon_optional_features(['features_3d'=>array_fill(0,380,0)],$pack);throw new RuntimeException('Invalid vector accepted');}catch(InvalidArgumentException $expected){}
try{fj_recon_optional_features(['reconstruction_clip_3d'=>array_fill(0,8*33*4-1,0)],$pack);throw new RuntimeException('Invalid clip accepted');}catch(InvalidArgumentException $expected){}
echo 'PASS legacy-only, 2D+3D, 3D-only optional features; full 8x33x4 reconstructed skeleton clips Q16; preservation; rejected invalid payloads'.PHP_EOL;
