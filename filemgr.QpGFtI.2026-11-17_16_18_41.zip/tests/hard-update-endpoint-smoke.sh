#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${1:-${FALCO_BASE_URL:-}}"
if [[ -z "$BASE_URL" ]]; then
  echo "Usage: bash tests/hard-update-endpoint-smoke.sh https://your-site.example" >&2
  exit 2
fi
BASE_URL="${BASE_URL%/}"
ORIGIN="$(printf '%s' "$BASE_URL" | sed -E 's#(https?://[^/]+).*#\1#')"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

code="$(curl -sS -D "$TMP/headers" -o "$TMP/body" -w '%{http_code}' -X POST \
  -H "Origin: $ORIGIN" -H 'Accept: application/json' -H 'Content-Type: application/json' \
  --data '{}' "$BASE_URL/index.php?api=hard-update-clear-cache")"
[[ "$code" == "200" ]] || { cat "$TMP/body"; echo "Expected 200, got $code" >&2; exit 1; }
grep -qi '^Clear-Site-Data: "cache"' "$TMP/headers"
grep -q '"clear_site_data":"cache"' "$TMP/body"

code="$(curl -sS -o "$TMP/get" -w '%{http_code}' "$BASE_URL/index.php?api=hard-update-clear-cache")"
[[ "$code" == "405" ]] || { echo "GET must be rejected with 405, got $code" >&2; exit 1; }

code="$(curl -sS -o "$TMP/cross" -w '%{http_code}' -X POST \
  -H 'Origin: https://hard-update-cross-origin.invalid' -H 'Content-Type: application/json' \
  --data '{}' "$BASE_URL/index.php?api=hard-update-clear-cache")"
[[ "$code" == "403" ]] || { echo "Cross-origin POST must be rejected with 403, got $code" >&2; exit 1; }

echo 'PASS HARD UPDATE endpoint: same-origin POST sends Clear-Site-Data; GET and cross-origin POST are rejected.'
