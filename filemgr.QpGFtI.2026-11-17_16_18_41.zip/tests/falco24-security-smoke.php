<?php
declare(strict_types=1);
$root=dirname(__DIR__);
require_once $root.'/security/request-origin.php';
$base=['HTTP_HOST'=>'falco.example:8443','HTTPS'=>'on','HTTP_SEC_FETCH_SITE'=>'same-origin'];
$cases=[
  [$base+['HTTP_ORIGIN'=>'https://falco.example:8443'],true,'same-origin'],
  [$base+['HTTP_REFERER'=>'https://falco.example:8443/index.php'],true,'same-origin referer'],
  [$base,true,'legacy client without source headers'],
  [$base+['HTTP_ORIGIN'=>'https://evil.example:8443'],false,'another host'],
  [$base+['HTTP_ORIGIN'=>'http://falco.example:8443'],false,'downgrade scheme'],
  [$base+['HTTP_ORIGIN'=>'https://falco.example:8444'],false,'another port'],
  [$base+['HTTP_ORIGIN'=>'https://falco.example'],false,'implicit wrong port'],
  [array_merge($base,['HTTP_ORIGIN'=>'https://falco.example:8443','HTTP_SEC_FETCH_SITE'=>'cross-site']),false,'fetch metadata blocks cross-site'],
  [array_merge($base,['HTTP_ORIGIN'=>'https://falco.example:8443','HTTP_SEC_FETCH_SITE'=>'same-site']),false,'fetch metadata blocks same-site subdomain'],
  [$base+['HTTP_ORIGIN'=>'https://attacker@falco.example:8443'],false,'origin with credentials'],
];
foreach($cases as [$server,$expected,$label]) {
    if(fj_api_same_origin($server)!==$expected)throw new RuntimeException('Origin policy failed: '.$label);
}
$installer=(string)file_get_contents($root.'/research/install_sources.php');
if (!str_contains($installer,"PHP_SAPI !== 'cli'") || !str_contains($installer,"http_response_code(403)")) throw new RuntimeException('Research installer not CLI-only');
if (!str_contains((string)file_get_contents($root.'/data/trained/.htaccess'),'Require all denied')) throw new RuntimeException('Research data not guarded');
if (!str_contains((string)file_get_contents($root.'/security/.htaccess'),'Require all denied')) throw new RuntimeException('Security source not guarded');
$rootAccess=(string)file_get_contents($root.'/.htaccess');
foreach(['data/trained','research','security','tests'] as $name) {
    if (!str_contains($rootAccess,$name))throw new RuntimeException('Apache policy missing '.$name);
}
$index=(string)file_get_contents($root.'/index.php');
if (!str_contains($index,"$"."method === 'POST' && !fj_api_same_origin("))throw new RuntimeException('Main POST origin guard not wired');
echo "Falco24 security regression: 10 origin cases, CLI-only guard, storage deny, POST policy: PASS\n";
