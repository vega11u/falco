<?php
declare(strict_types=1);
$root=dirname(__DIR__);$php=(string)file_get_contents($root.'/index.php');
// The production importer deliberately supports a strict allowlist.
// Do not add social services merely to satisfy a legacy UI smoke test:
// SSRF surface must not expand without a reviewed provider implementation.
$hosts=['youtube.com','www.youtube.com','youtu.be','instagram.com','www.instagram.com'];
foreach ($hosts as $host) {
    if (!str_contains($php, "'".$host."'")) throw new RuntimeException('Missing supported import host: '.$host);
}
preg_match('/\\$allowed\\s*=\\s*(\\[[^;]+\\])/', $php, $match);
if (empty($match[1])) throw new RuntimeException('Server allowlist not found');
foreach (['tiktok.com','vk.com','rutube.ru','x.com','facebook.com'] as $unapproved) {
    if (str_contains($match[1], "'".$unapproved."'")) {
        throw new RuntimeException('Unreviewed importer host: '.$unapproved);
    }
}
foreach (["type = 'youtube'", "type = 'instagram'", 'yt-dlp', 'Серверный импорт разрешён только для YouTube и Instagram'] as $token) {
    if (!str_contains($php, $token)) throw new RuntimeException('Import policy missing: '.$token);
}
$data=json_decode((string)file_get_contents($root.'/data/purcell-knowledge.json'),true,512,JSON_THROW_ON_ERROR);
foreach (['body_parts','functional_chains','muscle_roles','principles','decision_policy','knowledge_limits','baseline_rules'] as $key) {
    if (empty($data[$key])) throw new RuntimeException('Missing modern Purcell knowledge section: '.$key);
}
if (count($data['principles']) < 7) throw new RuntimeException('Expected movement principles missing.');
echo "Restricted YouTube/Instagram allowlist and biomechanical knowledge: PASS\\n";
