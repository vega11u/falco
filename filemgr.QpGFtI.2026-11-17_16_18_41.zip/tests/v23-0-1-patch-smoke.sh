#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
cd "$ROOT"
php -l index.php >/dev/null
node --check <(sed -n '/<script[^>]*>/,/<\/script>/p' index.php | sed '1d;$d') >/dev/null 2>&1 || true
! grep -q "stage.insertAdjacentElement('afterend',workspace)" index.php
grep -q "if(workspace)workspace.classList.add('clip-workspace-attached')" index.php
grep -q "Persist precisely the analyzed interval(s) for kata and sequence alike" index.php
! grep -q "Для подтверждения полного ката переключите режим" index.php
! grep -q '<section class="optimizer-player"' index.php
! grep -q 'id="optimizerCompareCanvas"' index.php
grep -q 'data-duration="${inferredReplayDuration}"' index.php
grep -q 'group.draftLabel=inp.value' index.php
grep -q 'group.draftKind=sel.value' index.php
grep -q 'Сохранить в библиотеку сервера' index.php
grep -q "\$('saveReportBtn').addEventListener('click',()=>saveReportToServer(false)" index.php
grep -q 'font-synthesis' falco-jugger-ui.css
grep -q 'clip-workspace-attached' falco-jugger-ui.css
echo 'Patch 23.0.1 compatibility contracts: PASS'
