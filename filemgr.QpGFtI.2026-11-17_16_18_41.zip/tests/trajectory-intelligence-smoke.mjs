import assert from 'node:assert/strict';
import {analyzeMovementPhases,applyPhaseRetimingCandidate} from '../trajectory-intelligence.mjs';
import {buildPurcellDecisionLayer,applyPurcellRecommendations} from '../purcell-core.mjs';
import {poseVectorAtTime} from '../kata-recognition-core.mjs';
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);};
function fixture({confidence=.97,cut=false,gap=false}={}){
  return Array.from({length:109},(_,i)=>{
    const t=i/60,im=Array.from({length:33},()=>[.5,.5,0,confidence]);
    im[11]=[.4,.3,0,confidence];im[12]=[.6,.3,0,confidence];im[23]=[.42,.6,0,confidence];im[24]=[.58,.6,0,confidence];
    // Two nearly straight outward bursts separated by an obvious short stall.
    const reach=.095*smooth((t-.2)/.25)+.24*smooth((t-.75)/.40);
    im[13]=[.37,.41,0,confidence];im[15]=[.32+reach,.46,0,confidence];
    im[14]=[.62,.43,0,confidence];im[16]=[.63,.54,0,confidence];
    im[17]=[im[15][0]-.01,.47,0,confidence];im[19]=[im[15][0]-.01,.45,0,confidence];im[21]=[im[15][0]+.01,.46,0,confidence];
    for(const id of [25,26])im[id]=[id===25?.42:.58,.75,0,confidence];
    for(const id of [27,28,29,30,31,32])im[id]=[id%2?.42:.58,.9,0,confidence];
    return {t,sample_index:i,camera_segment_id:cut&&i>=50?1:0,im};
  }).filter((f,i)=>!gap||i<40||i>50);
}
const frames=fixture(),window={start:0,end:1.8,kind:'hand_strike',label:'gyaku-zuki',confirmed:true,aspect:1};
const profile=analyzeMovementPhases(frames,window);
assert.equal(profile.available,true);
assert.equal(profile.effector,'left_hand');
assert.equal(profile.phases.length,5);
assert.ok(profile.metrics.peak_time_s>.8&&profile.metrics.peak_time_s<1.1);
assert.ok(profile.metrics.outbound_directness>.99);
assert.ok(Math.abs(profile.temporal_resolution_s-1/60)<1e-6);
assert.equal(profile.findings.length,1,'resolve a sustained stall between outward acceleration bursts');
assert.equal(analyzeMovementPhases(fixture({confidence:.3}),window).available,false,'occluded landmarks must not produce kinematic claims');
assert.equal(analyzeMovementPhases(fixture({cut:true}),window).available,false,'camera cut must not be bridged');
assert.equal(analyzeMovementPhases(fixture({gap:true}),window).available,false,'long temporal gap must not be bridged');
assert.equal(analyzeMovementPhases(frames,{...window,label:'mawashi-zuki'}).findings.length,0,'curved technique must not inherit straight-punch stall rule');
assert.equal(analyzeMovementPhases(frames,{...window,confirmed:false}).findings.length,0,'unreviewed label must not trigger a technique-specific correction');
const plan={available:true,recommendations:[],trajectory_analysis:{profiles:[profile]}};
const decision=buildPurcellDecisionLayer({plan,frames,metrics:[],examples:[],windows:[]});
assert.equal(decision.recommendations.length,1);
assert.equal(decision.recommendations[0].correction_mode,'phase_retiming_candidate');
assert.equal(decision.recommendations[0].correctionAvailable,true,'explicit timing hypotheses need no ideal-pose training example');
const saved=JSON.stringify(frames),applied=applyPurcellRecommendations(frames,decision.recommendations);
assert.ok(applied.changedFrames>0);
assert.equal(JSON.stringify(frames),saved,'measured source must be immutable');
assert.equal(applied.corrections[0].hypothesis,true);
for(let i=0;i<frames.length;i++){
  const a=frames[i],b=applied.frames[i];assert.equal(a.t,b.t);assert.deepEqual(a.im[11],b.im[11],'anchor preserved');assert.deepEqual(a.im[23],b.im[23],'support/body untouched');
  for(const [p,q] of [[11,13],[13,15]]){const length=f=>Math.hypot(f.im[p][0]-f.im[q][0],f.im[p][1]-f.im[q][1]);assert.ok(Math.abs(length(a)-length(b))<1e-10,'observed segment length must be preserved');}
}
assert.equal(applyPhaseRetimingCandidate(fixture({cut:true}),profile.findings[0].trajectory_candidate).changedFrames,0,'avatar proposal must reject cuts independently');
assert.equal(poseVectorAtTime(frames,10),null,'Lully cannot retrieve arbitrarily stale nearest pose');
const cut=fixture({cut:true});assert.equal(poseVectorAtTime(cut,49.5/60),null,'Lully cannot interpolate across a camera edit');
console.log('Phase intelligence: timestamps, phase gates, technique context, immutable bounded hypotheses, bone lengths and retrieval boundaries PASS');
