#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
echo 'The v21.12 regression suite is superseded by the v22 architecture checks.'
exec bash "$ROOT/tests/v22-smoke.sh"
