<?php
$root = dirname(__DIR__);
$load = static function (string $file) use ($root): array {
    $value = json_decode((string)file_get_contents($root . '/' . $file), true, 512, JSON_THROW_ON_ERROR);
    if (!is_array($value)) { throw new RuntimeException("Invalid JSON: $file"); }
    return $value;
};
$tax = $load('data/karate-technique-taxonomy.json');
$anat = $load('data/anatomy-functional-model.json');
$refs = $load('data/technique-reference-catalog.json');
$corpus = $load('data/real-training-corpus-manifest.json');
$app = (string)file_get_contents($root . '/index.php');
$styles = ['shotokan', 'shitoryu', 'gojuryu', 'ryueiryu'];
if (($tax['schema'] ?? '') !== 'kata-technique-taxonomy-v2' || ($tax['scope']['primary_styles'] ?? []) !== $styles) throw new RuntimeException('Taxonomy schema/style scope mismatch.');
if (!in_array('kyokushin', $tax['scope']['excluded_style_data'] ?? [], true)) throw new RuntimeException('Kyokushin exclusion missing.');
$entries = $tax['wkf_official_kata_list_2026'] ?? [];
if (count($entries) !== 102) throw new RuntimeException('Expected 102 official WKF kata entries.');
foreach ($entries as $i => $entry) if (($entry['wkf_number'] ?? null) !== $i + 1) throw new RuntimeException('WKF kata numbering mismatch.');
foreach (['stance_classes', 'hand_techniques', 'kicks', 'blocks', 'transitions'] as $key) if (empty($tax[$key])) throw new RuntimeException("Taxonomy section missing: $key");
$ms = $tax['research_dataset_class_inventory']['ms_kard_gojuryu_23'] ?? [];
if (($ms['published_dataset_claim']['classes'] ?? null) !== 23 || ($ms['style'] ?? '') !== 'gojuryu' || count($ms['classes'] ?? []) !== 23 || ($ms['dataset_availability'] ?? '') !== 'not_publicly_downloadable_verified') throw new RuntimeException('MS-KARD metadata mismatch.');
if (($anat['schema'] ?? '') !== 'karate-functional-anatomy-v1' || count($anat['muscle_groups'] ?? []) !== 24) throw new RuntimeException('Anatomy model mismatch.');
$conceptIds = array_column($anat['movement_concepts'] ?? [], 'id');
foreach (['coil_counter_rotation','proximal_distal_coordination','pull_push_hikite','knee_drive_chamber','support_foot_tripod','braking_recoil','myofascial_continuity_context'] as $concept) if (!in_array($concept, $conceptIds, true)) throw new RuntimeException("Biomechanical movement concept missing: $concept");
if (count($anat['optimization_decision_rules'] ?? []) < 7) throw new RuntimeException('Optimizer decision knowledge is incomplete.');
if (count($anat['functional_myofascial_continuities'] ?? []) < 5) throw new RuntimeException('Anatomy continuity model incomplete.');
if (empty($anat['neuromuscular_control_principles']['antagonist']) || empty($anat['connective_tissue_principles']['tendons']) || empty($anat['connective_tissue_principles']['ligaments']) || count($anat['optimization_safety_constraints'] ?? []) < 4) throw new RuntimeException('Functional muscle/tendon/ligament mechanics missing.');
$never = $anat['measurement_levels']['never_claim_from_single_monocular_video'] ?? [];
foreach (['measured_EMG', 'specific_myofascial_chain_activation', 'true_ground_reaction_force'] as $item) if (!in_array($item, $never, true)) throw new RuntimeException("Measurement limitation missing: $item");
if (($refs['scope']['primary_styles'] ?? []) !== $styles || count($refs['references'] ?? []) < 27 || count($refs['biomechanical_datasets'] ?? []) < 5) throw new RuntimeException('Research reference catalog mismatch.');
$referenceIds = array_column($refs['references'], 'id');
foreach (['hardmo_2024_motion_capture', 'hardmo_plus_plus_2026'] as $id) if (!in_array($id, $referenceIds, true)) throw new RuntimeException("Research reference missing: $id");
foreach (['kyokushin', 'oyama'] as $style) if (!in_array($style, $refs['scope']['excluded_training_style_data'] ?? [], true)) throw new RuntimeException("Excluded style missing: $style");
if (($corpus['training_pipeline']['actual_training_on_install'] ?? true) !== false || !str_contains((string)($corpus['training_pipeline']['pipeline_status'] ?? ''), 'research_inventory_only')) throw new RuntimeException('v19 must not claim automatic research-corpus training.');
$tokens = ['data/karate-technique-taxonomy.json', 'loadKarateTaxonomy()', 'kataNameSuggestions', 'karateTechniqueSuggestions', 'stanceLineageHint', 'refreshTechniqueSuggestions(sel.value)', 'shotokanTemporalPredictionForGroup', 'temporalHtml', 'myoarm_upper_limb', 'list="kataNameSuggestions"', 'list="karateTechniqueSuggestions"', "$('trainingStyle').addEventListener('change'"];
foreach ($tokens as $token) if (!str_contains($app, $token)) throw new RuntimeException("Runtime taxonomy integration missing: $token");
printf("Karate intelligence data smoke test passed: %d WKF entries; %d research references; %d datasets; %d anatomy groups.\n", count($entries), count($refs['references']), count($refs['biomechanical_datasets']), count($anat['muscle_groups']));
