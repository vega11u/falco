import assert from 'node:assert/strict';
import fs from 'node:fs';

const index = fs.readFileSync(new URL('../index.php', import.meta.url), 'utf8');
function extractFunction(name, prefix = 'function') {
  const start = index.indexOf(`${prefix} ${name}(`);
  assert.notEqual(start, -1, `Missing production function ${name}`);
  const end = index.indexOf('\n}\n', start);
  assert.notEqual(end, -1, `Could not delimit production function ${name}`);
  return index.slice(start, end + 2);
}

const isManagedSource = extractFunction('isManagedOpfsImportName');
const refreshSource = extractFunction('refreshManagedOpfsFile', 'async function');
const settleSource = extractFunction('settlePreparationWaiter');
const waitSource = extractFunction('waitForPreparedVideo');

const opfsNamePattern = new Function(`${isManagedSource}; return isManagedOpfsImportName;`)();
assert.equal(opfsNamePattern(`falco-import-${'a'.repeat(24)}.mp4`), true);
assert.equal(opfsNamePattern('../falco-import.mp4'), false);

const payload = new Uint8Array([0, 0, 0, 24, 102, 116, 121, 112, 105, 115, 111, 109, 0, 0, 2, 0]);
const snapshot = new File([payload], 'stored.mp4', { type: 'video/mp4', lastModified: 1234 });
const name = `falco-import-${'b'.repeat(24)}.mp4`;
let openedName = null;
const mockedNavigator = {
  storage: {
    async getDirectory() {
      return {
        async getFileHandle(requested, options) {
          openedName = requested;
          assert.deepEqual(options, { create: false });
          return { async getFile() { return snapshot; } };
        }
      };
    }
  }
};
const opfsState = { originalFile: new File([new Uint8Array(payload.byteLength)], 'old.mp4'), opfsImportName: name };
const refresh = new Function('state', 'navigator', 'isManagedOpfsImportName', 'File', `${refreshSource}; return refreshManagedOpfsFile;`)(opfsState, mockedNavigator, opfsNamePattern, File);
const refreshed = await refresh(opfsState.originalFile, name);
assert.equal(openedName, name);
assert.notEqual(refreshed, snapshot, 'The retry must produce a fresh named snapshot.');
assert.equal(refreshed.name, 'old.mp4');
assert.equal(refreshed.type, 'video/mp4');
assert.equal(refreshed.size, payload.byteLength);
assert.equal(opfsState.originalFile, refreshed, 'The state must retain the fresh retryable snapshot.');
assert.deepEqual(new Uint8Array(await refreshed.arrayBuffer()), payload);

function createWaiterHarness({ readyState = 0, demuxerUnavailable = false } = {}) {
  const state = { uploadToken: 7, demuxerUnavailable, preparationWaiter: null };
  const video = { readyState, duration: 2.4, videoWidth: 1920, videoHeight: 1080 };
  const factory = new Function('state', 'HTMLMediaElement', '$', `${settleSource}\n${waitSource}\nreturn { waitForPreparedVideo, settlePreparationWaiter };`);
  return { state, video, ...factory(state, { HAVE_FUTURE_DATA: 3 }, () => video) };
}

{
  const h = createWaiterHarness();
  const pending = h.waitForPreparedVideo(7, 500);
  assert.ok(h.state.preparationWaiter, 'A not-yet-ready player must install a waiter.');
  h.settlePreparationWaiter('ready');
  assert.equal(await pending, true);
  assert.equal(h.state.preparationWaiter, null);
}
{
  const h = createWaiterHarness();
  const pending = h.waitForPreparedVideo(7, 500);
  h.settlePreparationWaiter('failed', new Error('decoder failed'));
  await assert.rejects(pending, /decoder failed/);
  assert.equal(h.state.preparationWaiter, null);
}
{
  const h = createWaiterHarness({ readyState: 3 });
  assert.equal(await h.waitForPreparedVideo(7, 10), true, 'Already decoded video should not wait for a missed event.');
}
{
  const h = createWaiterHarness({ demuxerUnavailable: true });
  await assert.rejects(h.waitForPreparedVideo(7, 10), /Mediabunny недоступен/);
}
{
  const h = createWaiterHarness();
  await assert.rejects(h.waitForPreparedVideo(6, 10), /выбрано другое видео/);
}
{
  const h = createWaiterHarness();
  await assert.rejects(h.waitForPreparedVideo(7, 5), /canplay/);
  assert.equal(h.state.preparationWaiter, null);
}

assert.ok(index.includes('const useOpfs=expectedLength>memoryFallbackLimit'), 'Small social files must not be routed through OPFS.');
assert.ok(index.includes('state.mediaImportAck={id:started.id,sha256:fileHash}'), 'A pending server acknowledgement must be retained with the verified digest.');
assert.ok(index.indexOf('const accepted=await safeChooseFile(file') < index.indexOf('try{await acknowledgeMediaImport();}'), 'Server acknowledgement must follow successful browser preparation.');
assert.ok(index.includes("settlePreparationWaiter('ready')"), 'Only the actual canplay-ready event should settle the import readiness promise.');
assert.ok(index.includes('state.socialImportActive=true') && index.includes("if(state.socialImportActive){setStatus('Дождитесь завершения передачи и подготовки видео.'"), 'The import lock must prevent analysis and file selection races.');
assert.ok(index.includes('state.originalFile===state.mediaImportPreviousFile'), 'Retry must distinguish an old selected file from the newly downloaded server file.');
console.log('Social file lifecycle smoke passed: independent small-file Blob, refreshed large OPFS snapshot, readiness/timeout/cancel paths, and delayed server acknowledgement.');
