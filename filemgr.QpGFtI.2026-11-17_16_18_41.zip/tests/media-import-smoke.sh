#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
TMP="$(mktemp -d)"
PORT="$(php -r '$s=stream_socket_server("tcp://127.0.0.1:0",$e,$m); if(!$s) exit(1); $a=stream_socket_get_name($s,false); echo (int)substr(strrchr($a,":"),1); fclose($s);')"
PID=''
cleanup(){ if [[ -n "$PID" ]]; then kill -TERM "$PID" 2>/dev/null || true; for _ in $(seq 1 20); do kill -0 "$PID" 2>/dev/null || break; sleep 0.05; done; kill -KILL "$PID" 2>/dev/null || true; wait "$PID" 2>/dev/null || true; fi; rm -rf "$TMP"; }
trap cleanup EXIT
command -v php >/dev/null && command -v curl >/dev/null || { echo 'SKIP: PHP CLI and curl are required.'; exit 0; }
php -r 'exit(function_exists("proc_open") && !in_array("proc_open", array_map("trim", explode(",", (string)ini_get("disable_functions")))) ? 0 : 1);' || { echo 'SKIP: proc_open is disabled; media importer will use the configured CRON queue.'; exit 0; }

cat > "$TMP/fake-yt-dlp" <<'FAKE'
#!/usr/bin/env bash
set -Eeuo pipefail
out=''; url=''; profile=''; format=''
printf '%s\n' "$*" >> "$FAKE_ARGS_LOG"
while (($#)); do
  case "$1" in
    --output) out="$2"; shift 2 ;;
    --extractor-args) profile="$2"; shift 2 ;;
    --format) format="$2"; shift 2 ;;
    *) [[ "$1" == https://* ]] && url="$1"; shift ;;
  esac
done
[[ -n "$out" && -n "$url" ]]
key="$(printf '%s' "$url" | sha256sum | awk '{print $1}')"
counter="$FAKE_COUNT_DIR/$key.count"
n=0; [[ ! -f "$counter" ]] || n="$(cat "$counter")"; n=$((n+1)); printf '%s' "$n" > "$counter"
# Reproduce the reported default-client format failure and absence of an HLS playlist.
# Then verify that the alternate android_vr profile is actually reached. Instagram uses one profile.
if [[ "$url" == *youtube* || "$url" == *youtu.be* ]]; then
  if [[ "$url" == *abcdefghijk* ]]; then
    # Exercise all original profiles in their original order, then the new mweb fallback.
    if [[ "$n" -lt 5 ]]; then echo 'ERROR: [youtube] Simulated stream unavailable for this client'; exit 1;
    elif [[ "$n" -eq 5 && "$profile" == *mweb* ]]; then :
    else echo "ERROR: unexpected deep YouTube fallback $n / $profile"; exit 1; fi
  elif [[ "$n" -eq 1 ]]; then
    echo 'ERROR: [youtube] Requested format is not available. Use --list-formats for a list of available formats'
    exit 1
  elif [[ "$n" -eq 2 && "$profile" == *web_safari* ]]; then
    [[ "$format" == 'best[protocol^=m3u8]/bestvideo*[protocol^=m3u8]' ]] || { echo 'ERROR: Safari fallback was not constrained to HLS.'; exit 1; }
    echo 'ERROR: [youtube] No HLS formats were offered to web_safari.'
    exit 1
  elif [[ "$n" -eq 3 && "$profile" == *android_vr* ]]; then
    : # expected recovery profile
  else
    echo "ERROR: unexpected YouTube fallback order (attempt=$n profile=$profile format=$format)"
    exit 1
  fi
elif [[ "$url" == *instagram* && "$url" == *FGHJKL12345* ]]; then
  # First Instagram profile fails; second (iOS API app_id) must recover.
  if [[ "$n" -eq 1 ]]; then echo 'ERROR: [Instagram] simulated web endpoint rejected'; exit 1;
  elif [[ "$n" -eq 2 && "$profile" == 'instagram:app_id=ios' ]]; then :
  else echo "ERROR: unexpected Instagram fallback $n / $profile"; exit 1; fi
fi
out="${out//%(ext)s/mp4}"
mkdir -p "$(dirname "$out")"
# yt-dlp --verbose may print our progress and title templates as CLI argument text.
# These are NOT actual progress lines and must never reach user-visible status.
echo "[debug] Command-line config: ['--print', 'before_dl:KATA_TITLE:%(title)s', '--progress-template', 'download:KATA_PROGRESS:%(progress._percent_str)s|%(progress.downloaded_bytes)s']"
echo 'KATA_TITLE:Smoke Test Video'
echo 'KATA_PROGRESS:25.0%|1024|4096|00:00:01'
printf '\000\000\000\030ftypisom' > "$out"
dd if=/dev/zero bs=4084 count=1 status=none >> "$out"
echo 'KATA_PROGRESS:100.0%|4096|4096|00:00:00'
FAKE
chmod 700 "$TMP/fake-yt-dlp"
mkdir -p "$TMP/private-imports/bin" "$TMP/fake-counts"
cp "$TMP/fake-yt-dlp" "$TMP/private-imports/bin/yt-dlp"
printf '2026.10.26\n' > "$TMP/private-imports/bin/yt-dlp-stable-version.txt"
sha256sum "$TMP/private-imports/bin/yt-dlp" | awk '{print $1}' > "$TMP/private-imports/bin/yt-dlp-sha256.txt"
chmod 600 "$TMP/private-imports/bin/yt-dlp-stable-version.txt" "$TMP/private-imports/bin/yt-dlp-sha256.txt"
cat > "$TMP/private-imports/bin/qjs" <<'QJS'
#!/usr/bin/env sh
case "$1" in
  --version) echo '0.18.0' ;;
  -e) exit 0 ;;
  *) exit 0 ;;
esac
QJS
chmod 700 "$TMP/private-imports/bin/qjs"
printf '0.18.0\n' > "$TMP/private-imports/bin/qjs-version.txt"
QJS_FAKE_SHA="$(sha256sum "$TMP/private-imports/bin/qjs" | awk '{print $1}')"
printf '%s\n' "$QJS_FAKE_SHA" > "$TMP/private-imports/bin/qjs-sha256.txt"
printf 'quickjs-ng:0.18.0:%s\n' "$QJS_FAKE_SHA" > "$TMP/private-imports/bin/qjs-runtime-ok.txt"

export FAKE_COUNT_DIR="$TMP/fake-counts"
export FAKE_ARGS_LOG="$TMP/fake-args.log"
export KATA_YTDLP_PATH="$TMP/private-imports/bin/yt-dlp"
export KATA_QJS_PATH="$TMP/private-imports/bin/qjs"
export KATA_MEDIA_IMPORT_DIR="$TMP/private-imports"
# Match shared hosting without an FFmpeg executable: combined then video-only profiles.
export KATA_FFMPEG_PATH="$TMP/ffmpeg-not-installed"
php -S "127.0.0.1:$PORT" -t "$ROOT" "$ROOT/index.php" >"$TMP/php.log" 2>&1 &
PID=$!
BASE="http://127.0.0.1:$PORT/index.php"
for _ in $(seq 1 60); do if curl -fsS "$BASE?api=health" >/dev/null 2>&1; then break; fi; sleep .1; done

json_field(){ php -r '$x=json_decode($argv[1],true); if(!is_array($x)) exit(2); $v=$x[$argv[2]]??null; if(is_bool($v)) echo $v?"true":"false"; elseif(is_scalar($v)) echo $v; else echo "";' "$1" "$2"; }
COOKIE="$TMP/cookies.txt"; ORIGIN="http://127.0.0.1:$PORT"
HEALTH="$(curl -fsS -c "$COOKIE" -b "$COOKIE" "$BASE?api=health")"
[[ "$(json_field "$HEALTH" 'ok')" == 'true' && "$(php -r '$x=json_decode($argv[1],true); echo !empty($x["media_import"]["ready"])?"true":"false";' "$HEALTH")" == 'true' ]] || { echo "Media import health check failed: $HEALTH"; cat "$TMP/php.log"; exit 1; }
php -r '$x=json_decode($argv[1],true); if(empty($x["media_import"]["youtube_ready"]) || empty($x["media_import"]["instagram_ready"]) || empty($x["media_import"]["quickjs_sha256_verified"])) exit(1);' "$HEALTH" || { echo "Verified YouTube/Instagram runtime health failed: $HEALTH"; exit 1; }
# The PHP health endpoint must detect a replaced/corrupted qjs binary, even when
# the old version/readiness markers remain present. Instagram must stay available.
cp "$TMP/private-imports/bin/qjs" "$TMP/qjs-valid"
printf '\n#tampered\n' >> "$TMP/private-imports/bin/qjs"
TAMPERED_HEALTH="$(curl -fsS -c "$COOKIE" -b "$COOKIE" "$BASE?api=health")"
php -r '$x=json_decode($argv[1],true); if(!empty($x["media_import"]["youtube_ready"]) || empty($x["media_import"]["instagram_ready"]) || !empty($x["media_import"]["quickjs_sha256_verified"])) exit(1);' "$TAMPERED_HEALTH" || { echo "Health did not detect a changed QuickJS-NG binary: $TAMPERED_HEALTH"; exit 1; }
mv "$TMP/qjs-valid" "$TMP/private-imports/bin/qjs"
# The same health contract applies to yt-dlp: a valid-looking version stamp must
# not hide a replaced or corrupted standalone executable.
cp "$TMP/private-imports/bin/yt-dlp" "$TMP/yt-dlp-valid"
printf '\n#tampered\n' >> "$TMP/private-imports/bin/yt-dlp"
TAMPERED_YT_HEALTH="$(curl -fsS -c "$COOKIE" -b "$COOKIE" "$BASE?api=health")"
php -r '$x=json_decode($argv[1],true); if(!empty($x["media_import"]["yt_dlp_stable"]) || !empty($x["media_import"]["instagram_ready"]) || !empty($x["media_import"]["youtube_ready"]) || !empty($x["media_import"]["yt_dlp_sha256_verified"])) exit(1);' "$TAMPERED_YT_HEALTH" || { echo "Health did not detect a changed yt-dlp executable: $TAMPERED_YT_HEALTH"; exit 1; }
mv "$TMP/yt-dlp-valid" "$TMP/private-imports/bin/yt-dlp"

INVALID_CODE="$(curl -sS -o "$TMP/invalid.json" -w '%{http_code}' -c "$COOKIE" -b "$COOKIE" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' -d '{"url":"https://example.com/a.mp4"}' "$BASE?api=media-import-start")"
[[ "$INVALID_CODE" == '400' ]] || { cat "$TMP/invalid.json"; echo "Expected URL allowlist rejection, got $INVALID_CODE"; exit 1; }

# Plant an expired nested job; the next importer start must clean it recursively.
STALE_ID='aaaaaaaaaaaaaaaaaaaaaaaa'
mkdir -p "$TMP/private-imports/$STALE_ID/attempt-1/nested"
printf '{"id":"%s","owner":"stale"}' "$STALE_ID" > "$TMP/private-imports/$STALE_ID/job.json"
printf 'stale' > "$TMP/private-imports/$STALE_ID/attempt-1/nested/chunk.tmp"
touch -d '3 days ago' "$TMP/private-imports/$STALE_ID/job.json" "$TMP/private-imports/$STALE_ID"

start_job(){ curl -fsS -c "$COOKIE" -b "$COOKIE" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' -d "{\"url\":\"$1\"}" "$BASE?api=media-import-start"; }
wait_job(){
  local id="$1" status='' value=''
  for _ in $(seq 1 150); do
    status="$(curl -fsS -c "$COOKIE" -b "$COOKIE" "$BASE?api=media-import-status&id=$id")"
    value="$(json_field "$status" 'status')"
    [[ "$value" == 'complete' ]] && { printf '%s' "$status"; return 0; }
    [[ "$value" == 'failed' ]] && { echo "$status"; cat "$TMP/php.log"; return 1; }
    sleep .1
  done
  echo "Timed out: $status"; cat "$TMP/php.log"; return 1
}
wait_runner_exit(){
  local id="$1"
  # The worker writes its terminal status just before releasing locks; wait for its
  # cleanup to finish before testing destructive transfer cleanup of its directory.
  for _ in $(seq 1 100); do
    local active="$(cat "$TMP/private-imports/.active-job-lock/job-id" 2>/dev/null || true)"
    if [[ ! -e "$TMP/private-imports/$id/.started" && "$active" != "$id" && ! -e "$TMP/private-imports/$id/.worker-lock" ]]; then return 0; fi
    sleep .05
  done
  echo "Detached runner cleanup did not finish for $id"; return 1
}

START="$(start_job 'https://youtu.be/dQw4w9WgXcQ')"
ID="$(json_field "$START" 'id')"
[[ -n "$ID" ]] || { echo "YouTube import did not start: $START"; exit 1; }
COOKIE2="$TMP/other-session.txt"
curl -fsS -c "$COOKIE2" -b "$COOKIE2" "$BASE?api=health" >/dev/null
FOREIGN_CODE="$(curl -sS -o "$TMP/foreign.json" -w '%{http_code}' -c "$COOKIE2" -b "$COOKIE2" "$BASE?api=media-import-status&id=$ID")"
[[ "$FOREIGN_CODE" == '404' ]] || { cat "$TMP/foreign.json"; echo "Expected foreign-session denial, got $FOREIGN_CODE"; exit 1; }
GLOBAL_LOCK_CODE="$(curl -sS -o "$TMP/global-lock.json" -w '%{http_code}' -c "$COOKIE2" -b "$COOKIE2" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' -d '{"url":"https://www.instagram.com/reel/ABCDEF12345/"}' "$BASE?api=media-import-start")"
[[ "$GLOBAL_LOCK_CODE" == '409' ]] || { cat "$TMP/global-lock.json"; echo "Expected account-level concurrency lock, got $GLOBAL_LOCK_CODE"; exit 1; }
STATUS="$(wait_job "$ID")"
wait_runner_exit "$ID"
php -r '$x=json_decode($argv[1],true); if(($x["title"]??"")!=="Smoke Test Video" || str_contains($x["stage"]??"", "--progress-template") || str_contains($x["stage"]??"", "%(title)")) exit(1);' "$STATUS" || { echo "Verbose command line leaked into UI status: $STATUS"; exit 1; }
ATTEMPT="$(php -r '$x=json_decode($argv[1],true); echo (int)($x["attempt"]??0);' "$STATUS")"
[[ "$ATTEMPT" -eq 3 ]] || { echo "YouTube default → forced HLS → android_vr fallback order failed: $STATUS"; exit 1; }
grep -Fq -- "--retries 8" "$TMP/fake-args.log" && grep -Fq -- "--fragment-retries 15" "$TMP/fake-args.log" && grep -Fq -- "--js-runtimes" "$TMP/fake-args.log" && grep -Fq -- "quickjs:" "$TMP/fake-args.log" && grep -Fq -- "--format best[protocol^=m3u8]/bestvideo*[protocol^=m3u8]" "$TMP/fake-args.log" && grep -Fq -- "youtube:player_client=web_safari" "$TMP/fake-args.log" && grep -Fq -- "youtube:player_client=android_vr" "$TMP/fake-args.log" || { echo "yt-dlp retry/EJS/HLS/alternate-client fallback configuration is missing."; cat "$TMP/fake-args.log" 2>/dev/null || true; cat "$TMP/php.log"; exit 1; }
[[ ! -d "$TMP/private-imports/$STALE_ID" ]] || { echo 'Expired orphan job was not recursively cleaned.'; exit 1; }
OVER_RANGE_CODE="$(curl -sS -o /dev/null -w '%{http_code}' -c "$COOKIE" -b "$COOKIE" -H 'Range: bytes=0-4194304' "$BASE?api=media-import-file&id=$ID")"
[[ "$OVER_RANGE_CODE" == '416' ]] || { echo 'Media transfer accepted a range larger than the 4 MiB server buffer limit.'; exit 1; }
RANGE_CODE="$(curl -sS -D "$TMP/youtube.headers.0" -o "$TMP/youtube.part.0" -w '%{http_code}' -c "$COOKIE" -b "$COOKIE" -H 'Range: bytes=0-2047' "$BASE?api=media-import-file&id=$ID")"
RANGE_CODE_2="$(curl -sS -D "$TMP/youtube.headers.1" -o "$TMP/youtube.part.1" -w '%{http_code}' -c "$COOKIE" -b "$COOKIE" -H 'Range: bytes=2048-4095' "$BASE?api=media-import-file&id=$ID")"
[[ "$RANGE_CODE" == '206' && "$RANGE_CODE_2" == '206' && "$(wc -c < "$TMP/youtube.part.0")" -eq 2048 && "$(wc -c < "$TMP/youtube.part.1")" -eq 2048 ]] || { echo 'YouTube resumable range transfer failed.'; exit 1; }
for part in 0 1; do
  PART_HASH="$(sha256sum "$TMP/youtube.part.$part" | awk '{print $1}')"
  CHUNK_HASH="$(awk 'BEGIN{IGNORECASE=1}/^X-Chunk-SHA256:/{gsub("\r", "", $2); print $2}' "$TMP/youtube.headers.$part")"
  [[ "$PART_HASH" == "$CHUNK_HASH" ]] || { echo "YouTube range chunk $part SHA-256 mismatch."; exit 1; }
done
HEADER_HASH="$(awk 'BEGIN{IGNORECASE=1}/^X-File-SHA256:/{gsub("\r", "", $2); print $2}' "$TMP/youtube.headers.0")"
# Simulate a browser that loses the first transfer after the server has finished extraction.
# Re-requesting the same completed job must serve the cached file; it must not invoke yt-dlp again.
RETRY_CODE="$(curl -sS -D "$TMP/youtube.retry.headers" -o "$TMP/youtube.retry.part" -w '%{http_code}' -c "$COOKIE" -b "$COOKIE" -H 'Range: bytes=0-4095' "$BASE?api=media-import-file&id=$ID")"
URL_KEY="$(printf '%s' 'https://youtu.be/dQw4w9WgXcQ' | sha256sum | awk '{print $1}')"
[[ "$RETRY_CODE" == '206' && "$(wc -c < "$TMP/youtube.retry.part")" -eq 4096 && "$(cat "$TMP/fake-counts/$URL_KEY.count")" -eq 3 ]] || { echo 'Retry did not reuse the completed server-side video; yt-dlp was invoked again or Range failed.'; exit 1; }
cat "$TMP/youtube.part.0" "$TMP/youtube.part.1" > "$TMP/youtube.mp4"
FILE_HASH="$(sha256sum "$TMP/youtube.mp4" | awk '{print $1}')"
[[ "$FILE_HASH" == "$HEADER_HASH" ]] || { echo 'YouTube whole-file SHA-256 does not match server digest.'; exit 1; }
ACK="$(curl -fsS -c "$COOKIE" -b "$COOKIE" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' -d "{\"id\":\"$ID\",\"sha256\":\"$FILE_HASH\"}" "$BASE?api=media-import-ack")"
[[ "$(json_field "$ACK" 'verified')" == 'true' && ! -d "$TMP/private-imports/$ID" ]] || { echo "YouTube transfer acknowledgement failed: $ACK"; exit 1; }

# Instagram is handled by the same upstream extractor; it does not invoke QuickJS-NG or a second library.
IG_START="$(start_job 'https://www.instagram.com/reel/ABCDEF12345/')"
IG_ID="$(json_field "$IG_START" 'id')"
[[ -n "$IG_ID" ]] || { echo "Instagram import did not start: $IG_START"; exit 1; }
IG_STATUS="$(wait_job "$IG_ID")"
wait_runner_exit "$IG_ID"
IG_ATTEMPT="$(php -r '$x=json_decode($argv[1],true); echo (int)($x["attempt"]??0);' "$IG_STATUS")"
[[ "$IG_ATTEMPT" -eq 1 ]] || { echo "Instagram should complete on its first single-extractor profile: $IG_STATUS"; exit 1; }
IG_RANGE_CODE="$(curl -sS -D "$TMP/instagram.headers" -o "$TMP/instagram.mp4" -w '%{http_code}' -c "$COOKIE" -b "$COOKIE" -H 'Range: bytes=0-4095' "$BASE?api=media-import-file&id=$IG_ID")"
[[ "$IG_RANGE_CODE" == '206' && "$(wc -c < "$TMP/instagram.mp4")" -eq 4096 ]] || { echo 'Instagram resumable range transfer failed.'; exit 1; }
IG_HASH="$(sha256sum "$TMP/instagram.mp4" | awk '{print $1}')"
IG_ACK="$(curl -fsS -c "$COOKIE" -b "$COOKIE" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' -d "{\"id\":\"$IG_ID\",\"sha256\":\"$IG_HASH\"}" "$BASE?api=media-import-ack")"
[[ "$(json_field "$IG_ACK" 'verified')" == 'true' && ! -d "$TMP/private-imports/$IG_ID" ]] || { echo "Instagram transfer acknowledgement failed: $IG_ACK"; exit 1; }

# Exercise newly appended fallback profiles without changing the original order.
YT_EXTRA="$(start_job 'https://youtu.be/abcdefghijk')"
YT_EXTRA_ID="$(json_field "$YT_EXTRA" 'id')"
YT_EXTRA_STATUS="$(wait_job "$YT_EXTRA_ID")"
wait_runner_exit "$YT_EXTRA_ID"
[[ "$(json_field "$YT_EXTRA_STATUS" 'attempt')" -eq 5 ]] || { echo "mweb YouTube fallback failed: $YT_EXTRA_STATUS"; exit 1; }
grep -Fq -- 'youtube:player_client=mweb' "$TMP/fake-args.log" || { echo 'Missing mweb extractor-args'; exit 1; }
YT_EXTRA_HASH="$(curl -fsS -c "$COOKIE" -b "$COOKIE" -H 'Range: bytes=0-4095' "$BASE?api=media-import-file&id=$YT_EXTRA_ID" | sha256sum | awk '{print $1}')"
curl -fsS -c "$COOKIE" -b "$COOKIE" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' -d "{\"id\":\"$YT_EXTRA_ID\",\"sha256\":\"$YT_EXTRA_HASH\"}" "$BASE?api=media-import-ack" >/dev/null
IG_EXTRA="$(start_job 'https://www.instagram.com/reel/FGHJKL12345/')"
IG_EXTRA_ID="$(json_field "$IG_EXTRA" 'id')"
IG_EXTRA_STATUS="$(wait_job "$IG_EXTRA_ID")"
wait_runner_exit "$IG_EXTRA_ID"
[[ "$(json_field "$IG_EXTRA_STATUS" 'attempt')" -eq 2 ]] || { echo "Instagram iOS fallback failed: $IG_EXTRA_STATUS"; exit 1; }
grep -Fq -- 'instagram:app_id=ios' "$TMP/fake-args.log" || { echo 'Missing Instagram iOS API fallback'; exit 1; }
IG_EXTRA_HASH="$(curl -fsS -c "$COOKIE" -b "$COOKIE" -H 'Range: bytes=0-4095' "$BASE?api=media-import-file&id=$IG_EXTRA_ID" | sha256sum | awk '{print $1}')"
curl -fsS -c "$COOKIE" -b "$COOKIE" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' -d "{\"id\":\"$IG_EXTRA_ID\",\"sha256\":\"$IG_EXTRA_HASH\"}" "$BASE?api=media-import-ack" >/dev/null
echo 'Media-import smoke passed: verbose marker isolation, original+new fallback order, YouTube mweb and Instagram ios recovery, range transfer, SHA-256, ACK, privacy locks.'
