import assert from 'node:assert/strict';
import {vivaldiMultipass,VIVALDI_MULTIPASS_VERSION} from '../vivaldi-multipass-core.mjs';
const points=(scale=1)=>Array.from({length:33},(_,j)=>[.38+(j%5)*.035*scale,.1+(Math.floor(j/5))*.07*scale,0,.67]);
function frames(n=120){return Array.from({length:n},(_,i)=>{
 const im=points(),w=points(.8);for(const id of [11,12,13,14,15,16,23,24,25,26,27,28]){
   im[id][0]+=.006*Math.sin(i*.19);w[id][0]+=.003*Math.sin(i*.11);
 }
 if(i===42){im[15][0]+=.09;im[15][3]=.12;} // one low-confidence spike
 return {t:i/30,im,w,camera_segment_id:0};
});}
const original=frames(),snapshot=JSON.stringify(original),p=vivaldiMultipass(original);
assert.equal(p.metrics?.stages?.length,6);assert.equal(p.identity?.technique_space,'athlete-normalized');
assert.equal(p.frames.length,original.length);assert.equal(JSON.stringify(original),snapshot,'Original detector frames must not change');
assert(p.identity.anchor_count>=10,'Must use multi-view frames when possible');
assert.equal(p.metrics.neural_fitting,'not installed','Never misrepresent neural fitting');
assert.equal(p.metrics.fine_target_vertices,8192);
for(const f of p.frames)for(const k of ['render_im','render_w'])assert.equal(f[k].length,33);
const discontinuous=frames(80);for(let i=40;i<80;i++){discontinuous[i].camera_segment_id=1;discontinuous[i].t+=3;}
const q=vivaldiMultipass(discontinuous);assert.equal(q.metrics.stages[3].camera_segments,2);
console.log('Vivaldi multipass PASS');
