#!/usr/bin/env bash
# Developer/CI-only browser-JavaScript regression runner.
# The production installer never sources this file and never invokes system Node.
set -Eeuo pipefail
JS_RUNTIME_KIND=''
JS_RUNTIME_BIN=''
js_runtime_detect(){
  local v major
  command -v node >/dev/null 2>&1 || return 1
  v="$(node --version 2>/dev/null | sed 's/^v//')"
  [[ "$v" =~ ^([0-9]+)\. ]] || return 1
  major="${BASH_REMATCH[1]}"
  (( major >= 22 )) || return 1
  JS_RUNTIME_KIND='node'
  JS_RUNTIME_BIN="$(command -v node)"
  export JS_RUNTIME_KIND JS_RUNTIME_BIN
}
js_runtime_report(){
  [[ "$JS_RUNTIME_KIND" == 'node' && -n "$JS_RUNTIME_BIN" ]] || return 1
  printf 'Developer JavaScript runtime: %s (%s)\n' "$($JS_RUNTIME_BIN --version)" "$JS_RUNTIME_BIN"
}
js_runtime_check(){
  local file
  for file in "$@"; do
    [[ -f "$file" ]] || { echo "Missing JavaScript test file: $file" >&2; return 1; }
    case "$file" in
      *.mjs) "$JS_RUNTIME_BIN" --check "$file" ;;
      *.js) "$JS_RUNTIME_BIN" --input-type=module --check < "$file" ;;
      *) echo "Unsupported JavaScript source type: $file" >&2; return 1 ;;
    esac
  done
}
js_runtime_run(){
  "$JS_RUNTIME_BIN" "$@"
}
