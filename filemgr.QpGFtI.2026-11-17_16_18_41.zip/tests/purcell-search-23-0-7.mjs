import assert from 'node:assert/strict';
import {generate21Hypotheses} from '../purcell-search-core.mjs';
const frames=Array.from({length:61},(_,i)=>({t:i/30,im:Array.from({length:33},(_,j)=>[.2+(j%7)*.07+.02*Math.sin(i/15),.12+Math.floor(j/7)*.1,.4,1])}));
const input=JSON.stringify(frames),r=generate21Hypotheses({frames});
assert.equal(r.count,21);assert.equal(r.candidates.length,21);assert.equal(JSON.stringify(frames),input,'original frames mutated');
assert.equal(new Set(r.candidates.map(x=>x.family)).size,21);
assert.ok(r.candidates.every(x=>Number.isFinite(x.score)&&Number.isFinite(x.metrics.bone_distortion)));
assert.ok(r.top.length<=3);assert.ok(r.top.every(x=>x.passed));
for(const c of r.candidates){assert.deepEqual(c.frames[0].im,frames[0].im);assert.deepEqual(c.frames.at(-1).im,frames.at(-1).im);}
const second=generate21Hypotheses({frames,memory:[{family:'left_arm:arc_up',decision:'chosen'}]});
assert.ok(second.candidates[0].amplitude>r.candidates[0].amplitude);
console.log('PASS: 21 independent trajectories, constraints, untouched originals, deterministic feedback adaptation');
