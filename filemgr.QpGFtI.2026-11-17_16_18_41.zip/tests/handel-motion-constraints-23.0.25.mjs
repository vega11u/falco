import assert from 'node:assert/strict';
import {handelConstrainSequence} from '../handel-motion-constraints.mjs';
const base=(i)=>{const w=Array.from({length:33},()=>[0,0,0,0]);w[11]=[0,0,0,.91];w[13]=[.22+(i===3?.09:0),0,0,i===3?.2:.9];w[23]=[0,-.5,0,.95];w[25]=[0,-.95,0,.91];return {t:i/30,im:[],w,camera_segment_id:0};};
const input=Array.from({length:7},(_,i)=>base(i));const snapshot=JSON.stringify(input);
const result=handelConstrainSequence(input,{segment_lengths:{'11-13':.22,'23-25':.45}},{iterations:6});
assert.equal(result.frames.length,input.length);assert.equal(JSON.stringify(input),snapshot,'raw observations may never be modified');
assert.ok(result.quality.corrections>0);assert.ok(result.quality.median_relative_bone_error_after<=result.quality.median_relative_bone_error_before);
assert.equal(result.quality.metric_3d_guarantee,false);
console.log('Handel motion constraints: PASS');
