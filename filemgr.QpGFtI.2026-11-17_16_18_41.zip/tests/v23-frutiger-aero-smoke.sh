#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
php -r '
$p=$argv[1]; $version=trim(file_get_contents($p."/VERSION"));
if($version!=="23.0.27") throw new RuntimeException("Engine version contract must be 23.0.27");
foreach(["falco-jugger-ui.css","assets/aero-landscape.svg","assets/aero-motion.svg","media-import-adapters.php","setup-social-adapters.sh"] as $f) if(!is_file($p."/".$f)||filesize($p."/".$f)<100) throw new RuntimeException("Missing ".$f);
foreach(["index.php","uppurcell.php","Memories.php"] as $f){ob_start();require $p."/".$f;$h=ob_get_clean();if(!str_contains($h,"falco-jugger-ui.css?v=26.2.2"))throw new RuntimeException("Unified stylesheet missing on ".$f);if(!str_contains($h,"Falco Jugger") && !str_contains($h,"FALCO KATA LAB"))throw new RuntimeException("Brand missing on ".$f);}
$css=file_get_contents($p."/falco-jugger-ui.css");
foreach(["Segoe UI","--fj-accent","prefers-reduced-motion","focus-visible","source-chooser-grid","clip-workspace","fj-side-rail"] as $needle)if(!str_contains($css,$needle))throw new RuntimeException("Aero token missing: ".$needle);
if(str_contains($css,"IM Fell English SC")||str_contains($css,"Bebas Neue"))throw new RuntimeException("Retired display typography remains active");
$index=file_get_contents($p."/index.php");foreach(["id=\"clipWorkspace\"","id=\"rangeStart\"","id=\"rangeEnd\"","id=\"video\"","id=\"analyzeBtn\"","id=\"purcellTrainingPanel\""] as $needle)if(!str_contains($index,$needle))throw new RuntimeException("Existing UI contract missing: ".$needle);
echo "Falco 25.0.0 shared Aero Flight Deck stylesheet and preserved engine assets: PASS\n";
' "$ROOT"
