import assert from 'node:assert/strict';
import {generate21Hypotheses} from '../purcell-search-core.mjs';
import {buildBiomechanicalSequencePlan} from '../technique-planner.mjs';
import {assessPoseSequence,analyzeNextMovementReadiness} from '../biomechanics-core.mjs';
const frames=Array.from({length:90},(_,i)=>{
 const t=i/30,w=Array.from({length:33},(_,j)=>[.05+(j%5)*.05,.2+Math.floor(j/5)*.08,.02*Math.sin(t*2+j),.95]);
 for(const [a,x,y] of [[11,-.22,.40],[12,.22,.4],[13,-.34,.58],[14,.34,.58],[15,-.41,.8],[16,.41,.8],[23,-.16,.9],[24,.16,.9],[25,-.17,1.15],[26,.17,1.15],[27,-.16,1.4],[28,.16,1.4],[29,-.17,1.43],[30,.17,1.43],[31,-.19,1.44],[32,.19,1.44]])w[a]=[x,y,.025*Math.sin(2*t),.98];
 const im=w.map(p=>[.5+p[0]*.48,.05+p[1]*.52,p[2],p[3]]);return {t,sample_index:i,camera_segment_id:0,im,w};
});
const x=generate21Hypotheses({frames,context:[{kind:'stance',research_evidence:[{id:'abcdef012345abcdef01'}]}]});
const patterns=[{kind:'hand_strike',label:'Удар рукой',confirmed:true,rejected:false,instances:[{start:.3,end:2.4,review:'yes'}]}];
const evaluations=x.candidates.map(c=>({quality:assessPoseSequence(c.frames),readiness:analyzeNextMovementReadiness(c.frames),plan:buildBiomechanicalSequencePlan({frames:c.frames,patterns,metrics:[],goal:'balanced'})}));
assert.equal(evaluations.length,21);
assert.ok(evaluations.every(e=>e.plan.schema==='falco-biomechanical-sequence-plan-v1'));
assert.ok(evaluations.every(e=>e.readiness.schema==='falco-next-movement-v2'));
assert.ok(evaluations.every(e=>Number.isFinite(e.quality.score)));
const pathMetrics=evaluations.map(e=>e.plan.patterns?.[0]?.within_pattern?.path?.left_hand?.path_length).filter(Number.isFinite);
assert.ok(new Set(pathMetrics.map(x=>x.toFixed(5))).size>=3,'planner must actually see different trajectories, not stale original 3D data');
console.log('PASS: 21 individual evaluations by the existing biomechanics, readiness, and technique planner engines');
