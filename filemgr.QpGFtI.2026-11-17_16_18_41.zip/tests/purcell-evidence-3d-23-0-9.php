<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/research/build_evidence_index.php';
$root=sys_get_temp_dir().'/falco-evidence3d-'.bin2hex(random_bytes(5));
$dir=$root.'/data/trained/research-sources/opensim_3d_kinematics/Models/Test';
if(!mkdir($dir,0700,true))throw new RuntimeException('temp folder');
try{
  file_put_contents($dir.'/motion.trc',"PathFileType\t4\t(X/Y/Z)\tmotion.trc\nDataRate\tCameraRate\tNumFrames\nTime\tpelvis_x\thip_y\n0.0\t0.1\t0.2\n");
  file_put_contents($dir.'/motion.mot',"name motion\ndatarows 1\nendheader\ntime\tpelvis_tilt\tknee_angle\n0.0\t0.1\t0.2\n");
  file_put_contents($dir.'/model.osim','<OpenSimDocument><Model name="Test"><Body name="pelvis"/><Coordinate name="hip_flexion"/></Model></OpenSimDocument>');
  $result=fj_build_evidence_index($root);
  $data=json_decode(file_get_contents($result['index']),true);
  $items=array_values(array_filter($data['items']??[],fn($r)=>$r['source']==='opensim_3d_kinematics'));
  $kinds=array_unique(array_column($items,'kind'));
  if(count($items)<3||!in_array('kinematic_3d_metadata',$kinds,true)||!in_array('anatomy_model',$kinds,true))throw new RuntimeException('3D index missing '.json_encode($kinds));
  echo 'PASS 3D OpenSim model (.osim), TRC marker metadata, MOT kinematic metadata, source provenance, PHP-only index'.PHP_EOL;
}finally{
  $iterator=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
  foreach($iterator as $item){if($item->isDir())rmdir($item->getPathname());else unlink($item->getPathname());}rmdir($root);
}
