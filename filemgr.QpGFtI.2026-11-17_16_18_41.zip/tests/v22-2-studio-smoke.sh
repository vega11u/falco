#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
php -l "$ROOT/index.php" >/dev/null
php -l "$ROOT/Memories.php" >/dev/null
php -l "$ROOT/uppurcell.php" >/dev/null
php -r '
  $p=$argv[1];$version=trim(file_get_contents($p."/VERSION"));$_GET=[];ob_start();require $p."/index.php";$falcoMainHtml=ob_get_clean();
  $_GET=[];ob_start();require $p."/uppurcell.php";$falcoPurcellHtml=ob_get_clean();
  ob_start();require $p."/Memories.php";$falcoReportHtml=ob_get_clean();
  foreach(["main"=>$falcoMainHtml,"purcell"=>$falcoPurcellHtml] as $page=>$h){
    foreach(["falco-jugger-ui.css?v=26.2.2","id=\"clipWorkspace\"","id=\"clipSlot\"","id=\"clipPreviewPlay\"","id=\"clipResetFull\"","id=\"quickTrimApply\"","id=\"rangeStart\"","id=\"rangeEnd\"","id=\"video\"","id=\"analyzeBtn\"","installStudioWorkspace()","state.analyzedRanges=ranges.map", "const mergedRanges=[]"] as $part) if(!str_contains($h,$part))throw new RuntimeException("Missing studio contract $page/$part");
    foreach(["rangeStart","rangeEnd","clipSlot","clipWorkspace","clipPreviewPlay","openClipEditor"] as $id)if(substr_count($h,"id=\"".$id."\"")!==1)throw new RuntimeException("Duplicate control id: $page/$id");
  }
  foreach(["data-mode=\"purcell\"","id=\"purcellTrainingPanel\"","state.ranges=full?[]:[{start:a,end:b}]","Границы фрагмента изменены после анализа","выделите короткий технический фрагмент в блоке"] as $part)if(!str_contains($falcoPurcellHtml,$part))throw new RuntimeException("Purcell trim contract $part");
  foreach(["falco-jugger-ui.css?v=26.2.2","fj-page-heading","Библиотека отчётов"] as $part)if(!str_contains($falcoReportHtml,$part))throw new RuntimeException("Memories design $part");
  $php=file_get_contents($p."/index.php");
  foreach(["Lux · независимый Go-загрузчик","$"."mediaLuxReady", "lux-sha256.txt", "independent_downloaders"] as $part)if(!str_contains($php,$part))throw new RuntimeException("Independent downloader missing: $part");
  $css=file_get_contents($p."/falco-jugger-ui.css");
  foreach([".fj-workspace-heading", ".clip-workspace", "@media(max-width:899px)", "--fj-font"] as $part)if(!str_contains($css,$part))throw new RuntimeException("Unified layout CSS missing: $part");
  if(!str_contains($falcoMainHtml,"class=\"source-chooser-grid\""))throw new RuntimeException("Core upload layout contract missing");
  if(!str_contains($falcoReportHtml,"fj-page-heading"))throw new RuntimeException("Report archive heading contract missing");
  $installer=file_get_contents($p."/setup-lux-fallback.sh");
  foreach(["sha256sum --check --status","_checksums.txt","MEDIA_DIR","github.com/iawia002/lux"] as $part)if(!str_contains($installer,$part))throw new RuntimeException("Lux installation verification missing: $part");
  echo "Studio contracts: Purcell precise trim, Precision Lab design, safe independent fallback: PASS\n";
' "$ROOT"
