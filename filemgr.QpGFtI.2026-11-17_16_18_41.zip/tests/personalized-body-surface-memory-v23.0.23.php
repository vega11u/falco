<?php
declare(strict_types=1);
require_once __DIR__.'/../reconstruction-memory.php';
$pack=static function(array $values):string{$ints=[];foreach($values as $v){$v=max(-8.0,min(8.0,(float)$v));$ints[]=(int)round((($v+8.0)/16.0)*65535.0);}return base64_encode(pack('v*',...$ints));};
$keys=['torso','left_arm_upper','left_arm_lower','right_arm_upper','right_arm_lower','left_leg_upper','left_leg_lower','right_leg_upper','right_leg_lower'];$width=[];foreach($keys as $key)$width[$key]=[[.20,.8],[.22,.8],[.24,.8],[.21,.8]];
$values=array_fill(0,8*144*4,.125);
$row=['features'=>array_fill(0,384,0.1),'personalized_shape_profile'=>['schema'=>'falco-personalized-silhouette-surface-v1','profile_confidence'=>.84,'width_profile'=>$width],
 'personalized_surface_clip_2d'=>['schema'=>'falco-personalized-silhouette-surface-v1','space'=>'2d','values'=>$values],
 'personalized_surface_clip_3d'=>['schema'=>'falco-personalized-silhouette-surface-v1','space'=>'3d','values'=>$values]];
$out=fj_recon_optional_features($row,$pack);
if(!isset($out['personalized_shape_profile_q16'],$out['personalized_surface_clip_2d_q16'],$out['personalized_surface_clip_3d_q16']))throw new RuntimeException('Personalized profile or surface clip not persisted.');
$rowQ=$row;unset($rowQ['personalized_surface_clip_2d']['values'],$rowQ['personalized_surface_clip_3d']['values']);$rowQ['personalized_surface_clip_2d']['values_q16']=$pack($values);$rowQ['personalized_surface_clip_3d']['values_q16']=$pack($values);$outQ=fj_recon_optional_features($rowQ,$pack);if(($outQ['personalized_surface_clip_2d_q16']??null)!==$pack($values)||($outQ['personalized_surface_clip_3d_q16']??null)!==$pack($values))throw new RuntimeException('Prepacked Q16 surface clips were not accepted.');
$prior=$out;$merged=fj_recon_preserve_extra([], $prior);
if(!isset($merged['personalized_shape_profile_q16'],$merged['personalized_surface_clip_3d_q16']))throw new RuntimeException('Personalized profile not preserved on update.');
$counts=fj_recon_memory_counts([$out]);
if(($counts['personalized_surface_2d']??0)!==1||($counts['personalized_surface_3d']??0)!==1||($counts['personalized_shape_profiles']??0)!==1)throw new RuntimeException('Personalized surface counters incorrect.');
$bad=$row;$bad['personalized_surface_clip_3d']['values']=array_slice($values,0,-1);$failed=false;try{fj_recon_optional_features($bad,$pack);}catch(InvalidArgumentException $e){$failed=true;}if(!$failed)throw new RuntimeException('Invalid point-cloud length was accepted.');
$badQ=$rowQ;$badQ['personalized_surface_clip_3d']['values_q16']='not-base64';$failedQ=false;try{fj_recon_optional_features($badQ,$pack);}catch(InvalidArgumentException $e){$failedQ=true;}if(!$failedQ)throw new RuntimeException('Invalid Q16 point-cloud data was accepted.');
echo "personalized-body-surface-memory-v23.0.23: PASS\n";
