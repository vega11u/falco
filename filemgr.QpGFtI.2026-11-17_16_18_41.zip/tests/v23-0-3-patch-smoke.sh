#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
php -l index.php >/dev/null
php -l Memories.php >/dev/null
php index.php >/tmp/falco-23.0.3-rendered.html
python3 - <<'PYTEST'
from pathlib import Path
s=Path('/tmp/falco-23.0.3-rendered.html').read_text()
a=s.index('<script type="module">')+len('<script type="module">');b=s.index('</script>',a)
Path('/tmp/falco-23.0.3-inline.mjs').write_text(s[a:b])
for phrase in ('id="purcellBatchFiles"','id="purcellBatchQueue"','id="purcellBatchSave"','id="playerContinue"','id="playerRestart"','falco-avatar-sanchin.svg','purcellBatchRun','persistPurcellBatch','purcellBatchSelect','purcellBatchProcessing','Перед запуском укажите название'):
 assert phrase in s,phrase
assert 'entry.features=features' in s
assert "entry.status='saved';persistPurcellBatch()" in s
assert "if(!options.restoreWorkspace&&!options.retryExisting)" in s
assert Path('assets/falco-avatar-sanchin.svg').exists()
assert Path('falco-jugger-ui.css').stat().st_size>30000
assert '@layer compatibility' not in Path('falco-jugger-ui.css').read_text()
assert 'fj-player-column' in Path('falco-jugger-ui.css').read_text()
PYTEST
node --check /tmp/falco-23.0.3-inline.mjs
node tests/player-trim-core-smoke.mjs
node tests/purcell-core-smoke.mjs
php tests/release-smoke.php >/dev/null
echo '23.0.3 patch smoke PASS'
