<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/media-import-control.php';
$token = str_repeat('a', 64);
$hash = fj_media_owner_hash($token);
if (!is_string($hash) || strlen($hash) !== 64) throw new RuntimeException('Stable owner token hash failed');
if (fj_media_owner_hash('not-a-token') !== null) throw new RuntimeException('Invalid owner token was accepted');
if (!fj_media_owner_matches(['owner' => $hash], [$hash])) throw new RuntimeException('Owner match failed');
if (fj_media_owner_matches(['owner' => $hash], [str_repeat('b', 64)])) throw new RuntimeException('Foreign owner matched');
$root = sys_get_temp_dir() . '/falco-media-control-' . bin2hex(random_bytes(6));
mkdir($root, 0700, true);
try {
    $id = str_repeat('a', 24); $dir = $root . DIRECTORY_SEPARATOR . $id; mkdir($dir, 0700, true);
    $lock = $root . DIRECTORY_SEPARATOR . '.active-job-lock'; mkdir($lock, 0700, true);
    file_put_contents($lock . DIRECTORY_SEPARATOR . 'job-id', $id . "\n");
    $ticks = fj_media_process_start_ticks(getmypid());
    if ($ticks === null) throw new RuntimeException('/proc start ticks unavailable in test runtime');
    file_put_contents($dir . DIRECTORY_SEPARATOR . '.started', (string)getmypid());
    file_put_contents($dir . DIRECTORY_SEPARATOR . '.started-start', $ticks);
    if (!in_array(getmypid(), fj_media_job_process_pids($dir), true)) throw new RuntimeException('Verified current process not detected');
    $live = fj_media_recover_orphaned_active_lock($lock, $root, 1);
    if (!empty($live['recovered']) || !is_dir($lock)) throw new RuntimeException('Live job lock was incorrectly released');

    // A dead PID marker older than the conservative grace period is recoverable.
    $deadId = str_repeat('b', 24); $deadDir = $root . DIRECTORY_SEPARATOR . $deadId; mkdir($deadDir, 0700, true);
    $deadLock = $root . DIRECTORY_SEPARATOR . '.dead-lock'; mkdir($deadLock, 0700, true); file_put_contents($deadLock . DIRECTORY_SEPARATOR . 'job-id', $deadId);
    file_put_contents($deadDir . DIRECTORY_SEPARATOR . '.started', '99999999');
    touch($deadDir . DIRECTORY_SEPARATOR . '.started', time() - 30); touch($deadDir, time() - 30);
    $recovered = fj_media_recover_orphaned_active_lock($deadLock, $root, 12);
    if (empty($recovered['recovered']) || is_dir($deadLock)) throw new RuntimeException('Orphan lock was not recovered');

    // A stale queued job is returned to the CRON queue, not deleted.
    $queueId = str_repeat('c', 24); $queueDir = $root . DIRECTORY_SEPARATOR . $queueId; mkdir($queueDir, 0700, true);
    $queueLock = $root . DIRECTORY_SEPARATOR . '.queue-lock'; mkdir($queueLock, 0700, true); file_put_contents($queueLock . DIRECTORY_SEPARATOR . 'job-id', $queueId);
    file_put_contents($queueDir . DIRECTORY_SEPARATOR . '.queued', '1'); touch($queueDir . DIRECTORY_SEPARATOR . '.queued', time() - 240); touch($queueDir, time() - 240);
    $queueResult = fj_media_recover_orphaned_active_lock($queueLock, $root, 12);
    if (empty($queueResult['recovered']) || !is_file($queueDir . DIRECTORY_SEPARATOR . '.queued')) throw new RuntimeException('Queued job was not preserved after stale lock recovery');
    echo "PASS media import control: owner isolation, verified live PID protection, orphan lock recovery, queued job preservation\n";
} finally {
    $remove = static function (string $path) use (&$remove): void {
        if (is_link($path) || is_file($path)) { @unlink($path); return; }
        if (!is_dir($path)) return;
        foreach (scandir($path) ?: [] as $name) if ($name !== '.' && $name !== '..') $remove($path . DIRECTORY_SEPARATOR . $name);
        @rmdir($path);
    };
    $remove($root);
}
