#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
TMP="$(mktemp -d)"
PORT="$(php -r '$s=stream_socket_server("tcp://127.0.0.1:0",$e,$m); if(!$s) exit(1); $a=stream_socket_get_name($s,false); echo (int)substr(strrchr($a,":"),1); fclose($s);')"
PID=''
cleanup(){ if [[ -n "$PID" ]]; then kill -TERM "$PID" 2>/dev/null || true; for _ in $(seq 1 20); do kill -0 "$PID" 2>/dev/null || break; sleep 0.05; done; kill -KILL "$PID" 2>/dev/null || true; wait "$PID" 2>/dev/null || true; fi; rm -rf "$TMP"; }
trap cleanup EXIT
command -v php >/dev/null && command -v curl >/dev/null && command -v bash >/dev/null || { echo 'SKIP: PHP, curl and Bash are required.'; exit 0; }
HASH="$(printf '%s' "$ROOT" | sha256sum | awk '{print substr($1,1,12)}')"
MEDIA="$TMP/private-imports"
mkdir -p "$MEDIA/bin" "$TMP/counts"
cat > "$MEDIA/bin/yt-dlp" <<'FAKE'
#!/usr/bin/env bash
set -Eeuo pipefail
out=''; url=''
while (($#)); do case "$1" in --output) out="$2"; shift 2 ;; *) [[ "$1" == https://* ]] && url="$1"; shift ;; esac; done
[[ -n "$out" && -n "$url" ]]
key="$(printf '%s' "$url" | sha256sum | awk '{print $1}')"; file="$FAKE_COUNT_DIR/$key"
n=0; [[ ! -f "$file" ]] || n="$(cat "$file")"; n=$((n+1)); echo "$n" > "$file"
out="${out//%(ext)s/mp4}"; mkdir -p "$(dirname "$out")"; echo 'KATA_TITLE:Cron Queue Smoke'
printf '\000\000\000\030ftypisom' > "$out"; dd if=/dev/zero bs=4084 count=1 status=none >> "$out"
echo 'KATA_PROGRESS:100.0%|4096|4096|00:00:00'
FAKE
cat > "$MEDIA/bin/qjs" <<'QJS'
#!/usr/bin/env sh
case "$1" in
  --version) echo '0.18.0' ;;
  -e) exit 0 ;;
  *) exit 0 ;;
esac
QJS
chmod 700 "$MEDIA/bin/yt-dlp" "$MEDIA/bin/qjs"
printf '0.18.0\n' > "$MEDIA/bin/qjs-version.txt"
QJS_FAKE_SHA="$(sha256sum "$MEDIA/bin/qjs" | awk '{print $1}')"
printf '%s\n' "$QJS_FAKE_SHA" > "$MEDIA/bin/qjs-sha256.txt"
printf 'quickjs-ng:0.18.0:%s\n' "$QJS_FAKE_SHA" > "$MEDIA/bin/qjs-runtime-ok.txt"
printf '2026.10.26\n' > "$MEDIA/bin/yt-dlp-stable-version.txt"
sha256sum "$MEDIA/bin/yt-dlp" | awk '{print $1}' > "$MEDIA/bin/yt-dlp-sha256.txt"
export KATA_MEDIA_IMPORT_DIR="$MEDIA"
export FAKE_COUNT_DIR="$TMP/counts"
php -d disable_functions=proc_open -S "127.0.0.1:$PORT" -t "$ROOT" "$ROOT/index.php" >"$TMP/php.log" 2>&1 &
PID=$!
BASE="http://127.0.0.1:$PORT/index.php"; ORIGIN="http://127.0.0.1:$PORT"; COOKIE="$TMP/cookies.txt"
for _ in $(seq 1 60); do curl -fsS -c "$COOKIE" -b "$COOKIE" "$BASE?api=health" >/dev/null 2>&1 && break; sleep .1; done
HEALTH="$(curl -fsS -c "$COOKIE" -b "$COOKIE" "$BASE?api=health")"
php -r '$x=json_decode($argv[1],true); if(empty($x["media_import"]["ready"]) || ($x["media_import"]["mode"]??"")!=="cron-queue" || empty($x["media_import"]["cron_schedule_required"]) || !empty($x["media_import"]["proc_open"])) exit(1);' "$HEALTH" || { echo "CRON fallback health check failed: $HEALTH"; cat "$TMP/php.log"; exit 1; }
php -r '$x=json_decode($argv[1],true); if(empty($x["media_import"]["youtube_ready"]) || empty($x["media_import"]["quickjs_sha256_verified"]) || empty($x["media_import"]["instagram_ready"])) exit(1);' "$HEALTH" || { echo "CRON importer reports unverified downloader runtimes: $HEALTH"; exit 1; }
START="$(curl -fsS -c "$COOKIE" -b "$COOKIE" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' -d '{"url":"https://youtu.be/dQw4w9WgXcQ"}' "$BASE?api=media-import-start")"
ID="$(php -r '$x=json_decode($argv[1],true); echo $x["id"]??"";' "$START")"
[[ -n "$ID" && "$(php -r '$x=json_decode($argv[1],true); echo $x["status"]??"";' "$START")" == 'queued' ]] || { echo "Job did not enter CRON queue: $START"; exit 1; }
[[ -f "$MEDIA/$ID/.queued" && -x "$MEDIA/$ID/run.sh" ]] || { echo 'Queue marker or protected runner missing.'; exit 1; }
# A second browser session may queue work, but CRON must serialize the two jobs.
COOKIE2="$TMP/second-cookies.txt"
curl -fsS -c "$COOKIE2" -b "$COOKIE2" "$BASE?api=health" >/dev/null
START2="$(curl -fsS -c "$COOKIE2" -b "$COOKIE2" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' -d '{"url":"https://www.instagram.com/reel/ABCDEF12345/"}' "$BASE?api=media-import-start")"
ID2="$(php -r '$x=json_decode($argv[1],true); echo $x["id"]??"";' "$START2")"
[[ -n "$ID2" && -f "$MEDIA/$ID2/.queued" ]] || { echo "Second session could not queue independent CRON task: $START2"; exit 1; }
KATA_MEDIA_IMPORT_DIR="$MEDIA" FAKE_COUNT_DIR="$TMP/counts" bash "$ROOT/media-import-cron.sh"
ACTIVE_ID="$(cat "$MEDIA/.active-job-lock/job-id" 2>/dev/null || true)"
[[ "$ACTIVE_ID" == "$ID" || "$ACTIVE_ID" == "$ID2" ]] || { echo "CRON worker did not claim an expected account-level active slot: $ACTIVE_ID"; exit 1; }
if [[ "$ACTIVE_ID" == "$ID" ]]; then PENDING_ID="$ID2"; ACTIVE_COOKIE="$COOKIE"; PENDING_COOKIE="$COOKIE2"; else PENDING_ID="$ID"; ACTIVE_COOKIE="$COOKIE2"; PENDING_COOKIE="$COOKIE"; fi
KATA_MEDIA_IMPORT_DIR="$MEDIA" FAKE_COUNT_DIR="$TMP/counts" bash "$ROOT/media-import-cron.sh"
[[ -f "$MEDIA/$PENDING_ID/.queued" && ! -f "$MEDIA/$PENDING_ID/.started" ]] || { echo 'CRON dispatched a second task while the first was active.'; exit 1; }
wait_status(){
  local id="$1" cookie="$2" result=''
  for _ in $(seq 1 900); do if [[ -f "$MEDIA/$id/.queued" && ! -f "$MEDIA/$id/.started" ]] && (( _ % 10 == 0 )); then KATA_MEDIA_IMPORT_DIR="$MEDIA" FAKE_COUNT_DIR="$TMP/counts" bash "$ROOT/media-import-cron.sh" || true; fi
    result="$(curl --max-time 5 -fsS -c "$cookie" -b "$cookie" "$BASE?api=media-import-status&id=$id" 2>/dev/null || true)"; [[ "$(php -r '$x=json_decode($argv[1],true); echo $x["status"]??"";' "$result")" == "complete" ]] && { printf '%s' "$result"; return 0; }; sleep .1; done
  echo "Timed out after 90 seconds waiting for CRON job $id: $result"; return 1
}
ACTIVE_STATUS="$(wait_status "$ACTIVE_ID" "$ACTIVE_COOKIE")"
php -r '$x=json_decode($argv[1],true); if(($x["status"]??"")!=="complete" || (int)($x["size"]??0)!==4096 || (int)($x["attempt"]??0)!==1) exit(1);' "$ACTIVE_STATUS" || { echo "CRON worker did not complete active job: $ACTIVE_STATUS"; cat "$TMP/php.log"; exit 1; }
KATA_MEDIA_IMPORT_DIR="$MEDIA" FAKE_COUNT_DIR="$TMP/counts" bash "$ROOT/media-import-cron.sh"
PENDING_STATUS="$(wait_status "$PENDING_ID" "$PENDING_COOKIE")"
php -r '$x=json_decode($argv[1],true); if(($x["status"]??"")!=="complete" || (int)($x["size"]??0)!==4096 || (int)($x["attempt"]??0)!==1) exit(1);' "$PENDING_STATUS" || { echo "Second CRON job did not complete: $PENDING_STATUS"; cat "$TMP/php.log"; exit 1; }
curl -fsS -D "$TMP/video.headers" -c "$ACTIVE_COOKIE" -b "$ACTIVE_COOKIE" -H 'Range: bytes=0-4095' "$BASE?api=media-import-file&id=$ACTIVE_ID" -o "$TMP/video.mp4"
curl -fsS -D "$TMP/video2.headers" -c "$PENDING_COOKIE" -b "$PENDING_COOKIE" -H 'Range: bytes=0-4095' "$BASE?api=media-import-file&id=$PENDING_ID" -o "$TMP/video2.mp4"
[[ "$(wc -c < "$TMP/video.mp4")" -eq 4096 && "$(wc -c < "$TMP/video2.mp4")" -eq 4096 ]] || { echo 'CRON file transfer size mismatch.'; exit 1; }
for spec in "${ACTIVE_ID}|${ACTIVE_COOKIE}|${TMP}/video.mp4" "${PENDING_ID}|${PENDING_COOKIE}|${TMP}/video2.mp4"; do
  job_id="${spec%%|*}"; rest="${spec#*|}"; cookie="${rest%%|*}"; path="${rest#*|}"
  digest="$(sha256sum "$path" | awk '{print $1}')"
  ack="$(curl -fsS -c "$cookie" -b "$cookie" -H "Origin: $ORIGIN" -H 'Content-Type: application/json' -d "{\"id\":\"$job_id\",\"sha256\":\"$digest\"}" "$BASE?api=media-import-ack")"
  php -r '$x=json_decode($argv[1],true); if(empty($x["verified"]) || empty($x["deleted"])) exit(1);' "$ack" || { echo "CRON transfer acknowledgement failed: $ack"; exit 1; }
done
[[ ! -d "$MEDIA/$ID" && ! -d "$MEDIA/$ID2" ]] || { echo 'CRON acknowledgement did not clean temporary jobs.'; exit 1; }
echo 'Media-import CRON smoke passed: disabled web proc_open, two-session queue serialization, active-slot lock, single extractor, bounded Range transfer, SHA-256 acknowledgement and cleanup.'
