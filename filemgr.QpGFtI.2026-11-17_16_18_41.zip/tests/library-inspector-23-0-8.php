<?php
declare(strict_types=1);
define('FALCO_JUGGER_BOOTSTRAPPED',true);
require dirname(__DIR__).'/server-learning.php';
require dirname(__DIR__).'/library-inspector.php';
require dirname(__DIR__).'/classifier-validation.php';
function check(bool $value,string $msg):void{if(!$value)throw new RuntimeException($msg);}
$dir=sys_get_temp_dir().'/falco-test-'.bin2hex(random_bytes(5));mkdir($dir,0700,true);mkdir($dir.'/purcell',0700,true);
$examples=[];$phrases=['Маэ-гери','mae geri','Шисочин','schisochin'];
foreach($phrases as $i=>$label)$examples[]=['id'=>'entry-'.$i,'kind'=>$i<2?'kick':'kata','unit_type'=>$i<2?'sequence':'kata','label'=>$label,'style'=>'unspecified','confirmed'=>true,'source_session'=>'session_'.($i+10),'feature_version'=>'pose-window-v4-dtw-angle','feature_count'=>$i<2?384:1152,'features'=>array_fill(0,$i<2?384:1152,0.1+$i*.02)];
file_put_contents($dir.'/library.json',json_encode(['version'=>3,'examples'=>$examples,'feedback'=>[]],JSON_UNESCAPED_UNICODE));
file_put_contents($dir.'/purcell/library.json',json_encode(['version'=>1,'examples'=>[['id'=>'purcell-1','label'=>'mae geri','kind'=>'kick','style'=>'unspecified','rating'=>5,'notes'=>'keep my notes','features_q16'=>'original-q16-data']]],JSON_UNESCAPED_UNICODE));
try{
 fj_model_rebuild($dir,$examples);
 $first=fj_inspector_inspect($dir);
 check(count($first['proposals'])>=2,'both transliterated movement and kata must be suggested');
 $kicks=array_values(array_filter($first['proposals'],fn($x)=>$x['kind']==='kick'));
 check(count($kicks)>=1,'kick proposal');
 $result=fj_inspector_merge($dir,['old_name'=>'mae geri','canonical_name'=>'Маэ-гери','kind'=>'kick','style'=>'unspecified','revision'=>$first['revision']]);
 check($result['changed']['lully']===1,'Lully updated');check($result['changed']['purcell']===1,'Purcell updated');
 $after=fj_inspector_read($dir);check(count($after['lully']['examples'])===4,'no Lully examples lost');
 check(count($after['purcell']['examples'])===1,'no Purcell examples lost');
 check($after['purcell']['examples'][0]['notes']==='keep my notes','annotations preserved');
 check($after['purcell']['examples'][0]['features_q16']==='original-q16-data','numeric evidence preserved');
 check(fj_model_status($dir)['training_examples']===4,'classifier retrained all examples');
 check(is_dir($dir.'/.merge-backups'),'backup existed');
 $validation=fj_validation_report($dir,true);check($validation['ready']===true,'validation runs');
 check(count(array_filter($validation['groups'],fn($r)=>$r['learned']))===0,'never fake 94%');
 echo "PASS: names, consent merge, backups, preserved numeric observations, model rebuild, honest validation\n";
}finally{
 $delete=function($path)use(&$delete){if(is_dir($path)){foreach(array_diff(scandir($path),['.','..']) as $entry)$delete($path.'/'.$entry);rmdir($path);}elseif(file_exists($path))unlink($path);};$delete($dir);
}
