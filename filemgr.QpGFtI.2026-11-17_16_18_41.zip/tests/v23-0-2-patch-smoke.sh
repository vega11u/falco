#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
cd "$ROOT"
[[ "$(cat VERSION)" == '23.0.27' ]]
php -l index.php >/dev/null
php -l tests/release-smoke.php >/dev/null
node --check depth-worker.js
node --check depth-reconstruction-core.mjs
python3 - <<'PY'
import re
s=open('index.php',encoding='utf-8').read()
blocks=re.findall(r'<script[^>]*>(.*?)</script>',s,re.S)
assert blocks
open('/tmp/falco-v23.0.2-inline.js','w',encoding='utf-8').write(blocks[-1])
PY
node --check /tmp/falco-v23.0.2-inline.js
node tests/depth-reconstruction-smoke.mjs
node tests/depth-mode-policy-smoke.mjs
node tests/workspace-recovery-policy-smoke.mjs
php tests/release-smoke.php >/dev/null
grep -q -- '--fj-font' falco-jugger-ui.css
grep -q 'html\[data-theme="dark"\]' falco-jugger-ui.css
grep -q 'id="trimFilmstrip"' index.php
grep -q 'id="appJournalPanel"' index.php
grep -q 'indexedDB.open(WORKSPACE_DB_NAME' index.php
grep -q 'WORKSPACE_FRAME_STORE' index.php
grep -q 'workspaceFrameDeltas' index.php
grep -q 'frameChunks' index.php
grep -q 'id="depthModelChoice"' index.php
grep -q 'id="themeToggle"' Memories.php
echo 'v23.0.2 Aero / trim / journal / recovery / explicit depth / Lully guard smoke: PASS'
