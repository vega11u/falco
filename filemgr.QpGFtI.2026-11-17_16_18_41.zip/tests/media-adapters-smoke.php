<?php
declare(strict_types=1);
require dirname(__DIR__) . '/media-import-adapters.php';
foreach (['https://www.instagram.com/p/ABCde12345/','https://youtu.be/abcdefghijk','https://www.youtube.com/watch?v=abcdefghijk'] as $url) {
    $source = fj_media_adapter_source($url);
    if (!in_array($source['type'], ['instagram', 'youtube'], true)) throw new RuntimeException('Provider parser failed.');
}
foreach (['http://example.com/video','https://127.0.0.1/video','https://example.com:444/video'] as $url) {
    try { fj_media_adapter_url($url, ['example.com']); throw new RuntimeException('Unsafe URL accepted.'); }
    catch (RuntimeException $error) { if ($error->getMessage() === 'Unsafe URL accepted.') throw $error; }
}
$html = '<script type="application/ld+json">' . json_encode(['@type'=>'VideoObject','contentUrl'=>'https://cdninstagram.com/a.mp4','name'=>'kata demo']) . '</script>';
$metadata = fj_media_metadata_candidates($html);
if (count($metadata['urls']) !== 1 || $metadata['title'] !== 'kata demo') throw new RuntimeException('Metadata parser fixture failed.');
echo "PHP social adapter URL, provider, metadata and SSRF guards: PASS\n";
