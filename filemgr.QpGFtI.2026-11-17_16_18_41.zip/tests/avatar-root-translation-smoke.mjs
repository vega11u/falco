import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../index.php', import.meta.url), 'utf8');
const start = source.indexOf('function buildAvatarRootReferences(');
assert(start >= 0, 'camera-relative avatar root helper must exist');
const open = source.indexOf('{', start);
let depth = 0, end = -1;
for (let i = open; i < source.length; i++) {
  if (source[i] === '{') depth++;
  else if (source[i] === '}' && --depth === 0) { end = i + 1; break; }
}
assert(end > open, 'avatar root helper must be a complete function');
const median = values => { const v = values.filter(Number.isFinite).sort((a,b)=>a-b); if (!v.length) return null; const i = Math.floor(v.length/2); return v.length%2 ? v[i] : (v[i-1]+v[i])/2; };
const clamp = (x,a,b) => Math.max(a, Math.min(b, x));
const build = new Function('median', 'clamp', `return (${source.slice(start, end)});`)(median, clamp);
function frame(t, shift=0, segment=0) {
  const im = Array.from({length:33},()=>null), w = Array.from({length:33},()=>null);
  im[11]=[.40+shift,.25,0,.95]; im[12]=[.60+shift,.25,0,.95];
  im[23]=[.45+shift,.50,0,.95]; im[24]=[.55+shift,.50,0,.95];
  w[11]=[-.10,-.40,0,.95]; w[12]=[.10,-.40,0,.95];
  w[23]=[-.05,0,0,.95]; w[24]=[.05,0,0,.95];
  return {t,im,w,camera_segment_id:segment};
}
const referenceFrames=Array.from({length:20},(_,i)=>frame(i/30));
const refs=build(referenceFrames, 16/9);
assert(refs[0] && refs[0].samples===20, 'root baseline must be robustly estimated per camera segment');
const moving=frame(1,.06),hipX=(moving.im[23][0]+moving.im[24][0])*.5;
const dx=(hipX-refs[0].hipX)*(16/9)*refs[0].worldPerImageUnit;
const rootShift=clamp(dx,-refs[0].maxShift,refs[0].maxShift);
assert(rootShift>.1, 'visible pelvis travel must be restored as horizontal avatar root motion');
const cut=build([frame(0,0,0),frame(.03,.4,1)],16/9);
assert(cut[0]&&cut[1]&&cut[0].hipX!==cut[1].hipX, 'a camera cut must get independent root references');
console.log('Avatar root translation smoke: PASS (pelvis path, world/image scaling, camera-segment isolation).');
