<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/purcell-search-memory.php';
$dir=sys_get_temp_dir().'/falco-1000-memory-'.bin2hex(random_bytes(5));mkdir($dir,0700,true);
try{
 $rows=[];for($i=1;$i<=1000;$i++)$rows[]=['id'=>'hyp-'.str_pad((string)$i,4,'0',STR_PAD_LEFT),'family'=>'left_arm:arc_up','score'=>75.5,'passed'=>true,'engine_score'=>82,'objective_scores'=>['economy'=>80,'speed'=>78,'coherence'=>75],'metrics'=>['bone_distortion'=>.015],'muscle_phase_levels'=>[0,1,2,3,1]];
 $data=['action'=>'save_run','schema'=>'purcell-wide-search-v2-1000','unit_name'=>'Sanchin','scope_start'=>1,'scope_end'=>3,'selection_reason'=>'coherence_below_60','coherence'=>45.2,'candidates'=>$rows];
 $json=json_encode($data);if(strlen($json)>1600000)throw new RuntimeException('HTTP body exceeds cap');
 $result=fj_purcell_search_memory($dir,'POST',$data);if(($result['stored']??null)!==1000)throw new RuntimeException('1000 not stored');
 $id=$result['run_id'];fj_purcell_search_memory($dir,'POST',['action'=>'reject_candidate','run_id'=>$id,'candidate_id'=>'hyp-0010']);
 fj_purcell_search_memory($dir,'POST',['action'=>'select','run_id'=>$id,'candidate_id'=>'hyp-0001','comment'=>'Больше согласованности']);
 $read=fj_purcell_search_memory($dir,'GET');$run=$read['runs'][0]??[];
 if(count($run['candidates']??[])!==1000||($run['source_coherence']??null)!==45.2||($run['selected_candidate']??null)!=='hyp-0001'||!($run['candidates'][9]['user_rejected']??false))throw new RuntimeException('Memory roundtrip mismatch');
 echo 'PASS PHP 1000 independent scores, 3 categories, source coherence, rejection, selection, server memory: '.strlen($json).' bytes'.PHP_EOL;
}finally{
 foreach(glob($dir.'/*')?:[] as $file)@unlink($file);@rmdir($dir);
}
