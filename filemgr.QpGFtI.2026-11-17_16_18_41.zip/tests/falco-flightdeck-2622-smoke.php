<?php
declare(strict_types=1);
$root=dirname(__DIR__);$src=(string)file_get_contents($root.'/index.php');$css=(string)file_get_contents($root.'/falco-jugger-ui.css');$js=(string)file_get_contents($root.'/falco-jugger-ui.js');
$checks=[
 'core remains 23.0.27'=>trim((string)file_get_contents($root.'/VERSION'))==='23.0.27',
 'fixed mesh topology remains 2048'=>str_contains((string)file_get_contents($root.'/FALCO26_RELEASE_VERSION.txt'),'2048 vertices'),
 'desktop player is fixed to viewport'=>preg_match('/\.fj-player-column\{position:fixed;top:16px;right:var\(--fj-player-right\);width:var\(--fj-player-width\)/',$css)===1,
 'desktop player has no nested scrolling'=>str_contains($css,'.analysis-dock{display:flex;flex-direction:column')&&str_contains($css,'overflow:clip;overscroll-behavior:none'),
 'nav groups do not create scroll roots'=>preg_match('/\.fj-side-rail \.f24-rail-group\{[^}]*overflow:visible/',$css)===1&&!preg_match('/\.fj-side-rail \.f24-rail-group\{[^}]*overflow-y:auto/',$css),
 'navigation rail remains viewport fixed'=>str_contains($css,'.fj-side-rail{position:fixed;'),
 'player reserved grid width matches fixed player'=>str_contains($css,'grid-template-columns:minmax(0,1fr) var(--fj-player-width)'),
 'mobile player has bounded non-scroll composition'=>str_contains($css,'body.fj-player-expanded .analysis-dock{display:flex;flex-direction:column;justify-content:flex-start;overflow:clip}'),
 'video uses contain sizing'=>str_contains($css,'object-fit:contain;object-position:center center'),
 'no legacy sticky player remains'=>!str_contains($css,'.fj-player-column{position:sticky'),
 '3D reveal does not auto-scroll fixed player'=>!str_contains($src,"pane.scrollIntoView({behavior:'smooth',block:'center'})"),
 'player collapse control is wired'=>str_contains($src,'id="fjPlayerCollapse"')&&str_contains($js,"$('fjPlayerCollapse')?.addEventListener('click'"),
 'journal is separate drawer'=>str_contains($src,'id="fjJournalDrawer"')&&str_contains($js,'journalMount.append(journal)'),
 'single CSS and controller cache keys'=>substr_count($src,'falco-jugger-ui.css?v=26.2.2')===1&&substr_count($src,'falco-jugger-ui.js?v=26.2.2')===1,
 'Purcell optimizer remains global'=>str_contains($src,'data-optimizer-feedback="overall"')&&!preg_match('/data-optimizer-feedback="(?:speed|arms|legs|balance|feet)"/',$src),
];
foreach(['lully.php','purcell-lab.php','models.php','Memories.php'] as $page){$t=(string)file_get_contents($root.'/'.$page);$checks["$page uses 26.2.2 stylesheet"]=str_contains($t,'falco-jugger-ui.css?v=26.2.2');}
foreach($checks as $label=>$ok){echo ($ok?'PASS':'FAIL')." $label\n";if(!$ok)$failed=true;}
exit(!empty($failed)?1:0);
