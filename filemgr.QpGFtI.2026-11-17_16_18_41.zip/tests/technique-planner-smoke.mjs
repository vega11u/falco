import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { buildBiomechanicalSequencePlan } from '../technique-planner.mjs';
const anatomyModel = JSON.parse(readFileSync(new URL('../data/anatomy-functional-model.json', import.meta.url), 'utf8'));

function pose(t, segment=0) {
  const w=Array.from({length:33},()=>[0,0,0,1]);
  // Hip and shoulder axes, torso, limbs in MediaPipe-like world coordinates.
  w[0]=[0,.05,0,1]; w[11]=[-.23,.42,0,1]; w[12]=[.23,.42,0,1];
  w[13]=[-.36,.60,.06,1]; w[14]=[.36,.60,-.06,1];
  w[15]=[-.40,.80,.12+Math.sin(t*2)*.04,1]; w[16]=[.40,.80,-.12,1];
  w[17]=[-.43,.82,.15,1];w[18]=[-.39,.83,.15,1];w[19]=[-.41,.84,.16,1];w[20]=[-.42,.84,.17,1];w[21]=[-.45,.82,.15,1];w[22]=[.43,.82,-.15,1];
  w[23]=[-.15,.92,0,1];w[24]=[.15,.92,0,1];
  w[25]=[-.16,1.18,.02,1];w[26]=[.16,1.18,-.02,1];
  w[27]=[-.17,1.42,.03,1];w[28]=[.17,1.42,-.03,1];
  w[29]=[-.18,1.45,.02,1];w[30]=[.18,1.45,-.02,1];
  w[31]=[-.18,1.45,.25,1];w[32]=[.18,1.45,.25,1];
  // Small pelvis rotation and kick extension varying across time.
  const z=.015*Math.sin(t*3); w[23][2]=z-.03;w[24][2]=z+.03;
  const kick=Math.max(0,Math.sin((t-1.5)*Math.PI));
  w[25][2]+=.08*kick;w[27][2]+=.30*kick;w[31][2]+=.42*kick;w[25][1]-=.12*kick;w[27][1]-=.35*kick;w[31][1]-=.5*kick;
  const im=w.map(p=>[.5+p[0]*.32,.1+p[1]*.55,p[2],p[3]]);
  return {t,sample_index:Math.round(t*30),camera_segment_id:segment,w,im,_support:{side:'left',confidence:.82}};
}
const frames=Array.from({length:180},(_,i)=>pose(i/30));
const patterns=[
  {kind:'stance',label:'Стойка A',confirmed:true,rejected:false,instances:[{start:.10,end:.55,review:'yes'},{start:1.45,end:1.90,review:'yes'}]},
  {kind:'kick',label:'Удар ногой',confirmed:true,rejected:false,instances:[{start:.70,end:1.20,review:'yes'},{start:2.05,end:2.55,review:'yes'}]},
  {kind:'hand_strike',label:'Удар рукой',confirmed:true,rejected:false,instances:[{start:2.75,end:3.25,review:'yes'}]}
];
const metrics=frames.map((f,i)=>({t:f.t,bos_reliable:i%3===0}));
const plan=buildBiomechanicalSequencePlan({frames,patterns,metrics,feedback:{transition:2,legs:3},goal:'speed',style:'shotokan',anatomyModel});
assert.equal(plan.available,true);
assert.equal(plan.source.confirmed_instances,5);
assert.ok(plan.patterns.length>=3);
assert.ok(plan.patterns.some(x=>Object.values(x.within_pattern.path).some(p=>p&&Number.isFinite(p.reverse_progress_fraction)&&Number.isFinite(p.peak_progress_ratio))), 'within-pattern path must expose reverse steps and speed-peak phase');
assert.ok(plan.transitions.some(x=>Number.isFinite(x.features.left_hikite_elbow_angle_before)), 'transition must expose hikite elbow geometry');
assert.ok(plan.transitions.length>=3,'transition chain should be analysed');
assert.ok(plan.transitions.some(x=>x.next_pattern_analysis&&Number.isFinite(x.next_pattern_analysis.peak_progress_ratio)), 'next-pattern full trajectory phase should be exposed');
assert.ok(plan.transitions.some(x=>x.to.kind==='kick'&&x.next_pattern_analysis.moving_limb==='left_foot'), 'dominant kick limb should be selected from observed motion, not left/right list order');
assert.ok(plan.functional_anatomy?.roles?.antagonists&&plan.functional_anatomy?.tendon_role&&plan.functional_anatomy?.ligament_role, 'functional muscle/tendon/ligament model must be explicit');
assert.ok(plan.recommendations.some(x=>/опорную стопу|chamber/i.test(x.title)), 'kick preparation cue should exist');
assert.ok(plan.recommendations.some(x=>/хиките/i.test(x.title)), 'hand strike preparation cue should exist');
assert.equal(plan.mode,'recommendations_not_synthetic_pose');
assert.equal(plan.knowledge_base.version, 'kata-biomechanics-concepts-v1');
assert.equal(plan.knowledge_base.concepts.length, 7, 'planner should load the complete additive movement concept catalogue');
assert.ok(plan.knowledge_base.optimization_decision_rules.length >= 7, 'optimizer decision rules must reach the live plan');
assert.ok(plan.recommendations.some(x => (x.knowledge||[]).some(k => k.id === 'knee_drive_chamber')), 'kick recommendations must cite the chamber/knee-drive knowledge');
assert.ok(plan.recommendations.some(x => (x.knowledge||[]).some(k => k.id === 'coil_counter_rotation')), 'hand-strike recommendations must cite coil/counter-rotation knowledge');
assert.ok(plan.limitations.some(x=>x.includes('muscle activation')||x.includes('muscle')));
const named=buildBiomechanicalSequencePlan({frames,metrics,patterns:[
  {kind:'kick',label:'Mae geri',confirmed:true,instances:[{start:.70,end:1.20,review:'yes'}]},
  {kind:'kick',label:'Yoko geri',confirmed:true,instances:[{start:2.05,end:2.55,review:'yes'}]}
]});
assert.equal(named.patterns.length,2,'different technique labels must not be merged into one kick profile');
assert.notEqual(named.patterns[0].label,named.patterns[1].label);
const unconfirmed=buildBiomechanicalSequencePlan({frames,patterns:patterns.map(g=>({...g,confirmed:false})),metrics});
assert.equal(unconfirmed.source.confirmed_instances,0,'unconfirmed pattern groups must not become personal references');
console.log('Technique planner smoke: PASS');
