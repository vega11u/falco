import assert from 'node:assert/strict';
import {makeTemporalPattern,readTemporalPattern} from '../temporal-pattern-schema.mjs';
const frames=Array.from({length:61},(_,i)=>({t:i/30,im:[],w:[],phase:i<10?'windup':i<50?'execution':'recovery'}));
const p=makeTemporalPattern({kind:'punch',label:'gyaku-zuki',frames,athlete:{height_m:1.72}});
assert.equal(p.sample_count,61);assert.equal(p.schema,'kata-pattern-v2');assert.equal(p.athlete_profile.height_m,1.72);assert.equal(readTemporalPattern({frames}).legacy_compatible,true);
console.log('temporal pattern contract: ok');
