#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
php -l index.php >/dev/null
php -l models.php >/dev/null
node --check depth-worker.js
node --check depth-review-core.mjs
node tests/depth-review-23-0-4-smoke.mjs
node tests/depth-reconstruction-smoke.mjs
node tests/player-trim-core-smoke.mjs
node tests/workspace-recovery-policy-smoke.mjs
php index.php | node -e 'let s="";process.stdin.setEncoding("utf8");process.stdin.on("data",x=>s+=x);process.stdin.on("end",()=>{if(!s.includes("models.php")||!s.includes("id=\"trimSeek\"")||s.includes("id=\"lightweightAnalysisToggle\"")||!s.includes("depth-review-core.mjs"))process.exit(1);console.log("HTML controls and Model navigation PASS")});'
node --input-type=module <<'JS'
import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const source=readFileSync('index.php','utf8'),depth=readFileSync('depth-worker.js','utf8');
assert.match(source,/purcellOnly\?\(\(\$\('depthModelChoice'\)/);
assert.match(source,/option value="consensus"/);
assert.match(source,/review:!purcellOnly&&poseReview\.uncertain/);
assert.match(depth,/env\.useBrowserCache = true; env\.useWasmCache = true/);
assert.match(depth,/const second=downsample\(await evaluateMap\(model,inferenceCanvas\),80\)/);
assert.match(depth,/verification: reviewReasons\.length/);
assert.match(depth,/fuseConsensusMaps\(base,evidence/);
console.log('Small / Base / consensus selector, selective review, caching PASS');
JS
