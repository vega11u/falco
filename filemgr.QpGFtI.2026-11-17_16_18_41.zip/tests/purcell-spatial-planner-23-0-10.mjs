import assert from 'node:assert/strict';
import {spatialReadiness,generateSpatialCandidate,evaluateSpatialGravity} from '../purcell-spatial-core.mjs';
import {assessPoseSequence,analyzeNextMovementReadiness} from '../biomechanics-core.mjs';
import {buildBiomechanicalSequencePlan} from '../technique-planner.mjs';
import {relativeSceneCloud} from '../scene-reconstruction-core.mjs';
const tpose={11:[-.19,-.25,0],12:[.19,-.25,0],13:[-.27,-.02,.02],14:[.27,-.02,.02],15:[-.34,.19,.03],16:[.34,.19,.03],23:[-.11,.20,0],24:[.11,.20,0],25:[-.12,.57,.02],26:[.12,.57,.02],27:[-.13,.90,.02],28:[.13,.90,.02],29:[-.13,.95,0],30:[.13,.95,0],31:[-.14,.96,-.09],32:[.14,.96,-.09]};
const frames=Array.from({length:34},(_,i)=>{const w=Array.from({length:33},()=>[0,0,0,1]);for(const [k,p] of Object.entries(tpose))w[Number(k)]=[...p,1];return {t:i/30,sample_index:i,camera_segment_id:0,w,im:w.map(p=>[.5+p[0]*.5,.23+p[1]*.5,p[2],1])};});
assert.ok(spatialReadiness(frames).available);
let passed=0, signatures=new Set(),scores=[];
for(const idx of [0,10,20,30,40,50,80,100,125,150,170,190,240,310,440,500,570,650,740,810,880,950]) {
 const c=generateSpatialCandidate(frames,idx);const gravity=evaluateSpatialGravity(frames,c.frames);
 const quality=assessPoseSequence(c.frames);const ready=analyzeNextMovementReadiness(c.frames);
 const plan=buildBiomechanicalSequencePlan({frames:c.frames,patterns:[],metrics:[],goal:'balanced'});
 assert.ok(Number.isFinite(gravity.score)&&Number.isFinite(quality.score),'Finite gravity and biomechanics');
 assert.equal(ready.schema,'falco-next-movement-v2');assert.equal(plan.schema,'falco-biomechanical-sequence-plan-v1');
 signatures.add(JSON.stringify(c.frames[16].w[15].slice(0,3).map(x=>+x.toFixed(5))));
 scores.push(gravity.score);if(gravity.passed)passed++;
}
assert.ok(signatures.size>=8,`3D planner input distinctness ${signatures.size}`);
assert.ok(passed>1,`Physically screened 3D candidates ${passed}`);
const snapshot={width:40,height:20,values:Array.from({length:800},(_,i)=>Math.round(i/800*255))};
const cloud=relativeSceneCloud(snapshot,{maxPoints:500});assert.ok(cloud.points.length>50&&cloud.points.length<=500);
assert.ok(cloud.units.includes('NOT metres'));assert.throws(()=>relativeSceneCloud({width:10,height:10,values:[]}),/Нет карты/);
console.log(`PASS 22 independent 3D candidates through production biomechanics/readiness/planner, ${signatures.size} distinct, relative scene export`);
