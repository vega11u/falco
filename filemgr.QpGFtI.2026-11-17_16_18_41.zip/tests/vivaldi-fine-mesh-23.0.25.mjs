import assert from 'node:assert/strict';
import {buildVivaldiFineMesh,paintVivaldiMesh2D,VIVALDI_MESH_RESOLUTIONS} from '../vivaldi-fine-mesh.mjs';
import {normalizedTechniqueVector} from '../bach-coordinate-atlas.mjs';
const p=Array.from({length:33},()=>[0,0,0,0]);
for(const [i,xy] of [[0,[.5,.13]],[11,[.42,.27]],[12,[.58,.27]],[13,[.34,.4]],[14,[.65,.4]],[15,[.28,.55]],[16,[.7,.55]],[23,[.44,.57]],[24,[.56,.57]],[25,[.44,.76]],[26,[.57,.76]],[27,[.44,.95]],[28,[.57,.95]]])p[i]=[...xy,.0,.98];
const f={im:p,render_im:p,w:p.map(q=>[q[0],q[1],q[2],q[3]]),render_w:p};
const profile={width_profile:{torso:[[.65,1]],left_arm_upper:[[.22,1]],left_arm_lower:[[.22,1]],right_arm_upper:[[.22,1]],right_arm_lower:[[.22,1]],left_leg_upper:[[.35,1]],left_leg_lower:[[.35,1]],right_leg_upper:[[.35,1]],right_leg_lower:[[.35,1]]}};
for(const [mode,n] of Object.entries(VIVALDI_MESH_RESOLUTIONS)){
 const m=buildVivaldiFineMesh(f,profile,{resolution:mode,space:'2d'});
 assert.equal(m.vertex_count,n,mode+' exact topology');
 assert.equal(m.positions.length,n*4);
 assert.ok(m.visible_vertices>n*.65);
 assert.ok(m.triangles.length>0);
 assert.ok(m.segments.every(x=>x.first+x.count<=n));
 assert.ok([...m.positions].every(Number.isFinite));
}
const m=buildVivaldiFineMesh(f,profile,{resolution:'fine',space:'3d'});
assert.equal(m.vertex_count,8192);
const altered={...f,im:f.im.map(q=>[.5+(q[0]-.5)*1.5,.5+(q[1]-.5)*1.5,q[2],q[3]])};
const a=normalizedTechniqueVector(f),b=normalizedTechniqueVector(altered);
assert.ok(a&&b);
assert.ok(a.every((x,i)=>x===null&&b[i]===null||Math.abs(x-b[i])<1e-8),'technique scale invariant');
const ctx={save(){},restore(){},beginPath(){},moveTo(){},lineTo(){},closePath(){},fill(){},stroke(){}};
assert.equal(paintVivaldiMesh2D(ctx,f,profile,{resolution:'standard',width:600,height:400}),false,'A pose-only skeleton must never masquerade as a personalized measured surface');
console.log('PASS vivaldi geometric fine 512/2048/8192, invariance and renderer');
