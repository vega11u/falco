<?php
declare(strict_types=1);
$root = realpath($argv[1] ?? dirname(__DIR__));
if ($root === false) { fwrite(STDERR, "Invalid project root\n"); exit(2); }
$fail = [];
$pages = ['index.php','models.php','Memories.php','lully.php','purcell-lab.php'];
function readRequired(string $root, string $file, array &$fail): string {
    $path = $root . '/' . $file;
    if (!is_file($path)) { $fail[] = "Missing file: {$file}"; return ''; }
    return (string)file_get_contents($path);
}
function countHtmlStyleAttrs(string $source): array {
    $out = [];
    if (!preg_match_all('~(?<=\s)style\s*=\s*(["\'])(.*?)\1~is', $source, $m, PREG_OFFSET_CAPTURE)) return $out;
    foreach ($m[0] as $i => $full) {
        $offset = $full[1];
        $prefix = substr($source, 0, $offset);
        $lt = strrpos($prefix, '<'); $gt = strrpos($prefix, '>');
        if ($lt === false || ($gt !== false && $lt < $gt)) continue;
        $end = strpos($source, '>', $offset);
        if ($end === false) continue;
        $tag = substr($source, $lt, $end - $lt + 1);
        if (!preg_match('~^<[a-z][a-z0-9:-]*\b~i', $tag)) continue;
        $out[] = trim($m[2][$i][0]);
    }
    return $out;
}
foreach ($pages as $page) {
    $s = readRequired($root, $page, $fail);
    if ($s === '') continue;
    if (!preg_match('~<link\b[^>]*href=["\']falco-jugger-ui\.css\?v=27\.2\.2-C\.D2["\']~i', $s)) $fail[] = "{$page}: stylesheet cache key is not 27.2.2";
    if (!preg_match('~<script\b[^>]*src=["\']falco-jugger-ui\.js\?v=27\.2\.2-C\.D2["\']~i', $s)) $fail[] = "{$page}: UI JS cache key is not 27.2.2";
    $attrs = countHtmlStyleAttrs($s);
    foreach ($attrs as $v) if (!str_contains($v, '${') && !str_contains($v, '<?php')) $fail[] = "{$page}: static inline style remains: {$v}";
    if (preg_match('~<style\b~i', $s)) $fail[] = "{$page}: inline style block remains";
}
$index = readRequired($root,'index.php',$fail);
$models = readRequired($root,'models.php',$fail);
$purcell = readRequired($root,'purcell-lab.php',$fail);
$css = readRequired($root,'falco-jugger-ui.css',$fail);
$indexDynamicStyles = countHtmlStyleAttrs($index);
if (count($indexDynamicStyles) !== 4 || array_filter($indexDynamicStyles, fn($v) => !str_contains($v, '${')) ) $fail[] = 'Expected exactly four dynamic progress/timeline style attributes in index.php';
$versionText = readRequired($root,'FALCO_RELEASE_VERSION.txt',$fail);
$version = trim(strtok($versionText, "\n") ?: '');
if ($version !== '27.2.2-C.D2') $fail[] = "Release marker mismatch: {$version}";
if (preg_match('~\$\(\'serverDot\'\)\.style\.background|\.style\.cursor\s*=~', $index)) $fail[] = "Static server/interaction styling remains in index.php";
if (preg_match('~\.style\.(?:display|marginTop|width|textAlign|padding|margin|gap|flexWrap)\s*=~', $models)) $fail[] = "Static style property assignments remain in models.php";
if (str_contains($models, "serverDot').style.background") || str_contains(readRequired($root,'Memories.php',$fail), "serverDot').style.background")) $fail[] = "Static server-dot styling remains in model/report pages";
if (preg_match('~26\.(?:1\.0|2\.2|2\.3|3)\b~', $css)) $fail[] = "Historical 26.x layer marker remains in active CSS";
foreach (['aero-advanced-trim','aero-model-pipeline-list','depth-mode-switch','depth-policy-switch','overlay-legend','optimizer-kpi','optimizer-preview-wrap','replay-glyph','replay-type','report-table-wrap','table-responsive','top-link','replay-visual'] as $stale) {
    if (preg_match('~(?<![\w-])\.'.preg_quote($stale,'~').'(?![\w-])~', $css)) $fail[] = "Unreferenced legacy selector remains: {$stale}";
}
if (str_contains($css,'#c6f36b') || str_contains($css,'rgba(198, 243, 107')) $fail[] = "Legacy lime accent remains in CSS";
if (substr_count($css,'{') !== substr_count($css,'}')) $fail[] = "CSS brace balance failed";
if (preg_match('~@import\b~i',$css)) $fail[] = "Unexpected CSS @import remains";
foreach (['fj-reference-grid','fj-reference-list','fj-reference-video','fj-score-hero','fj-table-min-1180','fj-choice-actions','fj-progress-zero','fj-interactive-row'] as $class) {
    if (!preg_match('~\.'.preg_quote($class,'~').'\s*\{~',$css)) $fail[] = "Missing migrated style class: {$class}";
}
if ($fail) {
    foreach ($fail as $item) fwrite(STDERR, "FAIL: {$item}\n");
    exit(1);
}
echo "Falco UI cleanup 27.2.2 regression checks: PASS\n";
echo "Static inline styles: 0; live computed geometry/progress styles are intentionally retained.\n";
echo "Five page stylesheet and UI-script cache keys: PASS.\n";
echo "D2 legacy selector cleanup and CSS integrity: PASS.\n";
