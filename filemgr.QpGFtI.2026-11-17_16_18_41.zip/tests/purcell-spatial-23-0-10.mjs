import assert from 'node:assert/strict';
import {spatialReadiness,generateSpatialCandidate,evaluateSpatialGravity,spatialReplayPoints} from '../purcell-spatial-core.mjs';
const world=Array.from({length:33},()=>[0,0,0,1]);
const data={11:[-.19,-.25,0],12:[.19,-.25,0],13:[-.27,-.02,.02],14:[.27,-.02,.02],15:[-.34,.19,.03],16:[.34,.19,.03],23:[-.11,.20,0],24:[.11,.20,0],25:[-.12,.57,.02],26:[.12,.57,.02],27:[-.13,.90,.02],28:[.13,.90,.02],29:[-.13,.95,0],30:[.13,.95,0],31:[-.14,.96,-.09],32:[.14,.96,-.09]};
for(const [key,pos] of Object.entries(data))world[Number(key)]=[...pos,1];
const im=world.map(p=>[.50+p[0]*.5,.23+p[1]*.5,0,1]);
const source=Array.from({length:61},(_,i)=>({t:i/30,sample_index:i,w:world.map(p=>p.slice()),im:im.map(p=>p.slice())}));
const original=JSON.stringify(source);
assert.ok(spatialReadiness(source).available,JSON.stringify(spatialReadiness(source)));
let pass=0,unique=new Set(),chains=new Set(),modes=new Set();
for(let i=0;i<1000;i++){
 const c=generateSpatialCandidate(source,i),gravity=evaluateSpatialGravity(source,c.frames);
 assert.equal(c.frames[0].w[15][0],source[0].w[15][0]);assert.equal(c.frames.at(-1).w[15][0],source.at(-1).w[15][0]);
 assert.ok(Number.isFinite(gravity.score)&&gravity.gravity_m_s2===9.81);
 unique.add(c.frames[25].w[15].map(v=>Number(v).toFixed(4)).join(','));chains.add(c.chain);modes.add(c.mode);if(gravity.passed)pass++;
}
assert.ok(unique.size>40,`entropy across variants ${unique.size}`);assert.equal(chains.size,5);assert.ok(modes.size>=20);assert.ok(pass>0,'At least small hypotheses must pass the physical screen');
assert.equal(JSON.stringify(source),original,'Source training 3D/2D must not mutate');
const projected=spatialReplayPoints(source[0]);assert.ok(projected[11]?.x<projected[12]?.x);
const bad=source.map(f=>({...f,w:[]}));assert.equal(spatialReadiness(bad).available,false);
console.log(`PASS 1000 independent 3D geometries, ${unique.size} distinct mid-frame trajectories, ${pass} physically screened, g=9.81, immutable source`);
