#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
cd "$ROOT"
for file in index.php uppurcell.php lully.php purcell-lab.php Memories.php tests/intelligence-data-smoke.php tests/release-smoke.php tests/falco24-workspace-integration-smoke.php tests/falco24-learning-centers-smoke.php tests/learning-api-smoke.php tests/local-video-smoke.php; do php -l "$file" >/dev/null; done
for file in setup-release.sh setup-regru.sh setup-assets.sh setup-video-runtime.sh setup-ffmpeg-wasm.sh setup-media-import.sh setup-lux-fallback.sh setup-media-resilience.sh tests/js-runtime.sh tests/javascript-syntax-smoke.sh tests/optimizer-smoke.sh tests/media-import-smoke.sh tests/learning-api-smoke.sh tests/media-import-cron-smoke.sh tests/server-report-library-smoke.sh tests/purcell-and-report-api-smoke.sh tests/v22-smoke.sh tests/v22-2-studio-smoke.sh tests/v22-5-baroque-folio-smoke.sh tests/lux-only-cron-smoke.sh; do bash -n "$file"; done
bash -c 'quickjs_ng_supported(){ [[ "$1" =~ ^([0-9]+)\.([0-9]+)\.([0-9]+)$ ]] || return 1; local major="${BASH_REMATCH[1]}" minor="${BASH_REMATCH[2]}"; (( 10#$major > 0 || (10#$major == 0 && 10#$minor >= 12) )); }; quickjs_ng_supported 0.12.0 && quickjs_ng_supported 0.18.0 && ! quickjs_ng_supported 0.11.9 && ! quickjs_ng_supported 0.9.0'
php tests/intelligence-data-smoke.php
php tests/release-smoke.php
php tests/falco24-workspace-integration-smoke.php
php tests/falco24-learning-centers-smoke.php
php tests/falco24-security-smoke.php
php tests/falco24-ui-smoke.php
php tests/falco-flightdeck-2622-smoke.php
php tests/falco-flightdeck-2621-smoke.php
node tests/falco24-ui-smoke.mjs
node tests/falco25-purcell-overall-smoke.mjs
php tests/local-video-smoke.php
bash tests/javascript-syntax-smoke.sh
php tests/learning-api-smoke.php
bash tests/server-report-library-smoke.sh
bash tests/v22-smoke.sh
bash tests/v22-2-studio-smoke.sh
bash tests/v23-frutiger-aero-smoke.sh
bash tests/v23-0-1-patch-smoke.sh
bash tests/v23-0-2-patch-smoke.sh
bash tests/v23-0-3-patch-smoke.sh
bash tests/optimizer-smoke.sh
source "$ROOT/tests/js-runtime.sh"
if js_runtime_detect "$ROOT"; then
  js_runtime_report
  js_runtime_run "$ROOT/tests/avatar-render-core-smoke.mjs"
  js_runtime_run "$ROOT/tests/avatar-root-translation-smoke.mjs"
  js_runtime_run "$ROOT/tests/depth-reconstruction-smoke.mjs"
  js_runtime_run "$ROOT/tests/depth-mode-policy-smoke.mjs"
  js_runtime_run "$ROOT/tests/workspace-recovery-policy-smoke.mjs"
  js_runtime_run "$ROOT/tests/biomechanics-core-smoke.mjs"
  js_runtime_run "$ROOT/tests/kata-recognition-core-smoke.mjs"
  js_runtime_run "$ROOT/tests/technique-planner-smoke.mjs"
  js_runtime_run "$ROOT/tests/player-zoom-core-smoke.mjs"
  js_runtime_run "$ROOT/tests/purcell-core-smoke.mjs"
  js_runtime_run "$ROOT/tests/purcell-baseline-smoke.mjs"
  js_runtime_run "$ROOT/tests/scene-perspective-core-smoke.mjs"
  js_runtime_run "$ROOT/tests/kick-window-smoke.mjs"
  js_runtime_run "$ROOT/tests/social-file-lifecycle-smoke.mjs"
else
  echo 'ERROR: Node >=22 is required for developer-only JavaScript regression tests; it is not required on the hosting server.' >&2
  exit 2
fi
bash tests/media-import-smoke.sh
bash tests/lux-only-cron-smoke.sh
if [[ "${RUN_CRON_INTEGRATION:-0}" == '1' ]]; then
  bash tests/media-import-cron-smoke.sh
else
  echo 'CRON integration smoke is separate because it starts detached workers; run RUN_CRON_INTEGRATION=1 bash tests/verify.sh to include it.'
fi
echo 'All developer release checks passed. Production install does not use system Node; browser pose, Lully matching and Purcell biomechanics run in the visitor browser; PHP stores private learning and streaming reports; YouTube EJS uses the isolated private QuickJS-NG binary.'
