import assert from 'node:assert/strict';
import {auditBachReconstruction} from '../bach-reconstruction-audit.mjs';
const frames=Array.from({length:100},(_,i)=>({t:i/30,camera_segment_id:0,im:Array.from({length:33},(_,j)=>[.1+(j%6)*.045,.12+Math.floor(j/6)*.06,0,.95])}));
let audit=auditBachReconstruction(frames);assert.equal(audit.status,'no_obvious_numeric_anomaly');assert.equal(audit.usable_pose_frame_fraction,1);assert.equal(audit.segment_length_relative_error_p95,0);
let noisy=structuredClone(frames);for(let i=10;i<95;i+=2)noisy[i].im[13][0]+=.35;
audit=auditBachReconstruction(noisy);assert(audit.warnings.includes('temporal_acceleration_outliers'));assert(audit.temporal_acceleration_proxy_p95>100);
let missing=structuredClone(frames);for(const f of missing)for(const p of f.im)p[3]=0;
audit=auditBachReconstruction(missing);assert.equal(audit.status,'insufficient_evidence');assert.equal(audit.usable_pose_frame_fraction,0);
console.log('Bach reconstruction audit PASS');
