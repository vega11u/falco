import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const worker = await readFile(new URL('../depth-worker.js', import.meta.url), 'utf8');
const index = await readFile(new URL('../index.php', import.meta.url), 'utf8');
// Current policy: user chooses Small by default; Base, consensus, DPT and GLPN
// are explicit options. Heavy modes must keep the low-RAM gate.
assert.match(worker, /function normalizeMode\(value\).*\['small','base','consensus','dpt','glpn'\]\.includes\(value\).*'small'/);
assert.match(worker, /function modelIdFor\(mode\)/);
assert.match(worker, /\(mode === 'base'\|\|mode==='consensus'\) && reportedMemory && reportedMemory <= 4/);
assert.match(worker, /createPipeline\(pipeline, env, modelId, mode, 'wasm', fallbackDtype\)/);
assert.match(index, /id="depthModelChoice"/);
assert.match(index, /<option value="small">Только Small/);
assert.match(index, /state\.depthMode=.*\$\('depthModelChoice'\)\?\.value\|\|'small'/);
assert.match(index, /depthWorkerRpc\('init',\{mode:requestedMode\}/);
assert.match(index, /state\.depthWorkerReady&&state\.depthWorkerMode===requestedMode/);
console.log('Depth policy: explicit model selection, Small default, low-RAM gate, same-model WASM fallback: PASS');
