/** Bach global evolution planning: a single genome evaluated over a representative
 * sample of the entire performance, then applied continuously to every frame.
 * No independent optimization per chunk and no invented discontinuous transitions.
 */
import {applyGenome, validateHypothesis, assessEvolutionCandidate} from './purcell-evolution-core.mjs';
export const BACH_GLOBAL_EVOLUTION_VERSION='bach-global-evolution-v1';
const finite=Number.isFinite;
function visible(f,j){const p=f?.im?.[j];return Array.isArray(p)&&finite(p[0])&&finite(p[1])&&(p[3]??1)>.2;}
function activity(frames,i){const a=frames[Math.max(0,i-1)],b=frames[Math.min(frames.length-1,i+1)];let sum=0,count=0;for(const id of [11,12,15,16,23,24,27,28]){if(visible(a,id)&&visible(b,id)){sum+=Math.hypot(a.im[id][0]-b.im[id][0],a.im[id][1]-b.im[id][1]);count++;}}return count?sum/count:0;}
/** Sample temporally distributed observations, including peaks of motion and first/last frames.
 * The complete recording is held only once; the train worker receives at most `limit` frames.
 */
export function bachGlobalSample(frames,{limit=360}={}){
 if(!Array.isArray(frames)||frames.length<7)throw Error('Для глобальной эволюции нужно хотя бы 7 кадров');
 const n=frames.length,L=Math.max(7,Math.min(380,Math.floor(limit)));
 if(n<=L)return {frames:frames.slice(),indices:frames.map((_,i)=>i),sampled:false};
 const selected=new Set([0,n-1]);
 const bins=Math.max(1,Math.floor((L-2)/2));
 for(let b=0;b<bins;b++){
  const left=Math.max(1,Math.floor(1+b*(n-2)/bins));
  const right=Math.min(n-2,Math.ceil(1+(b+1)*(n-2)/bins));
  const center=Math.floor((left+right)/2);selected.add(center);
  let best=center,peak=-1;for(let i=left;i<=right;i++){const value=activity(frames,i);if(value>peak){best=i;peak=value;}}selected.add(best);
 }
 if(selected.size>L){const sorted=[...selected].sort((a,b)=>a-b),keep=new Set([0,n-1]);for(let i=0;i<L-2;i++)keep.add(sorted[Math.floor((i+1)*(sorted.length-1)/(L-1))]);return {frames:[...keep].sort((a,b)=>a-b).map(i=>frames[i]),indices:[...keep].sort((a,b)=>a-b),sampled:true};}
 const indices=[...selected].sort((a,b)=>a-b);return {frames:indices.map(i=>frames[i]),indices,sampled:true};
}
/** Decode a single genome for the entire take. Check continuity and anatomical validity.
 * Full resolution output remains an estimate from original observed coordinates.
 */
export function bachApplyGlobalEvolution(frames,genome,{modality='2d'}={}){
 if(!Array.isArray(genome)||!genome.length)throw Error('Эволюция не вернула геном');
 const output=applyGenome(frames,genome,{modality});
 const anatomy=validateHypothesis(frames,output,{requireWorld:modality==='3d'});
 const score=assessEvolutionCandidate(frames,output,{modality,worldReady:modality==='3d'});
 let maxJoin=0,checked=0;
 for(let i=1;i<output.length;i++){
  const dt=output[i].t-output[i-1].t;if(!(dt>.001&&dt<.2))continue;
  for(const j of [15,16,27,28]){const o=output[i].im?.[j],p=output[i-1].im?.[j],a=frames[i].im?.[j],b=frames[i-1].im?.[j];if(![o,p,a,b].every(q=>Array.isArray(q)&&q.length>=2&&finite(q[0])&&finite(q[1])))continue;
   const newDelta=Math.hypot(o[0]-p[0],o[1]-p[1]);const originalDelta=Math.hypot(a[0]-b[0],a[1]-b[1]);maxJoin=Math.max(maxJoin,Math.max(0,newDelta-originalDelta));checked++;
  }
 }
 return {schema:BACH_GLOBAL_EVOLUTION_VERSION,frames:output,score,anatomy,continuity:{checked_pairs:checked,max_extra_step_normalized:maxJoin},accepted:!!(anatomy.passed&&score.passed&&score.adequate_evidence),limitations:['A single genome is global but not a neural physics simulator','Full-video quality requires validation on the original recording']};
}
