# Falco Jugger 23.0.7 — PHP-only research pipeline + Purcell 21 hypotheses

**Upgrade from:** 23.0.6 (requires all earlier patches). Overlay only. Preserve user storage and learning data.

## 1. No Python on the hosting

- `install-research.sh` uses **only PHP CLI**: `research/install_sources.php`, then `research/build_evidence_index.php`.
- You may rebuild the evidence index without network access: `php research/build_evidence_index.php`.
- Downloading published public sources remains optional: `sh install-research.sh --only=opensim_anatomy` or `sh install-research.sh --dry-run`.
- PHP 8+ is required. Remote acquisition uses `ext-curl` or HTTPS `allow_url_fopen` and may fail on restricted shared hosting. Indexing existing files works offline. XML parser extension is optional; a conservative structural-name fallback is included.
- On hosting without PHP CLI, run the PHP indexer on a PC with PHP installed, then upload `data/trained/purcell-evidence-index.json`. You do **not** need Python.
- No Python scripts are called by this release; older Python helper files can remain inert. No automatic process executes during a web visit.
- Downloaded source materials are not automatically trained neural weights. Unavailable/manual sources stay unavailable; none are falsely marked ready.

## 2. 21 separate trajectory hypotheses

After standard Purcell recommendations, the experimental broad-search stage constructs **21** different 2D trajectories for the selected short linkage (typically ~3.4 seconds; at most 300 frames):

- 4 left-arm variants, 4 right-arm variants, 4 left-leg variants, 4 right-leg variants, 5 trunk variants.
- Variants have distinct arc, axis, lift, retract and rotation profiles. Trajectory endpoints and foot contact landmark anchors are preserved. The generator never modifies the measured frames.
- Each candidate is screened independently for bone-length distortion, temporal acceleration proxy, speed preservation, foot-anchor preservation and coordinate bounds.
- **Each** is also passed through existing `assessPoseSequence`, `analyzeNextMovementReadiness`, and `buildBiomechanicalSequencePlan`. These are re-evaluations of simulated *landmark tracks*, **not** MediaPipe inference on synthetic video, ground reaction force measurement or muscle force estimation.
- Knowledge and Purcell finding types influence which generator families are prioritized; learned reference feedback influences amplitude. Uncertain theoretical references never become unquestioned target trajectories.
- Three highest-rated candidates passing constraints are presented, with different body chains preferred for diversity. Scores are **relative numerical screening scores**, not validated correctness percentages. If all fail, there are no invented top-three results.
- Every run attempts to save all 21 scores and pass/fail outcomes to the existing owner's **private** Purcell storage (`trajectory-search.json`). A server failure is clearly reported and selection is disabled rather than silently claiming retention.
- For each top-3 hypothesis: 2.5-second *2D skeleton* preview, an option to select, and an explicit option to mark unsuccessful. User can submit a free-form reason or say that none qualifies.
- A selected hypothesis is previewed as a replacement only in the chosen short window; existing independently validated correction data outside it remain unchanged.
- On subsequent runs, previously **chosen** and expressly **rejected** families mildly adjust the search amplitude. Merely failing a synthetic filter or not being selected is **not** interpreted as a user's judgement. This is adaptive search-policy memory, **not** weight training or deep reinforcement learning.

## 3. Server format and compatibility

- Additive endpoint: `GET/POST index.php?api=purcell-search-memory` under the existing private Purcell data directory. Writes require the application's existing same-origin guard and file locking.
- Current `library.json`, `feedback.json`, `Lully` and report formats remain untouched.
- New data: private `purcell/trajectory-search.json`, retaining up to 150 runs; API reads up to 60 recent runs. Each stores 21 candidate summaries, decisions and comments — **not original videos or full pose trajectories**.
- `Models` displays how many runs, hypotheses, selections and explicit rejections were recorded.

## Safety and scientific limitations

1. A single uncalibrated camera cannot measure kinetic force, tissue activation, exact 3D joint moments or genuine improvement in technique. Do not call a top numerical hypothesis a proven correction.
2. The 21 synthetic 2D hypotheses remain speculative. Human review is needed. Confirm any claimed benefit by capturing a new real performance and comparing measured results, preferably with a qualified instructor.
3. A structurally implausible or poorly tracked source frame is not automatically fixed by trying more hypotheses. Quality gates can reject all candidates.
4. Experimental previews use the project's 2D avatar. There is no new generative video model and no Python/LLM dependency.
5. For speed and memory, the 21-way search is limited to one short linkage per run. It runs **after** primary kata analysis; it is not part of the live frame-processing loop.

## Install and rollback

1. Back up the current site including **private** Lully/Purcell directories and server report storage.
2. Extract `astra_patch_v23.0.7.zip` over the **23.0.6** site root and replace matching code files. Never delete data directories.
3. Refresh the page with cache bypass. Open `Models` and check research index / Purcell search memory.
4. If research files were installed earlier, run `php research/build_evidence_index.php`. If PHP CLI is unavailable on hosting, run it offline on a PHP-capable machine and upload the resulting JSON.
5. Analyze one short kata, open Purcell and inspect three alternative 2D previews. Choose one or reject all, then confirm the selection appears in `Models` after reload.
6. Rollback: restore backed-up 23.0.6 code files. The additive private trajectory-search JSON is ignored by older releases; no migration is necessary.

## Tested

- PHP lint of modified server scripts; JavaScript module syntax.
- 21 deterministic variations, unique families, unchanged original trajectories and protected endpoints.
- 21 independent biomechanics / next movement / planner engine evaluations on a test track.
- Server-memory save, explicit rejection, selection, comment and GET readback.
- PHP-only index on built-in theory, CSV and OpenSim XML fixture (including PHP without SimpleXML).
- Existing optimizer, Purcell baseline and evidence search tests.

**Not tested:** a 100-video production workload, live GPU inference on the user's PC, or exhaustive cross-browser visual QA. New trajectory scores are experimental and not calibrated against instructor-labelled kata corrections.
