<?php
declare(strict_types=1);

/**
 * Falco Jugger media-import control helpers (23.0.17 compatibility layer).
 *
 * These helpers only inspect/stop the current private import job and its lock.
 * They never touch training libraries, reports, model files or browser caches.
 */

if (!function_exists('fj_media_owner_hash')) {
    function fj_media_owner_hash(string $token): ?string
    {
        $token = strtolower(trim($token));
        if (!preg_match('/^[a-f0-9]{64}$/D', $token)) return null;
        return hash('sha256', 'falco-media-owner-v1:' . $token);
    }
}

if (!function_exists('fj_media_owner_matches')) {
    function fj_media_owner_matches(array $job, array $owners): bool
    {
        $stored = strtolower((string)($job['owner'] ?? ''));
        if (!preg_match('/^[a-f0-9]{64}$/D', $stored)) return false;
        foreach ($owners as $owner) {
            $candidate = strtolower((string)$owner);
            if (preg_match('/^[a-f0-9]{64}$/D', $candidate) && hash_equals($stored, $candidate)) return true;
        }
        return false;
    }
}

if (!function_exists('fj_media_process_start_ticks')) {
    /** Linux /proc starttime (field 22), robust to spaces and parentheses in comm. */
    function fj_media_process_start_ticks(int $pid): ?string
    {
        if ($pid < 2 || !is_readable('/proc/' . $pid . '/stat')) return null;
        $raw = @file_get_contents('/proc/' . $pid . '/stat');
        if (!is_string($raw) || $raw === '') return null;
        $close = strrpos($raw, ')');
        if ($close === false) return null;
        $fields = preg_split('/\s+/', trim(substr($raw, $close + 1)));
        // Remaining fields start at field 3 (state); starttime is field 22 => index 19.
        $ticks = $fields[19] ?? null;
        return is_string($ticks) && preg_match('/^[0-9]+$/D', $ticks) ? $ticks : null;
    }
}

if (!function_exists('fj_media_process_cmdline')) {
    function fj_media_process_cmdline(int $pid): string
    {
        if ($pid < 2 || !is_readable('/proc/' . $pid . '/cmdline')) return '';
        $raw = @file_get_contents('/proc/' . $pid . '/cmdline');
        return is_string($raw) ? str_replace("\0", ' ', $raw) : '';
    }
}

if (!function_exists('fj_media_process_matches_job')) {
    function fj_media_process_matches_job(int $pid, string $jobDir, ?string $expectedTicks = null): bool
    {
        $ticks = fj_media_process_start_ticks($pid);
        if ($ticks === null) return false;
        $stat = @file_get_contents('/proc/' . $pid . '/stat');
        $close = is_string($stat) ? strrpos($stat, ')') : false;
        if ($close === false) return false;
        $parts = preg_split('/\s+/', trim(substr($stat, $close + 1)));
        $state = (string)($parts[0] ?? '');
        if (in_array($state, ['Z', 'X', 'x'], true)) return false;
        if ($expectedTicks !== null && $expectedTicks !== '') return hash_equals($expectedTicks, $ticks);
        $real = realpath($jobDir);
        $needle = $real !== false ? $real : $jobDir;
        $cmd = fj_media_process_cmdline($pid);
        // Without a start-tick stamp, require the process command line to identify this job.
        return $needle !== '' && $cmd !== '' && str_contains($cmd, $needle);
    }
}

if (!function_exists('fj_media_job_process_pids')) {
    /** Return only PIDs whose identity is tied to this exact job directory. */
    function fj_media_job_process_pids(string $jobDir): array
    {
        $jobDir = rtrim($jobDir, DIRECTORY_SEPARATOR);
        if ($jobDir === '' || !is_dir($jobDir)) return [];
        $specs = [
            ['.started', '.started-start'],
            ['.child-pid', '.child-pid-start'],
        ];
        $found = [];
        foreach ($specs as [$pidFile, $ticksFile]) {
            $raw = trim((string)@file_get_contents($jobDir . DIRECTORY_SEPARATOR . $pidFile));
            if (!preg_match('/^[0-9]{1,10}$/D', $raw)) continue;
            $pid = (int)$raw;
            if ($pid < 2 || isset($found[$pid])) continue;
            $expected = trim((string)@file_get_contents($jobDir . DIRECTORY_SEPARATOR . $ticksFile));
            if ($expected !== '' && !preg_match('/^[0-9]+$/D', $expected)) $expected = '';
            if (fj_media_process_matches_job($pid, $jobDir, $expected !== '' ? $expected : null)) $found[$pid] = $pid;
        }
        return array_values($found);
    }
}

if (!function_exists('fj_media_job_last_activity')) {
    function fj_media_job_last_activity(string $jobDir): int
    {
        $latest = is_dir($jobDir) ? (int)@filemtime($jobDir) : 0;
        foreach (glob(rtrim($jobDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . '*') ?: [] as $path) {
            $latest = max($latest, (int)@filemtime($path));
            if (is_dir($path) && !is_link($path)) {
                foreach (glob($path . DIRECTORY_SEPARATOR . '*') ?: [] as $child) $latest = max($latest, (int)@filemtime($child));
            }
        }
        return $latest;
    }
}

if (!function_exists('fj_media_job_has_unverified_live_marker')) {
    /**
     * A recent marker that cannot be tied to a PID is treated conservatively as live.
     * This avoids releasing a lock while a CRON worker is between mkdir and PID write.
     */
    function fj_media_job_has_unverified_live_marker(string $jobDir): bool
    {
        if (!is_dir($jobDir)) return false;
        $now = time();
        foreach (['.started', '.child-pid'] as $file) {
            $path = $jobDir . DIRECTORY_SEPARATOR . $file;
            if (!is_file($path)) continue;
            $raw = trim((string)@file_get_contents($path));
            $age = $now - (int)@filemtime($path);
            if ($raw === 'starting' && $age <= 20) return true;
            if (preg_match('/^[0-9]{1,10}$/D', $raw)) {
                $pid = (int)$raw;
                $procStat = '/proc/' . $pid . '/stat';
                if (is_file($procStat) && !is_readable($procStat) && $age <= 180) return true;
                // If procfs is available and the PID no longer exists, the worker is dead;
                // a stale marker must not block the next import for three minutes.
                if (!is_dir('/proc') && $age <= 180) return true;
            }
        }
        $launch = $jobDir . DIRECTORY_SEPARATOR . '.launching';
        if (is_file($launch) && $now - (int)@filemtime($launch) <= 20) return true;
        $claim = $jobDir . DIRECTORY_SEPARATOR . '.worker-lock';
        if (is_dir($claim) && $now - (int)@filemtime($claim) <= 12) return true;
        return false;
    }
}

if (!function_exists('fj_media_remove_active_lock')) {
    function fj_media_remove_active_lock(string $lockDir): bool
    {
        if (!is_dir($lockDir)) return true;
        $ownerPath = $lockDir . DIRECTORY_SEPARATOR . 'job-id';
        if (is_file($ownerPath)) @unlink($ownerPath);
        // Never recursively delete unexpected files from a lock directory.
        return @rmdir($lockDir) || !is_dir($lockDir);
    }
}

if (!function_exists('fj_media_recover_orphaned_active_lock')) {
    /** Recover a dead/missing job lock after a short quiet window; queued jobs remain queued. */
    function fj_media_recover_orphaned_active_lock(string $lockDir, string $mediaDir, int $graceSeconds = 12): array
    {
        $result = ['recovered' => false, 'reason' => 'not_stale', 'job_id' => null];
        if (!is_dir($lockDir)) { $result['reason'] = 'no_lock'; return $result; }
        $id = trim((string)@file_get_contents($lockDir . DIRECTORY_SEPARATOR . 'job-id'));
        $result['job_id'] = $id !== '' ? $id : null;
        if (!preg_match('/^[a-f0-9]{24}$/D', $id)) {
            $age = time() - (int)@filemtime($lockDir);
            if ($age < max(60, $graceSeconds)) { $result['reason'] = 'invalid_lock_recent'; return $result; }
            $result['recovered'] = fj_media_remove_active_lock($lockDir);
            $result['reason'] = 'invalid_lock_removed';
            return $result;
        }
        $jobDir = rtrim($mediaDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $id;
        if (!is_dir($jobDir) || is_file($jobDir . DIRECTORY_SEPARATOR . 'exit-code.txt')) {
            $result['recovered'] = fj_media_remove_active_lock($lockDir);
            $result['reason'] = 'job_gone_or_terminal';
            return $result;
        }
        if (fj_media_job_process_pids($jobDir)) { $result['reason'] = 'verified_process_alive'; return $result; }
        if (fj_media_job_has_unverified_live_marker($jobDir)) { $result['reason'] = 'recent_unverified_worker_marker'; return $result; }
        $quietFor = time() - fj_media_job_last_activity($jobDir);
        if ($quietFor < max(1, $graceSeconds)) { $result['reason'] = 'job_recently_active'; return $result; }
        // A queued job is not discarded: release a stale global lock and leave .queued
        // so the user's CRON worker can claim it on its next run.
        @unlink($jobDir . DIRECTORY_SEPARATOR . '.started');
        @unlink($jobDir . DIRECTORY_SEPARATOR . '.started-start');
        @unlink($jobDir . DIRECTORY_SEPARATOR . '.child-pid');
        @unlink($jobDir . DIRECTORY_SEPARATOR . '.child-pid-start');
        @unlink($jobDir . DIRECTORY_SEPARATOR . '.launching');
        @rmdir($jobDir . DIRECTORY_SEPARATOR . '.worker-lock');
        $result['recovered'] = fj_media_remove_active_lock($lockDir);
        $result['reason'] = is_file($jobDir . DIRECTORY_SEPARATOR . '.queued') ? 'stale_lock_released_job_requeued' : 'orphaned_lock_released';
        return $result;
    }
}

if (!function_exists('fj_media_release_stale_active_lock')) {
    /** Conservative long-timeout fallback for locks whose worker died without exit-code. */
    function fj_media_release_stale_active_lock(string $lockDir, string $mediaDir): array
    {
        $result = ['recovered' => false, 'reason' => 'not_stale', 'job_id' => null];
        if (!is_dir($lockDir)) { $result['reason'] = 'no_lock'; return $result; }
        $id = trim((string)@file_get_contents($lockDir . DIRECTORY_SEPARATOR . 'job-id'));
        $result['job_id'] = $id !== '' ? $id : null;
        if (!preg_match('/^[a-f0-9]{24}$/D', $id)) {
            if (time() - (int)@filemtime($lockDir) < 21600) { $result['reason'] = 'invalid_lock_recent'; return $result; }
            $result['recovered'] = fj_media_remove_active_lock($lockDir);
            $result['reason'] = 'invalid_lock_removed';
            return $result;
        }
        $jobDir = rtrim($mediaDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $id;
        if (!is_dir($jobDir) || is_file($jobDir . DIRECTORY_SEPARATOR . 'exit-code.txt')) {
            $result['recovered'] = fj_media_remove_active_lock($lockDir);
            $result['reason'] = 'job_gone_or_terminal';
            return $result;
        }
        if (fj_media_job_process_pids($jobDir)) { $result['reason'] = 'verified_process_alive'; return $result; }
        if (fj_media_job_has_unverified_live_marker($jobDir)) { $result['reason'] = 'recent_unverified_worker_marker'; return $result; }
        $quietFor = time() - fj_media_job_last_activity($jobDir);
        if ($quietFor < 180) { $result['reason'] = 'job_recently_active'; return $result; }
        @unlink($jobDir . DIRECTORY_SEPARATOR . '.started');
        @unlink($jobDir . DIRECTORY_SEPARATOR . '.started-start');
        @unlink($jobDir . DIRECTORY_SEPARATOR . '.child-pid');
        @unlink($jobDir . DIRECTORY_SEPARATOR . '.child-pid-start');
        @unlink($jobDir . DIRECTORY_SEPARATOR . '.launching');
        @rmdir($jobDir . DIRECTORY_SEPARATOR . '.worker-lock');
        $result['recovered'] = fj_media_remove_active_lock($lockDir);
        $result['reason'] = is_file($jobDir . DIRECTORY_SEPARATOR . '.queued') ? 'stale_lock_released_job_requeued' : 'stale_lock_released';
        return $result;
    }
}

if (!function_exists('fj_media_signal_process')) {
    function fj_media_signal_process(int $pid, int $signal): bool
    {
        if ($pid < 2) return false;
        if (function_exists('posix_kill')) return @posix_kill($pid, $signal);
        $disabled = array_filter(array_map('trim', explode(',', (string)ini_get('disable_functions'))));
        if (function_exists('exec') && !in_array('exec', $disabled, true)) {
            $kill = is_executable('/bin/kill') ? '/bin/kill' : (is_executable('/usr/bin/kill') ? '/usr/bin/kill' : '');
            if ($kill === '') return false;
            $name = $signal === 9 ? 'KILL' : 'TERM';
            exec(escapeshellarg($kill) . ' -' . $name . ' ' . (int)$pid . ' 2>/dev/null', $out, $code);
            return $code === 0;
        }
        return false;
    }
}

if (!function_exists('fj_media_terminate_job_processes')) {
    /** Stop only PIDs verified against this job's recorded process start identity. */
    function fj_media_terminate_job_processes(string $jobDir, int $timeoutMs = 1100): array
    {
        $timeoutMs = max(100, min(5000, $timeoutMs));
        $pids = fj_media_job_process_pids($jobDir);
        if (!$pids) {
            $pending = fj_media_job_has_unverified_live_marker($jobDir);
            return ['stopped' => !$pending, 'pending' => $pending, 'pids' => [], 'signalled' => []];
        }
        $signalled = [];
        foreach ($pids as $pid) if (fj_media_signal_process($pid, 15)) $signalled[] = $pid;
        $deadline = microtime(true) + ($timeoutMs / 1000);
        do {
            usleep(100000);
            $alive = fj_media_job_process_pids($jobDir);
            if (!$alive) return ['stopped' => true, 'pending' => false, 'pids' => $pids, 'signalled' => $signalled];
        } while (microtime(true) < $deadline);
        foreach ($alive as $pid) fj_media_signal_process($pid, 9);
        usleep(100000);
        $remaining = fj_media_job_process_pids($jobDir);
        $pending = (bool)$remaining || fj_media_job_has_unverified_live_marker($jobDir);
        return ['stopped' => !$pending, 'pending' => $pending, 'pids' => $pids, 'remaining' => $remaining, 'signalled' => $signalled];
    }
}
