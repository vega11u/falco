/** Qualitative neuromuscular timing proxy from 2D motion, not EMG, torque or metabolic efficiency. */
export const MUSCLE_DYNAMIC_SCHEMA='falco-muscle-dynamics-v1';
const CHAINS={left_arm:[11,13,15],right_arm:[12,14,16],left_leg:[23,25,27],right_leg:[24,26,28],trunk:[11,12,23,24]};
const ROLES={
 left_arm:['стабилизаторы лопатки','ротаторная манжета','разгибатели/сгибатели локтя','стабилизаторы запястья'],
 right_arm:['стабилизаторы лопатки','ротаторная манжета','разгибатели/сгибатели локтя','стабилизаторы запястья'],
 left_leg:['мышцы стопы и голеностопа','средняя ягодичная','сгибатели/разгибатели бедра','квадрицепс и задняя группа бедра'],
 right_leg:['мышцы стопы и голеностопа','средняя ягодичная','сгибатели/разгибатели бедра','квадрицепс и задняя группа бедра'],
 trunk:['мышцы опорных ног','ягодичные мышцы','косые мышцы живота','стабилизаторы позвоночника']
};
const finite=n=>Number.isFinite(n),clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
function point(f,id){const p=f?.im?.[id];return Array.isArray(p)&&finite(p[0])&&finite(p[1])&&(p[3]??1)>=.5?p:null;}
const dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
function profile(frames,key){
 const chain=CHAINS[key],signals=[],n=frames.length;
 for(let i=1;i<n;i++){
  const a=frames[i-1],b=frames[i],dt=Number(b.t)-Number(a.t);if(!(dt>.003&&dt<.2))continue;
  const ids=chain.filter(id=>point(a,id)&&point(b,id));if(ids.length<Math.min(chain.length,3))continue;
  const velocity=ids.map(id=>dist(point(a,id),point(b,id))/dt);const proximal=velocity[0],distal=velocity.at(-1);
  signals.push({t:Number(b.t),v:velocity.reduce((s,x)=>s+x,0)/velocity.length,proximal,distal});
 }
 if(signals.length<6)return null;
 const speed=signals.map(x=>x.v),peak=Math.max(...speed);if(peak<.01)return null;
 const dt=signals.at(-1).t-signals[0].t;const bins=[[],[],[],[],[]];for(const s of signals){const phase=clamp((s.t-signals[0].t)/(dt||1));bins[Math.min(4,Math.floor(phase*5))].push(s);}
 const avg=arr=>arr.length?arr.reduce((s,x)=>s+x.v,0)/arr.length:0;
 const relative=bins.map(x=>Math.round(clamp(avg(x)/(peak||1))*3));
 const accel=[],brake=[];for(let i=1;i<signals.length;i++){
  const delta=signals[i].v-signals[i-1].v;
  if(delta>0)accel.push(delta);else brake.push(-delta);
 }
 const peakProx=signals.reduce((a,x)=>x.proximal>a.proximal?x:a,signals[0]).t;
 const peakDist=signals.reduce((a,x)=>x.distal>a.distal?x:a,signals[0]).t;
 const timing=peakDist-peakProx;
 const secPerFrame=dt/Math.max(1,signals.length-1);
 return {coverage:signals.length/Math.max(1,n-1),levels:relative,peak_time_s:signals.reduce((a,x)=>x.v>a.v?x:a,signals[0]).t,proximal_to_distal_delay_s:Number(timing.toFixed(3)),order_resolved:Math.abs(timing)>2*secPerFrame,accelerating:accel.reduce((s,x)=>s+x,0),braking:brake.reduce((s,x)=>s+x,0),peak_speed_projected:peak};
}
const phases=['Подготовка','Разгон','Передача импульса','Торможение','Возврат / переход'];
export function assessMuscleChainDynamics(frames,{chain='trunk',kind='movement',knowledge={}}={}){
 if(!Array.isArray(frames)||frames.length<8||!CHAINS[chain])return {available:false,reason:'no_valid_sequence'};
 const p=profile(frames,chain);if(!p||p.coverage<.7)return {available:false,reason:'insufficient_visible_landmarks'};
 const roles=ROLES[chain];const evidence=(Array.isArray(knowledge)?knowledge:[]).filter(x=>x&&typeof x==='object').slice(0,6).map(x=>x.id).filter(Boolean);
 const phaseNarratives=[
  `Подготовка: опорные и проксимальные стабилизаторы организуют положение. Наблюдаемый уровень движения ${p.levels[0]}/3; напряжение непосредственно не измерено.`,
  `Разгон: условный вклад ${roles[1]} и ${roles[2]}; уровень видимой кинематики ${p.levels[1]}/3.`,
  `Передача: координация от проксимальных сегментов к дистальным; уровень ${p.levels[2]}/3; ${p.order_resolved?`наблюдаемый сдвиг пиков ${Math.round(p.proximal_to_distal_delay_s*1000)} мс`:'временной порядок пиков не разрешается частотой кадров'}.`,
  `Торможение: вероятна регулирующая работа антагонистов ${roles[2]}; уровень видимого движения ${p.levels[3]}/3.`,
  `Возврат/переход: стабилизация ${roles[0]} и ${roles[3]}; уровень движения ${p.levels[4]}/3.`
 ];
 const discontinuity=Math.max(...p.levels.slice(1).map((v,i)=>Math.abs(v-p.levels[i])));
 const timingPenalty=p.order_resolved&&p.proximal_to_distal_delay_s<-.08?12:0;
 const brakingPenalty=p.braking>p.accelerating*2.5?8:0;
 const coveragePenalty=(1-p.coverage)*25;
 const score=Math.round(clamp(100-timingPenalty-brakingPenalty-discontinuity*2-coveragePenalty,0,100)*10)/10;
 return {schema:MUSCLE_DYNAMIC_SCHEMA,available:true,kind,chain,roles,phase_labels:phases,relative_motion_levels:p.levels,phase_explanations:phaseNarratives,kinematic_proxy_score:score,peak_time_s:p.peak_time_s,proximal_to_distal_delay_s:p.proximal_to_distal_delay_s,order_resolved:p.order_resolved,coverage:p.coverage,evidence_ids:evidence,confidence:'qualitative_only',limitations:['Не измеряются ЭМГ, фактическое напряжение, силы мышц, КПД, энергия или мышечная усталость.','Шкала 0–3 относится только к видимой кинематике сегментов, а не к процентам включения мышц.','Временные пики движения не равны моментам возбуждения мышц; камера/окклюзия могут искажать вывод.']};
}
