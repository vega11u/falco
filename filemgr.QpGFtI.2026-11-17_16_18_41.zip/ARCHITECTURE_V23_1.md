# Falco Jugger 23.1.0 — UI architecture and compatibility

## Scope

This is a corrective presentation and controls release on top of v23.0.0. No PHP API, persistence, training feature, report schema, inference worker, video decoder, or server-side import behavior is changed.

## Design system

- `aero-workbench-v23.css` is the single active visual layer for `index.php`, `uppurcell.php` (same analyzer template) and `Memories.php`.
- Four local Inter static weights are shipped as WOFF2 under `assets/fonts/`; the bundled OFL-1.1 notice is retained. The application no longer requests Google Fonts.
- `assets/aero-landscape.svg` is the local scenic sky / hills / water backdrop used by the studio hero.
- Main workspace panels are bright acrylic surfaces; the video stage, synchronized player and avatar canvases remain in a deep aquatic contrast chamber.
- Large surfaces do not use `backdrop-filter`. Blur is a progressive enhancement limited to the topbar, hero, analysis settings and source link card. There are no perpetual decorative animations or JS animation dependencies.
- All responsive layout changes are CSS-only and preserve existing DOM IDs and event bindings.

## Restored analysis settings

The three existing checkboxes `cameraAngleChanges`, `clothingSurface` and `depthEstimation` are now in a separate `details.analysis-settings` section, outside `.upload-options`. This is important because Purcell mode intentionally hides kata naming / learning metadata inside `.upload-options`, but scene and depth settings are also needed by the Purcell video workflow.

`installTaskFirstLayout()` now reuses the pre-existing analysis settings container and moves the same existing device profile, training metadata, control grid and report opt-in nodes into it. It does not create duplicate IDs or new controls. The checkbox elements and their existing JS readers remain unchanged.

The optimizer 3D subview and its playback checkbox remain intentionally suppressed by the existing performance guard: a hidden 3D canvas must not keep rendering. The primary spatial 3D projection is unchanged. No other advanced subpanel visibility policy is changed.

## Performance

- No framework, animation library, remote font, remote stylesheet or build step was introduced.
- Local WOFF2 reduces font transfer compared with shipping OTF files.
- `backdrop-filter` is limited to a handful of compact elements; the large player and report panels use translucent gradients and ordinary shadows instead.
- No new recurring timer, DOM polling loop, inference pass or frame-decimation policy was introduced.

## Compatibility invariants

Unchanged:
- PHP API routes, HTTP methods, request / response shapes and report archive format.
- Database schema, private Lully/Purcell stores, report ownership cookie and `.kata-*` storage roots.
- Q16 training feature packing, 384D / 1152D learning contracts, model weights and personal examples.
- Existing `cameraAngleChanges`, `clothingSurface`, `depthEstimation`, `optimizer3dPlayback`, trim and player control IDs.
- Worker messages, MediaPipe inference cadence, Mediabunny sample ordering, sparse Depth Anything pass, avatar interpolation and local browser inference.
- YouTube / Instagram / TikTok / VK / Rutube / X / Facebook import paths and REG.RU Host-0 PHP-only server deployment.

No database migration is required. Python and Node remain unnecessary on the hosting account.
