# Falco Jugger 26.0.1 — Handler Recovery

## Root cause (reproduced)

In Falco 26.0.0 the UI rewrite removed `id="pageModeLabel"`, but the original analyzer module still calls `$('pageModeLabel').textContent` in `installTaskFirstLayout()` before registering its primary event handlers. Browser evaluation failed with `TypeError: Cannot set properties of null (setting 'textContent')`. Consequently, upload, analysis, player/clip, reset, save/report, and feedback initialization stopped at that point.

This fix restores the DOM contract AND guards the mode label access. It leaves analytical algorithms, data formats and trained data unchanged.

## Other repaired interactions

- Removed competing UI theme handler in analyzer/Purcell modes. Previously the core and external UI controller could each toggle the theme during the same click.
- Reinstated editing-range visual updates and a close button that does not discard the selected range.
- Restored player keyboard shortcuts (K/space, left/right frames, Home), and a fullscreen action.
- Keeps the original video/3D/metrics nodes in place after the core has mounted them; no redundant DOM detach/re-attach.
- Makes previously hidden side-stack explanation/history panels accessible behind a collapsed “Дополнительные инструменты и история” section.
- Bumped only UI JavaScript query string to `26.0.1` on all public entrypoints to avoid stale cached event logic.

## Deliberately unchanged

- Approved one-file CSS design `falco-jugger-ui.css?v=26.0.0` (no extra stylesheet)
- Analysis engine, pose/depth modules, FFmpeg, model weights
- Lully/Purcell schemas and database content; Purcell has only overall optimization
- Server data/reports, vendor assets, videos, model caches, user configs

## Compatibility

- Base: Falco UI 26.0.0 with core 23.0.27; idempotent on 26.0.1.
- Server: Bash, PHP CLI >=8.1, tar, sha256sum; no system Node.js or npm.
- Installation creates an in-place archive under `.falco-rollback/` and restores it on an installation error.
