# QA report — v21.12.0

Base: v21.11.0. All changes are additive except UI default visibility and replacement of stale unconfirmed pattern cards during an explicit “Think again” pass.

## Automated results

`bash tests/verify.sh` — PASS.

Coverage includes PHP lint, embedded JS syntax, research-data checks, player and avatar, pose/recognition, biomechanical planner, optimizer, report rendering, full learning API, server report save/get/list/delete, owner isolation, report deletion/model immutability, taxonomy overlay save/reload, optimizer feedback persistence, and new v21.12 UI/API contracts.

Existing corpus fixture remains readable: 3,005 examples and 1,002 feedback entries. Existing feature schema checks remain unchanged (48D frame representation, 384D pattern examples, 1152D full-kata examples).

## Important deployment constraints

- 120 MB reports require web server request-body allowance >=128 MB (e.g. nginx `client_max_body_size 128m`) and PHP `memory_limit >=768M`; some shared hosts impose lower hard limits. In that case the server will reject the report and show an error rather than claim success.
- Browser save/list uses the durable `kata_report_owner` HttpOnly cookie; use one canonical scheme/host (do not mix www/non-www or HTTP/HTTPS) because report ownership is browser-cookie scoped.
- Maximum archive size is bounded; video pixels/source video are not uploaded.
- Live visual testing on physical mobile devices and real-world 120 MB transfer under a production reverse proxy remain deployment checks, not simulated claims.
- CRON detached worker test remains opt-in and unrelated to this patch.
