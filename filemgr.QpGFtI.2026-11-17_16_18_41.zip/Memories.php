<?php
declare(strict_types=1);
// Server-side report library UI. Report ownership is enforced by index.php's
// independent HttpOnly kata_report_owner cookie, not by this page.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
?><!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#0c202c">
<meta name="color-scheme" content="light dark">
<meta name="color-scheme" content="light dark">
<meta name="theme-color" content="#2799c8">
<title>Falco Jugger — Библиотека отчётов</title>
<script>try{const saved=localStorage.getItem("falco-jugger-theme-v1")||localStorage.getItem("fj-theme");document.documentElement.dataset.theme=(saved==="dark"||saved!=="light"&&window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches)?"dark":"light";}catch(_){}</script>

<link rel="stylesheet" href="falco-jugger-ui.css?v=27.2.2-C.D2">
</head>
<body class="aero-archive falco24-secondary">
<aside class="fj-side-rail fj-secondary-rail" id="fjSideRail" aria-label="Навигация Falco Jugger">
  <a class="fj-rail-brand" href="index.php" aria-label="Falco Jugger — анализ ката"><img src="assets/falco-avatar-sanchin.svg" width="46" height="46" alt=""><span><strong>FALCO JUGGER</strong><small>KATA BIOMECHANICS LAB</small></span></a>
  <div class="fj-rail-section-label">РАБОЧИЕ ОБЛАСТИ</div>
  <nav class="f24-rail-group fj-library-nav" aria-label="Рабочие области">
    <a class="f24-rail-link fj-secondary-link" href="index.php" data-fj-page="analyzer"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M8 4v16"/></svg></span><span>Анализ ката</span></a>
    <a class="f24-rail-link fj-secondary-link" href="uppurcell.php" data-fj-page="purcell-training"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M7 17 17 7M8 7h9v9"/></svg></span><span>Обучение Purcell</span></a>
    <a class="f24-rail-link fj-secondary-link" href="lully.php" data-fj-page="lully"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="12" cy="18" r="2"/><path d="M8 6h8M7.5 7.5l3.2 8.7m5.8-8.7-3.2 8.7"/></svg></span><span>Lully · паттерны</span></a>
    <a class="f24-rail-link fj-secondary-link" href="purcell-lab.php" data-fj-page="purcell-library"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="m12 3 8 5v8l-8 5-8-5V8z"/><path d="m4 8 8 5 8-5m-8 5v8"/></svg></span><span>Purcell · библиотека</span></a>
    <a class="f24-rail-link fj-secondary-link" href="models.php" data-fj-page="models"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><rect x="13" y="13" width="7" height="7" rx="1"/></svg></span><span>Модели</span></a>
    <a class="f24-rail-link fj-secondary-link" href="Memories.php" data-fj-page="reports"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 8h16v12H4zM3 4h18v4H3zM9 12h6"/></svg></span><span>Отчёты</span></a>
  </nav>
  <div class="fj-rail-footer">
    <button class="btn small theme-toggle" id="themeToggle" type="button" aria-pressed="false" title="Переключить светлую / тёмную тему">◐ Тема</button>
    <button class="btn small hard-update-btn" id="hardUpdateBtn" type="button" aria-haspopup="dialog" title="Очистить Cache Storage и загрузить актуальную версию">HARD UPDATE</button>
  </div>
</aside>
<div class="fj-nav-scrim" id="fjNavScrim" hidden></div>
<main class="fj-secondary-main shell fj-reports-shell">
<div class="fj-mobile-bar"><button class="fj-menu-toggle" id="fjNavToggle" type="button" aria-controls="fjSideRail" aria-expanded="false" aria-label="Открыть навигацию">☰</button><span class="fj-mobile-brand">FALCO JUGGER</span><span class="fj-mobile-page">БИБЛИОТЕКА ОТЧЁТОВ</span></div>
  <section class="fj-page-heading"><span class="fj-eyebrow">PRIVATE SERVER LIBRARY</span><h1>Библиотека отчётов</h1><p>Сохранённые анализы, персональные реконструкции и материалы для продолжения обучения</p><div class="fj-page-heading-status" id="serverStatus"><span class="server-dot" id="serverDot"></span><span id="serverStatusText">Проверка соединения…</span></div></section>
  <div class="toolbar"><div><strong>Архив</strong> <span class="count" id="count">Загрузка…</span></div><button class="btn" id="refresh" type="button">Обновить список</button></div>
  <div id="loading" class="loading" aria-hidden="true"></div>
  <section class="list" id="list" aria-live="polite"><div class="empty">Загружаю серверную библиотеку…</div></section>
  <details class="hint"><summary>О хранении</summary>Отчёты хранятся на сервере вне публичной папки сайта. Для новых архивов доступна переносимая ссылка: сохраните её, чтобы открыть отчёт после очистки кэша или на другом устройстве.</details>
</main>
<script>
const $=id=>document.getElementById(id);
const setServerDotState=state=>{const dot=$('serverDot');if(!dot)return;dot.classList.toggle('is-online',state==='online');dot.classList.toggle('is-offline',state==='offline');};
function applyWorkspaceTheme(theme){const next=theme==='dark'?'dark':'light';document.documentElement.dataset.theme=next;const button=$('themeToggle');if(button){button.setAttribute('aria-pressed',String(next==='dark'));button.textContent=next==='dark'?'☼ Светлая тема':'◐ Тёмная тема';}const meta=document.querySelector('meta[name="color-scheme"]');if(meta)meta.content=next==='dark'?'dark':'light';try{localStorage.setItem('falco-jugger-theme-v1',next);localStorage.setItem('fj-theme',next);}catch(_){}}
let initialTheme='light';try{const saved=localStorage.getItem('falco-jugger-theme-v1')||localStorage.getItem('fj-theme');initialTheme=saved==='dark'?'dark':saved==='light'?'light':(window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');}catch(_){}applyWorkspaceTheme(initialTheme);
$('themeToggle').dataset.fjThemeBound='1';$('themeToggle').addEventListener('click',()=>applyWorkspaceTheme(document.documentElement.dataset.theme==='dark'?'light':'dark'));
const fmtTime=s=>{const n=Math.max(0,Number(s)||0),m=Math.floor(n/60),sec=n-m*60;return `${String(m).padStart(2,'0')}:${sec.toFixed(1).padStart(4,'0')}`;};
const dateLabel=s=>{const d=new Date(s);return Number.isNaN(d.getTime())?'Дата не указана':new Intl.DateTimeFormat('ru-RU',{dateStyle:'medium',timeStyle:'short'}).format(d);};
const sizeLabel=n=>{const b=Number(n)||0;return b>1048576?(b/1048576).toFixed(2)+' МБ':(b/1024).toFixed(0)+' КБ';};
async function api(url,options={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...options,headers:{'Accept':'application/json',...(options.headers||{})}});let d;try{d=await r.json();}catch(_){throw new Error('Сервер вернул не JSON. Проверьте PHP API.');}if(!r.ok||d.ok===false)throw new Error(d.error||`HTTP ${r.status}`);return d;}
function action(label,href,kind=''){const a=document.createElement('a');a.className='btn '+kind;a.textContent=label;a.href=href;if(kind!=='danger'){a.target='_blank';a.rel='noopener';}return a;}
function render(items){const root=$('list');root.replaceChildren();$('count').textContent=`${items.length} отчётов`;
 if(!items.length){const empty=document.createElement('div');empty.className='empty';empty.textContent='Пока нет серверных отчётов в этой библиотеке. Файлы хранятся на сервере, а доступ к подборке ограничен HttpOnly cookie владельца и точным origin сайта. После отправки приложение проверяет, что новый отчёт появился в списке.';root.append(empty);return;}
 for(const x of items){const card=document.createElement('article');card.className='item';const main=document.createElement('div');main.className='item-main';const title=document.createElement('div');title.className='item-title';title.textContent=x.file_name||'Ката без названия';main.append(title);const meta=document.createElement('div');meta.className='meta';const m=(text,cls='')=>{const s=document.createElement('span');s.textContent=text;if(cls)s.className=cls;return s;};meta.append(m(dateLabel(x.created_at)),m(x.legacy_metadata_missing?'Старый архив · откройте для просмотра':`${fmtTime(x.duration_s)} · ${Number(x.frame_count)||0} кадров`),m(sizeLabel(x.bytes)));if(!x.legacy_metadata_missing)meta.append(m(`Оценка ${Math.round(Number(x.final_score)||0)}/100`,'score'));
 meta.append(m(['falco-personalized-vivaldi-mesh-keyframes-v2','falco-personalized-vivaldi-mesh-keyframes-v3-fixed2048'].includes(x.personalized_mesh_schema)&&Number(x.personalized_mesh_keyframes)>0?`${x.personalized_mesh_schema?.includes('v3')?'Персональная фиксированная сетка · 2048 вершин':'Персональная 3D-сетка'} · ${x.personalized_mesh_keyframes} сохранённых ключевых кадров`:'Архив прежнего формата · персональная 3D-сетка не сохранена','mesh-state'));main.append(meta);
 const buttons=document.createElement('div');buttons.className='actions';const access=x.access_key?`&key=${encodeURIComponent(x.access_key)}`:'';buttons.append(action('Открыть отчёт',`index.php?report=${encodeURIComponent(x.id)}${access}`));buttons.append(action('Открыть для обучения',`index.php?report=${encodeURIComponent(x.id)}&training=1${access}`,'primary'));buttons.append(action('В эталоны Purcell',`uppurcell.php?report=${encodeURIComponent(x.id)}&training=1${access}`));if(x.access_key){const copy=document.createElement('button');copy.className='btn small';copy.type='button';copy.textContent='Скопировать ссылку';copy.addEventListener('click',async()=>{const url=new URL(`index.php?report=${encodeURIComponent(x.id)}${access}`,location.href).href;try{await navigator.clipboard.writeText(url);copy.textContent='Ссылка скопирована';setTimeout(()=>copy.textContent='Скопировать ссылку',1800);}catch(_){prompt('Скопируйте ссылку доступа:',url);}});buttons.append(copy);}
 const del=document.createElement('button');del.className='btn danger';del.type='button';del.textContent='Удалить';del.addEventListener('click',()=>deleteReport(x.id,card,del));buttons.append(del);card.append(main,buttons);root.append(card);}
}
async function load(){ $('loading').hidden=false;$('count').textContent='Обновление…';$('refresh').disabled=true;try{const d=await api('index.php?api=reports-list');render(d.items||[]);setServerDotState('online');$('serverStatusText').textContent='Сервер онлайн';$('serverStatus').title='Последняя проверка: '+new Date().toLocaleTimeString('ru-RU');$('count').textContent=`${d.count??(d.items||[]).length} отчётов · библиотека ${d.owner_scope||'—'} · ${d.storage_ready?'хранилище доступно':'папка создаётся при первой записи'}`;}catch(e){setServerDotState('offline');$('serverStatusText').textContent='Нет соединения';$('count').textContent='Ошибка';$('list').replaceChildren();const box=document.createElement('div');box.className='error';box.textContent='Не удалось загрузить библиотеку: '+e.message;const retry=document.createElement('button');retry.className='btn';retry.textContent='Повторить';retry.addEventListener('click',load);box.append(document.createElement('br'),retry);$('list').append(box);}finally{$('loading').hidden=true;$('refresh').disabled=false;}}
async function deleteReport(id,card,button){if(!confirm('Удалить этот отчёт с сервера? Подтверждённые обучающие примеры и веса моделей останутся без изменений.'))return;button.disabled=true;button.textContent='Удаление…';try{await api('index.php?api=reports-delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})});card.remove();const remaining=$('list').querySelectorAll('.item').length;$('count').textContent=`${remaining} отчётов`;if(!remaining){const e=document.createElement('div');e.className='empty';e.textContent='Библиотека отчётов пуста.';$('list').append(e);}}catch(e){button.disabled=false;button.textContent='Удалить';alert('Не удалось удалить отчёт: '+e.message);}}
$('refresh').addEventListener('click',load);load();
</script>
<script defer src="falco-jugger-ui.js?v=27.2.2-C.D2"></script>
<script type="module" src="hard-update-v23.0.19.js?v=23.0.19"></script>
</body>
</html>
