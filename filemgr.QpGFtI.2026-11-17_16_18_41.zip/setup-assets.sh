#!/usr/bin/env bash
# Download pinned, same-origin MediaPipe inference + demux assets for Falco Jugger 21.5.0
# Run once on a machine with internet access, then upload the complete project folder.
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
MP_VERSION="1.1.1"
TMP="$(mktemp -d)"
cleanup() { rm -rf "$TMP"; }
trap cleanup EXIT

command -v curl >/dev/null 2>&1 || { echo "ERROR: curl is required." >&2; exit 1; }
command -v tar >/dev/null 2>&1 || { echo "ERROR: tar is required." >&2; exit 1; }
mkdir -p "$ROOT/vendor/mediapipe" "$ROOT/vendor/models" "$ROOT/vendor/mediabunny"

fetch() {
  local url="$1" out="$2" label="$3"
  echo "Downloading ${label}..."
  curl --fail --location --retry 3 --connect-timeout 20 --max-time 300 "$url" --output "$out"
}

fetch "https://registry.npmjs.org/@mediapipe/tasks-vision/-/tasks-vision-${MP_VERSION}.tgz" "$TMP/tasks-vision.tgz" "@mediapipe/tasks-vision ${MP_VERSION}"
tar -xzf "$TMP/tasks-vision.tgz" -C "$TMP"
test -s "$TMP/package/vision_bundle.mjs" || { echo "ERROR: vision_bundle.mjs is missing from the package." >&2; exit 1; }
test -d "$TMP/package/wasm" || { echo "ERROR: WASM directory is missing from the package." >&2; exit 1; }
cp "$TMP/package/vision_bundle.mjs" "$ROOT/vendor/mediapipe/vision_bundle.mjs"
rm -rf "$ROOT/vendor/mediapipe/wasm"
cp -R "$TMP/package/wasm" "$ROOT/vendor/mediapipe/wasm"
if test -f "$TMP/package/LICENSE"; then cp "$TMP/package/LICENSE" "$ROOT/vendor/mediapipe/LICENSE-MEDIAPIPE.txt"; fi

# Full and Lite are installed together: Full is the primary desktop model; Lite is the
# memory-efficient fallback for weaker devices and video worker recovery.
fetch "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/1/pose_landmarker_full.task" "$ROOT/vendor/models/pose_landmarker_full.task" "Pose Landmarker Full model"
test "$(wc -c < "$ROOT/vendor/models/pose_landmarker_full.task")" -ge 1000000 || { echo 'ERROR: Full model download is incomplete.' >&2; exit 1; }

fetch "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task" "$ROOT/vendor/models/pose_landmarker_lite.task" "Pose Landmarker Lite fallback model"
if test "$(wc -c < "$ROOT/vendor/models/pose_landmarker_lite.task")" -lt 1000000; then
  echo "ERROR: Lite model download looks incomplete (file smaller than 1 MB)." >&2; exit 1
fi

# Hand tracking adds wrist/finger detail used by the technical review; install it now
# rather than silently producing a reduced-feature deployment.
fetch "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task" "$ROOT/vendor/models/hand_landmarker.task" "Hand Landmarker model"
test "$(wc -c < "$ROOT/vendor/models/hand_landmarker.task")" -ge 1000000 || { echo 'ERROR: Hand model download is incomplete.' >&2; exit 1; }

# Install current, SHA-512 verified local Mediabunny; setup-media-import.sh uses the same helper.
bash "$ROOT/setup-video-runtime.sh"

find "$ROOT/vendor" -type d -exec chmod 755 {} +
find "$ROOT/vendor" -type f -exec chmod 644 {} +

test -s "$ROOT/vendor/mediapipe/vision_bundle.mjs"
test -s "$ROOT/vendor/mediapipe/wasm/vision_wasm_internal.js" || {
  echo "WARNING: expected vision_wasm_internal.js was not found; inspect the WASM asset layout." >&2
}
test -s "$ROOT/vendor/models/pose_landmarker_lite.task"
test -s "$ROOT/vendor/models/pose_landmarker_full.task"
test -s "$ROOT/vendor/models/hand_landmarker.task"
test -s "$ROOT/vendor/mediabunny/mediabunny.mjs"
echo
echo "Inference assets installed locally. Project asset size:"
du -sh "$ROOT/vendor"
echo "Upload the entire project directory to a PHP 8.1+ HTTPS host. The browser can then load the core runtime/model/demuxer same-origin."
