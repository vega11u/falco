import {silhouetteImageData,silhouetteContourImageData} from './athlete-silhouette-core.mjs?v=26.2.0';
/**
 * Vivaldi Fixed Athlete Mesh — one canonical topology for every frame and device.
 *
 * The mesh is a personalized silhouette-lifted proxy, not a photogrammetric scan.
 * Its 2D widths come from the multi-frame athlete mask profile; the hidden 3D
 * thickness is a bounded geometric prior. The topology, vertex order and triangle
 * indices never change with frame, device memory, confidence or render resolution.
 */
export const VIVALDI_FINE_MESH_VERSION='vivaldi-fixed-athlete-mesh-v2';
export const VIVALDI_MESH_TOPOLOGY='falco-vivaldi-fixed-2048-v2';
export const VIVALDI_MESH_VERTEX_COUNT=2048;
export const VIVALDI_MESH_RESOLUTIONS=Object.freeze({compact:2048,standard:2048,fine:2048,identity:2048});

const finite=Number.isFinite;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
const sub=(a,b)=>a.map((x,i)=>x-b[i]);
const add=(a,b,k=1)=>a.map((x,i)=>x+b[i]*k);
const norm=v=>Math.hypot(...v);
const unit=v=>{const n=norm(v);return n>1e-9?v.map(x=>x/n):null;};
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const valid=(p,d=2,c=.10)=>Array.isArray(p)&&p.length>=d&&p.slice(0,d).every(finite)&&(p[3]??1)>=c;
const STATIONS=[.30,.47,.64,.80];

const BODY_REGIONS=[
 {name:'torso',a:'shoulderCenter',b:'hipCenter',width:'torso',rings:8,sides:20,depth:.48,fallback:.64,kind:'torso'},
 {name:'left-arm-upper',a:11,b:13,width:'left_arm_upper',rings:8,sides:20,depth:.42,fallback:.24,kind:'arm'},
 {name:'left-arm-lower',a:13,b:15,width:'left_arm_lower',rings:8,sides:20,depth:.42,fallback:.19,kind:'arm'},
 {name:'right-arm-upper',a:12,b:14,width:'right_arm_upper',rings:8,sides:20,depth:.42,fallback:.24,kind:'arm'},
 {name:'right-arm-lower',a:14,b:16,width:'right_arm_lower',rings:8,sides:20,depth:.42,fallback:.19,kind:'arm'},
 {name:'left-leg-upper',a:23,b:25,width:'left_leg_upper',rings:8,sides:20,depth:.50,fallback:.35,kind:'leg'},
 {name:'left-leg-lower',a:25,b:27,width:'left_leg_lower',rings:8,sides:20,depth:.50,fallback:.27,kind:'leg'},
 {name:'right-leg-upper',a:24,b:26,width:'right_leg_upper',rings:8,sides:20,depth:.50,fallback:.35,kind:'leg'},
 {name:'right-leg-lower',a:26,b:28,width:'right_leg_lower',rings:8,sides:20,depth:.50,fallback:.27,kind:'leg'}
];
const AUX_REGIONS=[
 {name:'neck',a:'shoulderCenter',b:'headCenter',rings:4,sides:12,depth:.72,radius:.085,kind:'neck'},
 {name:'left-foot',a:29,b:31,rings:6,sides:12,depth:.52,radius:.075,kind:'foot'},
 {name:'right-foot',a:30,b:32,rings:6,sides:12,depth:.52,radius:.075,kind:'foot'},
 {name:'left-palm',a:15,b:'leftPalmCenter',rings:6,sides:12,depth:.55,radius:.060,kind:'hand'},
 {name:'right-palm',a:16,b:'rightPalmCenter',rings:6,sides:12,depth:.55,radius:.060,kind:'hand'}
];
const HEAD_REGION={name:'head',rings:17,sides:16,kind:'head'};

function buildTopology(){
 const regions=[],triangles=[];let first=0;
 const append=(def,part)=>{
  const count=def.rings*def.sides,region={...def,first,count,part};
  regions.push(region);
  for(let r=0;r<def.rings-1;r++)for(let k=0;k<def.sides;k++){
   const a=first+r*def.sides+k,b=first+r*def.sides+(k+1)%def.sides,c=first+(r+1)*def.sides+k,d=first+(r+1)*def.sides+(k+1)%def.sides;
   triangles.push(a,b,c,b,d,c);
  }
  first+=count;
 };
 BODY_REGIONS.forEach(x=>append(x,'body'));
 AUX_REGIONS.forEach(x=>append(x,'aux'));
 append(HEAD_REGION,'head');
 if(first!==VIVALDI_MESH_VERTEX_COUNT)throw new Error(`Vivaldi topology vertex mismatch: ${first}`);
 return Object.freeze({schema:VIVALDI_MESH_TOPOLOGY,vertex_count:first,regions:Object.freeze(regions.map(Object.freeze)),triangles:new Uint32Array(triangles)});
}
const TOPOLOGY=buildTopology();
export function getVivaldiMeshTopology(){return TOPOLOGY;}

function centerPoint(points,a,b,dim){
 const A=points?.[a],B=points?.[b];
 if(!valid(A,dim,.10)||!valid(B,dim,.10))return null;
 return {p:Array.from({length:dim},(_,k)=>(A[k]+B[k])*.5),confidence:Math.min(A[3]??1,B[3]??1)};
}
function pointsFor(frame,space){return space==='3d'?(frame?.render_w||frame?.w||[]):(frame?.render_im||frame?.im||[]);}
function pointById(points,id,dim){
 if(id==='shoulderCenter')return centerPoint(points,11,12,dim);
 if(id==='hipCenter')return centerPoint(points,23,24,dim);
 if(id==='headCenter')return null;
 if(id==='leftPalmCenter'||id==='rightPalmCenter'){
  const left=id==='leftPalmCenter',wrist=points?.[left?15:16],pinky=points?.[left?17:18],index=points?.[left?19:20];
  if(!valid(wrist,dim,.10)||!valid(pinky,dim,.10)||!valid(index,dim,.10))return null;
  const fingerMid=Array.from({length:dim},(_,k)=>(pinky[k]+index[k])*.5);
  return {p:Array.from({length:dim},(_,k)=>(wrist[k]+fingerMid[k])*.5),confidence:Math.min(wrist[3]??1,pinky[3]??1,index[3]??1)};
 }
 const p=points?.[id];return valid(p,dim,.10)?{p:p.slice(0,dim),confidence:p[3]??1}:null;
}
function headCenter(points,dim){
 const ears=centerPoint(points,7,8,dim),nose=points?.[0],shoulder=centerPoint(points,11,12,dim);
 if(ears&&valid(nose,dim,.10)){
  const toward=sub(nose.slice(0,dim),ears.p);
  return {p:add(ears.p,toward,.24),confidence:Math.min(ears.confidence,nose[3]??1)};
 }
 if(valid(nose,dim,.10))return {p:nose.slice(0,dim),confidence:nose[3]??1};
 if(shoulder&&valid(points?.[0],dim,.10))return {p:points[0].slice(0,dim),confidence:Math.min(shoulder.confidence,points[0][3]??1)};
 return null;
}
function deriveBasis(points,dim){
 const sh=centerPoint(points,11,12,dim),hip=centerPoint(points,23,24,dim);
 if(!sh||!hip)return null;
 let right=sub(points[12].slice(0,dim),points[11].slice(0,dim));
 if(dim===3&&valid(points[23],3)&&valid(points[24],3)){
  const pelvis=sub(points[24].slice(0,3),points[23].slice(0,3));
  right=right.map((x,i)=>x*.65+pelvis[i]*.35);
 }
 let up=sub(sh.p,hip.p);
 if(dim===2){right=unit(right);if(!right)return null;up=unit([-right[1],right[0]]);return {right:[...right,0],up:[...up,0],forward:[0,0,1],confidence:Math.min(sh.confidence,hip.confidence)};}
 right=unit(right);if(!right)return null;
 up=unit(sub(up,right.map(x=>x*dot(up,right))));if(!up)return null;
 let forward=unit(cross(up,right));if(!forward)return null;
 return {right,up,forward,confidence:Math.min(sh.confidence,hip.confidence)};
}
function frameBasis(frame,points,dim){
 const basis=frame?.mesh_basis;
 if(dim===3&&basis&&[basis.right,basis.up,basis.forward].every(v=>Array.isArray(v)&&v.length===3&&v.every(finite)))return basis;
 return deriveBasis(points,dim);
}
function segmentBasis(axis,basis){
 let side=basis?.right?sub(basis.right,axis.map(x=>x*dot(basis.right,axis))):null;
 if(!side||norm(side)<.08){const seed=basis?.up||[0,1,0];side=sub(seed,axis.map(x=>x*dot(seed,axis)));}
 if(norm(side)<.08){const seed=basis?.forward||[0,0,1];side=sub(seed,axis.map(x=>x*dot(seed,axis)));}
 side=unit(side||[1,0,0]);let depth=unit(cross(axis,side));
 if(!side||!depth)return null;
 if(basis?.forward&&dot(depth,basis.forward)<0){side=side.map(x=>-x);depth=depth.map(x=>-x);}
 return {side,depth};
}
function hasPersonalProfile(profile){
 if(!profile||!profile.width_profile||Number(profile.profile_confidence)<.08)return false;
 const measured=Object.values(profile.width_profile).filter(stations=>Array.isArray(stations)&&stations.filter(row=>Array.isArray(row)&&finite(row[0])&&row[0]>.015&&finite(row[1])&&row[1]>=.12).length>=2).length;
 return measured>=4;
}
function widthStations(profile,key,fallback){
 const src=profile?.width_profile?.[key];
 const values=STATIONS.map((_,i)=>{
  const row=Array.isArray(src?.[i])?src[i]:null;
  const ratio=Number(row?.[0]),confidence=Number(row?.[1]);
  return finite(ratio)&&ratio>.015&&ratio<1.4&&finite(confidence)&&confidence>=.12
   ?{ratio:clamp(ratio,.015,1.4),confidence:clamp(confidence,0,1)}
   :{ratio:fallback,confidence:.30};
 });
 return values;
}
function sampleWidth(stations,t){
 const pos=clamp((t-STATIONS[0])/(STATIONS.at(-1)-STATIONS[0]),0,1)*(stations.length-1),i=Math.floor(pos),u=pos-i,a=stations[i],b=stations[Math.min(stations.length-1,i+1)];
 return {ratio:a.ratio+(b.ratio-a.ratio)*u,confidence:a.confidence+(b.confidence-a.confidence)*u};
}
function shoulderScale(points,space,profile){
 if(space==='2d'){
  const a=points?.[11],b=points?.[12];
  const current=valid(a,2,.10)&&valid(b,2,.10)?Math.hypot(a[0]-b[0],a[1]-b[1]):0;
  return current>.005?current:Number(profile?.fixed_geometry?.reference_image_shoulder_span)||.12;
 }
 const fixed=Number(profile?.fixed_geometry?.world_shoulder_span||profile?.mesh_identity?.reference_world_shoulder_span);
 if(fixed>.025&&fixed<2.5)return fixed;
 const a=points?.[11],b=points?.[12];
 return valid(a,3,.10)&&valid(b,3,.10)?Math.hypot(...sub(a.slice(0,3),b.slice(0,3))):.32;
}
function segmentEndpoints(frame,points,def,space,dim){
 const a=pointById(points,def.a,dim),b=def.b==='headCenter'?headCenter(points,dim):pointById(points,def.b,dim);
 if(!a||!b)return null;
 return {a:a.p,b:b.p,confidence:Math.min(a.confidence,b.confidence)};
}
function placeTube(positions,confidence,region,endpoints,scale,basis,space,profile){
 const dim=space==='3d'?3:2,A=endpoints.a,B=endpoints.b,axis=unit(sub(B,A));
 if(!axis||norm(sub(B,A))<.012)return 0;
 const local=space==='3d'?segmentBasis(axis,basis):{side:[-axis[1],axis[0]],depth:[0,0,1]};
 if(!local)return 0;
 const stations=region.width?widthStations(profile,region.width,region.fallback):null;
 const endpointConfidence=clamp(endpoints.confidence||0,0,1);
 let placed=0;
 for(let r=0;r<region.rings;r++){
  const t=region.rings===1?.5:r/(region.rings-1),center=Array.from({length:dim},(_,k)=>A[k]+(B[k]-A[k])*t);
  let ratio,profileConfidence;
  if(stations){const q=sampleWidth(stations,t);ratio=q.ratio;profileConfidence=q.confidence;}
  else{ratio=region.radius*2;profileConfidence=.48;}
  const taper=region.kind==='torso'?(1-.13*Math.abs(t-.5)*2):region.kind==='leg'?(1-.20*Math.abs(t-.5)*2):region.kind==='arm'?(1-.17*Math.abs(t-.5)*2):1;
  const radius=clamp(scale*ratio*.5*taper,scale*.018,scale*.78),depthRadius=radius*(region.depth||.48);
  for(let k=0;k<region.sides;k++){
   const theta=2*Math.PI*k/region.sides,co=Math.cos(theta),si=Math.sin(theta);
   const point=Array.from({length:dim},(_,d)=>center[d]+local.side[d]*co*radius+(space==='3d'?local.depth[d]*si*depthRadius:0));
   const offset=(region.first+r*region.sides+k)*4;
   for(let d=0;d<3;d++)positions[offset+d]=point[d]??0;
   const confidenceValue=space==='3d'?Math.min(.48,endpointConfidence*profileConfidence*.68):endpointConfidence*profileConfidence;
   positions[offset+3]=confidenceValue;confidence[region.first+r*region.sides+k]=confidenceValue;placed++;
  }
 }
 return placed;
}
function placeHead(positions,confidence,region,points,scale,basis,space){
 const dim=space==='3d'?3:2,center=headCenter(points,dim),shoulder=centerPoint(points,11,12,dim);
 if(!center||!shoulder||!basis)return 0;
 const up=unit(sub(shoulder.p,center.p));if(!up)return 0;
 const right=unit(basis.right),forward=unit(basis.forward||[0,0,1]);if(!right||!forward)return 0;
 const rx=scale*.17,ry=scale*.225,rz=scale*.13;let placed=0;
 for(let r=0;r<region.rings;r++){
  const phi=Math.PI*r/(region.rings-1),v=Math.cos(phi),rad=Math.sin(phi);
  for(let k=0;k<region.sides;k++){
   const theta=2*Math.PI*k/region.sides,side=right.map(x=>x*Math.cos(theta)*rx),depth=space==='3d'?forward.map(x=>x*Math.sin(theta)*rz):[0,0,0];
   const point=Array.from({length:dim},(_,d)=>center.p[d]+up[d]*v*ry+side[d]+depth[d]);
   const offset=(region.first+r*region.sides+k)*4;
   for(let d=0;d<3;d++)positions[offset+d]=point[d]??0;
   const conf=space==='3d'?Math.min(.42,center.confidence*.42):center.confidence*.65;
   positions[offset+3]=conf;confidence[region.first+r*region.sides+k]=conf;placed++;
  }
 }
 return placed;
}

export function buildVivaldiFineMesh(frame,profile,{resolution='standard',space='2d'}={}){
 const normalizedSpace=space==='3d'?'3d':'2d',points=pointsFor(frame,normalizedSpace),dim=normalizedSpace==='3d'?3:2;
 const positions=new Float32Array(VIVALDI_MESH_VERTEX_COUNT*4),confidence=new Float32Array(VIVALDI_MESH_VERTEX_COUNT);
 const basis=frameBasis(frame,points,dim),scale=shoulderScale(points,normalizedSpace,profile);
 if(!hasPersonalProfile(profile))return {schema:VIVALDI_FINE_MESH_VERSION,topology:VIVALDI_MESH_TOPOLOGY,space:normalizedSpace,requested_resolution:resolution,resolution:'identity',vertex_count:VIVALDI_MESH_VERTEX_COUNT,positions,confidence,triangles:TOPOLOGY.triangles,regions:TOPOLOGY.regions,segments:TOPOLOGY.regions,visible_vertices:0,visible_triangles:0,quality:'insufficient_personalization'};
 if(!(scale>.005)||!basis)return {schema:VIVALDI_FINE_MESH_VERSION,topology:VIVALDI_MESH_TOPOLOGY,space:normalizedSpace,requested_resolution:resolution,resolution:'identity',vertex_count:VIVALDI_MESH_VERTEX_COUNT,positions,confidence,triangles:TOPOLOGY.triangles,regions:TOPOLOGY.regions,segments:TOPOLOGY.regions,visible_vertices:0,visible_triangles:0,quality:'insufficient_evidence'};
 let placed=0;
 for(const region of TOPOLOGY.regions){
  let endpoints=null,count=0;
  if(region.part==='body'||region.part==='aux'){
   endpoints=segmentEndpoints(frame,points,region,normalizedSpace,dim);
   if(endpoints){
    if(normalizedSpace==='3d')count=placeTube(positions,confidence,region,endpoints,scale,basis,normalizedSpace,profile);
    else count=placeTube(positions,confidence,region,endpoints,scale,basis,normalizedSpace,profile);
   }
  }else if(region.part==='head')count=placeHead(positions,confidence,region,points,scale,basis,normalizedSpace);
  placed+=count;
 }
 const visibleVertices=confidence.reduce((s,x)=>s+(x>=.12?1:0),0);
 let visibleTriangles=0;
 for(let i=0;i<TOPOLOGY.triangles.length;i+=3){if(confidence[TOPOLOGY.triangles[i]]>=.12&&confidence[TOPOLOGY.triangles[i+1]]>=.12&&confidence[TOPOLOGY.triangles[i+2]]>=.12)visibleTriangles++;}
 return {schema:VIVALDI_FINE_MESH_VERSION,topology:VIVALDI_MESH_TOPOLOGY,space:normalizedSpace,requested_resolution:resolution,resolution:'identity',vertex_count:VIVALDI_MESH_VERTEX_COUNT,positions,confidence,triangles:TOPOLOGY.triangles,regions:TOPOLOGY.regions,segments:TOPOLOGY.regions,visible_vertices:visibleVertices,visible_triangles:visibleTriangles,quality:visibleTriangles>=900?'personalized-surface':visibleVertices>=640?'partial-surface':'insufficient_evidence',placed_vertices:placed};
}

let silhouetteScratch=null,silhouetteScratchCtx=null;
const silhouetteAssetCache=new WeakMap();
function makeCanvas(width,height){
 if(typeof OffscreenCanvas==='undefined'&&typeof document==='undefined')return null;
 const canvas=typeof OffscreenCanvas!=='undefined'?new OffscreenCanvas(width,height):document.createElement('canvas');
 canvas.width=Math.max(1,Math.ceil(width));canvas.height=Math.max(1,Math.ceil(height));return canvas;
}
function tintMaskCanvas(source,width,height,color){
 const canvas=makeCanvas(width,height),ctx=canvas?.getContext('2d');if(!ctx)return null;
 ctx.clearRect(0,0,width,height);ctx.drawImage(source,0,0,width,height);ctx.globalCompositeOperation='source-in';ctx.fillStyle=color;ctx.fillRect(0,0,width,height);ctx.globalCompositeOperation='source-over';return canvas;
}
function getSilhouetteAssets(mask,width,height,color){
 if(!mask||typeof mask!=='object')return null;
 const key=`${Math.ceil(width)}x${Math.ceil(height)}:${color}`;let cache=silhouetteAssetCache.get(mask);
 if(cache?.key===key)return cache.assets;
 const alphaData=silhouetteImageData(mask),edgeData=silhouetteContourImageData(mask);if(!alphaData||!edgeData)return null;
 const source=makeCanvas(mask.w,mask.h),edgeSource=makeCanvas(mask.w,mask.h),sctx=source?.getContext('2d'),ectx=edgeSource?.getContext('2d');if(!sctx||!ectx)return null;
 const image=sctx.createImageData(mask.w,mask.h);image.data.set(alphaData);sctx.putImageData(image,0,0);
 const edgeImage=ectx.createImageData(mask.w,mask.h);edgeImage.data.set(edgeData);ectx.putImageData(edgeImage,0,0);
 const alpha=makeCanvas(width,height),edge=makeCanvas(width,height),actx=alpha?.getContext('2d'),edctx=edge?.getContext('2d');if(!actx||!edctx)return null;
 actx.imageSmoothingEnabled=true;actx.drawImage(source,0,0,width,height);edctx.imageSmoothingEnabled=true;edctx.drawImage(edgeSource,0,0,width,height);
 const tint=tintMaskCanvas(alpha,width,height,color),edgeTint=tintMaskCanvas(edge,width,height,color);if(!tint||!edgeTint)return null;
 const assets={alpha,tint,edgeTint};silhouetteAssetCache.set(mask,{key,assets});return assets;
}
function ensureScratch(width,height){
 if(typeof OffscreenCanvas==='undefined'&&typeof document==='undefined')return null;
 const w=Math.max(1,Math.ceil(width)),h=Math.max(1,Math.ceil(height));
 if(!silhouetteScratch||silhouetteScratch.width!==w||silhouetteScratch.height!==h){
  silhouetteScratch=makeCanvas(w,h);silhouetteScratchCtx=silhouetteScratch?.getContext('2d');
 }
 return silhouetteScratchCtx;
}
function drawRegionRibbon(ctx,mesh,region,width,height){
 const {first,rings,sides}=region,half=Math.floor(sides/2),left=[],right=[];
 for(let r=0;r<rings;r++){
  const a=(first+r*sides)*4,b=(first+r*sides+half)*4;
  if(mesh.positions[a+3]<.12||mesh.positions[b+3]<.12)continue;
  left.push([mesh.positions[a]*width,mesh.positions[a+1]*height]);
  right.push([mesh.positions[b]*width,mesh.positions[b+1]*height]);
 }
 if(left.length<2||right.length<2)return false;
 ctx.beginPath();ctx.moveTo(left[0][0],left[0][1]);for(let i=1;i<left.length;i++)ctx.lineTo(left[i][0],left[i][1]);
 for(let i=right.length-1;i>=0;i--)ctx.lineTo(right[i][0],right[i][1]);ctx.closePath();ctx.fill();ctx.stroke();return true;
}
export function paintVivaldiMesh2D(ctx,frame,profile,{resolution='standard',width=640,height=360,color='#79e2cf',alpha=.48,requireSilhouette=true,maskFillAlpha=.075,contourAlpha=.72}={}){
 if(!ctx||!frame)return false;
 const mask=frame.surface?.silhouette;if(requireSilhouette&&!mask)return false;
 const maskColor=mask?.quality==='low'?'#e8a46b':mask?.quality==='review'?'#e4c27d':color;
 const assets=mask?getSilhouetteAssets(mask,width,height,maskColor):null;if(mask&&!assets)return false;
 const mesh=buildVivaldiFineMesh(frame,profile,{resolution,space:'2d'});
 if(mesh.visible_vertices<500||mesh.quality==='insufficient_evidence'){
  if(assets){ctx.save();ctx.globalAlpha=maskFillAlpha;ctx.drawImage(assets.tint,0,0,width,height);ctx.globalAlpha=contourAlpha;ctx.drawImage(assets.edgeTint,0,0,width,height);ctx.restore();return true;}
  return false;
 }
 const scratch=ensureScratch(width,height);if(!scratch)return false;
 scratch.clearRect(0,0,width,height);scratch.save();scratch.strokeStyle=color;scratch.fillStyle=color;scratch.globalAlpha=1;scratch.lineWidth=Math.max(1.1,Math.min(width,height)*.0032);scratch.lineJoin='round';scratch.lineCap='round';
 let ribbons=0;for(const region of mesh.regions)if(drawRegionRibbon(scratch,mesh,region,width,height))ribbons++;
 scratch.restore();if(ribbons<5)return false;
 // The temporally registered 256px mask is the hard 2D boundary. No mesh pixel may extend outside it.
 if(assets){scratch.save();scratch.globalCompositeOperation='destination-in';scratch.imageSmoothingEnabled=true;scratch.drawImage(assets.alpha,0,0,width,height);scratch.restore();
  ctx.save();ctx.globalAlpha=maskFillAlpha;ctx.drawImage(assets.tint,0,0,width,height);ctx.globalAlpha=contourAlpha;ctx.drawImage(assets.edgeTint,0,0,width,height);ctx.globalAlpha=alpha;ctx.drawImage(silhouetteScratch,0,0,width,height);ctx.restore();
 }else{ctx.save();ctx.globalAlpha=alpha;ctx.drawImage(silhouetteScratch,0,0,width,height);ctx.restore();}
 return true;
}
export function paintVivaldiMesh3D(ctx,frame,profile,{resolution='standard',yaw=-.38,pitch=.16,centerX=320,centerY=210,size=240,color='#7ed9eb',alpha=.94}={}){
 if(!ctx||!frame)return false;
 const mesh=buildVivaldiFineMesh(frame,profile,{resolution,space:'3d'});
 if(mesh.visible_vertices<640||mesh.visible_triangles<450||mesh.quality==='insufficient_evidence')return false;
 const pts=mesh.positions,tri=mesh.triangles,ca=Math.cos(yaw),sa=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch),visible=[];
 for(let i=0;i<mesh.vertex_count;i++){const x=pts[i*4],y=pts[i*4+1],z=pts[i*4+2],X=x*ca+z*sa,Z=z*ca-x*sa,Y=y*cp-Z*sp,D=Math.max(.65,2.45+Z*cp+y*sp);visible.push({x:centerX+X/D*size,y:centerY+Y/D*size,z:Z,c:pts[i*4+3]});}
 const faces=[];
 for(let i=0;i<tri.length;i+=3){const a=visible[tri[i]],b=visible[tri[i+1]],c=visible[tri[i+2]];if(Math.min(a.c,b.c,c.c)<.12)continue;
  const area=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);if(Math.abs(area)<.02||Math.abs(area)>size*size*.9)continue;
  const nx=(b.y-a.y)*(c.z-a.z)-(b.z-a.z)*(c.y-a.y),ny=(b.z-a.z)*(c.x-a.x)-(b.x-a.x)*(c.z-a.z),nz=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
  const light=clamp(.58+.42*Math.abs(nz)/Math.max(1e-6,Math.hypot(nx,ny,nz)),.35,1);
  faces.push({a,b,c,z:(a.z+b.z+c.z)/3,light});
 }
 faces.sort((a,b)=>b.z-a.z);ctx.save();ctx.globalAlpha=alpha;ctx.lineWidth=.35;ctx.strokeStyle=color;
 for(const f of faces){ctx.beginPath();ctx.moveTo(f.a.x,f.a.y);ctx.lineTo(f.b.x,f.b.y);ctx.lineTo(f.c.x,f.c.y);ctx.closePath();ctx.fillStyle=`rgba(126,217,235,${(.22+f.light*.48).toFixed(3)})`;ctx.fill();ctx.stroke();}
 ctx.restore();return faces.length>=450;
}
export function chooseVivaldiLOD(){return 'identity';}
