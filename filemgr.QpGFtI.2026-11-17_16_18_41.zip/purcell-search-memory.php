<?php
declare(strict_types=1);
/** Persist legacy 21-candidate and top-1000 archive from each 10k 2D/3D search without source video or pose coordinates. */
function fj_purcell_search_memory(string $directory,string $method,array $body=[]): array {
  if(!is_dir($directory)||is_link($directory))throw new RuntimeException('Purcell private directory is not available');
  $lock=@fopen($directory.'/purcell.lock','c+');if(!$lock)throw new RuntimeException('Cannot open Purcell storage lock');
  try{
    if(!flock($lock,$method==='GET'?LOCK_SH:LOCK_EX))throw new RuntimeException('Cannot lock Purcell memory');
    $file=$directory.'/trajectory-search.json';
    $raw=is_file($file)?@file_get_contents($file):false;
    $data=is_string($raw)?json_decode($raw,true):null;
    if(!is_array($data)||!is_array($data['runs']??null))$data=['schema'=>'purcell-wide-search-memory-v1','runs'=>[]];
    if($method==='GET')return ['ok'=>true,'runs'=>array_slice($data['runs'],-12)];
    if($method!=='POST')throw new InvalidArgumentException('Method not allowed');
    $action=$body['action']??'save_run';
    if($action==='save_run'){
      $cases=$body['candidates']??null;if(!is_array($cases)||count($cases)>1000)throw new InvalidArgumentException('Expected 21 legacy candidates or up to 1000 archived passing candidates from a 10k search');
      $newSearch=in_array((string)($body['schema']??''),['purcell-wide-search-v3-10000','purcell-spatial-v2-10000'],true)||count($cases)===1000;
      $modality=($body['modality']??'2d')==='3d'?'3d':'2d';
      if($modality==='3d'&&!$newSearch)throw new InvalidArgumentException('3D requires 1000 candidates');
      $rows=[];$seen=[];
      foreach($cases as $case){
        if(!is_array($case))throw new InvalidArgumentException('Invalid candidate');
        $id=(string)($case['id']??'');$family=(string)($case['family']??'');
        if(!( $newSearch ? preg_match('/^hyp-(?:[0-9]{4}|[0-9]{5})$/',$id) && (int)substr($id,4)<=10000 && (int)substr($id,4)>0 : preg_match('/^hyp-(0[1-9]|1[0-9]|2[01])$/',$id))||isset($seen[$id])||!preg_match('/^[a-z_]+:[a-z_]+$/',$family))throw new InvalidArgumentException('Invalid candidate id or family');
        $seen[$id]=true;$score=$case['score']??null;if(!is_numeric($score)||!is_finite((float)$score))throw new InvalidArgumentException('Invalid candidate score');
        $rows[]=['id'=>$id,'family'=>substr($family,0,65),'score'=>max(0,min(100,(float)$score)),'passed'=>($case['passed']??false)===true,'engine_score'=>is_numeric($case['engine_score']??null)?max(0,min(100,(float)$case['engine_score'])):null,'readiness_score'=>is_numeric($case['readiness_score']??null)?max(0,min(100,(float)$case['readiness_score'])):null,'objective_scores'=>array_map(static fn($x)=>is_numeric($x)?round(max(0,min(100,(float)$x)),1):null,array_intersect_key((array)($case['objective_scores']??[]),array_flip(['overall','economy','speed','coherence']))),'metrics'=>array_map(static fn($x)=>is_numeric($x)?round((float)$x,5):0,array_intersect_key((array)($case['metrics']??[]),array_flip(['bone_distortion','max_bone_distortion','acceleration_proxy','speed_deviation','mean_displacement','clipped']))),'engine_diagnostics'=>[
          'planner_available'=>($case['engine_diagnostics']['planner_available']??false)===true,
          'planner_findings'=>max(0,min(1000,(int)($case['engine_diagnostics']['planner_findings']??0))),
          'trajectory_profiles'=>max(0,min(1000,(int)($case['engine_diagnostics']['trajectory_profiles']??0))),
          'transition_count'=>max(0,min(1000,(int)($case['engine_diagnostics']['transition_count']??0)))
        ],'gravity_score'=>is_numeric($case['gravity_score']??null)?round(max(0,min(100,(float)$case['gravity_score'])),1):null,'spatial_reliability'=>is_numeric($case['spatial_reliability']??null)?round(max(0,min(1,(float)$case['spatial_reliability'])),3):null,'personalized_surface_score'=>is_numeric($case['personalized_surface_score']??null)?round(max(0,min(100,(float)$case['personalized_surface_score'])),1):null,'personalized_surface_fit'=>is_array($case['personalized_surface_fit']??null)?[ 'available'=>($case['personalized_surface_fit']['available']??false)===true,'passed'=>($case['personalized_surface_fit']['passed']??false)===true,'space'=>in_array($case['personalized_surface_fit']['space']??null,['2d','3d'],true)?$case['personalized_surface_fit']['space']:null,'mean_log_drift'=>is_numeric($case['personalized_surface_fit']['mean_log_drift']??null)?round(max(0,min(5,(float)$case['personalized_surface_fit']['mean_log_drift'])),5):null,'p90_log_drift'=>is_numeric($case['personalized_surface_fit']['p90_log_drift']??null)?round(max(0,min(5,(float)$case['personalized_surface_fit']['p90_log_drift'])),5):null,'observations'=>max(0,min(10000,(int)($case['personalized_surface_fit']['observations']??0))),'segments'=>array_values(array_intersect((array)($case['personalized_surface_fit']['segments']??[]),['torso','left_arm_upper','left_arm_lower','right_arm_upper','right_arm_lower','left_leg_upper','left_leg_lower','right_leg_upper','right_leg_lower']))]:null,'evidence_ids'=>array_slice(array_values(array_filter((array)($case['evidence_ids']??[]),static fn($id)=>is_string($id)&&preg_match('/^[0-9a-f]{20}$/',$id))),0,8),'muscle_proxy_score'=>is_numeric($case['muscle_proxy_score']??null)?round(max(0,min(100,(float)$case['muscle_proxy_score'])),1):null,'muscle_chain'=>in_array($case['muscle_chain']??null,['left_arm','right_arm','left_leg','right_leg','trunk'],true)?$case['muscle_chain']:null,'muscle_phase_levels'=>array_slice(array_map(static fn($v)=>max(0,min(3,(int)$v)),(array)($case['muscle_phase_levels']??[])),0,5),'selected'=>false,'user_rejected'=>false];
      }
      $runId=bin2hex(random_bytes(12));$data['runs'][]=['id'=>$runId,'created_at'=>gmdate('c'),'unit_name'=>substr(trim(strip_tags((string)($body['unit_name']??''))),0,120),'scope_start'=>max(0,(float)($body['scope_start']??0)),'scope_end'=>max(0,(float)($body['scope_end']??0)),'goal'=>substr((string)($body['goal']??'balanced'),0,30),'schema'=>($newSearch?($modality==='3d'?'purcell-spatial-v2-10000-archive-top1000':'purcell-wide-search-v3-10000-archive-top1000'):'purcell-wide-search-v1'),'modality'=>$modality,'input_source'=>substr((string)($body['input_source']??'legacy'),0,100),'selection_reason'=>substr((string)($body['selection_reason']??''),0,50),'source_coherence'=>is_numeric($body['coherence']??null)?max(0,min(100,(float)$body['coherence'])):null,'total_evaluated'=>max(0,min(10000,(int)($body['total_evaluated']??count($cases)))),'passed_total'=>max(0,min(10000,(int)($body['passed_total']??count($rows)))),'archive_policy'=>$newSearch?'top-1000-passing':'legacy-21','candidates'=>$rows,'selected_candidate'=>null];
      $data['runs']=array_slice($data['runs'],-150);
      $response=['ok'=>true,'run_id'=>$runId,'stored'=>count($rows)];
    }elseif($action==='select'){
      $runId=(string)($body['run_id']??'');$candidate=(string)($body['candidate_id']??'');
      if(!preg_match('/^[0-9a-f]{24}$/',$runId)||($candidate!==''&&!preg_match('/^hyp-(?:[0-9]{2}|[0-9]{4}|[0-9]{5})$/',$candidate)))throw new InvalidArgumentException('Invalid selection');
      $found=false;
      foreach($data['runs'] as &$run){if($run['id']!==$runId)continue;$found=true;$valid=$candidate==='';
        foreach($run['candidates'] as &$row){if($row['id']===$candidate&&$row['passed']&&!($row['user_rejected']??false))$valid=true;$row['selected']=$row['id']===$candidate&&$row['passed'];}unset($row);
        if(!$valid)throw new InvalidArgumentException('Candidate unavailable or rejected');
        $run['selected_candidate']=$candidate!==''?$candidate:null;$run['selected_at']=gmdate('c');$run['comment']=substr(trim(strip_tags((string)($body['comment']??''))),0,1000);break;
      }unset($run);
      if(!$found)throw new InvalidArgumentException('Run not found');
      $response=['ok'=>true,'selected_candidate'=>$candidate!==''?$candidate:null];
    }elseif($action==='reject_candidate'){
      $runId=(string)($body['run_id']??'');$candidate=(string)($body['candidate_id']??'');
      if(!preg_match('/^[0-9a-f]{24}$/',$runId)||!preg_match('/^hyp-(?:[0-9]{2}|[0-9]{4}|[0-9]{5})$/',$candidate))throw new InvalidArgumentException('Invalid rejection');
      $found=false;
      foreach($data['runs'] as &$run){if($run['id']!==$runId)continue;
        foreach($run['candidates'] as &$row){if($row['id']===$candidate){$row['user_rejected']=true;$found=true;break;}}unset($row);
        if($found&&$run['selected_candidate']===$candidate)$run['selected_candidate']=null;
        break;
      }unset($run);
      if(!$found)throw new InvalidArgumentException('Run or candidate not found');
      $response=['ok'=>true,'rejected_candidate'=>$candidate];
    }else throw new InvalidArgumentException('Unsupported action');
    $json=json_encode($data,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE|JSON_UNESCAPED_SLASHES);
    if(!is_string($json))throw new RuntimeException('Cannot encode memory');
    $tmp=$file.'.tmp-'.bin2hex(random_bytes(4));
    if(@file_put_contents($tmp,$json,LOCK_EX)===false||!@rename($tmp,$file)){@unlink($tmp);throw new RuntimeException('Cannot atomically write Purcell search memory');}
    @chmod($file,0600);return $response;
  }finally{flock($lock,LOCK_UN);fclose($lock);}
}
