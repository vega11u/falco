# QA report — Falco Jugger 22.4.0

## Automated checks

- PHP syntax checks for `index.php`, `uppurcell.php`, `Memories.php`, `server-learning.php`.
- `tests/intelligence-data-smoke.php` and `tests/release-smoke.php`.
- `tests/v22-smoke.sh`, `tests/v22-2-studio-smoke.sh`, `tests/v22-4-editorial-smoke.sh`.
- Existing local-video, report library, learning API, media import, Lux CRON, optimizer and JS biomechanical regression suites.
- Shell syntax for setup and worker scripts.
- ZIP integrity and manifest/hash verification.

## Backend scope

No PHP API logic or storage schema was changed. The release test suite exercises the existing health endpoint contracts, learning storage, report streaming/listing, private Purcell store, and importer orchestration. Runtime checks on the user's REG.RU account remain necessary after deployment.

## Visual checks

- Rendered `index.php`, `uppurcell.php` and `Memories.php` at desktop and mobile viewport widths.
- Verified no horizontal overflow.
- Verified no FJ badge, generated crest or seal markup remains.
- Verified final stylesheet has no CSS gradients, Bebas Neue, generated crest or old acanthus logo references.
- Verified IM Fell English SC is reserved for `.brand-title` and Times New Roman is the UI family.

## Limits

A local browser cannot verify the user's server configuration, actual external social downloads, or device-specific GPU performance. The installed site's private model/report data was not present in the deployment ZIP and was not modified.
