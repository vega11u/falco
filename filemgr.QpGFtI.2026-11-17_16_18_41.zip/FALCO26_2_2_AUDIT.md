# Falco Jugger 26.2.2 — Code inspection and regression report

## Source basis

- Exact source archive: `filemgr.zxylYr.2026-11-15_19_00_00.zip` (Falco 26.2.0, core 23.0.27).
- The patch is built on the immediately preceding 26.2.1 Flight Deck patch and is intended for a site where that patch is installed.
- Fixed personalized topology remains `falco-vivaldi-fixed-2048-v2` (2048 vertices).

## Scope inspected

The uploaded source archive contains 548 files. The audit pass inspected all files by inventory and checksum, plus source-level checks across the runtime:

- 41 PHP files: `php -l` passed for all.
- 107 JavaScript / MJS files: `node --check` passed for all.
- One root CSS file: parsed with tinycss2 as 483 rules, zero parser errors.
- Rendered main page: 370 unique DOM IDs, zero duplicate IDs; 134 buttons, all with explicit `type`.
- Main release test suite: `bash tests/verify.sh` passed after updating stale version-specific UI assertions.
- One root stylesheet remains; no CSS imports, legacy compatibility layer, or old `.f24-workspace-grid` system.

This is a full static source inspection and regression pass, not a formal proof that every runtime path is defect-free. The PHP endpoints and browser ML workflows require production environment integration tests. A full Chromium interaction run was not available in the build environment; the final QA therefore does not claim that every click path has been end-to-end exercised in a real production browser.

## Confirmed UI defects addressed

1. The desktop player was `position: sticky`, and its containing column was in the page's scroll context. It is now fixed to the viewport on desktop; the central grid reserves the same exact width so the player does not cover content.
2. The navigation groups each had their own `overflow-y:auto` scroll root. They now remain naturally laid out; only the fixed rail itself can scroll when viewport height is unusually short.
3. The player dock and its column no longer have independent vertical scrolling. The player is height-aware; 3D is bounded and on-demand.
4. Mobile expanded player no longer uses a nested scroll container. It is a bounded composition with a scaled video stage, collapse action, and safe-area spacing.
5. Opening the 3D pane no longer calls `scrollIntoView()` on the fixed player.
6. Text in the central workstream and player headers can wrap without forcing adjacent controls outside their containers.
7. Transport controls have stable dimensions and timeline layout adapts to narrow widths.
8. Cache keys updated to 26.2.2 on all primary and secondary pages.

## Preserved

- Analysis core `23.0.27`.
- Fixed-mesh reconstruction architecture and 2048-vertex topology.
- Existing PHP APIs, import pipeline, report persistence, training records, Lully/Purcell data, workers, and heavy model assets.
- Existing player and analysis handlers; no replacement of the analysis module.
- Purcell remains a single general optimization objective.

## QA limitation

`tests/verify.sh` passes all developer checks. This does not replace an actual REG.RU HOST-0 production run with a real kata video, real model assets, and the user's browser. If the server has local edits to any protected file, the installer refuses to overwrite it and exits before making changes.
