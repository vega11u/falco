# Falco Jugger v20.0.2 — deployment notes

This is an overlay update for v20.0.1. It does not include or overwrite `data/`, `training-data/`, `vendor/`, or private `.kata-*` storage. Back up the site and private storage before deployment.

## Changes

- Fixed the out-of-scope `footLift` value in kick-event reporting. Peak lift is recalculated from the peak frame through `estimateFootLiftAtFrame()` in `biomechanics-core.mjs`.
- Added a confidence-gated single-frame outlier repair for ankle/heel/toe landmarks. Only low-confidence spikes bracketed by confident samples are corrected; confident rapid motion is not smoothed. The number of repairs is included in `report.analysis.pose_track_repair`.
- YouTube import now tries the default yt-dlp client set, then separate `web_safari` (HLS), `android_vr`, and `web_embedded` delivery profiles. These are different YouTube delivery clients, not different downloader binaries.

## YouTube limitations

YouTube currently applies client-dependent SABR and Proof-of-Origin token requirements. A different client profile may expose another downloadable stream, but no downloader can guarantee access when the host IP is blocked, the video requires an unavailable PO token, or the video is private/age-restricted. The project does not use untrusted public proxy APIs.

## Install

1. Back up the project and private `.kata-*` storage.
2. Extract the overlay over the project root.
3. Run `bash setup-media-import.sh` only if the runtime/yt-dlp binary is not installed or health reports it missing.
4. Hard-refresh the browser.
5. Test local MP4/MOV and one public YouTube link.

The host-side Python 3.8.6 is not used by this release. Sports2D is not installed on Host-0: current Sports2D requires Python >=3.11 and its pose/OpenSim stack is too resource-intensive for Host-0's shared CPU allowance.
