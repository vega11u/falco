/** CPU-only body reconstruction in a dedicated worker.
 * Long sequences report progress without blocking the UI thread. */
import {reconstructBodySequence} from './body-reconstruction-core.mjs?v=26.2.0';
import {optimizeResearchSequence,RESEARCH_C_OPTIMIZER_VERSION} from './research-c-temporal-optimizer.mjs?v=27.2.0';
self.onmessage=event=>{
  const {frames,aspect,maxGap}=event.data||{};
  try{
    if(!Array.isArray(frames)||frames.length>120000)throw new Error('Недопустимый размер последовательности реконструкции.');
    const result=reconstructBodySequence(frames,{aspect,maxGap,onProgress:progress=>{
      self.postMessage({type:'progress',...progress});
    }});
    const temporal=optimizeResearchSequence(result.tracks,{onProgress:progress=>{
      self.postMessage({type:'progress',...progress});
    }});
    if(temporal.tracks.length!==result.tracks.length)throw new Error('Research C temporal optimizer frame-count mismatch');
    result.tracks=temporal.tracks;
    result.diagnostics={...result.diagnostics,research_c_temporal:temporal.diagnostics,research_c_optimizer_version:RESEARCH_C_OPTIMIZER_VERSION,canonical_track_refined_in_worker:true};
    self.postMessage({type:'complete',ok:true,...result});
  }catch(error){self.postMessage({type:'complete',ok:false,error:String(error?.message||error).slice(0,800)});}
};
