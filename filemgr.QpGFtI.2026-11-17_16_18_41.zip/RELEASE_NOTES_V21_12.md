# Falco Jugger v22.0.0

## Fixes and changes

1. **Server report library:** raised per-report upload/read/decompression limits to 120 MB; added server memory/time allowance, clearer request-size diagnostics, and exposed storage owner-scope diagnostics in the list response. Reports remain isolated from model files. For the maximum size, hosting must allow request bodies of at least 128 MB and PHP memory_limit of at least 768 MB.
2. **Think again:** every pass now performs a fresh full-sequence discovery using explicit yes/no decisions and edited labels/types. Old pending/reviewed cards are replaced; confirmed historical exemplars remain visible and stored in training.
3. **Biomechanics:** the planner uses research-grounded multi-segment coordination, proximal-to-distal timing, support-base/balance context, braking/recoil and individual repeated-transition references. It still distinguishes observable kinematics from unobservable force/EMG/tissue strain.
4. **Optimizer feedback:** each recommendation offers “Хорошая правка”, “Нормальная правка”, “Неверная правка”. Votes persist in the existing learning feedback archive and influence subsequent recommendation priority. They do not overwrite motion measurements or feature vectors.
5. **Transitions:** each transition is classified as fast, smooth, mixed or unknown using duration, pelvis-path velocity and normalized log dimensionless jerk. Fast transitions are evaluated for speed and control; smooth transitions are evaluated for continuity and preservation.
6. **Report size:** maximum archive JSON body is 120 MB; decompressed server read ceiling is 240 MB.
7. **Interface:** secondary analysis panels start hidden; video upload, synchronized player and analysis progress/debug remain available. A control reveals the analysis panels when needed.
8. **Taxonomy sync:** user-entered kata and technique labels are stored in `taxonomy-custom.json` under the private learning directory and merged into suggestions on load. The shipped JSON taxonomy is not rewritten; taxonomy updates are independent from classifier/model weights.

## Research and implementation references

- Zago et al., *Multi-segmental movements as a function of experience in karate*, J Sports Sci, 2017, PMID 27560105.
- *Kinematic and electromyographic analyses of a karate punch*, proximal-to-distal sequence and segmental velocity timing.
- *On the analysis of movement smoothness*, PMCID PMC4674971; log dimensionless jerk and SPARC methodology.
- *Smoothness Metrics in Complex Movement Tasks*, PMCID PMC6143727.
- *Dynamic balance in elite karateka*, PMID 26499923.
- GitHub: [Sports2D](https://github.com/davidpagnon/Sports2D), [MMPose](https://github.com/open-mmlab/mmpose), [VideoJS annotation comments](https://github.com/trilogy-group/contently-videojs-annotation-comments). Reviewed as design/algorithm references; no new production dependency is added.

## Compatibility guarantees

- 48D per-frame pose representation unchanged.
- 384D per-pattern and 1152D full-kata feature formats unchanged.
- Existing `library.json`, `classifier-model.json`, trained weights and confirmed examples are not migrated, replaced or cleared.
- Custom taxonomy is an additive file beside the learning archive.
- Report deletion remains independent of learning storage.
