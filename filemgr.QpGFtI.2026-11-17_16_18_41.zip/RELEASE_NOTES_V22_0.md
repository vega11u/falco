# Falco Jugger 22.0.0 — release notes

## Main interface
- Replaced the crowded dashboard with a focused sequence: upload/link inputs,
  synchronized 2D player, current-frame metrics, quality timeline, overall
  scores, Lully pattern review and Purcell optimizer.
- Added collapsible human-readable legends for current-frame and report metrics.
- Added average movement consistency, calculated from usable frames.
- Secondary diagnostics are available from a compact panel at the bottom.
- Typography: Bebas Neue for headings, Times New Roman for all other text.
- Added a live server-connection indicator with a 30-second heartbeat.

## Lully
- Existing classifier and personal training archive remain in place.
- Confirmed pattern examples continue to upload immediately when the user saves
  a card.
- Added an idempotent **Обновить модель Lully** action.
- Added **Повторный поиск паттернов**: stores all yes/no review vectors in
  persistent learning feedback, synchronizes Lully, clears every visible
  candidate and runs a fresh search.
- Each review pass is stored separately; prior passes are not overwritten.

## Purcell
- Added `uppurcell.php`, which reuses the same upload, decoder, 2D avatar,
  player and calculation pipeline.
- Added ratings 1–5, good/problem body-region tags and Russian notes for each
  short biomechanics example.
- Positive references, counterexamples and recommendation votes are stored
  separately from Lully.
- Purcell combines Lully pattern context, the existing anatomy/karate knowledge
  and reviewed user examples. It is a lightweight explainable decision layer,
  not a general-purpose language model.
- It does not denoise or smooth numeric trajectories. A changed avatar is only
  offered when a significant measured cue and a sufficiently close positive
  reference are both present. Otherwise it explicitly declines to fabricate a
  correction.
- User votes are persisted and influence later recommendations.

## Reports and REG.RU Host-0
- Report library now shares the main page's visual identity. A saved report can also be opened directly in `uppurcell.php` and used as a reviewed Purcell example.
- New report saves are gzip-compressed in the browser and sent in sequential
  2 MiB chunks. PHP verifies compressed checksum, gzip integrity, uncompressed
  size and archive structure while streaming to disk.
- Report listing uses small metadata sidecars; legacy report metadata is extracted
  from a bounded gzip stream. Report restoration streams decompressed JSON
  without decoding the entire report in PHP.
- Existing legacy report files remain readable. Reports, Lully data and Purcell
  data remain three separate private stores.
- No Python or additional server-side model runtime was introduced.
