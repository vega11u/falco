Runtime directory intentionally contains no downloaded training database, model weights, or third-party research payloads.
Set KATA_LEARNING_DIR outside DOCUMENT_ROOT for persistent private training data.
