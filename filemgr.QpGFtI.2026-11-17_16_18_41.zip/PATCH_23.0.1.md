# Falco Jugger 23.0.1 — patch update

## Target
Patch is based on the supplied Falco Jugger 23.0.0 archive. It is an overlay, not a clean deployment.

## Apply
1. Back up the site files and the private data directories (`.kata-reports-*`, `.kata-biomechanics-*`, `.kata-media-import-*`, `data/trained/`, and `vendor/`).
2. Upload the contents of this patch ZIP into the existing site root, replacing matching files.
3. Do not delete or replace private data directories. No schema migration is required.
4. Hard-refresh the browser after deployment. `index.php` sends no-cache headers; the stylesheet URL is versioned to 23.0.1.
5. Run `bash tests/v23-0-1-patch-smoke.sh` if shell access is available. The full developer suite remains `bash tests/verify.sh`.

## Patch contents
- `index.php`: the primary “Сохранить в библиотеку сервера” action now performs the durable full-archive upload and verifies that the archive appears in the server library (the old session-only action is no longer the primary action); player-docked trim workspace; trimmed kata samples can be saved as kata training samples without being forced into a “sequence” or rejected as incomplete; Lully annotation drafts survive review-triggered rerenders; Purcell global player removed; replay is scoped to recommendation cards.
- `frutiger-aero-v23.css`: Cyrillic-capable Frutiger-style font fallback stack, consistent button states, responsive trim workspace and media-card sizing.
- `VERSION`, `README.md`, `CHANGELOG.md`, `DEPLOYMENT_V23.md`: patch version and deployment notes.
- `tests/v23-0-1-patch-smoke.sh`, `tests/verify.sh`: regression contracts.

## Important behavior
Trimming is a selection of analyzed timestamps only. It does not infer whether the source recording contains a full kata. When a user confirms a training identity in range mode, the exact analyzed intervals are stored for both kata and sequence types. Existing full-video behavior is unchanged.

The Lully review fix stores the current input/select values into each in-memory pattern's draft fields on every edit. Re-rendering after marking an instance Yes/No therefore restores the current label and kind rather than reverting to the detected candidate's original label.

Purcell no longer presents a single global playback dock. Its finding cards show the source frame and a comparative before/after avatar when a safe correction is available. Each replay is 1–5 seconds (recommendation-supplied duration when available; otherwise movement-aware defaults). The application does not fabricate a correction when there is no validated reference or safe correction.

## Server reports and library
The server-side report endpoints and ownership model are deliberately unchanged. The main Save button was previously wired to a PHP-session shortcut; it is now wired to the full compressed server-archive upload, followed by a server-library visibility check. The supplied 23.0.0 report-library integration test was run against PHP's local HTTP server and passed: save, list, get, delete, persistence beyond the PHP session, owner isolation, and independence from the learning archive. Reports remain server files in the configured private report directory, not browser localStorage. After deployment, verify the destination configured by `KATA_REPORTS_DIR` is writable by the PHP user; use `Memories.php` to confirm the server library is visible.

## Limits / accuracy
This patch does not claim to reduce model error to a particular percentage. Pose-estimation error depends on camera angle, occlusion, clothing, lighting, source resolution and ground-plane visibility. The current archive's tests validate regression properties, not a motion-capture-validated absolute error rate. Better foot support and scene/person association require representative videos and ground-truth annotations before a numerical accuracy claim is justified.

## Rollback
Restore the backed-up `index.php`, `frutiger-aero-v23.css`, and version/docs files. Leave private reports, learning data, media import jobs and vendor assets untouched.
