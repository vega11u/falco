/** Canonical, compact, chunkable evidence envelope for Research C. */
export const RESEARCH_C_EVIDENCE_SCHEMA='falco-canonical-reconstruction-v3';
export const RESEARCH_C_RUN_SCHEMA='falco-analysis-run-v3';
const finite=Number.isFinite;
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const pointConf=p=>Array.isArray(p)&&finite(p[0])&&finite(p[1])?clamp(Number(p[3]??0),0,1):0;
const CLASS={rejected:0,uncertain:1,inferred:2,observed:3};
function classifyPoint(p,raw,threshold=.72){
 if(!Array.isArray(p)||!finite(p[0])||!finite(p[1]))return 'rejected';
 const c=pointConf(p),r=pointConf(raw);
 if(c>=threshold&&r>=threshold)return 'observed';
 if(c>=.18)return 'inferred';
 return 'uncertain';
}
function stableId(prefix,index){return `${prefix}-${String(index).padStart(7,'0')}`;}
export function createResearchRunManifest({runId,mediaName,mediaSha256=null,mediaSizeBytes=null,mediaLastModified=null,trimStartUs=0,trimEndUs=null,modelManifestSha256=null,backendPlan=[],depthMode='FULL_CONSENSUS',calibration=null,createdAt=new Date().toISOString()}={}){
 return Object.freeze({schema:RESEARCH_C_RUN_SCHEMA,run_id:runId||`run-${Date.now()}-${Math.random().toString(36).slice(2,9)}`,media:{name:String(mediaName||'unknown'),size_bytes:Number.isFinite(mediaSizeBytes)?mediaSizeBytes:null,last_modified:Number.isFinite(mediaLastModified)?mediaLastModified:null,sha256:mediaSha256},trim:{start_us:Math.max(0,Math.round(trimStartUs)),end_us:finite(trimEndUs)?Math.max(0,Math.round(trimEndUs)):null},model_manifest_sha256:modelManifestSha256,pipeline_version:'research-c-1.0.0',depth_mode:depthMode,backend_plan:Array.isArray(backendPlan)?backendPlan:[],calibration:calibration||{type:'none',metric_scale_verified:false},timestamps:{source:'source_presentation_timestamp',unit:'microseconds',vfr_supported:true},status:'CREATED',created_at:createdAt});
}
export function buildFrameEvidenceV3(f,i,{runId='frame',depthMode='FULL_CONSENSUS',calibrationVerified=false}={}){
 const t=Number(f.t),im=f.im||[],raw=f.raw_im||[],world=f.w||[],rawWorld=f.raw_w||[];
 const pose2d=Array.from({length:33},(_,j)=>{const p=im[j],e=classifyPoint(p,raw[j]);return [finite(p?.[0])?p[0]:null,finite(p?.[1])?p[1]:null,pointConf(p),CLASS[e]];});
 const pose3d=Array.from({length:33},(_,j)=>{const p=world[j],e=classifyPoint(p,rawWorld[j]);return [finite(p?.[0])?p[0]:null,finite(p?.[1])?p[1]:null,finite(p?.[2])?p[2]:null,pointConf(p),CLASS[e]];});
 const ens=f.depth_ensemble||{},contributors=Array.isArray(ens.contributors)?ens.contributors:[],failures=ens.failures||[];
 const complete=!!ens.complete&&contributors.length>=4&&!failures.length;
 const observed=pose2d.filter(x=>x[3]===CLASS.observed).length,inferred=pose2d.filter(x=>x[3]===CLASS.inferred).length,uncertain=pose2d.filter(x=>x[3]===CLASS.uncertain).length,rejected=pose2d.filter(x=>x[3]===CLASS.rejected).length;
 return {frame_id:stableId(runId,i),source_frame_index:Number.isInteger(f.source_frame_index)?f.source_frame_index:(Number.isInteger(f.sample_index)?f.sample_index:i),t_us:finite(t)?Math.round(t*1e6):null,camera_segment_id:f.camera_segment_id??0,pose_2d:pose2d,pose_3d_relative:pose3d,depth:{mode:depthMode,contributors,complete,failures,agreement:f.depth_ensemble?.model_agreement??null},mask:{confidence:Number(f.surface?.silhouette?.boundary_confidence??f.surface?.clothing_surface_confidence??f.surface?.mask_coverage)||null,source:f.surface?.silhouette?.schema||'legacy-silhouette',width:f.surface?.silhouette?.w||null,height:f.surface?.silhouette?.h||null,full_resolution_available:!!(f.surface?.silhouette?.source_resolution_available),source_width:f.surface?.silhouette?.source_width||null,source_height:f.surface?.silhouette?.source_height||null,native_mask_width:f.surface?.silhouette?.native_mask_width||f.surface?.silhouette?.w||null,native_mask_height:f.surface?.silhouette?.native_mask_height||f.surface?.silhouette?.h||null},observation_counts:{observed,inferred,uncertain,rejected},quality_class:observed>=20?'observed':observed+inferred>=12?'inferred':'uncertain',metric_scale_verified:!!calibrationVerified,coordinate_system:calibrationVerified?'calibrated_world':'relative_world',flags:[...(f.pose_suspicion||[]),...(complete?[]:['depth_consensus_incomplete'])]};
}
export function buildCanonicalReconstructionV3(frames,{runId,mediaSha256=null,optimizerDiagnostics=null,depthMode='FULL_CONSENSUS',calibrationVerified=false}={}){
 if(!Array.isArray(frames))throw new TypeError('frames must be an array');
 let observed=0,inferred=0,uncertain=0,rejected=0;
 const keyframes=[];
 for(let i=0;i<frames.length;i++){
  const f=frames[i],raw=f.raw_im||[],im=f.im||[];
  for(let j=0;j<33;j++){const c=classifyPoint(im[j],raw[j]);if(c==='observed')observed++;else if(c==='inferred')inferred++;else if(c==='uncertain')uncertain++;else rejected++;}
  const ens=f.depth_ensemble||{};
  if((ens.contributors||[]).length||(ens.failures||[]).length)keyframes.push(!!ens.complete&&(ens.contributors||[]).length>=4&&!(ens.failures||[]).length);
 }
 const consensusRequired=depthMode==='FULL_CONSENSUS',consensusFrames=keyframes.filter(Boolean).length;
 const consensusComplete=!consensusRequired||(keyframes.length>0&&consensusFrames===keyframes.length);
 const status=frames.length&&consensusComplete?'COMPLETE':frames.length?'PARTIAL':'FAILED';
 return Object.freeze({schema:RESEARCH_C_EVIDENCE_SCHEMA,run_id:runId||null,media_sha256:mediaSha256,depth_mode:depthMode,status,metric_scale_verified:!!calibrationVerified,coordinate_system:calibrationVerified?'calibrated_world':'relative_world',frame_count:frames.length,observation_counts:{observed,inferred,uncertain,rejected},depth_consensus:{required_models:['base','small','glpn','dpt'],required:consensusRequired,evaluated_keyframes:keyframes.length,complete_keyframes:consensusFrames,complete_keyframe_fraction:keyframes.length?consensusFrames/keyframes.length:(consensusRequired?0:null),source_frame_coverage:keyframes.length?keyframes.length/Math.max(1,frames.length):0,complete:consensusComplete,semantics:'Completeness applies to evaluated depth keyframes, not every decoded source frame; temporal pose track covers source frames.'},optimizer:optimizerDiagnostics||null,storage:{format:'chunked-indexeddb',chunk_size:240,full_frame_records_in_memory:false},limitations:['Monocular 3D is not metric without calibration','Hidden surface regions are prior-only unless supported by observations','Mask resolution is the native MediaPipe segmentation output; source-resolution equality is explicitly recorded and may be false','Depth consensus agreement is not ground-truth accuracy']});
}
export function buildCanonicalEvidenceChunk(frames,start,end,options={}){
 const first=Math.max(0,Math.floor(start)),last=Math.min(frames.length,Math.floor(end));
 if(last<first)throw new RangeError('Invalid canonical evidence chunk range');
 const out=[];for(let i=first;i<last;i++)out.push(buildFrameEvidenceV3(frames[i],i,options));return out;
}
