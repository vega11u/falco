# QA · единый патч 23.0.12 + 23.0.13 + 23.0.14 + 23.0.15

## База и безопасность

- Основа: `falcojugger.art.zip` — прикреплённый архив пользователя, а не вымышленный путь полной сборки.
- Патч накладывается на текущую папку сайта, содержит только программные файлы, документацию и тесты.
- В архиве **нет** учебных библиотек, приватных отчётов, конфигурации, пользовательских видеозаписей, заранее загруженных весов нейросетей.
- Структура API, данные старого обучения Lully/Purcell, маршруты распознавания и память Purcell неизменны; никакой обязательной миграции.

## Регрессии и новые проверки

- `php -l index.php models.php Memories.php`; `php index.php`, `php uppurcell.php`, `php models.php`, `php Memories.php` — HTML генерация и подключение новой CSS.
- Основной `<script type=module>` извлечён из уже обработанного PHP HTML и проверен `node --check` (JavaScript без PHP-плейсхолдеров).
- `node --check aero-studio-ux-v23.0.15.js`, tinycss2 parse CSS, проверка синтаксиса и наличия мобильных / тёмных правил.
- `tests/aero-studio-contract-23-0-15.mjs`: исходные UI IDs сохранены, инверсия 3D-toggle, CSS видимости 3D, консистентный таймкод, binary-search replay по нерегулярным timestamps, ускорение локального индекса, reset-engine preservation, IN/OUT ручки близких диапазонов, отсутствие новых GPU/WebGL движков в UI.
- `tests/velocity-and-quality-23-0-14.mjs`, `tests/purcell-evolution-23-0-14.mjs`, `tests/body-reconstruction-23-0-13.mjs`, `tests/body-reconstruction-worker-23-0-13.mjs`, `tests/depth-stability-23-0-11.mjs`, `tests/purcell-evolution-memory-23-0-14.php`, `tests/reconstruction-memory-23-0-13.php` — успешно.
- **PASS:** объединённый ZIP наложен на чистую копию прикреплённого `falcojugger.art.zip` в `/mnt/data/falco_1215_verify/falcojugger.art`; SHA-256 всех **112** файлов из защищённых каталогов (`training-data/`, `data/trained/`, `reports/`) совпали до и после. Проверены PHP lint и HTML-рендер всех четырёх страниц уже после наложения; синтаксис JS/CSS и тест нового интерфейса тоже проверены на наложенном сайте.

## Границы проверки

- В данной среде попытка скриншотов Chromium/Playwright получила `net::ERR_BLOCKED_BY_ADMINISTRATOR`; реальное визуальное тестирование отрисовки, drag-перетаскивания, касаний на Android, производительности WebGPU и температурного режима пользователя **не выполнялось**.
- Регрессионные тесты на синтетических данных не являются измерением спортивной точности, метрической калибровки 3D и фактического КПД.
