/** Kata pause / linkage partitioner. Kinematics only; no inferred intent or style rule. */
export const PAUSE_SCHEMA='falco-kata-pauses-v1';
const ids=[11,12,15,16,23,24,27,28];
const ok=p=>Array.isArray(p)&&Number.isFinite(p[0])&&Number.isFinite(p[1])&&(p[3]??1)>=.4;
const median=a=>{if(!a.length)return null;const b=[...a].sort((x,y)=>x-y);return b[Math.floor(b.length/2)];};
export function detectKataPauses(frames,{minPause=.18,maxStep=.24}={}){
 if(!Array.isArray(frames)||frames.length<7)return {schema:PAUSE_SCHEMA,pauses:[],linkages:[],threshold:null};
 const speed=new Array(frames.length).fill(null),scales=[];
 for(let i=0;i<frames.length;i++){
   const p=frames[i].im||[];if(ok(p[11])&&ok(p[23])&&ok(p[12])&&ok(p[24]))scales.push((Math.hypot(p[11][0]-p[23][0],p[11][1]-p[23][1])+Math.hypot(p[12][0]-p[24][0],p[12][1]-p[24][1]))/2);
 }
 const scale=Math.max(.09,median(scales)||.25);
 for(let i=1;i<frames.length;i++){
   const a=frames[i-1],b=frames[i],dt=Number(b.t)-Number(a.t);
   if(!(dt>.003&&dt<=maxStep)||(a.camera_segment_id??0)!==(b.camera_segment_id??0))continue;
   const values=ids.filter(k=>ok(a.im?.[k])&&ok(b.im?.[k])).map(k=>Math.hypot(b.im[k][0]-a.im[k][0],b.im[k][1]-a.im[k][1])/dt/scale);
   if(values.length>=5)speed[i]=median(values);
 }
 const observed=speed.filter(Number.isFinite).sort((a,b)=>a-b),p75=observed[Math.floor((observed.length-1)*.75)]||.2;
 const threshold=Math.min(.30,Math.max(.035,p75*.18));
 const pauses=[];let start=-1;
 const emit=end=>{
   if(start<0)return;const t0=Number(frames[start].t),t1=Number(frames[end].t);
   if(t1-t0>=minPause){const mid=Math.floor((start+end)/2);pauses.push({start_s:t0,end_s:t1,center_s:frames[mid].t,first_index:start,last_index:end,confidence:'motion_only'});}start=-1;
 };
 for(let i=1;i<=frames.length;i++){
   const still=i<frames.length&&Number.isFinite(speed[i])&&speed[i]<=threshold;
   if(still&&start<0)start=i;
   if(!still)emit(i-1);
 }
 const boundaries=[0,...pauses.map(p=>Math.floor((p.first_index+p.last_index)/2)),frames.length-1];
 const linkages=[];
 for(let i=1;i<boundaries.length;i++){
  const a=boundaries[i-1],b=boundaries[i];if(b-a<6)continue;
  const chunk=frames.slice(a,b+1);const s=chunk.filter(f=>Number.isFinite(speed[frames.indexOf(f)])).map(f=>speed[frames.indexOf(f)]);
  linkages.push({start_s:chunk[0].t,end_s:chunk.at(-1).t,start_index:a,end_index:b,peak_speed:Math.max(0,...s),mean_speed:s.length?s.reduce((v,x)=>v+x,0)/s.length:0});
 }
 if(!linkages.length)linkages.push({start_s:frames[0].t,end_s:frames.at(-1).t,start_index:0,end_index:frames.length-1});
 return {schema:PAUSE_SCHEMA,pauses,linkages,threshold,scale,observed_speed_samples:observed.length};
}
export function linkageAtTime(result,time){return (result?.linkages||[]).find(q=>time>=q.start_s&&time<=q.end_s)||null;}
export function coherenceOfLinkage(frames,metrics=[],start,end){
 const samples=(metrics||[]).filter(m=>m&&m.t>=start&&m.t<=end).map(m=>Number(m.movement_consistency??m.movement_coherence??m.coherence_score??m.coordination_score??m.harmony_score)).filter(n=>Number.isFinite(n)&&n>=0&&n<=100);
 return samples.length?Math.round(samples.reduce((s,x)=>s+x,0)/samples.length*10)/10:null;
}
