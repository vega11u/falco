# QA Report — Falco Jugger 27.2.1-C.D2

## Причина hotfix
В 27.2.0 установщик выполнял `node --check body-reconstruction-worker.js`. Node разбирал `.js` в CommonJS-контексте, хотя файл является ES-модулем и запускается браузером через `new Worker(..., {type:'module'})`. Это вызывало `SyntaxError: Unexpected token {` на строке import во время dry-run.

## Исправления
1. Проверка module Worker выполняется через временную копию с расширением `.mjs`.
2. `pose-worker.js` проверяется тем же способом, поскольку это также module Worker.
3. Классический `falco-jugger-ui.js` проверяется как обычный скрипт.
4. ES-модули `.mjs` проходят `node --check`.
5. Установщик сначала проверяет поддержку ESM и современного синтаксиса небольшим probe-файлом. Если системный Node устарел, все Node-проверки пропускаются с явным предупреждением; обязательные PHP integrity и integration smoke checks остаются.
6. URL `body-reconstruction-worker.js` обновлён с `v=27.1.0` до `v=27.2.1`, чтобы исключить получение браузером старого Worker из кеша.
7. Release smoke и integrity тесты проверяют cache key и `type:'module'`.

## Локальная проверка
- PHP lint: installer inputs and changed PHP pages.
- Release manifest SHA-256 verification.
- PHP integration smoke.
- JavaScript syntax validation in correct parsing mode.
- Research C unit/integration tests.
- Dry-run against a copy of the Host-0 site root.

## Ограничения
Этот hotfix исправляет установочную проверку и cache-busting Worker. Он не является подтверждением метрической точности 3D-реконструкции. Для этого по-прежнему необходимы эталонные видео, независимая разметка и калибровка камеры.
