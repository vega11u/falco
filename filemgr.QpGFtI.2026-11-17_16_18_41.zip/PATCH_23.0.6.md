# Falco Jugger 23.0.6 — Purcell evidence loop

**Base:** patch 23.0.5 (which must already be installed over 23.0.4).

## What actually works

- At every manual Purcell analysis, all non-rejected Lully pattern candidates and independent numerical error findings trigger *new* evidence retrieval against the current research index (up to 80 queries per request). This is **not** a one-time static attachment.
- Each query includes type, technique label, observed cues, and relevant positive/negative notes from the user's Purcell exemplars. The existing Purcell 384-dimensional comparison and its positive/counterexample logic remain intact.
- Knowledge types are indexed separately: built-in anatomical theory, functional chains and muscle roles; research CSV columns and textual observations; OpenSim/MyoSuite anatomical XML elements; BVH joint hierarchy metadata; text/Markdown and PDF excerpts where available. Source provenance and evidence type appear under the affected recommendations and under the Lully pattern list.
- User votes on a Purcell recommendation now remember retrieved source IDs in the **private** Purcell feedback store. On the next analysis this mildly changes search ordering, without promoting a user's comment to scientific fact or rewriting scientific content.
- Feedback and examples continue to persist server-side, with the existing APIs and format. New `evidence_ids` is an additive optional feedback field.
- The index builder runs after `install-research.sh`, so newly acquired sources become searchable without a code change. It can also be run independently after manually adding files.
- The Models page reports indexed passage counts, sources, index revision, and whether an optional local language engine is configured.
- If retrieval fails or there are no sources, the independent biomechanical baseline and personally learned recommendations remain operational; a journal warning is recorded.

## Installation

1. Back up site and private `KATA_LEARNING_DIR` and report directory.
2. Upload this ZIP over **23.0.5** with file replacement. Do not delete private learning archives.
3. From the site root, run `python3 research/build_evidence_index.py`. The ZIP contains a starter index from built-in theory; rebuilding is essential after research files have been downloaded using 23.0.5.
4. Open **Models**, check *Purcell — поиск доказательств*. Try one kata and open Purcell's *Основания и ограничения* per finding and *Исследовательские материалы* under patterns.
5. After adding new research sources, run `python3 research/build_evidence_index.py` or `bash install-research.sh` again. This will not reset your examples.

## Optional local compact LLM

The retrieval/evidence loop works without an LLM. Free-form Russian phrasing is an optional additional stage, **not a replacement** for numeric biomechanics.

For an independently operated VPS or machine running the PHP application, install `llama.cpp` (upstream: https://github.com/ggml-org/llama.cpp), launch `llama-server` with an appropriate small **GGUF** instruction model, for example an officially published Qwen3 0.6B GGUF. A Q4 quantization is commonly hundreds of MB, not a tiny PHP library. Validate Russian output and factuality on your own cases. The `llama-server` API supports `/v1/chat/completions`.

Example deployment settings (for a **server running on the same host as PHP**):

```
PURCELL_LLM_URL=http://127.0.0.1:8080/v1/chat/completions
PURCELL_LLM_MODEL=your-installed-gguf-model-id
```

The endpoint deliberately accepts **only loopback** addresses and uses short connect/total timeouts. It sends only abridged findings and short retrieved texts, never source videos or full private libraries. The generated text is labelled as unverified additional wording and must be reviewed by a human. On ordinary shared hosting without a long-running llama.cpp process, **leave these settings unset**; the core evidence loop continues to work.

## Important limitations — not yet equivalent to trained biomechanics

- A downloaded OpenSim model is a structural model, not directly measured muscle activation. An article is a theoretical source, not a validated clinical result for the observed athlete. BVH metadata is not a semantically aligned kata template.
- Raw motion files are **not** automatically transformed into a compatible 384-D Purcell feature reference; explicit motion retargeting, camera coordinate alignment and validated corpus labels remain separate work.
- The index is **lexical/provenance retrieval**, not a new neural network or autonomous parameter fine-tuning. User votes re-rank retrieval and existing reference matching; they do not change weights.
- Only PDF text pages 1–30 are indexed if `pdftotext` is installed. Unreadable/scanned PDFs are skipped, never hallucinated; no OCR.
- Some prior 23.0.5 research sources are marked manual/unavailable; this patch cannot fabricate restricted datasets or missing trained models. The starter index contains just built-in theory (48 fragments on the supplied installation snapshot).
- No production/browser/GPU benchmark has been run on your specific hosting or videos.

## QA in development environment

- PHP lint: index, evidence helper, models — passed.
- Extracted browser JavaScript syntax: passed.
- Original Purcell core and baseline regression tests: passed.
- Evidence API HTTP smoke: status, stance, kick, missing LLM — passed.
- Indexer fixture: CSV and OpenSim XML ingestion with source attribution — passed.
- Syntax and package validation — passed.
