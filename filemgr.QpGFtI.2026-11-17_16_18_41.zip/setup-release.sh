#!/usr/bin/env bash
# Compatibility entry point retained for the familiar one-command installation.
# On REG.RU virtual hosting this must run the non-root shared-hosting profile.
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
exec bash "$ROOT/setup-regru.sh" "$@"
