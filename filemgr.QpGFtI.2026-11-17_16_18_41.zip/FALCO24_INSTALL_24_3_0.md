# Falco 24.3.0 installation

Upload `Falco24_3_0_Precision_Lab_Installer.zip` to the website root and run the one-line command from the site directory's parent:

```bash
cd ./www/falcojugger.art && tmp="$(mktemp -d)" && trap 'rm -rf "$tmp"' EXIT && unzip -q Falco24_3_0_Precision_Lab_Installer.zip -d "$tmp" && bash "$tmp/install-falco24.sh" --source "$tmp" --target "$PWD" --aggressive-cleanup
```

The installer backs up overwritten files outside the web root, checks PHP, runs integration/security/UI smoke tests, and rolls back on any mandatory failure. It does not target training databases, uploaded media, report archives or model stores.
