# Falco Jugger v19.4 — PHP/JavaScript release for REG.RU

## v19.4 — восстановление загрузки локальных видео и диагностика

- Исправлена фатальная повторная декларация `mb` в основном JS-модуле: ранее браузер не мог разобрать модуль, поэтому не запускались обработчик выбора файла и остальные интерфейсные обработчики.
- Совместимые с WebCodecs MP4/MOV/WebM теперь открываются из исходного файла без ненужной потери качества при перекодировании.
- Добавлен self-hosted Mediabunny 1.65.0 с проверкой npm SHA-512; `setup-media-import.sh` и `setup-assets.sh` используют единый установщик.
- Если Mediabunny отсутствует, браузер может показать исходное видео нативно, но покадровый анализ остаётся выключен до установки декодера.
- Исправлен параметр Deno 2: `--lock-write` заменён на `--frozen=false`.
- Добавлены проверки синтаксиса полного основного JS-модуля, worker-файлов, видео-пути, установщика и контрактов API.
- Обычный локальный видеофайл остаётся в браузере и не отправляется на сервер; `video_upload=false` в health — ожидаемая конфигурация.


## v19.3 — независимый JS-экстрактор YouTube

В каскад импорта добавлен отдельный `youtubei.js` 18.3.0 через Deno (без Node.js и npm CLI). После базового профиля yt-dlp приложение пробует InnerTube TV, WEB и Android. Зависимости фиксируются lock-файлом и заранее сохраняются в приватном Deno cache. PHP fallback остаётся последней независимой веткой. Это повышает число независимых путей получения публичного видео, но не устраняет блокировки серверного IP, CAPTCHA, PO Token/attestation или изменения внутреннего API YouTube.

## Release intent

This release corrects the shared-hosting regressions introduced in v18. The application logic remains PHP + JavaScript. The YouTube/Instagram URL import control is visible again, the importer is installed by the one-command REG.RU setup, and it supports either direct PHP execution or a user-CRON queue when web PHP disables `proc_open`.

## Regressions corrected

- Restored the always-visible YouTube / Instagram URL import panel in the main media-ingestion workflow.
- Removed the v18 shared-hosting setting that forced `server_social_import` to `false`.
- Restored importer installation to `bash setup-release.sh`.
- Retained YouTube watch, youtu.be, Shorts/live and Instagram post/Reel/IGTV import through the existing yt-dlp extractor paths, with the original progressive/video-only format selection, alternate player/extractor profiles, curl and optional aria2c transport retries.
- Removed the additional `gallery-dl` Python virtual environment from the shared-hosting profile. Instagram continues through yt-dlp's native extractor retries; a separate gallery-dl fallback is no longer installed.
- Removed Node.js as an importer runtime option. In v19.1 Deno handled yt-dlp's JavaScript challenge solving; v19.3 additionally uses Deno to execute the independent YouTube.js InnerTube extractor.
- Added a REG.RU user-CRON queue fallback for accounts where web PHP disables `proc_open`; the importer UI reports that CRON task is required rather than silently hiding or disabling URL import.
- Removed Python corpus setup scripts, Python requirements and Python-only deployment tests from the deployable REG.RU package. Active personal example learning remains PHP storage + JavaScript feature extraction/matching.
- Kept the v17 research manifest honest: all corpus-derived research models are not ready; the archive does not contain trained research weights. It does not claim automatic research-corpus training on shared hosting.
- Preserved the personal learning API, full archive retrieval, Q16 features, DTW matching and separation of subjective feedback from objective biomechanical measures.
- Kept the existing browser video/pose/3D analysis path from v17; the release's functional changes are limited to hosting/installation, URL import, CRON fallback, branding and release metadata.

## Current install

```bash
bash setup-release.sh
```

No `sudo`, `dnf`, `yum`, installed system Python, `pip`, Python venv, Node.js, Composer or root privileges are required. PHP CLI 8.1+, required PHP extensions, Bash, curl, OpenSSL, SHA-256 tools, outbound HTTPS and at least 2 GiB free disk are required. The supplied REG.RU environment (PHP 8.2.35, x86_64 AlmaLinux 8.10 and roughly 9.2 GB free disk) meets the PHP and disk profile based on the information supplied by the user.

## Important yt-dlp distinction

The application's own source and orchestration are PHP + JavaScript. However, the official yt-dlp standalone Linux executable is built from the upstream Python project and packages its interpreter using PyInstaller. The setup does not install or invoke a separate/system Python, `pip` or `venv`, but it would be inaccurate to claim the yt-dlp binary contains no Python runtime whatsoever. This extractor was already part of the v17 importer. The new release removes the separate `gallery-dl` Python environment added to the v18 installation path. Deno is a standalone JavaScript runtime for yt-dlp YouTube challenge solving and the independent YouTube.js InnerTube extractor.

If the requirement is that even a bundled Python-based yt-dlp executable must be removed, the robust existing social importer would need to be replaced by separate pure-JavaScript extractors for both platforms. That would be a different importer implementation and should not be silently represented as equivalent or release-validated.

## Import modes

- **direct**: yt-dlp/Deno and/or independent YouTube.js are installed, and web PHP has `proc_open`, `/bin/sh` and `nohup`.
- **cron-queue**: yt-dlp/Deno and/or independent YouTube.js are installed, but web PHP cannot spawn a process. Add the absolute path to `media-import-cron.sh` as a user CRON task in the REG.RU control panel with a one-minute interval. The app accepts the URL into a private queue; CRON dispatches one job per run. A queued task will not start until this schedule is enabled.
- **unavailable**: the download executables are absent or neither direct mode nor the CRON worker is available. The URL field remains visible and reports the reason; local browser video analysis remains independent.

## Validation boundary

Local syntax, static release, learning API, synthetic biomechanics and mocked media-import tests are run by `tests/verify.sh`. The CRON fallback test deliberately runs web PHP with `proc_open` disabled and verifies queued job dispatch through a mocked extractor. These tests do not prove a real YouTube/Instagram download, do not measure inference on the user's actual kata video and do not constitute a real installation on the user's REG.RU account. Actual PHP-FPM capabilities, CRON configuration and platform extraction must be checked on the target hosting account after installation.

## v19.3 — отдельный YouTube.js экстрактор и усиление PHP-резерва

The YouTube cascade now inserts `youtubei.js` 18.3.0 as a truly separate InnerTube implementation immediately after the initial yt-dlp attempt. It runs under Deno, is pinned in a lock file and cached privately; no Node.js or npm CLI is used. The PHP fallback now validates each redirect before making the next HTTPS request. Its upstream package has a published SSRF advisory affecting its public demo endpoint; the application never exposes that endpoint, runs the package privately from CLI, and applies its own source/media-host allowlists. Local smoke tests verify orchestration and transfer using a mocked Deno worker; a live test from the target hosting IP remains outstanding.
