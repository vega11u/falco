/** Robust observational velocity estimates for reconstructed pose tracks.
 * The world track is pelvis-centred (MediaPipe model metres), so all measured
 * 3D rates are athlete-relative, not displacement of the body across the room.
 * Relative depth is used for reconstruction confidence, NEVER as metric scale.
 */
export const VELOCITY_VERSION='falco-robust-relative-velocity-v1';
const finite=Number.isFinite;
const good=(p,d=2)=>Array.isArray(p)&&p.length>=d&&p.slice(0,d).every(finite)&&(p[3]??1)>=.5;
const median=a=>{if(!a.length)return null;const x=a.slice().sort((a,b)=>a-b),m=x.length>>1;return x.length%2?x[m]:(x[m-1]+x[m])/2;};
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const distance=(a,b,d)=>Math.hypot(...Array.from({length:d},(_,j)=>a[j]-b[j]));
const segment=f=>f?.camera_segment_id??0;
const midpoint=(a,b,d)=>good(a,d)&&good(b,d)?Array.from({length:d},(_,k)=>(a[k]+b[k])/2):null;
const idParent={15:13,16:14,27:25,28:26,29:27,30:28,31:27,32:28,23:11,24:12};
const worldTorso=f=>{const w=f?.w||[],sh=midpoint(w[11],w[12],3),hip=midpoint(w[23],w[24],3);return sh&&hip?distance(sh,hip,3):null;};
const imageHeight=f=>{const im=f?.im||[],nose=im[0],feet=[im[27],im[28],im[31],im[32]].filter(p=>good(p));if(!good(nose)||feet.length<2)return null;const x=feet.reduce((s,p)=>s+p[0],0)/feet.length,y=feet.reduce((s,p)=>s+p[1],0)/feet.length;const h=Math.hypot(nose[0]-x,nose[1]-y)*1.08;return h>.10&&h<1.6?h:null;};
const coords=(f,id,domain,pxPerM)=>{
 const points=f[domain==='world'?'w':'im']||[],p=points[id];if(!good(p,domain==='world'?3:2))return null;
 const hip=midpoint(points[23],points[24],domain==='world'?3:2);if(!hip)return null;
 const dim=domain==='world'?3:2;
 const vec=Array.from({length:dim},(_,k)=>p[k]-hip[k]);
 if(domain==='world')return vec;
 if(!(pxPerM>0))return null;
 return vec.map(v=>v/pxPerM);
};
const robustFit=(samples,dimension)=>{
 if(samples.length<3)return null;
 const slopes=[];
 for(let j=0;j<dimension;j++){
  const pair=[];for(let k=0;k<samples.length;k++)for(let l=k+1;l<samples.length;l++){
   const dt=samples[l].t-samples[k].t;if(dt>=.018)pair.push((samples[l].v[j]-samples[k].v[j])/dt);
  }
  if(pair.length<3)return null;slopes.push(median(pair));
 }
 const tmid=median(samples.map(x=>x.t)),mid=Array.from({length:dimension},(_,j)=>median(samples.map(x=>x.v[j]-slopes[j]*(x.t-tmid))));
 const residual=median(samples.map(row=>Math.hypot(...row.v.map((v,j)=>v-(mid[j]+slopes[j]*(row.t-tmid))))));
 return {speed:Math.hypot(...slopes),components:slopes,residual:residual??0};
};
/** Pre-compute per-camera-segment median anthropometric ratios once. */
function references(frames,heightCm){
 const refs=new Map();for(const f of frames){const sid=segment(f),ref=refs.get(sid)||{torso:[],height:[],bones:new Map()};
  const torso=worldTorso(f);if(torso!=null&&torso>.12&&torso<1.15)ref.torso.push(torso);
  const height=imageHeight(f);if(height!=null)ref.height.push(height);
  for(const [id,pid] of Object.entries(idParent)){
   const a=f.w?.[id],b=f.w?.[pid];if(!good(a,3)||!good(b,3))continue;
   const len=distance(a,b,3);if(len<.035||len>1.15)continue;const l=ref.bones.get(+id)||[];l.push(len);ref.bones.set(+id,l);
  }
  refs.set(sid,ref);
 }
 for(const ref of refs.values()){
  ref.torso=median(ref.torso);ref.height=median(ref.height);ref.heightMeters=(Number.isFinite(heightCm)&&heightCm>=110&&heightCm<=225?heightCm:175)/100;
  ref.bones=new Map([...ref.bones].map(([k,v])=>[k,median(v)]));
 }
 return refs;
}
/** Returns one object per video frame. Unsafe spikes are missing estimates, not capped values. */
export function measureRelativeSpeeds(frames,{heightCm=175}={}){
 if(!Array.isArray(frames)||!frames.length)return [];
 const refs=references(frames,heightCm),ids=[15,16,27,28,29,30,31,32];
 const bounds={15:16,16:16,27:18,28:18,29:18,30:18,31:19,32:19};
 const out=frames.map(f=>({t:f.t,values:{},quality:{},source:{},reasons:{}}));
 for(let i=0;i<frames.length;i++){
  const f=frames[i],sid=segment(f),ref=refs.get(sid),scale=ref?.heightMeters&&ref.height?ref.height/ref.heightMeters:null;
  for(const id of ids){let picked=null,reason='insufficient_continuous_observations';
   for(const domain of ['world','image']){
    if(domain==='world'&&(!ref?.torso||ref.torso<.18))continue;
    if(domain==='image'&&(!scale||!ref.height||ref.height<.12))continue;
    const rows=[];for(let k=Math.max(0,i-4);k<=Math.min(frames.length-1,i+4);k++){
     const row=frames[k],dt=Math.abs(row.t-f.t);if(segment(row)!==sid||!finite(row.t)||dt>.12)continue;
     if(domain==='world'){
      const l=ref.bones.get(id),a=row.w?.[id],b=row.w?.[idParent[id]];
      if(l!=null&&good(a,3)&&good(b,3)){const m=distance(a,b,3);if(m/l<.68||m/l>1.37)continue;}
      const torso=worldTorso(row);if(torso!=null&&Math.abs(torso/ref.torso)>.001&&(torso/ref.torso<.65||torso/ref.torso>1.4))continue;
     }else{
      const local=imageHeight(row);if(!local||Math.abs(local/ref.height-1)>.30)continue;
     }
     const v=coords(row,id,domain,scale);if(v)rows.push({t:row.t,v,confidence:Math.min(row[domain==='world'?'w':'im']?.[id]?.[3]??1,row[domain==='world'?'w':'im']?.[23]?.[3]??1,row[domain==='world'?'w':'im']?.[24]?.[3]??1)});
    }
    if(rows.length<3)continue;
    const span=rows.at(-1).t-rows[0].t;if(span<.052||span>.26)continue;
    const fit=robustFit(rows,domain==='world'?3:2);if(!fit)continue;
    const depthValues=f.depth_agreement_values;
    const depth=Array.isArray(depthValues)&&finite(depthValues[id])?clamp(depthValues[id]):null;
    const sampleReliability=median(rows.map(r=>r.confidence))??0;
    const confidence=clamp(sampleReliability*(domain==='world'?1:.70)*Math.exp(-fit.residual/.08)*(depth!=null?(.8+.2*depth):1));
    if(fit.speed>bounds[id]){reason=`velocity_outlier_${domain}_${fit.speed.toFixed(1)}_mps`;continue;}
    if(confidence<.42){reason='low_confidence_'+domain;continue;}
    picked={value:Number(fit.speed.toFixed(4)),source:domain==='world'?'pose_world_relative_m_s':'image_height_scaled_relative_m_s_proxy',confidence:Number(confidence.toFixed(3)),samples:rows.length,residual:Number(fit.residual.toFixed(4)),depth_agreement:depth};break;
   }
   if(picked){out[i].values[id]=picked.value;out[i].quality[id]=picked.confidence;out[i].source[id]=picked.source;out[i].reasons[id]=null;}
   else {out[i].values[id]=null;out[i].quality[id]=0;out[i].source[id]='unavailable';out[i].reasons[id]=reason;}
  }
 }
 return out;
}
export function summarizeVelocityQuality(measurements){const rows=[];let rejected=0,world=0,image=0,missing=0;for(const row of measurements||[])for(const id of [15,16,27,28,31,32]){if(finite(row.values[id])){rows.push(row.values[id]);if(row.source[id].startsWith('pose_world'))world++;else image++;}else{missing++;if(row.reasons[id]?.startsWith('velocity_outlier'))rejected++;}}
 return {schema:VELOCITY_VERSION,usable:rows.length,world_samples:world,image_proxy_samples:image,unavailable:missing,rejected_spikes:rejected,peak_estimate_m_s:rows.length?Math.max(...rows):null,method:'3D pelvis-relative Theil-Sen world-landmark rates or height-scaled image proxy with local anthropometric gates; robust outlier rejection without numerical clamping',limit:'Not calibrated athlete travel speed / impact speed; height and model scale uncertainty remain.'};
}
