# Falco 24.3.0 — Precision Lab Interface

## Visual system
- New 60/30/10 color roles: 60% graphite-blue canvas, 30% ocean-teal surfaces, 10% mint-cyan action accent.
- Times New Roman for interface copy; Consolas for technical values, timecodes and compact status.
- Single active interface stylesheet for analyzer, Lully, Purcell, reports and model pages.
- No duplicate sidebar brand; brand and author mark live once in the top bar.
- Old Aero/Vista progressive UI scripts are no longer loaded by the analyzer.

## Workspace architecture
- Existing source, analysis, timeline, result and player nodes are physically reparented, not cloned.
- Desktop: one analysis stream and one sticky player column.
- Mobile: upload first, player second, analysis stream after; normal document flow.
- No independent vertical scrolling in the sidebar, player or result stream.
- Nine original anchor destinations remain in the sidebar.

## Player and trimming
- Primary transport controls are grouped: previous frame, play/pause, next frame, playback speed.
- Continue/restart, 3D, captures and zoom live in a single collapsed tools section.
- Seek bar and timecode form one timeline row.
- Original clip workspace and original range editor live together in the player trim fold.
- Current-frame metrics are in a separate fold.
- Existing control IDs and core event handlers are preserved; no second video or decoder is created.

## Compatibility
- No analysis algorithm, worker, API route, storage schema, training record or uploaded media format is changed.
- Lully and Purcell remain standalone library pages; no iframe embedding.
- Models and reports use the same interface stylesheet.

## QA limitations
- PHP/JS syntax and integration tests are executed in the release build.
- Automated browser screenshot acceptance is not claimed unless a real browser render is available.
