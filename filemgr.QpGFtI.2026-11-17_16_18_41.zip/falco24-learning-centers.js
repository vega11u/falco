
(() => {
 'use strict';
 const $ = id => document.getElementById(id);
 const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const fmtDate = value => { if(!value) return 'Дата не указана'; const d=new Date(value); return Number.isNaN(d.getTime())?String(value):d.toLocaleString('ru-RU',{dateStyle:'medium',timeStyle:'short'}); };
 const api = async name => { const r=await fetch(`index.php?api=${encodeURIComponent(name)}`,{credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'}}); const d=await r.json(); if(!r.ok||d.ok===false) throw new Error(d.error||`HTTP ${r.status}`); return d; };
 const styleName = v => ({shotokan:'Сётокан',shitoryu:'Сито-рю',gojuryu:'Годзю-рю',ryueiryu:'Рюэй-рю',unspecified:'Стиль не указан'})[v]||'Стиль не указан';
 const kindName = v => ({stance:'Стойка',hand_strike:'Удар рукой',kick:'Удар ногой',block:'Блок',movement:'Переход / движение',biomechanics:'Биомеханика'})[v]||v||'Движение';
 const ratingName = n => Number(n)>=4?'Эталон':Number(n)<=2?'Антипример':'Нейтральный пример';
 let lullyRows=[],purcellRows=[];
 function lullyCard(x,i){
   const label=x.label||'Без названия', style=styleName(x.style), group=x.kind||x.category||'Паттерн';
   const featureCount=Number(x.feature_count||0), stamp=x.updated_at||x.created_at||x.timestamp||'';
   return `<article class="replay-card"><div class="replay-body"><h3>${esc(label)}</h3><div class="replay-meta">${esc(style)} · ${esc(kindName(group))}</div><div class="tag-row"><span class="tag good">Подтверждён</span><span class="tag">${featureCount?featureCount+' признаков':'Числовые признаки'}</span></div><div class="replay-meta">${esc(fmtDate(stamp))}</div><div class="card-actions"><a class="primary" href="index.php#patternsSection">Разбор паттернов</a><a href="models.php">Модель</a></div></div></article>`;
 }
 function purcellCard(x,i){
   const label=x.label||'Биомеханический пример', rating=Number(x.rating||3), style=styleName(x.style), stamp=x.created_at||x.updated_at||x.timestamp||'';
   const good=Array.isArray(x.good_parts)?x.good_parts:Array.isArray(x.positive_parts)?x.positive_parts:[];
   const bad=Array.isArray(x.problem_parts)?x.problem_parts:Array.isArray(x.negative_parts)?x.negative_parts:[];
   return `<article class="replay-card"><div class="replay-body"><h3>${esc(label)}</h3><div class="replay-meta">${esc(style)} · ${esc(kindName(x.kind))}</div><div class="tag-row"><span class="tag ${rating>=4?'good':rating<=2?'warn':''}">${esc(ratingName(rating))} · ${rating}/5</span>${good.slice(0,2).map(v=>`<span class="tag good">${esc(v)}</span>`).join('')}${bad.slice(0,2).map(v=>`<span class="tag warn">${esc(v)}</span>`).join('')}</div>${x.notes?`<p class="replay-meta">${esc(x.notes).slice(0,240)}</p>`:''}<div class="replay-meta">${esc(fmtDate(stamp))}</div><div class="card-actions"><a class="primary" href="index.php#purcellWeaknessSection">К анализу Purcell</a><a href="index.php#purcellEvolutionSection">Эволюция</a></div></div></article>`;
 }
 function renderLully(){
   const q=($('searchLully')?.value||'').toLowerCase(), style=$('filterStyle')?.value||'', sort=$('sortLully')?.value||'recent';
   let rows=lullyRows.filter(x=>(!style||x.style===style)&&(`${x.label||''} ${x.kind||''} ${x.style||''}`).toLowerCase().includes(q));
   if(sort==='label')rows.sort((a,b)=>(a.label||'').localeCompare(b.label||'','ru'));
   else rows.sort((a,b)=>String(b.updated_at||b.created_at||'').localeCompare(String(a.updated_at||a.created_at||'')));
   $('lullyCards').innerHTML=rows.length?rows.map(lullyCard).join(''):'<div class="empty" style="grid-column:1/-1">Подтверждённых примеров по этому фильтру нет. Новые replay-кандидаты появятся после анализа видео и поиска паттернов.</div>';
 }
 function renderPurcell(){
   const q=($('searchPurcell')?.value||'').toLowerCase(), rating=$('filterRating')?.value||'', sort=$('sortPurcell')?.value||'recent';
   let rows=purcellRows.filter(x=>{const r=Number(x.rating||3),match=rating===''||(rating==='good'&&r>=4)||(rating==='neutral'&&r===3)||(rating==='bad'&&r<=2);return match&&(`${x.label||''} ${x.notes||''} ${x.kind||''}`).toLowerCase().includes(q);});
   if(sort==='rating')rows.sort((a,b)=>Number(b.rating||3)-Number(a.rating||3));
   else rows.sort((a,b)=>String(b.created_at||'').localeCompare(String(a.created_at||'')));
   $('purcellCards').innerHTML=rows.length?rows.map(purcellCard).join(''):'<div class="empty" style="grid-column:1/-1">Примеров с такими параметрами нет. Добавьте видео через потоковую мастерскую Purcell.</div>';
 }
 async function loadLully(){
   $('lullyStatus').textContent='Загрузка…';
   const [lib,model]=await Promise.all([api('library'),api('model-status').catch(()=>({}))]);
   lullyRows=Array.isArray(lib.examples)?lib.examples:[];
   $('totalExamples').textContent=lib.total_examples??lullyRows.length;
   $('labelCount').textContent=lib.labelled_examples??lullyRows.length;
   $('feedbackCount').textContent=lib.feedback_count??(lib.feedback?.length||0);
   $('modelExamples').textContent=model.training_examples??model.examples??'—';
   $('lullyStatus').textContent='Библиотека синхронизирована';$('lullyStatus').classList.add('ready');renderLully();
 }
 async function loadPurcell(){
   $('purcellStatus').textContent='Загрузка…';
   const [status,lib]=await Promise.all([api('purcell-status'),api('purcell-library')]);
   purcellRows=Array.isArray(lib.examples)?lib.examples:[];
   $('purcellTotal').textContent=status.examples??purcellRows.length;
   $('purcellPositive').textContent=status.positive_examples??purcellRows.filter(x=>Number(x.rating)>=4).length;
   $('purcellNegative').textContent=status.counterexamples??purcellRows.filter(x=>Number(x.rating)<=2).length;
   $('purcellFeedback').textContent=status.feedback??(lib.feedback?.length||0);
   $('purcellUpdated').textContent=status.updated_at?`Обновлено ${fmtDate(status.updated_at)}`:'Дата обновления неизвестна';
   const total=Math.max(0,Number(status.examples??purcellRows.length)||0);
   const positive=Math.max(0,Number(status.positive_examples??purcellRows.filter(x=>Number(x.rating)>=4).length)||0);
   const negative=Math.max(0,Number(status.counterexamples??purcellRows.filter(x=>Number(x.rating)<=2).length)||0);
   const neutral=Math.max(0,total-positive-negative);
   const share=value=>total?`${(value/total*100).toFixed(2)}%`:'0%';
   $('purcellPositiveBar').style.width=share(positive);
   $('purcellNeutralBar').style.width=share(neutral);
   $('purcellNegativeBar').style.width=share(negative);
   $('purcellPositiveLabel').textContent=String(positive);
   $('purcellNeutralLabel').textContent=String(neutral);
   $('purcellNegativeLabel').textContent=String(negative);
   $('purcellLibraryNote').textContent=`Всего ${total} записей. Показано фактическое распределение оценок; это не процент эволюции.`;
   $('purcellStatus').textContent='Библиотека синхронизирована';$('purcellStatus').classList.add('ready');renderPurcell();
 }


 const center=document.body.dataset.center;
 if(center==='lully'){
   ['searchLully','filterStyle','sortLully'].forEach(id=>$(id)?.addEventListener('input',renderLully));
   $('refreshLully')?.addEventListener('click',()=>loadLully().catch(e=>{$('lullyStatus').textContent=e.message;}));
   loadLully().catch(e=>{$('lullyStatus').textContent='Ошибка API';$('lullyCards').innerHTML=`<div class="empty" style="grid-column:1/-1">${esc(e.message)}. Проверьте доступность index.php и серверной библиотеки.</div>`;});
 }else if(center==='purcell'){
   ['searchPurcell','filterRating','sortPurcell'].forEach(id=>$(id)?.addEventListener('input',renderPurcell));
   $('refreshPurcell')?.addEventListener('click',()=>loadPurcell().catch(e=>{$('purcellStatus').textContent=e.message;}));
   loadPurcell().catch(e=>{$('purcellStatus').textContent='Ошибка API';$('purcellCards').innerHTML=`<div class="empty" style="grid-column:1/-1">${esc(e.message)}. Проверьте доступность index.php и базы Purcell.</div>`;});
 }
})();
