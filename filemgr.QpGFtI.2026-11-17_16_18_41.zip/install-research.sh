#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if ! command -v php >/dev/null 2>&1; then
  echo 'PHP CLI is required; Python is not used.' >&2
  exit 1
fi
php "$ROOT/research/install_sources.php" "$@"
php "$ROOT/research/build_evidence_index.php"
echo 'PHP-only download and evidence index complete. Source files are not trained Lully/Purcell models.'
