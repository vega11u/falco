<?php
declare(strict_types=1);

if (!defined('FALCO_JUGGER_BOOTSTRAPPED')) { http_response_code(404); exit; }

/** A present but unreadable store is never equivalent to a new, empty store. */
class FjStorageException extends RuntimeException {}

function fj_storage_read_json(string $path, array $requiredArrays = [], array $optionalArrays = []): ?array {
    if (!file_exists($path) && !is_link($path)) return null;
    $raw = @file_get_contents($path);
    $data = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_string($raw) || json_last_error() !== JSON_ERROR_NONE || !is_array($data) || substr(ltrim($raw), 0, 1) !== '{') {
        throw new FjStorageException('Файл ' . basename($path) . ' не читается или повреждён. Существующие данные сохранены без перезаписи; восстановите файл из резервной копии.');
    }
    foreach ($requiredArrays as $key) {
        if (!isset($data[$key]) || !is_array($data[$key])) throw new FjStorageException('Неподдерживаемая структура ' . basename($path) . ': ' . $key . '. Файл оставлен без изменений.');
    }
    foreach ($optionalArrays as $key) {
        if (array_key_exists($key, $data) && !is_array($data[$key])) throw new FjStorageException('Повреждён раздел ' . $key . ' в ' . basename($path) . '. Файл оставлен без изменений.');
    }
    // Invalid rows must not disappear during a subsequent array_filter + save.
    foreach (array_merge($requiredArrays, $optionalArrays) as $key) {
        if (!in_array($key, ['examples', 'feedback'], true)) continue;
        foreach ($data[$key] ?? [] as $row) if (!is_array($row)) throw new FjStorageException('Повреждена запись в ' . basename($path) . '. Файл оставлен без изменений.');
    }
    return $data;
}

function fj_model_read_file(string $path): array {
    $model = fj_storage_read_json($path, ['classes']);
    if ($model === null) return fj_model_empty();
    if (($model['schema'] ?? '') !== 'falco-server-classifier-v1' || !is_array($model['seen'] ?? null)
        || !is_numeric($model['training_examples'] ?? null) || (int)$model['training_examples'] < 0) {
        throw new FjStorageException('Существующая модель Lully имеет неподдерживаемую структуру. Автоматическая перезапись запрещена.');
    }
    return $model;
}

/**
 * Falco Jugger server-side supervised prototype learner.
 * This is a real statistical model trained only from user-confirmed, numeric motion windows.
 * Per-class means and variances are updated with Welford online statistics.
 * It is intentionally not described as a pretrained deep neural network or as calibrated probability.
 */

function fj_model_empty(): array {
    return ['schema' => 'falco-server-classifier-v1', 'model_version' => 1, 'updated_at' => null,
        'training_examples' => 0, 'classes' => [], 'seen' => []];
}

function fj_model_decode_features(array $row): ?array {
    if (is_array($row['features'] ?? null)) {
        $values = $row['features'];
    } else {
        $packed = $row['features_q16'] ?? null;
        if (!is_string($packed) || $packed === '') return null;
        $raw = base64_decode($packed, true);
        if (!is_string($raw) || strlen($raw) % 2 !== 0) return null;
        $unpacked = unpack('v*', $raw);
        if (!is_array($unpacked)) return null;
        $values = array_map(static fn($q): float => ((float)$q / 65535.0) * 16.0 - 8.0, array_values($unpacked));
    }
    if (!in_array(count($values), [384, 1152], true)) return null;
    $out = [];
    foreach ($values as $v) {
        if (!is_numeric($v) || !is_finite((float)$v) || abs((float)$v) > 8.0001) return null;
        $out[] = (float)$v;
    }
    return $out;
}

function fj_model_class_key(array $row): string {
    $role = (string)($row['training_role'] ?? 'positive');
    $parts = [
        (string)($row['style'] ?? 'unspecified'), (string)($row['kind'] ?? 'movement'),
        (string)($row['unit_type'] ?? 'sequence'), (string)($row['label'] ?? ''),
        (string)($row['feature_version'] ?? 'pose-window-v4-dtw-angle'), (string)($row['feature_count'] ?? (is_array($row['features'] ?? null) ? count($row['features']) : 0))
    ];
    // Preserve legacy positive-class hashes; only the new explicit negative class
    // gets a role suffix so old trained models remain compatible.
    if ($role === 'negative') $parts[] = 'negative';
    return hash('sha256', implode("\x1f", $parts));
}

function fj_model_observation_key(array $row): string {
    $reviewKey = (string)($row['review_observation_key'] ?? '');
    if (preg_match('/^[a-f0-9]{64}$/', $reviewKey)) {
        return hash('sha256', "review\x1f" . $reviewKey);
    }
    return hash('sha256', implode("\x1f", [
        (string)($row['source_session'] ?? ''), (string)($row['kind'] ?? ''),
        (string)($row['style'] ?? 'unspecified'), (string)($row['unit_type'] ?? 'sequence'),
        (string)($row['feature_version'] ?? ''), (string)($row['start_s'] ?? ''),
        (string)($row['end_s'] ?? ''), (string)($row['unit_name'] ?? $row['kata_name'] ?? '')
    ]));
}

function fj_model_accumulate(array &$model, array $row): bool {
    $trainingRole = (string)($row['training_role'] ?? 'positive');
    if (!in_array($trainingRole, ['positive', 'negative'], true)) $trainingRole = 'positive';
    $label = $trainingRole === 'negative' ? '__not_a_pattern__' : trim((string)($row['label'] ?? ''));
    if (empty($row['confirmed']) || $label === '') return false;
    $row['label'] = $label;
    $row['training_role'] = $trainingRole;
    $kind = (string)($row['kind'] ?? '');
    if (!in_array($kind, ['stance', 'hand_strike', 'kick', 'block', 'movement', 'kata', 'sequence'], true)) return false;
    $style = (string)($row['style'] ?? 'unspecified');
    if (!in_array($style, ['unspecified', 'shotokan', 'shitoryu', 'gojuryu', 'ryueiryu'], true)) return false;
    $unitType = (string)($row['unit_type'] ?? 'sequence');
    if (!in_array($unitType, ['kata', 'sequence'], true)) return false;
    $features = fj_model_decode_features($row);
    if ($features === null) return false;
    $expectedDimensions = in_array($kind, ['kata', 'sequence'], true) ? 1152 : 384;
    if (count($features) !== $expectedDimensions) return false;
    $observationKey = fj_model_observation_key($row);
    $classKey = fj_model_class_key($row);
    $featureHash = hash('sha256', json_encode($features, JSON_PRESERVE_ZERO_FRACTION));
    if (isset($model['seen'][$observationKey])) {
        $prior = $model['seen'][$observationKey];
        $priorClass = is_array($prior) ? (string)($prior['class'] ?? '') : (string)$prior;
        $priorFeatureHash = is_array($prior) ? (string)($prior['feature_hash'] ?? '') : '';
        if ($priorClass !== $classKey || $priorFeatureHash === '' || !hash_equals($priorFeatureHash, $featureHash)) $model['_rebuild_required'] = true;
        return false;
    }
    if (!isset($model['classes'][$classKey])) {
        $model['classes'][$classKey] = [
            'key' => $classKey, 'label' => (string)$row['label'], 'training_role' => $trainingRole, 'kind' => $kind,
            'style' => $style, 'unit_type' => $unitType,
            'feature_version' => (string)($row['feature_version'] ?? 'pose-window-v4-dtw-angle'), 'feature_count' => $expectedDimensions,
            'count' => 0, 'sessions' => [], 'mean' => array_fill(0, $expectedDimensions, 0.0), 'm2' => array_fill(0, $expectedDimensions, 0.0)
        ];
    }
    $class =& $model['classes'][$classKey];
    if (!isset($class['training_role'])) $class['training_role'] = $trainingRole;
    $class['count']++;
    $n = $class['count'];
    for ($i = 0; $i < $expectedDimensions; $i++) {
        $delta = $features[$i] - $class['mean'][$i];
        $class['mean'][$i] += $delta / $n;
        $delta2 = $features[$i] - $class['mean'][$i];
        $class['m2'][$i] += $delta * $delta2;
    }
    $session = (string)($row['source_session'] ?? '');
    if ($session !== '') $class['sessions'][$session] = true;
    $model['seen'][$observationKey] = ['class' => $classKey, 'feature_hash' => $featureHash];
    $model['training_examples']++;
    unset($class);
    return true;
}

function fj_model_write(string $dir, array $model): void {
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) throw new RuntimeException('Не удалось создать каталог модели классификации.');
    unset($model['_rebuild_required']);
    $model['updated_at'] = gmdate('c');
    $model['model_hash'] = hash('sha256', json_encode([$model['training_examples'], $model['source_library_hash'] ?? null, array_map(static fn($c) => [$c['key'], $c['count'], count($c['sessions'])], array_values($model['classes']))], JSON_UNESCAPED_SLASHES));
    $json = json_encode($model, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    if (!is_string($json)) throw new RuntimeException('Не удалось сериализовать модель классификации.');
    $path = $dir . DIRECTORY_SEPARATOR . 'classifier-model.json';
    $tmp = $path . '.tmp.' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $json, LOCK_EX) === false || !@rename($tmp, $path)) { @unlink($tmp); throw new RuntimeException('Не удалось атомарно сохранить модель классификации.'); }
    @chmod($path, 0640);
}

function fj_model_read(string $dir): array {
    $path = $dir . DIRECTORY_SEPARATOR . 'classifier-model.json';
    if (!is_file($path)) return fj_model_empty();
    $lock = @fopen($dir . DIRECTORY_SEPARATOR . 'classifier-model.lock', 'c+');
    if (!$lock) throw new FjStorageException('Не удалось открыть блокировку существующей модели Lully.');
    try {
        if (!flock($lock, LOCK_SH)) throw new FjStorageException('Не удалось прочитать существующую модель Lully под блокировкой.');
        $data = fj_model_read_file($path);
        flock($lock, LOCK_UN);
    } finally { fclose($lock); }
    return $data;
}

function fj_model_update(string $dir, array $newRows, ?array $fullLibrary = null): array {
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) throw new RuntimeException('Не удалось создать каталог модели.');
    $lock = @fopen($dir . DIRECTORY_SEPARATOR . 'classifier-model.lock', 'c+');
    if (!$lock) throw new RuntimeException('Не удалось открыть блокировку модели.');
    $rebuild = false;
    try {
        if (!flock($lock, LOCK_EX)) throw new RuntimeException('Не удалось заблокировать модель.');
        $path = $dir . DIRECTORY_SEPARATOR . 'classifier-model.json';
        $model = fj_model_read_file($path);
        foreach ($newRows as $row) if (is_array($row)) fj_model_accumulate($model, $row);
        $rebuild = !empty($model['_rebuild_required']);
        if (!$rebuild) fj_model_write($dir, $model);
        flock($lock, LOCK_UN);
    } finally { fclose($lock); }
    if ($rebuild && is_array($fullLibrary)) return fj_model_rebuild($dir, $fullLibrary);
    $saved = fj_model_read($dir);
    return ['training_examples' => (int)($saved['training_examples'] ?? 0), 'classes' => count($saved['classes'] ?? []), 'rebuilt' => false, 'rebuild_required' => $rebuild, 'model_hash' => $saved['model_hash'] ?? null];
}

function fj_model_rebuild(string $dir, array $rows): array {
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) throw new RuntimeException('Не удалось создать каталог модели для перестроения.');
    $lock = @fopen($dir . DIRECTORY_SEPARATOR . 'classifier-model.lock', 'c+');
    if (!$lock) throw new RuntimeException('Не удалось открыть блокировку модели для перестроения.');
    try {
        if (!flock($lock, LOCK_EX)) throw new RuntimeException('Не удалось заблокировать модель для перестроения.');
        $prior = fj_model_read_file($dir . DIRECTORY_SEPARATOR . 'classifier-model.json');
        $model = fj_model_empty();
        foreach ($rows as $row) if (is_array($row)) fj_model_accumulate($model, $row);
        if ((int)$prior['training_examples'] > 0 && (int)$model['training_examples'] === 0) {
            throw new FjStorageException('Нет пригодных примеров для перестроения. Существующая обученная модель сохранена без изменений.');
        }
        fj_model_write($dir, $model);
        flock($lock, LOCK_UN);
    } finally { fclose($lock); }
    $saved = fj_model_read($dir);
    return ['training_examples' => (int)($saved['training_examples'] ?? 0), 'classes' => count($saved['classes'] ?? []), 'rebuilt' => true, 'model_hash' => $saved['model_hash'] ?? null];
}

function fj_model_training_rows(array $rows): array {
    $training = [];
    foreach ($rows as $row) {
        if (!is_array($row) || empty($row['confirmed'])) continue;
        $count = (int)($row['feature_count'] ?? count($row['features'] ?? []));
        if (!in_array($count, [384, 1152], true)) continue;
        $decoded = fj_model_decode_features($row);
        if (!is_array($decoded) || count($decoded) !== $count) continue;
        $featuresQ16 = is_string($row['features_q16'] ?? null) ? $row['features_q16'] : null;
        $features = $featuresQ16 === null ? $decoded : null;
        $trainingRow = [
            'kind' => (string)($row['kind'] ?? 'movement'),
            'label' => trim((string)($row['label'] ?? '')),
            'style' => (string)($row['style'] ?? 'unspecified'),
            'unit_type' => (string)($row['unit_type'] ?? 'kata'),
            'feature_version' => (string)($row['feature_version'] ?? 'legacy'),
            'feature_count' => $count,
            'features_q16' => $featuresQ16,
            'features' => $featuresQ16 === null ? $features : null
        ];
        // Keep the pre-v2 hash byte-for-byte stable for legacy positive rows.
        // Only explicit human-review metadata participates in the new hash.
        if (($row['training_role'] ?? 'positive') !== 'positive') $trainingRow['training_role'] = (string)$row['training_role'];
        if (isset($row['review_decision']) && $row['review_decision'] !== '') $trainingRow['review_decision'] = (string)$row['review_decision'];
        if (isset($row['review_observation_key']) && preg_match('/^[a-f0-9]{64}$/', (string)$row['review_observation_key'])) $trainingRow['review_observation_key'] = (string)$row['review_observation_key'];
        $training[] = $trainingRow;
    }
    return $training;
}

function fj_model_source_library_hash_from_rows(array $rows): string {
    $payload = json_encode(fj_model_training_rows($rows), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    if (!is_string($payload)) throw new RuntimeException('Не удалось вычислить хеш обучающих примеров Lully.');
    return hash('sha256', $payload);
}

function fj_model_set_source_library_hash(string $dir, ?string $sourceHash = null): array {
    $libraryPath = $dir . DIRECTORY_SEPARATOR . 'library.json';
    if ($sourceHash === null) {
        $libraryData = fj_storage_read_json($libraryPath, ['examples'], ['feedback']);
        if ($libraryData === null) throw new FjStorageException('Личная библиотека Lully не найдена. Модель оставлена без изменений.');
        $rows = is_array($libraryData['examples'] ?? null) ? array_values($libraryData['examples']) : [];
        $sourceHash = fj_model_source_library_hash_from_rows($rows);
    }
    if (!is_string($sourceHash) || !preg_match('/^[a-f0-9]{64}$/', $sourceHash)) {
        throw new RuntimeException('Не удалось вычислить контрольную сумму личной библиотеки Lully.');
    }
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) throw new RuntimeException('Не удалось создать каталог модели.');
    $lock = @fopen($dir . DIRECTORY_SEPARATOR . 'classifier-model.lock', 'c+');
    if (!$lock) throw new RuntimeException('Не удалось открыть блокировку модели для обновления контрольной суммы.');
    try {
        if (!flock($lock, LOCK_EX)) throw new RuntimeException('Не удалось заблокировать модель для обновления контрольной суммы.');
        $path = $dir . DIRECTORY_SEPARATOR . 'classifier-model.json';
        $model = fj_model_read_file($path);
        $model['source_library_hash'] = $sourceHash;
        fj_model_write($dir, $model);
        flock($lock, LOCK_UN);
    } finally { fclose($lock); }
    return fj_model_status($dir);
}

function fj_model_rebuild_from_library(string $modelDir, string $libraryDir): array {
    // Lock order is always library -> classifier. Writers commit the library first and
    // then acquire the classifier lock, so a rebuild cannot overwrite a concurrent update.
    $libraryLock = @fopen($libraryDir . DIRECTORY_SEPARATOR . 'library.lock', 'c+');
    if (!$libraryLock) throw new RuntimeException('Не удалось заблокировать личную библиотеку для перестроения модели.');
    try {
        if (!flock($libraryLock, LOCK_SH)) throw new RuntimeException('Не удалось получить read-lock личной библиотеки.');
        $data = fj_storage_read_json($libraryDir . DIRECTORY_SEPARATOR . 'library.json', ['examples'], ['feedback']);
        if ($data === null) throw new FjStorageException('Личная библиотека Lully не найдена. Перестроение модели отменено.');
        $rows = $data['examples'];
        $result = fj_model_rebuild($modelDir, $rows);
        $libraryHash = fj_model_source_library_hash_from_rows($rows);
        $status = fj_model_set_source_library_hash($modelDir, $libraryHash);
        $result['model_hash'] = $status['model_hash'] ?? ($result['model_hash'] ?? null);
        $result['source_library_hash'] = $libraryHash;
        flock($libraryLock, LOCK_UN);
        return $result;
    } finally { fclose($libraryLock); }
}

function fj_model_status(string $dir): array {
    $model = fj_model_read($dir);
    $classes = [];
    $sessions = [];
    foreach (($model['classes'] ?? []) as $class) {
        $sessionCount = count($class['sessions'] ?? []);
        $sessions[$class['style'] . ':' . $class['kind'] . ':' . $class['label']] = $sessionCount;
        $role = (string)($class['training_role'] ?? 'positive');
        $classes[] = ['label' => $role === 'negative' ? 'Не паттерн' : $class['label'], 'raw_label' => $class['label'], 'training_role' => $role, 'kind' => $class['kind'], 'style' => $class['style'], 'unit_type' => $class['unit_type'], 'feature_version' => $class['feature_version'], 'feature_count' => (int)($class['feature_count'] ?? 384), 'observations' => (int)$class['count'], 'independent_sessions' => $sessionCount, 'support' => $sessionCount >= 3 ? 'supported' : ($sessionCount >= 2 ? 'limited' : 'preliminary')];
    }
    usort($classes, static fn($a, $b) => ($b['independent_sessions'] <=> $a['independent_sessions']) ?: ($b['observations'] <=> $a['observations']));
    return ['ok' => true, 'schema' => $model['schema'], 'model_version' => $model['model_version'], 'updated_at' => $model['updated_at'], 'training_examples' => (int)$model['training_examples'], 'class_count' => count($classes), 'classes' => $classes, 'model_hash' => $model['model_hash'] ?? null, 'source_library_hash' => $model['source_library_hash'] ?? null,
        'training_method' => 'incremental supervised class prototypes with per-feature Welford mean/variance; confirmed examples only',
        'interpretation' => 'Similarity ranking, not calibrated probability. Three independent sessions are required for supported status.',
        'pretrained_pose_runtime' => 'MediaPipe Pose Landmarker Full/Lite and Hand Landmarker are separate pretrained perception models; they are not karate classifiers.'];
}

function fj_model_predict_one(array $model, array $item): array {
    $features = fj_model_decode_features(['features' => $item['features'] ?? null]);
    if ($features === null) return ['id' => (string)($item['id'] ?? ''), 'matches' => [], 'status' => 'invalid_features'];
    $kind = (string)($item['kind'] ?? '');
    $style = (string)($item['style'] ?? 'unspecified');
    $unitType = (string)($item['unit_type'] ?? 'sequence');
    $featureVersion = (string)($item['feature_version'] ?? 'pose-window-v4-dtw-angle');
    $dimensions = count($features);
    $candidates = [];
    foreach (($model['classes'] ?? []) as $class) {
        if (($class['kind'] ?? '') !== $kind || ($class['unit_type'] ?? '') !== $unitType || ($class['feature_version'] ?? '') !== $featureVersion || (int)($class['feature_count'] ?? 384) !== $dimensions) continue;
        if ($style !== 'unspecified' && !in_array(($class['style'] ?? ''), [$style, 'unspecified'], true)) continue;
        if ($style === 'unspecified' && ($class['style'] ?? '') !== 'unspecified') continue;
        $n = max(1, (int)($class['count'] ?? 1));
        $sum = 0.0; $used = 0;
        for ($i = 0; $i < $dimensions; $i++) {
            $mean = (float)($class['mean'][$i] ?? 0.0);
            $variance = $n > 1 ? (float)($class['m2'][$i] ?? 0.0) / ($n - 1) : 1.0;
            $scale = sqrt(max(0.04, $variance) + 0.04);
            $z = ($features[$i] - $mean) / $scale;
            $sum += min(100.0, $z * $z); $used++;
        }
        $distance = $used ? sqrt($sum / $used) : INF;
        $sessionCount = count($class['sessions'] ?? []);
        $similarity = 100.0 * exp(-0.5 * $distance);
        $role = (string)($class['training_role'] ?? 'positive');
        $candidates[] = ['label' => $role === 'negative' ? 'Не паттерн' : (string)$class['label'], 'raw_label' => (string)$class['label'], 'training_role' => $role, 'kind' => $kind, 'style' => (string)$class['style'], 'observations' => $n,
            'independent_sessions' => $sessionCount, 'distance' => round($distance, 4), 'similarity_index' => round($similarity, 1),
            'support' => $sessionCount >= 3 ? 'supported' : ($sessionCount >= 2 ? 'limited' : 'preliminary')];
    }
    usort($candidates, static fn($a, $b) => $a['distance'] <=> $b['distance']);
    return ['id' => (string)($item['id'] ?? ''), 'matches' => array_slice($candidates, 0, 3), 'status' => $candidates ? 'ranked' : 'no_compatible_classes'];
}

function fj_model_predict_batch(string $dir, array $items): array {
    $model = fj_model_read($dir);
    $results = [];
    foreach ($items as $item) if (is_array($item)) $results[] = fj_model_predict_one($model, $item);
    return ['ok' => true, 'model_hash' => $model['model_hash'] ?? null, 'results' => $results,
        'interpretation' => 'similarity_index is a distance-derived ranking aid, not a probability or technique correctness score'];
}
