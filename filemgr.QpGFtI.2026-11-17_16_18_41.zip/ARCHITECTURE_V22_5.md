# Architecture and compatibility — Falco Jugger 22.5.0

## Scope

This release replaces the presentation layer only. The existing application logic remains the source of truth for analysis, storage and import.

## Presentation

- `baroque-workbench-v22-5.css` is loaded after the existing inline structural CSS on `index.php` / `uppurcell.php` and on `Memories.php`.
- The stylesheet resets the former dark dashboard treatment and composes the pages as a Baroque folio: paper sheet, framed margins, engraved rules, asymmetric source area, printed contents navigation, score columns, continuous archive catalogue and dark player chamber.
- `assets/folio-corners.svg` and `assets/title-cartouche.svg` are ornamental frames, not a brand. `assets/acanthus-engraving.svg`, `assets/baroque-rule.svg`, and `assets/paper-fiber.svg` are decorative assets only.
- `Falco Jugger` is the only wordmark. The empty `#pageModeLabel` node is retained solely because existing JS updates it; it contains no tagline and remains hidden.
- IM Fell English SC is used only for `.brand-title`. It is served by Google Fonts. A bundled EB Garamond SC OFL fallback keeps the title styled when Google Fonts is unavailable. All other UI text is Times New Roman.

## Unchanged application contracts

No changes were made to:

- PHP API routes or request/response payloads;
- private storage roots, Lully `library.json` / `classifier-model.json`, Purcell library/feedback, or report ownership model;
- report gzip/chunk upload, streaming restore/list/delete, owner isolation or hashes;
- YouTube/Instagram importer order, yt-dlp/QuickJS-NG, Lux fallback, CRON worker or media transfer checks;
- Mediabunny, ProRes, FFmpeg.wasm fallback, MediaPipe Pose/Hand, Depth Anything workers, frame sampling, analysis frequency or 2D/3D player engines;
- DOM IDs and event handlers for upload, trim, playback, analysis, Lully, Purcell, optimizer feedback and report actions.

`index.php` has only presentational HTML changes in the header: a non-visible empty compatibility node is kept for legacy JS; no invented mark or tagline is emitted.

## Hosting

The application remains PHP + browser JavaScript on REG.RU Host-0. No Python, Node service, GPU server, new daemon, npm build step or new database migration is required. The font CDN is optional; the local fallback font is bundled.

## Data safety

The deployment ZIP contains no private user models, training examples, report archives or source videos. Install as an overlay and do not mirror-delete files or private sibling directories.
