# Falco Jugger 23.0.2 — patch installation

**Target:** Falco Jugger 23.0.1. This is an overlay patch, not a full deployment archive.

## Installation

1. Back up the current site files and the private server-side report, Lully and Purcell data directories.
2. Confirm the deployed application reports version `23.0.1`.
3. Extract `astra_patch_v23.0.2.zip` into the site root and allow the listed files to be replaced.
4. Do not delete or replace private report folders, learning libraries, model weights, `vendor`, media-import executables, or server configuration files.
5. Open the analyzer with a hard refresh. Confirm the header shows the new theme control and local-save indicator.
6. Test a short local video: open the trim editor, move both IN/OUT sliders and the two timeline handles, and confirm the player seeks to the selected boundary frame.
7. Confirm the Lully status reports a complete server library before trying to mark a pattern card. If offline, annotation controls must stay disabled; use **Проверить связь с Lully** after connectivity returns.
8. Run `bash tests/verify.sh` from the deployment root where the existing test prerequisites are available.

## Changes

- Full Frutiger Aero refinement: tokenized sky/water/leaf palette, gloss and bevel surfaces, consistent spacing and control sizing, responsive layout, dark-water theme, local Lato WOFF2 subsets with Cyrillic coverage and OFL notice.
- Live trim preview: nine local filmstrip thumbnails; dragging the timeline handles or moving either time slider seeks the actual video player to the selected IN/OUT frame. The source file is not modified by previewing.
- Central journal: pipeline stages, media import, worker statuses, API writes and failures, JavaScript errors, and Lully annotation decisions are persisted locally and can be exported as JSON.
- Local recovery: IndexedDB stores the current page state, source video blob when quota permits, report, trim ranges, optimizer result and incremental frame/metric chunks. Frame chunks are appended incrementally so autosave does not clone the entire analysis array on every checkpoint. If quota is low, the last successful checkpoint and report are retained where possible; the UI says when the video must be selected again.
- Explicit depth policy: Base by default. Small only when the user enables **Облегчённый анализ**. WebGPU-to-WASM fallback may change the runtime backend, but never the selected model family. If Base cannot run, depth analysis is disabled with a visible reason; it does not silently load Small.
- Lully annotation guard: full library plus model-status confirmation required. Network loss and failed Lully writes immediately lock card editing and are recorded in the journal. A manual reconnect action restores access only after successful verification.

## Compatibility and data safety

- No PHP endpoint names, report payload contracts, Lully vector schema, Purcell storage format, or private server data directories are migrated.
- The 2D player implementation is not replaced. The filmstrip uses a detached local video element and does not add a second visible player.
- Browser-local recovery uses IndexedDB for blobs and incremental frame chunks; the process journal and small preferences use localStorage. This does not replace the server-side report library.
- No framework, animation library, remote font CDN, Python service, or new server process is added.

## QA

See `QA_REPORT_V23_0_2.md` for the exact test inventory and execution limits. The patch smoke checks cover PHP and inline-JavaScript syntax, Base/Small selection policy, trim-to-player seeking, IndexedDB frame checkpoints, process journal, Lully connection gating, and depth reconstruction metadata. The full legacy verification suite includes media-import integration checks that depend on the host's installed downloader/runtime prerequisites.
