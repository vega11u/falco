# QA report — Falco Jugger 21.9.0

Date: 2026-11-05. This report records local developer and archive checks. It is not a live test on the user's REG.RU account; the actual browser/device performance and hosting environment still require an installation-side check.

## Implemented release scope

- Browser-local depth ensemble: Depth Anything V2 Small + Base. Maps are normalized and fused; disagreement is retained per pixel and sampled around pose landmarks. If Base initialization/inference fails, Small remains a working fallback.
- Original MediaPipe image/world landmarks and biomechanical measurements are not overwritten. Relative depth is fused only into a dedicated display track.
- Main procedural 3D view is hidden and disabled by default; the explicit action button enables rendering using 2D pose, relative depth and available world landmarks.
- 2D overlay includes a far-to-near depth legend, additional derived display points, and a floor perspective grid. A metric tatami overlay is enabled only when repeated candidate square geometry is supported across sampled frames.
- Repeated orthogonal line families and paired parallel lines are used to estimate a candidate tile homography. A candidate tile is treated as 1×1 m by the user's convention, not as an independently surveyed measurement.
- Muscle panel includes an embedded top-down projection player synchronized with the source video (play/pause, seek, frame step).
- Pattern review includes same-time camera and estimated-side snapshots; matched body segments/points are highlighted red.
- Detailed spatial/depth series are Q16/Base64 encoded in `analysis.spatial_reconstruction_local` and included in the locally downloaded JSON report. `saveReport()` removes this block from the PHP-session copy.

## Automated verification

Executed in the working source tree and then repeated after extracting the release ZIP into a clean directory:

```bash
RUN_CRON_INTEGRATION=1 bash tests/verify.sh
```

Result: **PASS**. Coverage includes:

- PHP syntax, intelligence-data smoke, release smoke, health/API and local-video pipeline contracts.
- Browser JavaScript parsing and device profile checks.
- Biomechanics, technique sequence planner, avatar render, root translation and relative-depth fusion.
- Tatami grid synthetic regression: repeated square candidate accepted; a one-frame candidate rejected; projective homographies generated only for stable evidence.
- Recognition / DTW / pose quality / report rendering / foot geometry / pattern UI / optimizer constraints.
- Learning API: Q16 encoding, confirmed-only pattern storage, feedback isolation, 3,005-example archive and 1,002 feedback records.
- Media-import lifecycle, queue serialization, bounded range transfer, SHA-256 acknowledgement and CRON integration.

Focused checks also passed:

```bash
php -l index.php
php -l tests/release-smoke.php
node --check depth-worker.js
node --check depth-reconstruction-core.mjs
node --check scene-perspective-core.mjs
node tests/depth-reconstruction-smoke.mjs
node tests/scene-perspective-core-smoke.mjs
```

## Archive integrity and training-data preservation

- Full application archive, root layout (no enclosing project directory), 128 ZIP entries.
- `unzip -t`: PASS; clean extraction: PASS; full release suite from extracted archive: PASS.
- Runtime `data/trained/training-manifest.json` is absent; only `data/trained/training-manifest.json.template` is packaged.
- Personal `.kata-biomechanics-*` and `.kata-media-import-*` directories are not packaged.
- Overlay sentinel simulation: pre-existing `data/trained/training-manifest.json`, sibling `.kata-biomechanics-test/library.json`, and `.kata-media-import-test/marker.txt` all retained identical SHA-256 values after archive extraction over the test site.
- The saved 384-value temporal-window / 1,152-value kata schema is unchanged; no training-library or manifest migration is included.

## Important limits

- This is relative monocular scene depth, not stereo or calibrated metric capture. Model agreement is a confidence cue, not ground truth.
- The inferred side snapshot is an estimated orthographic-like view built from MediaPipe world landmarks where available and the local relative-depth track otherwise.
- Tatami metric scale is conditional on detecting repeated tile geometry and on the explicit assumption that one visible square is 1×1 m. Without this evidence, only relative floor projection is displayed.
- Model weights are not bundled; the browser fetches them from Hugging Face on first use and may cache them. Source video frames stay in the browser for this depth pass.
- Depth Anything V2 Small ONNX is listed as Apache-2.0. Depth Anything V2 Base is listed as CC-BY-NC-4.0; commercial use requires separate license review or replacement of Base.
- No claim is made that this archive has been installed or visually benchmarked on the user's live REG.RU account or on their actual kata videos.
