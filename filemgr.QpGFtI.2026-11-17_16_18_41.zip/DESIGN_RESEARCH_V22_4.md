# Baroque editorial design research — v22.4.0

## References inspected

- `pinecreativelabs/Baroquest-Framework` — inspected its README and source entry page. The useful ideas are the separation of typography, layout, ornaments and movement into independent systems, and the use of engraved rules/frames as accents. Its maximalist backgrounds, masks and motion are deliberately not imported because this is an analytical workspace, not a decorative landing page.
- `garymeyerca/design-styles-demo` — inspected the self-contained Baroque style example and its stated principles. It demonstrates chiaroscuro, ornamental flourishes and historical typography; its heavy gradients, glowing controls, faux marks and dashboard cards were intentionally rejected.
- `cyanharlow/purecss-lace` — inspected as an example of hand-drawn Flemish Baroque ornamental construction. Its art-only layout is not copied; the project uses only a restrained ornamental divider.
- `CatharsisFonts/Cormorant` was reviewed as a display-family candidate, but the project wordmark uses the more period-specific IM Fell English SC instead.
- The IM Fell English type family is a digital revival of 17th-century Fell types; the SC font is reserved for the Latin project name only. The font is distributed under SIL Open Font License 1.1.

## Design decision

The new design is a Baroque editorial workbench rather than a dark luxury dashboard:

- warm paper ground and ink-first contrast;
- oxblood as a functional accent, antique brass as a structural rule;
- asymmetrical frontispiece, typographic hierarchy and book-like navigation;
- thin and double rules, small-caps wordmark and one engraved scroll divider;
- no gradients, glass effects, floating cards, generated crest, initials badge or invented logo;
- the project name `Falco Jugger` is the sole brand mark;
- IM Fell English SC is used only for that wordmark; all interface text remains Times New Roman;
- video and 3D player stages stay dark for visual fidelity, framed by the light paper interface.

## Implementation

`baroque-editorial-v22-4.css` is a presentation-only stylesheet loaded after the retained structural layer. Existing element IDs, JS handlers, PHP endpoints, report formats, Lully/Purcell storage and media pipelines are unchanged. The old experimental baroque layer and unused crest/acanthus logo assets were removed from the release.
