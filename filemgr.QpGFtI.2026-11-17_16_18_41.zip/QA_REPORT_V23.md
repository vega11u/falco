# QA report — Falco Jugger 23.0.0

## Automated verification

Executed `bash tests/verify.sh` successfully after the final code changes. Covered:

- PHP syntax, release/API contracts and valid JSON assets.
- Social provider host allowlist and generic yt-dlp/Lux fallback contracts.
- Lully confirmed-example storage, Purcell separate storage/feedback and report archive persistence/owner isolation.
- Browser-local video handling, decoder fallback and runtime installer contract.
- Device profile, pose quality, temporal recognition, DTW, biomechanics planner, Purcell baseline/correction bounds, avatar rendering, depth fusion, player zoom, trim and report rendering.
- Existing YouTube/Instagram recovery profiles, media transfer integrity, SHA-256, ACK, privacy locks and Lux-only CRON fallback.
- New Frutiger Aero shared stylesheet, retained DOM/player/trim contracts, additive Purcell knowledge blocks and decision-layer propagation of phase/trajectory theory.

All tests in the default verification suite passed. Detached CRON integration also passed through the standalone Lux-only CRON test. The optional full `RUN_CRON_INTEGRATION=1` combined test was not run for this release.

## Compatibility checks

- `VERSION` is 23.0.0.
- Purcell knowledge schema remains `purcell-knowledge-v1`.
- No database schema migration.
- No API payload or private storage path migration.
- No change to training feature dimensions, worker message contracts, report ownership, report streaming or video frame capture policy.
- Legacy Baroque stylesheet remains available but is no longer loaded by the app.

## Limits / not verified in this environment

- The actual REG.RU account, PHP permissions, CRON configuration, installed binary hashes, host egress and social platform access cannot be verified from a local archive.
- Social extractors are best-effort and can change upstream without notice.
- A real device-specific FPS benchmark requires the user's browser, video, CPU/GPU, memory and thermal conditions.
- Automated checks cannot validate biomechanics against laboratory motion capture, force plates or EMG. Monocular video remains limited to visible 2D and model-estimated relative 3D evidence.
