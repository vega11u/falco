/** Falco 23.0.14: non-saturating, evidence-gated kinematic rating.
 * Scores measured movement coherence; NOT elite skill, contact power or physiological efficiency.
 * Missing metrics are omitted, not replaced by neutral 50. KE fraction is diagnostic only.
 */
const cl=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const valid=p=>Array.isArray(p)&&p.length>=3&&Number.isFinite(p[0])&&Number.isFinite(p[1])&&(p[3]??1)>=.18;
const avg=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:null;
const median=a=>{if(!a.length)return null;const b=a.slice().sort((x,y)=>x-y);return b.length%2?b[(b.length-1)/2]:(b[b.length/2-1]+b[b.length/2])/2;};
function robustSpread(a){if(!a.length)return null;const m=median(a);return median(a.map(x=>Math.abs(x-m)));}
const interp=(v,low,high)=>100*cl((v-low)/(high-low));
function scoreTrajectory(frames){
  const tracks=[15,16,27,28],scores=[],paths=[],activeIntervals=[];let validTotal=0,total=0;
  // Preserve local timing on long videos: thinning by frame count creates 1s+ gaps
  // and silently drops all velocity/curvature evidence. This pass is O(frames).
  const sampleStep=1;
  const scaleAt=f=>{const a=f.im?.[11],b=f.im?.[12],c=f.im?.[23],d=f.im?.[24];if(![a,b,c,d].every(valid))return null;const shoulder=Math.hypot(a[0]-b[0],a[1]-b[1]),height=Math.hypot((a[0]+b[0]-c[0]-d[0])/2,(a[1]+b[1]-c[1]-d[1])/2);return Math.max(.1,shoulder*2,height*2);};
  for(const id of tracks){
    const values=[];let previous=null,prevSeg=null;
    for(let i=0;i<frames.length;i+=sampleStep){const f=frames[i],point=f.im?.[id],scale=scaleAt(f);total++;
      if(!valid(point)||!scale){previous=null;continue;}
      validTotal++;if(previous){const dt=f.t-previous.t;if(dt>.01&&dt<.32&&(f.camera_segment_id??0)===prevSeg){const vx=(point[0]-previous.p[0])/scale/dt,vy=(point[1]-previous.p[1])/scale/dt;values.push({vx,vy,t:f.t});}else values.push(null);}
      previous={p:point,t:f.t};prevSeg=f.camera_segment_id??0;
    }
    const speeds=values.map(v=>v?Math.hypot(v.vx,v.vy):null).filter(Number.isFinite);const sortedSpeeds=speeds.slice().sort((a,b)=>a-b),base=sortedSpeeds.length?sortedSpeeds[Math.floor((sortedSpeeds.length-1)*.75)]:null;
    if(base==null||base<.045)continue;
    const transitions=[],angles=[],active=[];
    for(let i=1;i<values.length-1;i++){
      const a=values[i-1],b=values[i],c=values[i+1];if(!a||!b||!c)continue;
      const m=Math.hypot(b.vx,b.vy),pa=Math.hypot(a.vx,a.vy),pc=Math.hypot(c.vx,c.vy);
      // Don't treat intentional starts/stops as jitter; skip low-activity boundaries.
      if(Math.min(m,pa,pc)<Math.max(.05,base*.20))continue;
      const dd=Math.hypot(b.vx-(a.vx+c.vx)/2,b.vy-(a.vy+c.vy)/2)/Math.max(.1,m,base);
      transitions.push(cl(dd,0,3));
      const dir=(b.vx*c.vx+b.vy*c.vy)/(Math.max(.00001,m*pc));angles.push(cl((dir+1)/2));active.push(m);
    }
    if(transitions.length>=5){
      const jitter=median(transitions),spread=robustSpread(transitions)||0;
      // Smooth continuous motion can score ~85-95; noise raises the relative jerk term.
      const score=cl(100*Math.exp(-1.65*jitter-.55*spread),0,100);
      scores.push(score);paths.push(median(angles));activeIntervals.push(transitions.length);
    }
  }
  return {smoothness:scores.length?avg(scores):null,continuity:paths.length?avg(paths)*100:null,coverage:total?validTotal/total:0,active_intervals:activeIntervals.reduce((a,b)=>a+b,0),tracks:scores.length};
}
/** Selects only observable, relevant evidence; no fixed cap at 85 and no default score=50. */
export function evaluateMovementQuality({frames=[],strikes=[],metrics=[],risks=[],allowPartial=false}={}){
  const motion=scoreTrajectory(frames);const signals=[];
  const add=(key,label,weight,score,detail,samples=0)=>{if(Number.isFinite(score)&&samples>=1)signals.push({key,label,weight,score:Math.round(cl(score,0,100)*10)/10,source:detail,samples});};
  const sequence=(strikes||[]).map(s=>Number(s?.sequencing_index)).filter(x=>Number.isFinite(x)&&x>=0&&x<=1);
  if(sequence.length>=2){const seq=median(sequence);add('sequencing','Порядок передачи движения',.18,interp(seq,.04,.94),'Медианная последовательность пиков цепей; без предположения об идеальном ката',sequence.length);}
  add('kinematic_smoothness','Управляемость траектории',.36,motion.smoothness,'Локальные изменения скорости активных конечностей; не штрафуются паузы',motion.active_intervals>=8?motion.tracks:0);
  // Direction reversal can be intentional in kata; small weight and only when sustained movement exists.
  add('directional_continuity','Непрерывность фазы',.12,motion.continuity,'Направление движения внутри активной фазы, не абсолютная скорость',motion.active_intervals>=8?motion.tracks:0);
  const supported=(metrics||[]).filter(m=>m?.bos_reliable&&Number.isFinite(m?.bos_margin_body_heights)&&Number(m.pose_confidence??1)>.4);
  // Projection COM/BOS is unreliable in dynamic transitions: check plausible stationary samples only.
  const stance=supported.filter(m=>{const speed=Number(m.pelvis_speed_m_s??m.pelvis_speed_body_heights_s??NaN);return !Number.isFinite(speed)||speed<.28;});
  if(stance.length>=Math.max(8,Math.floor(frames.length*.12))){const negatives=stance.filter(x=>x.bos_margin_body_heights<-.012).length/stance.length;
    const boundary=median(stance.map(x=>x.bos_margin_body_heights));add('stability','Опора в устойчивых фазах',.18,cl(88-65*negatives+Math.max(-12,Math.min(12,Number(boundary)*85)),0,100),'Проекция COM/BOS только при достаточно видимой опоре',stance.length);}
  const significant=(risks||[]).filter(e=>Number(e.pose_confidence_mean??1)>=.65&&['projected_com_outside_bos','abrupt_wrist_acceleration_proxy','joint_anomaly','unstable_support'].includes(String(e.type)));
  if(significant.length){const rate=significant.length/Math.max(1,(frames.at(-1)?.t??0)-(frames[0]?.t??0));add('critical_events','Существенные отклонения',.16,100*Math.exp(-.55*rate),'Только выраженные подтверждённые физические события',significant.length);}
  const available=signals.reduce((z,s)=>z+s.weight,0);
  // Global quality is unidentifiable from smoothness + direction alone: a perfectly
  // smooth but biomechanically wrong arm wave must not score 97 as a complete kata.
  const hasIndependentEvidence=signals.some(s=>['sequencing','stability','critical_events'].includes(s.key));
  const partial=available>=.36&&motion.active_intervals>=8;
  const complete=partial&&(hasIndependentEvidence||allowPartial);
  const value=complete?Math.round(signals.reduce((z,s)=>z+s.weight*s.score,0)/available*10)/10:null;
  const reliability=cl((motion.coverage*.6+.4*cl(motion.active_intervals/25))*(.55+.45*cl(available/.7)),0,1);
  return {schema:'falco-motion-quality-v2',value,raw:value,has_independent_evidence:hasIndependentEvidence,provisional:!hasIndependentEvidence,confidence:Math.round(reliability*100)/100,available_weight:available,measurable:complete,breakdown:signals.map(s=>({...s,weight:s.weight/available,contribution:s.score*s.weight/available})),
    kinetic_energy_weight:0,velocity_weight:0,ke_diagnostic_only:true,
    reason:complete?(hasIndependentEvidence?null:'Промежуточная оценка только траектории; независимых признаков биомеханики нет.'):!partial?'Недостаточно движущихся достоверных интервалов; оценка качества не заменяется числом 40–50.':'Отсутствует независимый признак передачи движения, устойчивой опоры или физического события; итоговая оценка не определяется.',
    note:'Кинематическая шкала, а не рейтинг квалификации спортсмена. Не используются абсолютная скорость, доля KE или внутренняя ранжировка одного ката.'};
}
/** Return scalar only when measured; used in evolutionary fitness to avoid default scores. */
export function scoreMotionFrames(frames){return evaluateMovementQuality({frames});}
