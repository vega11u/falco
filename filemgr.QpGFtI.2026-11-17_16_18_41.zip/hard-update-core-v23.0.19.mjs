/**
 * Falco Jugger 23.0.19 — explicit origin-cache purge for a hard app refresh.
 * Deliberately does NOT touch localStorage, sessionStorage, IndexedDB, cookies,
 * server-side reports, training libraries, or model files on the server.
 */
export async function purgeFalcoOriginCaches({
  cacheStorage = globalThis.caches,
  serviceWorker = globalThis.navigator?.serviceWorker,
  currentUrl = globalThis.location?.href || 'http://localhost/'
} = {}) {
  const current = new URL(currentUrl);
  const deletedCacheNames = [];
  const unregisteredScopes = [];
  const errors = [];
  let cacheNames = [];
  const cacheStorageAvailable = !!(cacheStorage && typeof cacheStorage.keys === 'function' && typeof cacheStorage.delete === 'function');

  if (cacheStorageAvailable) {
    try {
      cacheNames = await cacheStorage.keys();
    } catch (error) {
      errors.push({ scope: 'Cache Storage', message: String(error?.message || error) });
    }
    for (const name of cacheNames) {
      try {
        if (await cacheStorage.delete(name)) deletedCacheNames.push(String(name));
      } catch (error) {
        errors.push({ scope: `Cache Storage · ${String(name)}`, message: String(error?.message || error) });
      }
    }
  }

  if (serviceWorker && typeof serviceWorker.getRegistrations === 'function') {
    try {
      const registrations = await serviceWorker.getRegistrations();
      // Only unregister workers from this origin whose scope currently controls
      // the Falco page. Workers for unrelated paths/origins remain untouched.
      const controlling = registrations.filter(registration => {
        try {
          const scope = new URL(registration.scope);
          return scope.origin === current.origin && current.pathname.startsWith(scope.pathname);
        } catch (_) { return false; }
      });
      for (const registration of controlling) {
        try {
          if (await registration.unregister()) unregisteredScopes.push(String(registration.scope));
        } catch (error) {
          errors.push({ scope: `Service Worker · ${String(registration.scope || 'unknown')}`, message: String(error?.message || error) });
        }
      }
    } catch (error) {
      errors.push({ scope: 'Service Worker', message: String(error?.message || error) });
    }
  }

  return {
    cacheStorageAvailable,
    cacheCountBefore: cacheNames.length,
    deletedCacheNames,
    serviceWorkersRemoved: unregisteredScopes.length,
    unregisteredScopes,
    errors,
    // Cache API covers app/model Cache Storage. The browser's private HTTP disk
    // cache is not exposed to websites; the caller adds a one-time URL nonce.
    browserHttpCacheAccessible: false
  };
}

export function buildHardUpdateUrl(href, nonce = Date.now()) {
  const url = new URL(href);
  url.searchParams.set('__falco_hard_update', String(nonce));
  return url.href;
}

export function stripHardUpdateMarker(href) {
  const url = new URL(href);
  url.searchParams.delete('__falco_hard_update');
  return url.href;
}
