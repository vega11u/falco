/* Pure depth-map arithmetic shared by the worker and regression tests.
 * No model, browser, network or storage dependencies. */
const clamp01 = value => Math.max(0, Math.min(1, value));

// Three-way quickselect handles constant/quantized maps without the quadratic
// duplicate-key behaviour of a two-way partition. Only the scratch array changes.
function select(values, index, count) {
  let left = 0, right = count - 1;
  while (left < right) {
    const mid = (left + right) >>> 1;
    const a = values[left], b = values[mid], c = values[right];
    const pivot = a < b ? (b < c ? b : Math.max(a, c)) : (a < c ? a : Math.max(b, c));
    let lower = left, scan = left, upper = right;
    while (scan <= upper) {
      const value = values[scan];
      if (value < pivot) { values[scan] = values[lower]; values[lower++] = value; scan++; }
      else if (value > pivot) { values[scan] = values[upper]; values[upper--] = value; }
      else scan++;
    }
    if (index < lower) right = lower - 1;
    else if (index > upper) left = upper + 1;
    else return values[index];
  }
  return values[left];
}

/** Same exact nearest-rank 3/97 percentiles as the legacy full-sort normalizer. */
export function normalizeDepthMap(source) {
  const width = Number(source?.width), height = Number(source?.height), data = source?.data;
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 2 || height < 2 || !data || data.length < width * height) throw new Error('Некорректные размеры карты глубины.');
  const size = width * height, scratch = new Float64Array(size);
  let count = 0;
  for (let i = 0; i < size; i++) { const value = Number(data[i]); if (Number.isFinite(value)) scratch[count++] = value; }
  if (count < 16) throw new Error('Недостаточно конечных значений карты глубины.');
  const lo = select(scratch, Math.round((count - 1) * .03), count);
  const hi = select(scratch, Math.round((count - 1) * .97), count), span = hi - lo;
  if (!Number.isFinite(span) || span < 1e-7) throw new Error('Карта глубины почти постоянна.');
  const out = new Float32Array(size);
  for (let i = 0; i < size; i++) { const value = Number(data[i]); out[i] = Number.isFinite(value) ? clamp01((value - lo) / span) : .5; }
  return { data: out, width, height };
}

export function downsampleDepthMap(source, maxWidth = 80) {
  const width = Math.min(maxWidth, source.width), height = Math.max(2, Math.round(source.height * width / source.width));
  const values = new Float32Array(width * height);
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const sx = Math.min(source.width - 1, Math.floor((x + .5) * source.width / width));
    const sy = Math.min(source.height - 1, Math.floor((y + .5) * source.height / height));
    values[y * width + x] = source.data[sy * source.width + sx];
  }
  return { values, width, height };
}

/** Depth and disagreement are calculated in the same pass and transferred once. */
export function fuseDepthMaps(primary, secondary) {
  const width = Math.min(80, primary.width, secondary.width), height = Math.max(2, Math.round(primary.height * width / primary.width));
  const values = new Float32Array(width * height), agreement_values = new Float32Array(width * height);
  let delta = 0;
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const px = Math.min(primary.width - 1, Math.floor((x + .5) * primary.width / width)), py = Math.min(primary.height - 1, Math.floor((y + .5) * primary.height / height));
    const qx = Math.min(secondary.width - 1, Math.floor((x + .5) * secondary.width / width)), qy = Math.min(secondary.height - 1, Math.floor((y + .5) * secondary.height / height));
    const a = primary.data[py * primary.width + px], b = secondary.data[qy * secondary.width + qx], d = Math.abs(a - b), index = y * width + x;
    values[index] = .38 * a + .62 * b; agreement_values[index] = clamp01(1 - d); delta += d;
  }
  return { values, width, height, agreement_values, agreement: clamp01(1 - delta / values.length) };
}
