# Falco 24.2.3 — Clean UI Rebuild

- Removed the stacked Frutiger/Aero legacy stylesheet chain from the analyzer runtime.
- Introduced one consolidated UI stylesheet with one document scroll; sidebar is fixed desktop navigation and never independently scrolls.
- Removed duplicate sidebar footer branding and duplicate header brand. Functional header actions remain.
- Simplified the right-hand video dock: one vertical player stack, one bounded sticky surface on desktop, no independent page/rail scrolling.
- On mobile the navigation becomes a horizontal strip and the player returns to normal document flow.
- Preserved existing analysis DOM, IDs, handlers, API routes, data stores and algorithms.
- This is a CSS/layout-only rebuild plus stylesheet-link cleanup; no analysis engine or training data changed.
- Browser screenshot validation is still required on the live host.
