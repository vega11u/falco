# QA report — Falco Jugger 21.7.0

Date: 2026-11-05

## Объём аудита и выявленная причина слабого 3D

Исходная версия использовала MediaPipe Pose/Hand landmarks для определения суставов, а объёмное тело строила процедурно вокруг суставов. Это полезная кинематическая модель, но она не является плотной оценкой глубины сцены или реконструкцией поверхности человека. `worldLandmarks` MediaPipe — оценки координат ориентиров тела в модельной системе, а не карта расстояний до камеры. Из этого следовало, что увеличение числа полигонов само по себе не могло дать корректное движение в глубину.

REG.RU Host-0 подходит для PHP API и хранения численных данных, но не для запуска больших нейросетевых 3D-реконструкторов на серверной GPU. Поэтому v21.7 оставляет вычисления видео в браузере, как и исходный проект.

## Изменения

- Добавлен необязательный `depth-worker.js` на Transformers.js 4.3.2 и `onnx-community/depth-anything-v2-small-ONNX`.
- WebGPU FP16 используется при успешной инициализации адаптера; иначе включается WASM Q8. Если WebGPU рушится уже на первом инференсе, worker автоматически переключается на WASM и повторяет этот кадр. Ошибка дополнительного depth-worker не останавливает MediaPipe/2D и основное построение отчёта.
- Глубина оценивается на уже декодированном `VideoFrame`, без повторного декодирования полного видео и без передачи пикселей PHP/облачному inference API. Кадр обрабатывается в отдельном worker; видео остаётся в браузере.
- Карта глубины семплируется около видимых MediaPipe landmarks. Относительная глубина интерполируется только в рамках одного camera segment и с ограничением временного разрыва.
- Результат сливается только в `render_w`, используемый 3D-представлением. Исходный `w` и координаты 2D не переписываются; расчёты биомеханики и обучающие признаки используют прежние исходные данные.
- Повышена детализация объёмной геометрии туловища, конечностей, головы и крупных суставов. Дополнительный регрессионный тест проверяет, что сглаживатель использует depth-fused `render_w` и не смешивает его с исходным `w` соседних кадров.
- Отчёт сохраняет фактический backend, тип данных, попытки/успешные кадры/ошибки, среднее время depth-инференса и фактическое покрытие слиянием.

## Automated checks

| Check | Result |
|---|---|
| `RUN_CRON_INTEGRATION=1 bash tests/verify.sh` | PASS — all developer release checks, including the detached-worker CRON integration |
| `php -l index.php` | PASS |
| `php -l tests/release-smoke.php` | PASS |
| `bash -n setup-regru.sh` | PASS |
| JavaScript syntax checks | PASS — application modules and both workers |
| Depth reconstruction smoke | PASS — robust sampling, invalid-landmark handling, camera-cut guard, interpolation and display-only fusion |
| Avatar render smoke | PASS |
| Biomechanics/recognition/planner/perspective/report tests | PASS |
| Local video/social import/learning API/optimizer tests | PASS |
| JSON assets | PASS — release smoke validates every shipped JSON file |

The detached CRON integration test was explicitly run and passed. It verified two-session queue serialization, the account-level active-job lock, single-extractor execution, bounded range transfer, SHA-256 acknowledgement and cleanup. No browser/device-specific live video benchmark was run in this environment.


## Rebuilt archive integrity

- ZIP paths start at the website document root; `index.php`, `.htaccess` and `tests/` are top-level entries (no enclosing project directory).
- The archive contains the complete 119-file source tree, including `tests/.htaccess` and `tests/intelligence-data-smoke.php`.
- The repacked ZIP was extracted to a clean temporary directory; the full verification suite was run from that extracted copy.
- The installer now checks the required `tests/` files before any downloads and prints the exact missing path plus extraction guidance, rather than failing later with a generic PHP file-open error.

## Ограничения и честная оценка результата

Depth Anything V2 Small даёт относительную моноскопическую глубину, не абсолютные метры. Система не получает калибровку камеры и не восстанавливает невидимые поверхности тела, точную толщину мышц/одежды или индивидуальную антропометрию. Слияние помогает разрешать часть неоднозначности глубины суставов, но не заменяет 2D detection и не превращает landmarks в плотную surface reconstruction. Поэтому результат — более связный объёмный аватар человека, а не гарантированно точная photogrammetry/motion-capture модель.

ExMR/SMPL-X и FlowHMR требуют отдельной GPU-среды/весов; они не устанавливаются на Host-0 и не подключаются как автоматическая отправка пользовательского видео. Для проверки качества на реальных записях нужен тестовый kata-клип и визуальное сравнение аватара с исходными кадрами на поддерживаемом браузере, сначала с WebGPU, затем с WASM fallback.
