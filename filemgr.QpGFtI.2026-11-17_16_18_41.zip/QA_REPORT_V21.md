# QA report — Falco Jugger 21.3.0

Дата сборки: 2026-11-03. Релиз: v21.3.0.

## Выполненные проверки

| Проверка | Результат |
|---|---|
| PHP syntax: `index.php` | PASS |
| PHP syntax: `server-learning.php` | PASS |
| JavaScript syntax: main module | PASS |
| JavaScript syntax: pose worker | PASS |
| JavaScript syntax: device profile + benchmark worker | PASS |
| Browser biomechanics/recognition modules syntax | PASS |
| Learning API: Q16 round-trip | PASS |
| Learning API: only confirmed patterns enter training | PASS |
| Learning API: 384-D server pattern model trains and predicts | PASS |
| Learning API: 1152-D full-kata model trains and predicts | PASS |
| Learning API: subjective feedback excluded from objective biomechanics | PASS |
| Learning archive: 3,005 examples / 1,002 feedback records returned without truncation | PASS |
| Release smoke | PASS |
| Social importer smoke: URL allowlist, retry profiles, cross-session lock | PASS |
| Social importer smoke: HTTP Range cap 4 MiB, per-chunk hash, acknowledgement cleanup | PASS |
| Health detects modified yt-dlp and QuickJS binaries | PASS |
| Large executable SHA-256 checks limited to health/import-start API requests | PASS |
| Browser retry path retains the same server job after transfer/status interruption | PASS (release-contract regression) |
| Social file lifecycle: independent Blob for small imports; fresh OPFS snapshot on retry | PASS (production helper functions exercised with mocked OPFS/File APIs) |
| Browser readiness gate: canplay, failure, timeout, cancel, and no-demuxer paths | PASS (production helper functions exercised in Node test harness) |
| Delayed acknowledgement: server copy is not removed until browser decode readiness | PASS (release integration contract) |
| CRON importer integration: disabled web `proc_open`, two-session serialization, Range transfer and SHA-256 acknowledgement | PASS |
| YouTube fallback order: default → HLS-only web_safari → android_vr | PASS (fake yt-dlp integration) |
| OPFS/Blob safety limits and no system Node install dependency | PASS (release-contract tests) |
| Full CRON integration with detached workers | PASS |
| Downloader installation smoke: yt-dlp/QuickJS CLI, version + binary SHA-256 proofs | PASS with controlled test doubles; actual QuickJS binary execution on target Host-0 is pending deployment |

## What PASS means

Automated PHP/API and browser-JavaScript tests ran in the build container (Node 22 is used only for developer verification). The production installer does not invoke system Node; it validates the actual installed yt-dlp and private QuickJS-NG executables with CLI smoke checks. The downloader installation smoke test was executed with controlled test doubles in the build container. The release installer downloads the official QuickJS-NG 0.18.0 Cosmopolitan binary first, falls back to the native Linux build, validates upstream SHA-256, and runs the actual qjs CLI on the target hosting account before enabling YouTube; that target-side execution is not yet observed because the user has not run v21.3.0. The installed yt-dlp binary is also checked against the official release SHA-256 manifest, and health/import-start requests compare both executable hashes against their installation stamps. Unrelated learning/status API calls do not reread the large yt-dlp binary. Social importer uses deterministic fake yt-dlp for integration tests; it verifies PHP orchestration, ownership, YouTube retry order, range transfer, hashing, cleanup and retained-job retry contracts, but does not prove live extraction from a particular REG.RU IP.

No real kata videos were available in this build turn for full end-to-end pose accuracy validation. Browser GPU performance, Safari/Firefox codec matrix, and actual REG.RU Host-0 process/CRON behaviour require deployment hardware and a real sample video. The automated importer tests use a deterministic fake yt-dlp binary; they validate direct and CRON orchestration, fallback order, transfer protocol and cleanup, not live platform extraction from a REG.RU IP. No claim is made that all public videos can be downloaded: PO Token, age, region, private-content and anti-bot limits remain controlled by the platforms.

## Known scientifically important limitations

- MediaPipe keypoints are image/model estimates, not marker-based motion capture.
- Monocular video cannot directly measure GRF/COP, joint torques, muscle forces or true athlete-specific 3D anatomy.
- The server classifier is a trained statistical prototype model, not a pretrained karate neural network.
- Karate-specific accuracy grows only after independently recorded, user-confirmed examples are accumulated.
- A similarity index is not a probability and not a correctness score.


## v21.3.0 post-download lifecycle regression

The new release adds regression contracts for independent Blob storage of small imports, long-lived OPFS entries for large imports, old-entry cleanup only after detaching the previous video source, retry reuse, and delayed server acknowledgement. The production readiness/waiter helpers and OPFS snapshot refresh function are executed in a Node regression harness with mocked browser storage; the complete HTML app was not successfully exercised in headless Chromium in this build environment. These checks supplement but do not replace the real Chrome/REG.RU end-to-end run with the user's actual MP4.
