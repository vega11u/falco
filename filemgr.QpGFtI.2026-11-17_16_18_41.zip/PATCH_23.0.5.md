# Patch 23.0.5 — research downloader

Накладывать поверх 23.0.4. Распаковать файлы из ZIP в корень проекта и исполнить `bash install-research.sh` из SSH. Требуется Python 3.9+, исходящий HTTPS и свободное место. Установщик скачивает только публичные доступные исходные материалы, создаёт `data/trained/research-acquisition.json`; манифест обученных моделей **не подменяется**. Подробнее в `docs/RESEARCH_INSTALLER_23_0_5.md`.
