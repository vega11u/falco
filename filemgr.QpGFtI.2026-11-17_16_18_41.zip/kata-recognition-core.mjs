/** Temporal pose retrieval for karate technique/stance examples.
 * Short per-joint occlusions are interpolated only for signature extraction.
 * This never alters saved raw landmarks or biomechanical measurements.
 */
export const PATTERN_LANDMARKS = Object.freeze([11,12,13,14,15,16,23,24,25,26,27,28,29,30,31,32]);
export const MIRROR_JOINT = Object.freeze({11:12,12:11,13:14,14:13,15:16,16:15,23:24,24:23,25:26,26:25,27:28,28:27,29:30,30:29,31:32,32:31});
export const POSE_FRAME_DIM = 48; // v21.8 keeps the persisted 48D frame / 384D window contract
// Keep the persisted 48D-per-frame/384D-window format. Weight distal-leg and foot
// landmarks more strongly so heel/toe geometry contributes to retrieval without schema migration.
const JOINT_WEIGHTS = [1.05,1.05,1.02,1.02,1.08,1.08,1.15,1.15,1.24,1.24,1.32,1.32,1.18,1.18,1.18,1.18];
const finite = Number.isFinite;
const clamp = (x,a,b)=>Math.max(a,Math.min(b,x));
function validPoint(p){return Array.isArray(p)&&p.length>=3&&p.slice(0,3).every(finite)&&(p[3]??1)>=.04;}
function pointVector(frame,mirror=false,minValid=10){
  if(!frame)return null;
  const world=frame.w, image=frame.im;
  const anchors=[11,12,23,24];
  const worldUsable=Array.isArray(world)&&world.length>=33&&PATTERN_LANDMARKS.filter(i=>validPoint(world[i])).length>=minValid&&anchors.every(i=>validPoint(world[i]));
  const imageUsable=Array.isArray(image)&&image.length>=33&&PATTERN_LANDMARKS.filter(i=>validPoint(image[i])).length>=minValid&&anchors.every(i=>validPoint(image[i]));
  const src=worldUsable?world:(imageUsable?image:null);
  if(!Array.isArray(src)||src.length<33)return null;
  const get=i=>src[mirror?(MIRROR_JOINT[i]??i):i];
  const valid=PATTERN_LANDMARKS.filter(i=>validPoint(get(i)));
  if(valid.length<minValid)return null;
  const hipL=get(mirror?24:23),hipR=get(mirror?23:24),shoL=get(mirror?12:11),shoR=get(mirror?11:12);
  if(![hipL,hipR,shoL,shoR].every(validPoint))return null;
  const center=[0,1,2].map(k=>(hipL[k]+hipR[k])*.5),shoulder=[0,1,2].map(k=>(shoL[k]+shoR[k])*.5);
  const scale=Math.max(.08,Math.hypot(...shoulder.map((v,k)=>v-center[k]))),out=[];
  for(const idx of PATTERN_LANDMARKS){const p=get(idx);if(!validPoint(p)){out.push(0,0,0);continue;}out.push(clamp((mirror?-1:1)*(p[0]-center[0])/scale,-4,4),clamp((p[1]-center[1])/scale,-4,4),clamp((p[2]-center[2])/scale,-4,4));}
  return out.every(finite)?out:null;
}
function nearestIndex(frames,time){let lo=0,hi=frames.length-1;while(lo<hi){const mid=(lo+hi)>>1;if(Number(frames[mid].t)<time)lo=mid+1;else hi=mid;}if(lo>0&&Math.abs(frames[lo-1].t-time)<Math.abs(frames[lo].t-time))lo--;return lo;}

export function poseVectorAtTime(frames,time,{mirror=false,minValid=10,oneSidedTolerance=.045,bracketTolerance=.085,maxBracket=.17}={}){
  if(!Array.isArray(frames)||!frames.length||!finite(time))return null;
  const center=nearestIndex(frames,time),near=frames[center];
  if(!near||!finite(Number(near.t))||Math.abs(Number(near.t)-time)>oneSidedTolerance)return null;
  const segment=near.camera_segment_id??near.segment_id??0;
  const sameSegment=frame=>(frame?.camera_segment_id??frame?.segment_id??0)===segment;
  // A point just across an edit must not borrow the other camera's pose.
  const before=frames[center]?.t>time?frames[center-1]:frames[center];
  const after=frames[center]?.t>time?frames[center]:frames[center+1];
  if(before&&after&&before.t<time&&after.t>time&& !sameSegment(before===near?after:before))return null;
  const anchors=[11,12,23,24];
  const worldUsable=Array.isArray(near.w)&&near.w.length>=33&&PATTERN_LANDMARKS.filter(i=>validPoint(near.w[i])).length>=minValid&&anchors.every(i=>validPoint(near.w[i]));
  const imageUsable=Array.isArray(near.im)&&near.im.length>=33&&PATTERN_LANDMARKS.filter(i=>validPoint(near.im[i])).length>=minValid&&anchors.every(i=>validPoint(near.im[i]));
  const field=worldUsable?'w':'im';
  const reconstructed=Array.from({length:33},()=>[NaN,NaN,NaN,0]);
  for(const id of PATTERN_LANDMARKS){
    const direct=near[field]?.[id];if(validPoint(direct)){reconstructed[id]=direct.slice(0,4);continue;}
    let left=null,right=null;
    for(let j=center;j>=0&&sameSegment(frames[j])&&time-Number(frames[j].t)<=bracketTolerance;j--){const p=frames[j][field]?.[id];if(validPoint(p)){left={t:Number(frames[j].t),p};break;}}
    for(let j=center+1;j<frames.length&&sameSegment(frames[j])&&Number(frames[j].t)-time<=bracketTolerance;j++){const p=frames[j][field]?.[id];if(validPoint(p)){right={t:Number(frames[j].t),p};break;}}
    if(left&&right&&right.t-left.t>1e-6&&right.t-left.t<=maxBracket){
      const u=clamp((time-left.t)/(right.t-left.t),0,1),confidence=Math.min(left.p[3]??1,right.p[3]??1)*.72;
      reconstructed[id]=[0,1,2].map(k=>left.p[k]+(right.p[k]-left.p[k])*u).concat(confidence);
    }else{
      const candidate=[left,right].filter(Boolean).sort((a,b)=>Math.abs(a.t-time)-Math.abs(b.t-time))[0];
      if(candidate&&Math.abs(candidate.t-time)<=oneSidedTolerance)reconstructed[id]=candidate.p.slice(0,3).concat((candidate.p[3]??1)*.60);
    }
  }
  return pointVector(field==='w'?{w:reconstructed,im:[]}:{im:reconstructed,w:[]},mirror,minValid);
}

function angleAt(a,i,j,k){const A=a.slice(i*3,i*3+3),B=a.slice(j*3,j*3+3),C=a.slice(k*3,k*3+3);if(![...A,...B,...C].every(finite))return null;const u=A.map((v,n)=>v-B[n]),v=C.map((x,n)=>x-B[n]),lu=Math.hypot(...u),lv=Math.hypot(...v);if(lu<1e-5||lv<1e-5)return null;return Math.acos(clamp(u.reduce((z,x,n)=>z+x*v[n],0)/(lu*lv),-1,1));}
function angles(a){return [[0,2,4],[1,3,5],[6,8,10],[7,9,11],[6,0,2],[7,1,3],[0,6,8],[1,7,9],[8,10,12],[9,11,13],[10,12,14],[11,13,15]].map(q=>angleAt(a,...q));}
function poseDistance(a,b){if(!a||!b||a.length!==POSE_FRAME_DIM||b.length!==POSE_FRAME_DIM)return Infinity;let sum=0,weight=0;for(let j=0;j<16;j++)for(let k=0;k<3;k++){const x=a[j*3+k],y=b[j*3+k],w=JOINT_WEIGHTS[j];if(finite(x)&&finite(y)){sum+=w*(x-y)*(x-y);weight+=w;}}if(!weight)return Infinity;const aa=angles(a),bb=angles(b);let as=0,aw=0;for(let i=0;i<aa.length;i++)if(aa[i]!=null&&bb[i]!=null){const d=(aa[i]-bb[i])/Math.PI;as+=d*d;aw++;}const pos=Math.sqrt(sum/weight),ang=aw?Math.sqrt(as/aw):pos;return .78*pos+.22*ang;}
function motionDistance(ap,ac,bp,bc){let sum=0,weight=0;for(let j=0;j<16;j++)for(let k=0;k<3;k++){const d1=ac[j*3+k]-ap[j*3+k],d2=bc[j*3+k]-bp[j*3+k],w=JOINT_WEIGHTS[j];if(finite(d1)&&finite(d2)){sum+=w*(d1-d2)*(d1-d2);weight+=w;}}return weight?Math.sqrt(sum/weight):null;}
export function mirrorSignature(sig){if(!Array.isArray(sig)&&!ArrayBuffer.isView(sig))return sig;if(sig.length%POSE_FRAME_DIM!==0)return sig;const map=new Map(PATTERN_LANDMARKS.map((id,j)=>[id,j])),out=[];for(let base=0;base<sig.length;base+=POSE_FRAME_DIM){const sample=sig.slice(base,base+POSE_FRAME_DIM);for(const id of PATTERN_LANDMARKS){const other=map.get(MIRROR_JOINT[id]??id),k=other*3;out.push(-sample[k],sample[k+1],sample[k+2]);}}return out;}
export function temporalSignatureDistance(a,b){if((!Array.isArray(a)&&!ArrayBuffer.isView(a))||(!Array.isArray(b)&&!ArrayBuffer.isView(b))||!a.length||!b.length||a.length%POSE_FRAME_DIM||b.length%POSE_FRAME_DIM)return Infinity;const na=a.length/POSE_FRAME_DIM,nb=b.length/POSE_FRAME_DIM;if(na===1&&nb===1)return poseDistance(a,b);if(na<2||nb<2)return Infinity;const band=Math.max(1,Math.ceil(Math.max(na,nb)*.18));let prev=new Array(nb+1).fill(Infinity),prevLen=new Array(nb+1).fill(0);prev[0]=0;for(let i=1;i<=na;i++){const cur=new Array(nb+1).fill(Infinity),curLen=new Array(nb+1).fill(0),jMin=Math.max(1,Math.floor(i/na*nb-band)),jMax=Math.min(nb,Math.ceil(i/na*nb+band));for(let j=jMin;j<=jMax;j++){const ai=a.slice((i-1)*POSE_FRAME_DIM,i*POSE_FRAME_DIM),bj=b.slice((j-1)*POSE_FRAME_DIM,j*POSE_FRAME_DIM);let d=poseDistance(ai,bj);if(i>1&&j>1){const ap=a.slice((i-2)*POSE_FRAME_DIM,(i-1)*POSE_FRAME_DIM),bp=b.slice((j-2)*POSE_FRAME_DIM,(j-1)*POSE_FRAME_DIM),motion=motionDistance(ap,ai,bp,bj);if(finite(motion))d=.86*d+.14*motion;}if(!finite(d))continue;const choices=[{cost:prev[j-1],len:prevLen[j-1]},{cost:prev[j],len:prevLen[j]},{cost:cur[j-1],len:curLen[j-1]}].filter(q=>finite(q.cost));if(!choices.length)continue;choices.sort((x,y)=>x.cost-y.cost);cur[j]=choices[0].cost+d;curLen[j]=choices[0].len+1;}prev=cur;prevLen=curLen;}return finite(prev[nb])&&prevLen[nb]?prev[nb]/prevLen[nb]:Infinity;}
export function temporalSignatureSimilarity(a,b){const direct=temporalSignatureDistance(a,b),mirrored=temporalSignatureDistance(a,mirrorSignature(b)),d=Math.min(direct,mirrored);return{distance:d,similarity:finite(d)?Math.round(clamp(100*(1-d/.78),0,100)):0,mirrored:mirrored<direct,method:'constrained-dtw-posture-motion-v6-foot-aware'};}
