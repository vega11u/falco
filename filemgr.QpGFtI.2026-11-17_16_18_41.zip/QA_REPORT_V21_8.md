# QA report — Falco Jugger 21.8.0

This report is generated with the release package after local developer checks. It must not be interpreted as a live test on REG.RU; server-side external downloads depend on the account and host network.

## Automated checks

- PHP syntax and release smoke tests.
- JavaScript module syntax and browser-module regression tests.
- Optimizer UI contract, new playback controls and scorecard structure.
- Default-off 3D playback with still rendering on seek.
- Heel-contact inference guards: inference only on occlusion; observed raised heel remains untouched.
- Recognition module: temporal DTW, mirrored signatures, occlusion handling, lower-chain/foot sensitivity, and an explicit test that a raised heel changes similarity while 48D/384D dimensions stay unchanged.
- 3D avatar root-path reference: robust pelvis-path scaling per camera segment, bounded translation, and reset on video replacement.
- Pattern evidence UI: separate labels for shoulder, elbow/hand, pelvis, thigh/knee, shin/ankle, and heel/toe groups.
- Existing release regression suite: media import, learning API, video pipeline, depth reconstruction, biomechanics planner, scene perspective, avatar geometry, and social-import lifecycle.
- ZIP CRC, clean extraction, root-path layout, exact path manifest, and SHA-256.

## Data-compatibility controls

- The learned feature contract remains 384 numeric values per temporal window (8 frames × 16 joints × 3 coordinates).
- No storage schema migration was added.
- Existing hidden private directories `.kata-biomechanics-*` and `.kata-media-import-*` are not packaged and are not targeted by installer cleanup.
- The smoke-test learning API uses its own temporary test directory.
- Verified that setup scripts do not remove or rewrite `.kata-biomechanics-*` or `.kata-media-import-*` directories; no storage migration is introduced.

## Manual checks still required on REG.RU

- Run `bash setup-release.sh` in the site document root after a file backup.
- Keep the same site path and the adjacent `.kata-biomechanics-*` directory: its path is derived from the installation path and it is the personal learning store.
- Verify `/index.php?api=health`.
- Load a representative source video, compare normal 2D/3D seeking, then enable 3D playback if the browser has sufficient headroom.
- Confirm personal learning examples and feedback counts before and after deployment.

The browser-side test suite cannot establish the actual quality of a particular user's 3D reconstruction without their source videos and a visual review of the resulting renders.

## Final release run

The complete developer verification was run with the CRON integration enabled:

```bash
RUN_CRON_INTEGRATION=1 bash tests/verify.sh
```

Result: all checks passed, including the detached-worker/queue CRON integration test. The final ZIP is separately checked by CRC, clean extraction, path/hash comparison, and then the same release test suite is run from the extracted archive.


## Additional training-preservation audit (repack verification)
- Removed mutable `data/trained/training-manifest.json` from the distributable archive.
- Kept only `data/trained/training-manifest.json.template` as a clean-install template.
- Added a release regression assertion that fails if the runtime manifest is ever packaged.
- The personal confirmed-example library path is outside DOCUMENT_ROOT (`../.kata-biomechanics-<site-hash>/library.json`) and is not part of the archive.
- `setup-regru.sh` contains no delete/truncate operation against `.kata-biomechanics-*`, `library.json`, or `data/trained`.
- Deployment instructions explicitly prohibit mirror-delete and removal of training directories.
- Result: overlay extraction cannot replace the runtime training manifest from this ZIP; the external personal library is not touched.

## Final archive verification
- Archive: `Falco-Jugger-v21.8.0-FULL-DEPLOY-REG.RU-TRAINING-SAFE.zip`
- ZIP entries: 127; root layout (no enclosing project directory); `tests/` and all installer entry points included.
- `unzip -t`: no CRC or compression errors.
- Full developer suite: `RUN_CRON_INTEGRATION=1 bash tests/verify.sh` passed from a clean extraction of the final ZIP.
- Overlay preservation simulation: pre-existing `data/trained/training-manifest.json` sentinel and external `.kata-biomechanics-* / library.json` sentinel retained byte-for-byte after extracting the ZIP over an existing installation.
- Final SHA-256 is supplied alongside the archive.
