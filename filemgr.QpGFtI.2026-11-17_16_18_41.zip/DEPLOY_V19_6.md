# Falco Jugger v19.6.0 — установка и обновление REG.RU

1. Сделайте резервную копию каталога сайта и соседней приватной библиотеки `.kata-biomechanics-*`.
2. Распакуйте архив поверх проекта. Не удаляйте `data/`, `training-data/`, пользовательские записи и приватные каталоги `.kata-*`.
3. Из корня приложения запустите `bash setup-release.sh`. Для повторной установки только загрузчиков используйте `bash setup-media-import.sh`.
4. Откройте HTTPS-сайт с жёстким обновлением страницы и проверьте `index.php?api=health`.

## Контроль состояния

- YouTube: `yt_dlp_stable=true`, `youtube_ejs_runtime=true`, `youtube_ready=true`.
- Instagram: `yt_dlp_stable=true`, `instagram_ready=true`.
- Локальное видео: `local_video_pipeline.mediabunny_demuxer_installed=true`, `prores_decoder_installed=true`, `ffmpeg_wasm_installed=true`.
- Если веб-PHP отключает `proc_open`, установите CRON REG.RU на запуск `/bin/bash /полный/путь/к/сайту/media-import-cron.sh` раз в минуту.

## Важные детали

Социальные ссылки обрабатываются единственным официальным standalone `yt-dlp`; Deno 2 нужен только YouTube для EJS challenge solver. Установщик не запускает `deno cache`, не ставит Composer/npm и не требует системных Python, pip, Node.js или root. Установка проверяет SHA-256 бинарников и SHA-512 npm-архивов.

Локальные видео не передаются на сервер. Путь декодирования: Mediabunny → официальный `@mediabunny/prores` для ProRes MOV → FFmpeg.wasm, если декодирование или конвертация через Mediabunny не удались. MediaRecorder не используется для входного перекодирования.

Пользовательские данные и учебная библиотека не должны удаляться установщиком. Реальная доступность конкретного YouTube/Instagram ролика зависит от ограничений платформы и IP хостинга; локальные smoke-тесты не могут подтвердить live-доступ. Поддержка MOV также зависит от фактического кодека и памяти/возможностей браузера.
