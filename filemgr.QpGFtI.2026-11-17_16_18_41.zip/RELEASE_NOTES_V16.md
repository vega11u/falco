# Kata Biomechanics Analyzer v16 — personal learning and subjective feedback

## What changed

- Post-analysis feedback panel with optional 1–10 ratings for technique, subjective biomechanics impression, power, speed and balance.
- Manual confirmation/rejection of discovered patterns and explicit confirmation before the kata/sequence signature is added to the personal reference library.
- Full kata signatures are guarded by an exact 1,152-feature contract (24 temporal samples × 48 values); partial ranges cannot be promoted as a complete kata.
- The biomechanics score is saved as opinion only. It does not affect objective kinematic/biomechanical metrics and is excluded from the personal preference tie-breaker.
- Technique, power, speed and balance scores can only act as a secondary tie-breaker for near-identical template matches; they never change measured angles, speeds or other physical outputs.
- Stored vectors are packed as 16-bit quantised data; old float arrays are migrated on the next write. Unconfirmed candidates are not persisted as training vectors.
- The setup script does not download large research corpora or train local corpus models by default. Existing bounded corpus setup remains opt-in through `KATA_ENABLE_LOCAL_CORPUS_TRAINING=1`.

## Important meaning of training

The user-learning path is incremental, confirmed-example retrieval with constrained DTW. It does not retrain MediaPipe or a neural network. This keeps server CPU/RAM/storage requirements low and makes each confirmed reference immediately available to the matcher. It also means that feedback cannot repair a bad pose estimate or guarantee correct classification.

See [`docs/CONTINUAL_LEARNING_ARCHITECTURE.md`](docs/CONTINUAL_LEARNING_ARCHITECTURE.md) for architecture, storage limits and measurement boundaries.
