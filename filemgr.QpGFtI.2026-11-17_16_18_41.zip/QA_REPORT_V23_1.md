# QA report — Falco Jugger 23.1.0

## Visual and interaction verification

- Rendered the PHP analyzer and Purcell pages with Chromium at 1440 px and 390 px viewport widths.
- Confirmed the bundled `Falco Inter` family is applied to brand, headings, labels, controls and methodology cards.
- Confirmed no horizontal overflow at 390 px.
- Confirmed `cameraAngleChanges`, `clothingSurface` and `depthEstimation` are present exactly once on both analyzer and Purcell pages and live inside the visible, open analysis settings container.
- Confirmed the optimizer 3D subview remains intentionally hidden under the existing performance guard; the primary spatial 3D projection remains unchanged.
- Confirmed Memories uses the same local font / stylesheet without a Google Fonts request.

## Automated verification

The release suite includes PHP syntax, browser JS syntax, storage/API compatibility, import policy, video runtime, trim/player, biomechanics, Purcell baseline, optimizer, report archive, and UI smoke tests. The UI smoke tests now assert the restored checkboxes and the analysis-settings container in both page modes.

## Compatibility

- `VERSION`: 23.1.0.
- No database schema migration.
- No API payload or private storage path change.
- No learning feature dimension or model weight change.
- No change to frame decode / pose inference / depth worker cadence.
- No Python, Node, npm or build step on REG.RU Host-0.

## Limits

Local Chromium screenshots and automated tests do not replace testing on the user's actual REG.RU account, phone, browser, GPU or long-form kata videos. Social import success still depends on public source availability, current extractor support and host network egress.

## Final run

- `bash tests/verify.sh` — PASS, all standard release checks.
- `bash tests/media-import-cron-smoke.sh` — PASS, including two-session queue serialization, disabled PHP `proc_open`, bounded transfer, SHA-256 acknowledgement and cleanup.
- `php -l` for `index.php`, `Memories.php`, `uppurcell.php` — PASS.
- `bash -n` for shipped shell scripts — PASS.
- CSS parser — 0 syntax errors.
- Chromium visual inspection: analyzer / Purcell / Memories at 1440 px and analyzer at 390 px; local font face confirmed loaded and no horizontal overflow.
