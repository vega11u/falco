# Falco Jugger 27.2.2-C.D2 — Deep UI Cleanup & Consolidation

Патч собран поверх предоставленного архива `filemgr.8DODxS.2026-11-16_23_56_46.zip`, который содержит Falco Jugger 23.0.27 + Research C/D2 27.2.1.

## Что исправлено

### CSS / D2
- Удалены 46 CSS-only legacy selector names, не имеющих ссылок в runtime PHP/JS/MJS/HTML исходниках архива. Удалялись отдельные ветви групповых селекторов, а не целые группы с активными компонентами.
- Удалены 30 конкретных устаревших визуальных деклараций, которые были перекрыты утверждённым D2-правилом, и 18 точных повторов деклараций. Различающиеся fallback-значения (`100vh`/`100dvh`, `overflow-x:hidden`/`clip`, safe-area) сохранены.
- Удалены старые hard-coded lime акценты и заменены на D2 токены.
- Исторические комментарии 26.1–26.3 переименованы в функциональные разделы. Рабочие responsive, safe-area, reduced-motion и annotation-state правила сохранены.
- Остаётся одна активная таблица `falco-jugger-ui.css`; внешние старые CSS-файлы в предоставленном live-root не обнаружены.

### PHP / inline styles
- Перенесено 97 статических inline-style атрибутов из `index.php`, `models.php` и `purcell-lab.php` в именованные классы единого CSS.
- В `models.php` заменены 10 статических JS style assignments на классы.
- В `index.php` заменены статические изменения курсора и цвета индикатора сервера на классы состояния.
- Оставлены 4 динамических inline-style атрибута в `index.php`: вычисляемые ширины progress/quality bars и позиция/ширина timeline segment. Это значения текущего кадра/прогресса, не старый визуальный слой.
- Динамические `style.width`, `style.left` и `style.transform` в плеере/обрезке/прогрессе сохранены: они управляют геометрией в реальном времени.

### GC / диагностика
- `falco-gc.sh` по-прежнему использует только явный allowlist и переносит кандидатов в карантин вне webroot. Он не удаляет PHP/JS-фрагменты, данные, отчёты, обученные модели или кеш.
- Исправлены переносы строк в GC-отчёте.
- Добавлен read-only `tools/falco-ui-cleanup-audit.php`: проверяет активные CSS-файлы, ссылки страниц, статические/dynamic inline styles, inline style blocks, @import и баланс CSS.
- `audit-css-references.php` теперь запускает полный read-only аудит.

## Что намеренно НЕ удалено
- `hard-update-v23.0.19.js` используется всеми пятью основными страницами.
- `falco24-learning-centers.js` используется `lully.php` и `purcell-lab.php`.
- `falco-jugger-ui.js` используется всеми пятью основными страницами.
- Все остальные анализаторы и модели оставлены: отсутствие прямой ссылки из PHP не доказывает отсутствие импорта из другого ES-модуля.
- В исходном allowlist 21 старый CSS/JS путь отсутствовал в live-root. GC фиксирует `ALLOWLIST_ENTRY_ABSENT`, не создавая пустые файлы и не удаляя что-либо ещё.
- `.falco-rollback`, `data`, `data/trained`, отчёты, приватные конфигурации, source media и model cache не входят в список изменяемых путей.

## Установка на Reg.ru Host-0

Положить `Falco_Jugger_UI_CLEANUP_27_2_2_OVER_27_2_1_HOST0.zip` в `$HOME/www/falcojugger.art`.

Сначала dry-run:

```bash
cd "$HOME/www/falcojugger.art" && ( T="$(mktemp -d)" && trap 'rm -rf "$T"' EXIT && unzip -q Falco_Jugger_UI_CLEANUP_27_2_2_OVER_27_2_1_HOST0.zip -d "$T" && bash "$T/install-host0-c-d2-cleanup-27.2.2.sh" "$PWD" --dry-run )
```

После успешной проверки:

```bash
cd "$HOME/www/falcojugger.art" && ( T="$(mktemp -d)" && trap 'rm -rf "$T"' EXIT && unzip -q Falco_Jugger_UI_CLEANUP_27_2_2_OVER_27_2_1_HOST0.zip -d "$T" && bash "$T/install-host0-c-d2-cleanup-27.2.2.sh" "$PWD" --install )
```

Установщик принимает родительскую версию 27.2.1-C.D2 (повторное применение 27.2.2 также допускается), проверяет SHA-256 файлов пакета, PHP 8.1+, создаёт резервную копию изменяемых файлов в `$HOME/.falco-backups/`, атомарно заменяет только allowlisted файлы и выполняет read-only аудит после установки.

## Важно
Этот релиз — зачистка CSS/PHP-разметки и диагностических инструментов. Он не меняет алгоритмы реконструкции, глубину, консенсус, обучение Lully/Purcell или веса моделей.
