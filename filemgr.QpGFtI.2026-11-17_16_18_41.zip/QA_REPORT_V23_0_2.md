# QA report — Falco Jugger 23.0.2

## Result

The patch's targeted release checks pass. Existing PHP report/library, learning API, Purcell, media-import and local-video contracts remain in place. No server-side report or model storage directory is part of the patch.

## Checks run

- PHP syntax: `index.php`, `Memories.php`, `tests/release-smoke.php` — pass.
- Browser JavaScript syntax: inline scripts from `index.php` and `Memories.php`; `depth-worker.js`; `depth-reconstruction-core.mjs` — pass.
- Depth reconstruction smoke — pass; single-model provenance is explicit, unknown legacy provenance is not mislabeled Base, and no ensemble-agreement value is fabricated.
- Depth mode policy smoke — pass; Base is default, Small requires the user switch, and WebGPU/WASM fallback remains within the selected model.
- Workspace recovery policy smoke — pass; analyzer/Purcell drafts are isolated, frame chunks are incremental, and quota fallback is explicit.
- v23.0.2 trim/journal/recovery/depth/Lully smoke — pass.
- Frutiger Aero, v23.0.1 compatibility, v22.2 studio and release smoke — pass.
- Intelligence-data, local-video, JavaScript syntax, v22, social-file lifecycle, media-import, LUX-only cron, optimizer, learning API, server report library and Purcell/report API tests — pass when run individually.

## Scope limits

- The full `tests/verify.sh` orchestration exceeded the execution environment's 360-second aggregate command limit. The long-running media-import and LUX-only cron checks were then run separately and passed. The optional detached cron integration (`RUN_CRON_INTEGRATION=1`) was not run.
- A headless Chromium screenshot did not complete in this execution environment. Responsive breakpoints, CSS contracts, markup and JavaScript syntax were checked, but final visual sign-off should still be done in the deployment browser at desktop and mobile widths.
- No production server deployment was performed. Server report and learning API regression tests passed against the local test harness.

## Compatibility notes

The 2D player implementation, PHP endpoint names, report payload formats, Lully learning schema, Purcell storage schema and server-side report library were not migrated. The IndexedDB draft is a browser recovery checkpoint only; permanent reports remain in the server library.
