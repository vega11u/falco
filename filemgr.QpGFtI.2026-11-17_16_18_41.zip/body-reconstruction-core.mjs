/** Falco Jugger articulated 2D/3D body reconstruction 23.0.13.
 * Uses visible MediaPipe observations, gated relative-depth evidence and time.
 * Does not hallucinate long occlusions or claim calibrated 3D coordinates.
 * Pure module: callers decide whether to promote the result to canonical inputs.
 */
export const BODY_RECONSTRUCTION_VERSION = 'falco-articulated-body-v2-dual-learning';
const J=33;
const BONES=[[11,12],[11,13],[13,15],[15,17],[15,19],[15,21],[12,14],[14,16],[16,18],[16,20],[16,22],[11,23],[12,24],[23,24],[23,25],[25,27],[27,29],[29,31],[24,26],[26,28],[28,30],[30,32]];
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const finite=Number.isFinite;
const median=arr=>{if(!arr.length)return null;const v=[...arr].sort((a,b)=>a-b),n=v.length;return n%2?v[(n-1)/2]:(v[n/2-1]+v[n/2])/2;};
const good=(p,d=2,c=.10)=>Array.isArray(p)&&p.length>=d&&p.slice(0,d).every(finite)&&(p[3]??1)>=c;
const clonePoints=(input)=>Array.from({length:J},(_,j)=>Array.isArray(input?.[j])?input[j].slice(0,4):null);
const norm=(a,b,d)=>Math.hypot(...Array.from({length:d},(_,k)=>(a[k]||0)-(b[k]||0)));
const root=(pts,d)=>[23,24].every(k=>good(pts[k],d,.24))?Array.from({length:d},(_,i)=>(pts[23][i]+pts[24][i])*.5):null;
function scaleFromFrame(image,world,aspect){const ri=root(image,2),rw=root(world,3);if(!ri||!rw)return null;
  const ratios=[];for(const id of [11,12,13,14,23,24,25,26,27,28]){const p=image[id],q=world[id];if(!good(p,2,.55)||!good(q,3,.55))continue;const a=norm([p[0]*aspect,p[1]],[ri[0]*aspect,ri[1]],2),b=norm(q,rw,3);if(b>.09&&a>.025&&a<2)ratios.push(a/b);}
  if(ratios.length<4)return null;const scale=median(ratios);return scale>.04&&scale<5?{scale,ri,rw,confidence:clamp(ratios.length/12,.22,1)}:null;
}
function calibratedDepth(frame){const im=frame.im||[],world=frame.w||[],depth=frame.render_depth_landmark_values||frame.depth_landmark_values||[],agreement=frame.render_depth_agreement_values||frame.depth_agreement_values||[];
 const pairs=[];for(let i=0;i<J;i++)if(good(im[i],2,.55)&&good(world[i],3,.55)&&finite(depth[i])&&(!finite(agreement[i])||agreement[i]>=.48))pairs.push([depth[i],world[i][2]]);
 if(pairs.length<8)return null;
 const x=median(pairs.map(p=>p[0])),y=median(pairs.map(p=>p[1]));let cov=0,vx=0,vy=0;for(const [a,b] of pairs){cov+=(a-x)*(b-y);vx+=(a-x)**2;vy+=(b-y)**2;}if(vx<1e-5||vy<1e-5)return null;
 const corr=cov/Math.sqrt(vx*vy),slope=clamp(cov/vx,-3,3);if(Math.abs(corr)<.42||Math.abs(slope)<.025)return null;
 return {slope,intercept:y-slope*x,reliability:clamp((Math.abs(corr)-.35)*1.3,0,.72),count:pairs.length};
}
function modelToImage(p,cal,aspect){if(!p||!cal)return null;return [clamp(cal.ri[0]+(p[0]-cal.rw[0])*cal.scale/aspect,-.2,1.2),clamp(cal.ri[1]+(p[1]-cal.rw[1])*cal.scale,-.2,1.2)];}
function modelToWorld(p,z,cal,aspect){if(!p||!cal||!finite(z))return null;return [cal.rw[0]+(p[0]-cal.ri[0])*aspect/cal.scale,cal.rw[1]+(p[1]-cal.ri[1])/cal.scale,z];}
function groupSegments(frames){const groups=[];let g=null;for(let i=0;i<frames.length;i++){const camera=frames[i].camera_segment_id??0,t=Number(frames[i].t);if(!g||camera!==g.camera||i>0&&(!(t>frames[i-1].t)||t-frames[i-1].t>.8)){g={camera,first:i,last:i};groups.push(g);}else g.last=i;}return groups;}
function computeBonePriors(frames,first,last){const maps=new Map(),stride=Math.max(1,Math.floor((last-first+1)/2400));for(const [a,b] of BONES){const arr=[];for(let i=first;i<=last;i+=stride){const w=frames[i].w;if(good(w?.[a],3,.60)&&good(w?.[b],3,.60)){const d=norm(w[a],w[b],3);if(d>.015&&d<1.2)arr.push(d);}}if(arr.length>=6){const med=median(arr),deviation=median(arr.map(x=>Math.abs(x-med)))||.005;maps.set(a+':'+b,{length:med,mad:deviation,observations:arr.length});}}return maps;}
function estimateCamera(frames,first,last,aspect){const valid=[];const stride=Math.max(1,Math.floor((last-first+1)/1800));for(let i=first;i<=last;i+=stride){const cal=scaleFromFrame(frames[i].im||[],frames[i].w||[],aspect);if(cal)valid.push(cal.scale);}const typical=median(valid)||null;return {typical_scale:typical,confidence:valid.length>8?clamp(valid.length/80,.2,1):0,observations:valid.length};}
const pointConfidence=p=>clamp(Number(p?.[3])||0,0,1);
const defaultConf=(p,d)=>good(p,d,.12)?pointConfidence(p):0;
function fillFromProjection(rows,i,cal,depth,aspect,stats){const item=rows[i],im=item.im,w=item.w,cI=item.cI,cW=item.cW;
 for(let j=0;j<J;j++){
  if(cI[j]<.32&&cW[j]>.6&&good(w[j],3,.6)&&cal){const q=modelToImage(w[j],cal,aspect);if(q&&q.every(x=>x>-.03&&x<1.03)){im[j]=[...q,w[j][2],Math.min(.52,cW[j]*cal.confidence*.65)];cI[j]=Math.min(.52,cW[j]*cal.confidence*.65);stats.projected2d++;}}
  if(cW[j]<.26&&cI[j]>.55&&good(im[j],2,.55)&&cal&&depth){const value=item.frame.render_depth_landmark_values?.[j]??item.frame.depth_landmark_values?.[j],agreement=item.frame.render_depth_agreement_values?.[j]??item.frame.depth_agreement_values?.[j];if(finite(value)&&(!finite(agreement)||agreement>=.55)){const z=depth.slope*value+depth.intercept,xyz=modelToWorld(im[j],z,cal,aspect);if(xyz&&xyz.every(x=>Math.abs(x)<3)){w[j]=[...xyz,Math.min(.46,.38*depth.reliability+.12)];cW[j]=Math.min(.46,.38*depth.reliability+.12);stats.projected3d++;}}}
 }
}
function repairTemporally(rows,first,last,key,dimension,stats,{maxGap=.16,maxSpikeGap=.12,onProgress=null,phase='repair'}={}){
 const confKey=key==='im'?'cI':'cW';
 for(let j=0;j<J;j++){
  // Temporal spikes are rejected ONLY when strong neighbouring agreement supports a single isolated error.
  for(let i=first+1;i<last;i++){
   const prev=rows[i-1],cur=rows[i],next=rows[i+1],a=prev[key][j],b=cur[key][j],c=next[key][j],dt=next.t-prev.t;
   if(!(dt>0&&dt<=maxSpikeGap&&good(a,dimension,.2)&&good(b,dimension,.12)&&good(c,dimension,.2)))continue;
   const u=(cur.t-prev.t)/dt,pred=Array.from({length:dimension},(_,k)=>a[k]+(c[k]-a[k])*u),span=norm(a,c,dimension),residual=norm(b,pred,dimension);
   const unit=dimension===2?.20:.28;
   if(span>unit*.72||residual<unit||residual<span*2.8||cur[confKey][j]>.70&&residual<unit*2.6)continue;
   const confidence=Math.min(.43,Math.max(.16,Math.min(prev[confKey][j],next[confKey][j])*.70));cur[key][j]=dimension===2?[pred[0],pred[1],b?.[2]??0,confidence]:[...pred,confidence];cur[confKey][j]=confidence;stats.spikes_rejected++;
  }
  // Fill SHORT gaps bracketed in the SAME camera segment; never extrapolate into long occlusion.
  let anchor=first;while(anchor<=last){while(anchor<=last&&!good(rows[anchor][key][j],dimension,.22))anchor++;if(anchor>last)break;
   let next=anchor+1;while(next<=last&&!good(rows[next][key][j],dimension,.22))next++;if(next>last)break;
   if(next>anchor+1){const dt=rows[next].t-rows[anchor].t;if(dt>.003&&dt<=maxGap){const a=rows[anchor][key][j],b=rows[next][key][j],span=norm(a,b,dimension),unit=dimension===2?.28:.46;
     if(span<=unit){for(let x=anchor+1;x<next;x++){const u=(rows[x].t-rows[anchor].t)/dt,pts=Array.from({length:dimension},(_,k)=>a[k]+(b[k]-a[k])*u),confidence=clamp(Math.min(rows[anchor][confKey][j],rows[next][confKey][j])*.52,.15,.46);rows[x][key][j]=dimension===2?[pts[0],pts[1],0,confidence]:[...pts,confidence];rows[x][confKey][j]=confidence;stats.interpolated++;}}}}
   anchor=next;
  }
  // Very-low-amplitude denoising only for low-confidence, near-static movements.
  for(let i=first+1;i<last;i++){const prev=rows[i-1],cur=rows[i],next=rows[i+1],a=prev[key][j],b=cur[key][j],c=next[key][j];if(!(good(a,dimension,.24)&&good(b,dimension,.20)&&good(c,dimension,.24)))continue;
   const dt=next.t-prev.t,unit=dimension===2?.024:.030;if(!(dt>0&&dt<=.15))continue;
   const displacement=norm(a,c,dimension),mid=Array.from({length:dimension},(_,k)=>(a[k]+c[k])/2),deviation=norm(mid,b,dimension);if(displacement>unit*2.5||deviation>unit||cur[confKey][j]>.72)continue;
   const factor=.22*(1-cur[confKey][j]);for(let k=0;k<dimension;k++)b[k]+=factor*(mid[k]-b[k]);stats.denoised++;}
  if(onProgress&&(j%2===1||j===J-1))onProgress({phase,completed:j+1,total:J,segment_first:first,segment_last:last});
 }
}
function enforceBones(rows,first,last,priors,stats,{onProgress=null}={}){
 for(let i=first;i<=last;i++){const item=rows[i],w=item.w,c=item.cW;if(!w?.length)continue;
  for(let pass=0;pass<4;pass++)for(const [a,b] of BONES){const prior=priors.get(a+':'+b);if(!prior||!good(w[a],3,.14)||!good(w[b],3,.14))continue;
   const distance=norm(w[a],w[b],3),desired=prior.length;if(distance<.002)continue;
   const error=distance-desired,tolerance=Math.max(.012,desired*.13,prior.mad*3);if(Math.abs(error)<=tolerance)continue;
   const pa=c[a],pb=c[b],ra=Math.max(.04,1-pa),rb=Math.max(.04,1-pb),total=ra+rb;
   // No single observation is displaced more than ~5cm by one pass.
   const shift=clamp(error*.48,-.05,.05),dx=Array.from({length:3},(_,k)=>(w[b][k]-w[a][k])/distance*shift);
   for(let k=0;k<3;k++){w[a][k]+=dx[k]*ra/total;w[b][k]-=dx[k]*rb/total;}stats.bone_adjustments++;
  }
  if(onProgress&&i%512===0)onProgress({phase:'bone-constraints',completed:i-first+1,total:last-first+1,segment_first:first,segment_last:last});
 }
}
function updateImageFromWorld(rows,first,last,aspect,{onProgress=null}={}){for(let i=first;i<=last;i++){const item=rows[i],cal=item.cal;if(cal&&cal.confidence>=.5)for(let j=0;j<J;j++)if(item.cI[j]<.44&&item.cW[j]>.48&&good(item.w[j],3,.48)){const p=modelToImage(item.w[j],cal,aspect);if(p&&p.every(x=>x>=0&&x<=1)){item.im[j]=[p[0],p[1],item.im[j]?.[2]??0,Math.min(.48,item.cW[j]*.68)];item.cI[j]=Math.min(.48,item.cW[j]*.68);}}
 if(onProgress&&i%512===0)onProgress({phase:'image-projection',completed:i-first+1,total:last-first+1,segment_first:first,segment_last:last});}}
/** Reconstruction is a separate pass. Caller can promote returned im/w into the canonical analysis fields. */
export function reconstructBodySequence(frames,{aspect=1,maxGap=.16,onProgress=null}={}){
 const stats={schema:BODY_RECONSTRUCTION_VERSION,frames:frames?.length||0,camera_segments:0,projected2d:0,projected3d:0,interpolated:0,spikes_rejected:0,denoised:0,bone_adjustments:0,quality_2d:0,quality_3d:0,frames_reconstructed:0,world_frames_available:0,limitations:'Relative articulated landmarks only; body-centred 3D without camera calibration, external forces or reliable hidden surface.'};
 if(!Array.isArray(frames)||!frames.length)return {tracks:[],diagnostics:stats};
 aspect=finite(aspect)&&aspect>.1&&aspect<8?aspect:1;
 const emit=(phase,completed,total,extra={})=>{if(typeof onProgress==='function'){try{onProgress({phase,completed,total,progress:total?clamp(completed/total,0,1):0,...extra});}catch(_){}}};
 const rows=frames.map(f=>{const im=clonePoints(f.im),w=clonePoints(f.w);return {frame:f,t:Number(f.t)||0,im,w,cI:im.map(p=>defaultConf(p,2)),cW:w.map(p=>defaultConf(p,3)),cal:null};});
 emit('prepare',0,frames.length);
 let segmentDone=0;
 for(const seg of groupSegments(frames)){
  stats.camera_segments++;const {first,last}=seg,segmentTotal=last-first+1,cam=estimateCamera(frames,first,last,aspect),bone=computeBonePriors(frames,first,last);
  emit('camera-calibration',segmentDone,frames.length,{segment_first:first,segment_last:last});
  for(let i=first;i<=last;i++){let cal=scaleFromFrame(rows[i].im,rows[i].w,aspect);if(cal&&cam.typical_scale&&Math.abs(Math.log(cal.scale/cam.typical_scale))>.72)cal=null;
   rows[i].cal=cal;const depth=cal?calibratedDepth(frames[i]):null;if(cal)fillFromProjection(rows,i,cal,depth,aspect,stats);
   if((i-first)%256===0)emit('paired-projection',segmentDone+i-first+1,frames.length,{segment_first:first,segment_last:last});
  }
  repairTemporally(rows,first,last,'im',2,stats,{maxGap,onProgress:p=>emit('temporal-2d',segmentDone+Math.round((p.completed/p.total)*segmentTotal),frames.length,{detail:p.phase,segment_first:first,segment_last:last})});
  repairTemporally(rows,first,last,'w',3,stats,{maxGap,onProgress:p=>emit('temporal-3d',segmentDone+Math.round((p.completed/p.total)*segmentTotal),frames.length,{detail:p.phase,segment_first:first,segment_last:last})});
  enforceBones(rows,first,last,bone,stats,{onProgress:p=>emit(p.phase,segmentDone+p.completed,frames.length,{segment_first:first,segment_last:last})});
  updateImageFromWorld(rows,first,last,aspect,{onProgress:p=>emit(p.phase,segmentDone+p.completed,frames.length,{segment_first:first,segment_last:last})});
  segmentDone+=segmentTotal;emit('segment-complete',segmentDone,frames.length,{segment_first:first,segment_last:last});
 }
 const tracks=rows.map(item=>{const n2=item.cI.filter(v=>v>=.18).length,n3=item.cW.filter(v=>v>=.18).length,q2=item.cI.reduce((s,x)=>s+x,0)/J,q3=item.cW.reduce((s,x)=>s+x,0)/J;stats.quality_2d+=q2;stats.quality_3d+=q3;if(n2>=7)stats.frames_reconstructed++;if(n3>=7)stats.world_frames_available++;
  const im=item.im.map((p,j)=>good(p,2,.1)&&p[0]>=0&&p[0]<=1&&p[1]>=0&&p[1]<=1?[p[0],p[1],p[2]??0,item.cI[j]]:null);
  const w=item.w.map((p,j)=>good(p,3,.1)&&Math.max(...p.slice(0,3).map(Math.abs))<5?[p[0],p[1],p[2],item.cW[j]]:null);
  return {im,w,body_reconstruction:{quality_2d:q2,quality_3d:q3,valid_2d:n2,valid_3d:n3,source:'paired-2d3d-reconstruction',schema:BODY_RECONSTRUCTION_VERSION}};
 });
 stats.quality_2d=Number((stats.quality_2d/frames.length).toFixed(4));stats.quality_3d=Number((stats.quality_3d/frames.length).toFixed(4));stats.coverage_2d=stats.frames_reconstructed/frames.length;stats.coverage_3d=stats.world_frames_available/frames.length;
 emit('complete',frames.length,frames.length,{diagnostics:stats});
 return {tracks,diagnostics:stats};
}
