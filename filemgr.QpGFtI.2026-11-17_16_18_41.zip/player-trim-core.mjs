/** Shared player/trim math. Time values remain seconds; no change to saved range schemas. */
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

export function parseVideoTimecode(value) {
  const text = String(value ?? '').trim().replace(',', '.');
  if (/^\d+(?:\.\d+)?$/.test(text)) return Number(text);
  const match = /^(\d+):([0-5]?\d)(?:\.([0-9]+))?$/.exec(text);
  if (match) return Number(match[1]) * 60 + Number(match[2]) + Number('0.' + (match[3] || '0'));
  const hours = /^(\d+):([0-5]?\d):([0-5]?\d)(?:\.([0-9]+))?$/.exec(text);
  if (hours) return Number(hours[1]) * 3600 + Number(hours[2]) * 60 + Number(hours[3]) + Number('0.' + (hours[4] || '0'));
  return NaN;
}

export function normalizeClipRange(start, end, duration, fps = 30, moving = 'both') {
  const d = Number.isFinite(Number(duration)) ? Math.max(0, Number(duration)) : 0;
  const rate = Number.isFinite(Number(fps)) && Number(fps) > 0 ? Number(fps) : 30;
  const gap = Math.min(d, 1 / rate);
  let a = Number.isFinite(Number(start)) ? clamp(Number(start), 0, d) : 0;
  let b = Number.isFinite(Number(end)) ? clamp(Number(end), 0, d) : d;
  if (moving === 'start') { b = Math.max(gap, b); a = Math.min(a, b - gap); }
  else { a = Math.min(a, Math.max(0, d - gap)); b = Math.max(b, a + gap); }
  return { start: a, end: b, duration: b - a, minGap: gap };
}

/** Uses actual available presentation times (including variable-rate archives), without an O(n) scan. */
export function adjacentFrameTime(frames, currentTime, direction, fps = 30, duration = Infinity) {
  const time = Number.isFinite(Number(currentTime)) ? Number(currentTime) : 0;
  const step = direction < 0 ? -1 : 1;
  const epsilon = 1e-5;
  if (frames?.length) {
    let lo = 0, hi = frames.length;
    const target = time + (step > 0 ? epsilon : -epsilon);
    while (lo < hi) {
      const mid = (lo + hi) >>> 1;
      if (Number(frames[mid].t) < target) lo = mid + 1; else hi = mid;
    }
    const index = step < 0 ? lo - 1 : lo;
    return Number(frames[clamp(index, 0, frames.length - 1)].t);
  }
  const rate = Number.isFinite(Number(fps)) && Number(fps) > 0 ? Number(fps) : 30;
  return clamp(time + step / rate, 0, Math.max(0, Number(duration) || 0));
}

/** Editable/native controls keep their own keyboard behavior. */
export function playerShortcut(event) {
  if (event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey || event.isComposing) return null;
  const target = event.target;
  if (target?.isContentEditable || target?.closest?.('input,textarea,select,button,a,[role="slider"],[role="textbox"],[contenteditable]')) return null;
  if (event.key === ' ' || event.key?.toLowerCase() === 'k') return { type: 'toggle' };
  if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') return { type: event.shiftKey ? 'seek' : 'frame', delta: event.key === 'ArrowLeft' ? -1 : 1 };
  if (event.key?.toLowerCase() === 'i') return { type: 'boundary', boundary: 'start' };
  if (event.key?.toLowerCase() === 'o') return { type: 'boundary', boundary: 'end' };
  if (event.key === 'Home') return { type: 'home' };
  if (event.key === 'End') return { type: 'end' };
  return null;
}
