# Falco Jugger 23.0.0

- Replaced the active Baroque skin with a detailed Frutiger Aero visual system across analyzer, Purcell workspace and report archive. Legacy stylesheet remains shipped but unused.
- Preserved all existing UI IDs, player/trim controls, workers, APIs, storage paths, database/data formats and private learning libraries.
- Expanded Purcell's pre-training theory additively: preparation → initiation → acceleration → terminal phase → deceleration → recoil → next-element readiness; trajectory-level optimization; functional anatomy; evidence/confidence policy; concise constrained explanations; explicit Lully/Purcell role separation.
- Added generic public-video import support for TikTok, VK/VK Video, Rutube, X/Twitter and Facebook/FB Watch via yt-dlp, retaining existing YouTube/Instagram recovery profiles and Lux fallback.
- Retained every-source-frame MediaPipe inference and bounded sparse depth inference. No unsafe frame thinning or unbounded GPU queue was introduced.
- Updated release regression tests and deployment documentation.

## Limits

Single-view RGB video cannot directly measure EMG, muscle force, joint moments, true ground reaction forces or tissue strain. New social extractors are best-effort and depend on upstream platform changes, public availability and hosting network access.
