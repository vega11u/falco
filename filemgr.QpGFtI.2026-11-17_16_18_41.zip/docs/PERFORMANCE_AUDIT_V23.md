# Processing audit in v23

The capture loop keeps every decoded source sample and limits optional depth work to two in-flight jobs. Pose and depth run in workers, and the report records capture wall time, pose RPC time, decode time, depth backpressure, source cadence and throughput separately. This prevents display refresh rate from being confused with analysis FPS.

Depth normalisation and fusion are shared through `depth-map-core.mjs`; valid quantiles use bounded sampling, maps are downsampled once, and confidence/age gates prevent an old joint estimate from being carried across an occlusion. The depth worker disposes model tensors and the capture loop clears pending jobs on stop and fatal worker recovery.

The practical limit is device inference speed. A slower device may still take longer than real time; the application preserves temporal correctness and reports the measured rate instead of dropping frames to make a number look higher.
