# Falco Jugger — trajectory refinement and biomechanics limits

## What v20.0 actually optimizes

The browser module `biomechanics-core.mjs` performs a conservative kinematic trajectory refinement, not a claim of globally optimal karate technique. It targets high-frequency landmark jitter while preserving the observed time base and meaningful events.

The objective is confidence-weighted temporal regularization. For an interior observation at time `t_i`, the algorithm compares the observed coordinate with a time-aware linear prediction between its neighbours. Corrections are weaker for high-confidence observations and stronger for uncertain observations. It uses short, bounded iterations; maximum displacement is capped at 0.006 in normalized image coordinates and 0.010 m in MediaPipe world coordinates.

Hard constraints:
- first and last analysed frames;
- nearest samples to the detected boundaries of recognized events;
- ankle, heel and toe landmarks for the foot selected as supporting foot, when the support confidence is at least 0.68;
- original timestamps, frame order and labels.

The optimizer reports acceleration RMS before/after, relative MAD of world-space bone lengths, maximum displacement and anchor counts. If acceleration RMS does not improve, it returns the source trajectory unchanged and disables guide-video export. Bone-length dispersion is monitored, not forced to an assumed ideal skeleton. This avoids silently imposing a generic body template on an individual athlete.

The selected priority changes regularization strength only. It does not change video speed, retime actions, infer muscle forces or prove that an action is mechanically more efficient. In particular, “speed” means the least intrusive correction to preserve fast transitions; it is not an optimization that makes a punch faster.

## Recognition and missing landmarks

`kata-recognition-core.mjs` constructs a 48-dimensional pelvis-centred, torso-normalized pose feature per time sample. A joint missing in the selected sample may be interpolated only when valid observations bracket the time within 0.17 s (or a single valid observation is within 0.045 s). Interpolated values receive reduced confidence. A long gap is not filled. These temporary values are used only for retrieval features; raw landmarks, per-frame metrics, velocity, acceleration and reports retain the measured/detected values and existing short-gap repair policy.

The constrained DTW matcher combines posture/joint-angle distance with a 14% temporal-motion term. This discourages matching a sequence solely because it passes through similar static poses while moving in the opposite temporal direction. The 48-D feature layout is unchanged, so existing confirmed examples remain readable. This is retrieval against confirmed user-labelled examples, not a neural classifier and not a probability of technical correctness.

## Pose quality gate

`assessPoseSequence()` scores the visibility of trunk/pelvis, arms, legs, feet, whole-body coverage, confidence and time continuity. It is a practical capture-quality diagnostic, not a validated clinical metric. It is included in every new report and used to block trajectory correction when the capture is too incomplete. A good average score does not prove that every joint was identified anatomically correctly. Kinematic correction additionally requires a continuous time base: duplicate/invalid timestamps, large source gaps and incomplete timestamp coverage can block optimization. When the user selects multiple non-overlapping ranges, their explicit boundaries are excluded from cadence checks and no derivatives or smoothing are carried across the gaps.

## What cannot be optimized from one uncalibrated RGB camera

The current input does not provide ground reaction forces, pressure distribution, centre of pressure, EMG, muscle force, joint moments, tissue loading, absolute room coordinates or calibrated 3D camera geometry. Consequently the system cannot calculate a physically validated optimum, injury probability, strike impulse or physiological efficiency. Foot contact, COM/BOS, segment lengths and 3D locations remain model-based estimates with explicit limitations.

A meaningful future biomechanical optimization requires subject anthropometry, multi-view or calibrated capture, reliable contact/force data and an individual musculoskeletal model. Until those measurements exist, the application should present candidate kinematic changes for human review, not prescribe an “ideal” movement.
