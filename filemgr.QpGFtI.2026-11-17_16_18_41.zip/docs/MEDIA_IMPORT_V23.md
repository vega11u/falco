# Social video import in v23

The original official yt-dlp + QuickJS-NG path, alternate YouTube/Instagram profiles, Go Lux fallback and CRON queue remain in their original order. Two additive PHP adapters are available:

- the public Instagram metadata adapter reads OpenGraph/JSON-LD from a public page and downloads only a validated media URL;
- an owner-configured Cobalt adapter is disabled by default and accepts only an explicitly configured HTTPS self-hosted or trusted endpoint.

No public Cobalt proxy is bundled. Redirects, DNS results, private/reserved IPs, response size (750 MiB), API-key characters and output paths are checked. Configure the private `adapters.json` created by `setup-social-adapters.sh`; it is outside the document root. Existing downloader binaries and queues are untouched.
