# Frutiger Aero implementation research — v23.0.2

## References reviewed

- `https://github.com/PetoKrisa/frutiger-aero-css` — compact community CSS reference for the early-web Aero language: glossy controls, soft bevels, aqua gradients, bright highlights and rounded navigation.
- `https://github.com/biagio-scaglia/frutiger-js` — a more systematic Aero-oriented UI implementation. Its useful architectural idea is a layered design vocabulary (primitive colours and spacing → semantic surfaces → component treatments), with reusable glass, gloss and theme primitives rather than isolated one-off gradients.
- `https://github.com/Ektie/react-video-timeline-editor` — a browser video-editor reference for the interaction pattern: the source preview remains the visual authority while timeline/trim controls manipulate the selected time range. The analyzer uses the pattern without adopting the editor's framework or bundling its runtime.

## What was adopted

- A humanist type stack that prefers an installed Frutiger family and falls back to bundled Lato. The bundled WOFF2 subsets include Latin and Cyrillic glyphs and are distributed with the Lato SIL Open Font License notice.
- A layered token system for sky/water/leaf colours, glass surfaces, borders, specular highlights, shadows, and button materials.
- Clear daylight surfaces: translucent sky/water gradients, thin white specular edges, restrained bevels, aqua selection states, and small leaf-green status accents. Cards are not blurred with expensive backdrop filters; the visual material is made from static gradients and inset highlights to keep rendering inexpensive.
- A separate night-water palette for the dark theme, with the same component geometry and interaction contrast. The analyzer, Purcell route and report-library page share the same saved theme preference.
- Consistent spacing, radii, form heights, button treatments, panel headers, and mobile breakpoints to remove uneven margins and accidental overlaps.
- A filmstrip inside the trim track, generated locally from nine representative frames. Dragging an IN/OUT boundary seeks the real source video to that exact boundary, so the frame being trimmed is visible in the existing player.

## Deliberate non-adoption

No React/Vite framework, animation library, glass-blur dependency, video-editor bundle, remote font CDN or third-party runtime was added. The analyzer remains PHP + existing browser JavaScript and workers. The trim filmstrip is generated once per source and uses a detached video element; it does not create a second visible player or modify the established 2D player.
