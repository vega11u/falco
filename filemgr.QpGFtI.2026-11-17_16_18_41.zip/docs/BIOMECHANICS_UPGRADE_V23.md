# Biomechanics and model upgrade in v23

Lully still recognises the existing 48-dimensional temporal feature contract and Purcell still reads the existing 384/1152-dimensional stores. The new phase layer adds a separate `falco-trajectory-analysis-v1` result: preparation, onset, acceleration, peak, braking, recovery and readiness for the next movement. It uses source timestamps, rejects camera cuts and long gaps, and reports visible torso-length-normalised quantities.

Purcell combines these measurements with the anatomy catalogue, technique-specific cues, support-foot evidence and reviewed personal examples. Its text is generated from bounded rules and observations, so it stays short and functional rather than becoming a general language model. A phase-retiming candidate is an explicitly labelled projected-avatar hypothesis. It keeps source measurements, timestamps, support constraints and segment lengths; it does not claim greater force, power or injury safety.

Single-camera world landmarks and monocular depth remain model estimates. Reports therefore distinguish observation, interpretation and proposal and avoid presenting force, EMG, tendon strain, calibrated room depth or contact impulse as measured facts. Training examples improve recognition and athlete-specific comparison; they do not silently replace the anatomical rules.
