# Player and trim improvements in v23

`player-trim-core.mjs` centralises strict timecode parsing, range clamping and adjacent-frame stepping. Trim handles preserve the opposite boundary, enforce a positive interval and keep the source file untouched. Preview playback stops at the selected end using the video-frame callback where available.

Keyboard stepping is active only when focus is outside text controls. Archived reports step from their stored timestamps instead of assuming the live video FPS. Touch and pointer interactions retain the existing zoom and seek controls.
