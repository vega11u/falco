# Falco Jugger 23.0 — Frutiger Aero design

The active presentation is `frutiger-aero-v23.css`. It uses local SVG landscape and motion artwork, so the page remains usable when external fonts and CDNs are unavailable. Sky, water, leaf green, aqua glass edges, glossy controls and bright readable surfaces are applied consistently to the analyzer, Purcell workspace and report archive.

The visual direction follows the CARI Frutiger Aero archive, `khang-nd/7.css` control details, Visnalize Make Aero highlights and AamirrH/FrutigerAero composition references. The project uses its own CSS and artwork; these references are not runtime dependencies.

Large animated backgrounds and continuously animated blur were deliberately avoided. Interaction highlights are short, the page supports `prefers-reduced-motion`, and every interactive control retains visible keyboard focus. Existing IDs, hidden states, report controls, trim controls and data attributes remain unchanged.
