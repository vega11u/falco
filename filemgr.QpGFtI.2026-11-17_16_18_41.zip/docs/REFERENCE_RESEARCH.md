# Исследовательская база распознавания карате и ката (релиз v14)

Дата проверки источников: 31.10.2026. Приоритет: WKF-контекст и четыре заданные технические линии — Сётокан, Сито-рю, Годзю-рю, Рюэй-рю. Киокушин / Oyama не используется как целевая техника, источник эталонных поз или стиль обучающих примеров.

## 1. Правила WKF как рамка контекста

Первичный источник — WKF Kata Competition Rules 2026.0, действуют с 01.01.2026: https://kai.is/wp-content/uploads/2025/12/WKF-Kata-Competition-Rules-2026-MASTER-COPY_V2.pdf . Официальная страница документов WKF: https://www.wkf.net/documents .

В приложении 1 перечислены **102 нумерованные позиции ката**. Номер важнее текстового имени при регистрации. Есть повторяющиеся или близкие названия: например, `Sanseru` находится под номерами 79 и 80; `Seishan` и `Seisan (Sesan)` — отдельные записи. Поэтому база хранит номер и оригинальное написание, а не дедуплицирует по строке.

Правила допускают небольшие вариации, принятые технической линией (Ryu-ha). В разделе оценки отдельно указаны стойки, техники, переходы, тайминг и синхронизация, дыхание, фокус/кимэ и соответствие кихон. Следствие для софта: узнавание должно быть иерархическим и контекстным. Одна и та же поза/траектория не является уникальным идентификатором школы или ката; название может пересекаться между линиями.

WKF не присваивает каждую из 102 позиций единственному стилю. В интерфейсе стиль — контекст, введённый спортсменом/тренером; имя ката и его номер не должны автоматически определять ryu-ha. Рюэй-рю остаётся отдельной линией по запросу пользователя; оно не подменяется Уэчи-рю. Допуск в соревнования WKF определяется официальным списком ката и регламентом, а не тем, что софт знает название линии.

## 2. Источники терминологии и стилевой техники

Это не готовый тренировочный корпус и не универсальный стандарт техники. Источники используются для проверки названий, структуры kihon/kata, перечней стоек и типов действий; стилевые примеры должны подтверждаться инструктором конкретной линии. Полный машиночитаемый каталог находится в `data/technique-reference-catalog.json`.

- **Сётокан:** JKA описывает взаимосвязь kihon–kata–kumite и собственные принципы обучения; отдельный Instructor Technical Manual содержит критерии базовой техники, положения стоп, баланса, таза и kime. Дополнительный IJKA syllabus содержит комбинации `age-uke`, `soto-ude-uke`, `uchi-ude-uke`, `shuto-uke`, `gyaku-zuki`, mae/yoko/mawashi-geri. Эти документы являются организационными/школьными источниками, а не правилом для всех ветвей Сётокан.
- **Сито-рю:** официальный syllabus Shito-Ryu International Karate Do Kai перечисляет виды оружия рук/ног, 12 стоек, thrusting и striking techniques; World Shito-Ryu Federation grading syllabus даёт независимую сверку стойк, kihon, перемещений и ката. Это позволяет расширить классификацию за пределы одной стойки или одного удара, но оба документа отражают конкретные организации.
- **Годзю-рю:** Goju-Ryu Bujutsukan описывает Yobi-undo, Kihon-gata (Sanchin/Tensho), Hojo-undo и Kaishu-gata; в тренировочном разделе прямо перечислены работа стоп, голеностопов, коленей, тазобедренных суставов, вращения корпуса, блоки, удары, дыхание и смена напряжения/расслабления. GKI дополняет рамку kihon/kata/kumite. Эти описания не задают обязательную единую геометрию для всех организаций Годзю-рю.
- **Рюэй-рю:** официальный Ryuei Ryu International и Ryueiryu Karate Kobudo Association дают источники по линии Накаима и организационному контексту. Подписанный видео-индекс Karate Do Alliance содержит демонстрации Paiho, Heiku, Paiku, Pachu и Anan известными поимённо исполнителями. В открытых первичных источниках меньше систематизированных таблиц кихон, чем для Сётокан/Сито-рю; поэтому нельзя синтезировать полный «канон» по фрагментам видео. Для новых примеров необходима проверка тренером именно Рюэй-рю.

### Визуальные материалы

Поиск изображений выявляет схемы стоек с силуэтами и отпечатками стоп, а также фото/видео демонстраций. Они полезны тренеру как визуальный справочник для первичной разметки, но **не являются автоматически допустимыми ML-данными**: у поиска нет гарантии лицензии, корректной стилевой атрибуции, угла камеры и разметки суставов. Изображения из поисковой выдачи не включены в архив и не используются в качестве биомеханических целей. Для обучения нужны лицензированные оригиналы/разрешение автора и метаданные каждого клипа.

## 3. Кинематические базы данных и измеренные референсы

Каталог дополнен отдельными кандидатами HardMo и HardMo++ для анализа ошибок оценки кистей/стоп; они не используются для стилевой классификации или обучения без проверки прав на исходные интернет-материалы.

### Pavani et al. (2026): стойки, кинематика и силовые платформы — самый релевантный найденный набор

Репозиторий исследовательского конвейера: https://github.com/luiz-pavani/karate-stances-dataset-scripts ; датасет Figshare DOI 10.6084/m9.figshare.32288943, заявленная лицензия CC BY 4.0. По открытой документации это 12 спортсменов (7 Сётокан, 5 Годзю-рю), 180 динамических попыток и 9 статических референсов. Спортсмены выполняли гяку-дзуки по пять раз из трёх базовых семейств; захват включал markerless-кинематику Theia3D/Qualisys 180 Hz и две силовые платформы Bertec 1000 Hz. Доступны серии суставных углов, центр масс, параметры базы опоры, sway и временные ряды GRF/CoP.

Ключевая для распознавания деталь: авторы протокола адаптировали название к собственной линии спортсмена. Для задне-смещённой базы в таблице указан `kokutsu-dachi` для Сётокан и `neko-ashi-dachi` для Naha-te/Годзю-рю; для латеральной базы — `kiba-dachi` для Сётокан и `shiko-dachi` для Годзю-рю. В словаре добавлены эти функциональные соответствия, но они помечены как эквивалентность задачи в протоколе, а не тождество геометрии или универсальный закон для всех ветвей.

Это лучший найденный источник для будущей проверки баланса/CoM/опоры в двух целевых стилях, но он не является набором видео для классификации, не содержит Сито-рю и Рюэй-рю и не покрывает ката, блоки и полный репертуар ударов. Данные не скачаны и не включены в релиз: доступ к Figshare в этой сборочной среде не удалось проверить, а научная статья о наборе обозначена авторами как находящаяся в подготовке. Поэтому программа не получила выведенных из этого набора числовых «норм» или оптимальных углов.

### MADS (Zhang et al., 2017): многокамерные данные для общей позы

MADS содержит 30 multi-view и 30 stereo-depth видео, всего около 53 000 кадров, включая карате, тайцзи, танцы и спорт. В описании датасета фигурируют шесть ката, исполненных двумя мастерами. Это потенциально полезно для общего тестирования восстановления сложной позы, ракурсов и окклюзий, но открытые метаданные не подтверждают нужную стилевую принадлежность и не дают достаточной разметки стоек/блоков/ударов для обучения именно нашего классификатора. Условия доступа/распространения требуют отдельной проверки. Источники: https://scholars.cityu.edu.hk/en/datasets/martial-arts-dance-sports-mads-dataset/ ; DOI 10.1016/j.imavis.2017.02.002.

### Kolykhalova et al. (2015): мультимодальный набор целых ката

Публикация: https://eudl.eu/doi/10.4108/icst.intetain.2015.260039 . Авторы описывают синхронизированные видеозаписи, аудио и motion capture нескольких участников с различным опытом, исполнявших ката. Предложенные авторами критерии качества включали геометрические/кинематические параметры позы и синхронизацию частей тела. По характеру задач это один из наиболее полезных кандидатов для сегментации целой последовательности и оценки межсегментной синхронизации. Однако публичное описание не позволяет подтвердить принадлежность материала к четырём заданным линиям, лицензию/условия распространения исходных записей и точную разметку классов. Поэтому набор занесён в каталог как кандидат для запроса авторам, но не включён в релиз и не используется для обучения.

### Karate Motion Capture Database (Tomasz Hachaj / Kraków)

Проект: https://cci.up.krakow.pl/gdl2/ . Описывается как собрание 12 наборов, 2 886 файлов CSV/BVH, более 10 000 образцов движений; общий объём исходных материалов — порядка 18 ГБ. Упоминаются отдельные техники и стойки (zenkutsu-dachi, kokutsu-dachi, kiba-dachi, mae-geri, mawashi-geri, yoko-geri, gedan-barai, soto-uke, uchi-uke, jodan-uke), а также ката. Это потенциально ценнее фотографий, поскольку содержит временные 3D-координаты.

**Не считать эту базу единым чистым корпусом для данного проекта.** В ней есть набор Oyama/Kyokushin-контекста, и на страницах отдельных наборов может быть собственный copyright/terms. В частности, Oyama-поднабор имеет пометку `Copyright 2020 Tomasz Hachaj. All rights reserved.` Он не используется как источник техники или меток в этом проекте. Для любого другого поднабора до импорта нужны: подтверждённая школа/линия, согласие/лицензия на обучение и производные модели, состав участников и протокол захвата, частота кадров/координатная система, список действий и независимые субъекты.

Статус для релиза: источник занесён в исследовательский каталог; сырьё не включено, не скачивается установщиком и не объявляется обучающей выборкой. Предусмотрен формат для последующего импорта лицензированных CSV/BVH.

### Статические изображения и таблицы техники

Открытые фотографии, рисунки и диаграммы могут помогать идентифицировать названия и вариации (weak labels), но ракурс, перспектива, постановочная остановка, одежда и различия между школами не позволяют считать их ground truth для 3D-траектории, силы, контакта или оптимальной биомеханики. Их нельзя напрямую превращать в целевую позу оптимизатора.

### HardMo / HardMo++: экстремальные положения кистей и стоп

- **HardMo (Liao et al., CVPR 2024):** https://openaccess.thecvf.com/content/CVPR2024/html/Liao_HardMo_A_Large-Scale_Hardcase_Dataset_for_Motion_Capture_CVPR_2024_paper.html . Описан набор из 7 млн изображений, 15 категорий танца и 14 категорий боевых искусств; авторы отдельно выделяют ошибки восстановления кисть–запястье и стопа–голеностоп. Полезен как методический источник для проверки pose-estimation на сложных конфигурациях, но не как эталон конкретного карате-стиля или временной классификации ката.
- **HardMo++ (Zhu et al., Electronics, 2026):** https://www.mdpi.com/2075-1702/15/17/3870 . Описано около 830 тыс. кадров, 2D whole-body keypoints и 3D SMPL; отдельные этапы уточняют руки и стопы. Многовидовая коррекция относится только к синхронизированной части FreeMan, тогда как HardMo-derived martial-arts subset остаётся single-view. Это современный ориентир для снижения ошибок в кистях/стопах, но не доказанная база Сётокан, Сито-рю, Годзю-рю или Рюэй-рю.
- Важное правовое ограничение: изображения HardMo были собраны из интернет-источников. Открытая публикация не означает автоматического разрешения на копирование исходных клипов/изображений в другой тренировочный набор. В релиз они не включены и для обучения не использовались.

## 4. Компьютерное распознавание действий

1. Hachaj et al. (2015), *Application of Assistive Computer Vision Methods to Oyama Karate Techniques Recognition*. Методологически полезно как пример сегментации коротких действий и классификации компьютерным зрением. Но Oyama-данные и стиль исключены из целевой тренировочной выборки.
2. Hachaj et al. (2017), *Human Actions Analysis: Templates Generation, Matching and Visualization Applied to MoCap of Highly-Skilled Karate Athletes*. Работа использует временные шаблоны и DTW для сравнения действий на motion-capture данных. Опубликованная цифра 94.2% относится к конкретной небольшой мастерской выборке/экспериментальному переносу между корпусами; это **не** ожидаемая точность этого приложения и не доказательство распознавания наших четырёх линий.
3. Сама идея DTW полезна, поскольку два спортсмена могут выполнить один и тот же элемент с разной длительностью фаз. В релизе применён ограниченный DTW для временных последовательностей поз с дополнительным угловым вкладом в расстояние. Это пока алгоритм сопоставления подтверждённых примеров, а не глубокая нейросеть.
4. Важный отрицательный пример: один монокулярный ролик не позволяет достоверно различить намерение «блок» от другой траектории руки, если не виден контекст. Программа выдаёт кандидата «движение руки», а тип «блок» фиксируется после подтверждения тренером или узнаётся по нескольким чистым эталонам с нужной меткой.

## 5. Исследования по технике и биомеханике

| Источник | Что изучалось | Какое решение поддерживает | Ограничение переноса |
|---|---|---|---|
| VencesBrito et al., 2011, choku-zuki kinematics + EMG, PMID 22005009 | Временная организация удара и мышечные сигналы у опытных и начинающих | Анализировать временную координацию сегментов и фаз, а не только конечную позу | Конкретная техника и выборка; видео не восстанавливает ЭМГ |
| Rinaldi et al., 2018, Junzuki, PMID 29609507, DOI 10.1080/17461391.2018.1455899 | Кинематика, кинетика и ЭМГ; связи параметров тела и силы удара | Не максимизировать вращение туловища само по себе; учитывать ноги, колено, коактивацию и точность момента контакта | Исследованный Junzuki и выборка не задают универсальную норму для всех ударов/школ |
| Zago et al., 2017, PMID 27560105, DOI 10.1080/02640414.2016.1223332 | Motion capture, PCA, многосегментные синергии у 10 каратистов | Рассматривать движение как координацию всего тела; индивидуальные и опыт-зависимые паттерны | Маленькая выборка; PCA-компоненты не являются прямой физиологической «цепью» |
| Camomilla et al., 2009, Unsu jump, PMID 24474884 | 3D, силовые платформы и ЭМГ; пять фаз прыжка; изменённая версия | Фазовая сегментация и проверка, улучшает ли изменение не только кинематику, но и судейское исполнение | Четыре элитных спортсмена; модификация не улучшила судейский балл значимо |
| Lovecchio et al., 2015, dynamic balance, PMID 26499923 | CoM, ширина шага и суставная кинематика в kihon | Измерять баланс и стабилизацию после перехода | n=10 суммарно; не универсальные нормативы |
| Mele et al., 2026, DOI 10.25847/jomar.2026.63 | Продольное освоение удара и маэ-гери у новичков Годзю-рю | Анализировать профиль скорости по фазам и прогресс одного спортсмена | Четыре новичка, один инструктор, две техники |
| Fathalla et al., 2023, DOI 10.1155/2023/1561942 | Угловые кривые и continuous wavelet transform по sensor data | Анализировать пики, впадины и формы суставных сигналов во времени | Не однокамерный видеопоток; экспертные стандарты зависят от выборки |
| Gaweł et al., 2025, PMID 39794812 | Систематический обзор физических/физиологических качеств элитных WKF | Контекст для скорости, мощности, ловкости, гибкости и тестов атлета | Объединяет ката и кумите; не эталон технической формы |
| Silva et al., 2026, Scientific Reports, DOI 10.1038/s41598-026-41414-5 | Пилот мобильного анализа Zenkutsu/Kokutsu/Kiba в Сётокан | Практический пример pose landmarks + углы/выравнивание для стоек | Одно испытуемое лицо; авторы требуют валидации не менее 30 практикующих; показатели веса — прокси |
| Gavagan & Sayers, 2017, PMID 28841670, DOI 10.1371/journal.pone.0182645 | 3D-кинематика roundhouse kick и ударная сила у 8 каратистов, 8 тхэквондистов и 8 тайбоксёров; 9-камерный motion capture | Анализировать последовательность вращения таза, движений бедра/колена, перемещения центра масс и скорости стопы | Это круговой удар, не все удары ката; выборка мала, целевые стили карате не размечены как четыре заданные линии |
| OpenCap (Uhlrich et al., 2023), PLOS Comput Biol 19:e1011462, DOI 10.1371/journal.pcbi.1011462 | Многокамерное видео, калибровка, marker augmentation, OpenSim и muscle-driven simulation | Архитектура дальнейшего перехода к 3D-кинематике и модельным нагрузкам | Валидация проведена на обычных движениях (ходьба, присед, вставание, drop jump), не на карате; требуются синхронные камеры и корректные входы |
| OpenCap lower-limb validation (2024), PMID 38905926 | Валидация вне плоскости и на многих задачах | Отмечать разную точность плоскостей и не обещать точность 3D по одной камере | Средняя ошибка сильно зависит от движения и плоскости |

## 5а. Дополнительные работы: целое ката, моторные синергии и оценка навыка

- **Camomilla et al. (2009), Unsu jump:** https://pubmed.ncbi.nlm.nih.gov/24474884/ . В четырёх высококвалифицированных каратистов прыжок Unsu разбит на подготовку, отталкивание, восходящую/нисходящую фазы полёта и приземление; одновременно использовались 3D-фотограмметрия, силовые платформы и двусторонняя поверхностная ЭМГ пяти мышц ног. Предложенная модификация изменила часть нейромеханических параметров, но не дала значимого улучшения судейской оценки. Практический вывод: результат оптимизации нужно проверять по нескольким критериям, включая сохранение техники и результативность; локальная оптимизация одного параметра не гарантирует более высокого балла.
- **Mele et al. (2026), Goju-ryu training longitudinal:** https://jomar.dshs-koeln.de/archiv/artikel/a-longitudinal-study-on-karate-parallel-punch-and-front-kick-biomechanics-performance-indicators-and-the-effect-of-training/ . Четыре новичка занимались 32 сессии под руководством инструктора Годзю-рю; отслеживались параллельный удар рукой и фронтальный удар ногой, сравнивались с экспертным исполнением. Работа обращает внимание на временную форму скорости, повторяемость и этапы освоения. Это небольшой продольный материал, не универсальная норма времени пика скорости.
- **Fathalla et al. (2023):** https://onlinelibrary.wiley.com/doi/10.1155/2023/1561942 . Временные кривые углов суставов и непрерывное вейвлет-преобразование использовались для извлечения пиков/впадин в движениях карате с сопоставлением экспертным панелям. Поддерживает анализ формы временных сигналов, но исходный метод использует sensor/mocap данные, а не одиночное видео.
- **Gaweł et al. (2025), systematic review:** https://pmc.ncbi.nlm.nih.gov/articles/PMC11724538/ . Обзор исследований 2012–2024 рассматривает силу, мощность, скорость, ловкость, гибкость и энергетические компоненты у элитных WKF-каратистов. Авторы подчёркивают различия требований ката и кумите, а вклад энергетических систем в результат ката остаётся недостаточно определённым. Используется для выбора дополнительных персональных тестов, не как эталон технической формы.
- **Dynamical balance (Lovecchio et al., 2015):** https://pubmed.ncbi.nlm.nih.gov/26499923/ . В небольшой выборке мастеров и практикующих анализировались CoM, ширина шага и суставное поведение при последовательности kihon. Это основание включать динамический баланс и восстановление после перехода, но не вводить фиксированную «идеальную» высоту CoM.
- **Zenkutsu stepping energy (2021):** https://pubmed.ncbi.nlm.nih.gov/34269821/ . Работа показывает значительную механическую/энергетическую стоимость специфического шага в дзэнкуцу-дати у одного опытного каратиста. Нельзя минимизировать энергозатраты любой ценой или стремиться превратить традиционное движение в обычную ходьбу: первичны смысл техники, стойка и требования ката.
- **Gavagan & Sayers (2017), mawashi/roundhouse kick:** https://pubmed.ncbi.nlm.nih.gov/28841670/ . Трёхмерная кинематика и измерение удара по цели показали связь скорости стопы при контакте с относительной силой удара, а также вклад ротации таза и движений бедра/колена. Это полезно только для ударов по реальной цели и не становится нормативом не контактного ката.
- **Lateral kick videogrammetry (2026):** https://www.mdpi.com/2075-1702/14/3/339 . Исследовательская работа на трёх участниках описывает временные траектории голеностопа, подъём, ударную и возвратную фазы. Из-за очень малой выборки используется как гипотеза для анализа фаз, не как подтверждённый эталон.

## 6. Анатомия и фасциальные непрерывности

Модель `data/anatomy-functional-model.json` содержит 24 функциональные мышечные группы/комплекса, сегменты тела и степени свободы для объяснения движений. В ней описаны ягодичные, сгибатели/разгибатели бедра и колена, приводящие мышцы, мышцы голени и стопы, мышцы корпуса, лопаточного комплекса, плеча, локтя, предплечья и кисти. В интерфейсе группа в списке кликабельна: программа показывает основные действия, возможную роль в карате и ограничения наблюдения.

Фасциальные линии хранятся отдельно от мышечных групп. Kalichman (2025), PMID 41316622, DOI 10.1016/j.jbmt.2025.09.020, сообщает сильную анатомическую поддержку Superficial Back Line, Back Functional Line и Front Functional Line, умеренную — Spiral и Lateral Line; Superficial Front Line в обзоре не имеет достаточной валидации как непрерывная цепь. Доказательства функциональной передачи силы in vivo ограничены. Поэтому приложение может показывать анатомическую связность как гипотезу для интерпретации координации, но не рассчитывает «процент активации фасциальной цепи».

## 6а. Явно исключённые данные

- **Optical motion capture dataset of selected techniques in Kyokushin karate athletes (Szczęsna et al., 2021):** https://www.nature.com/articles/s41597-021-00801-5 . Несмотря на ценные C3D-траектории ударов, полностью исключён по прямому требованию проекта. Он не используется для обучения, нормирования, проверки или построения biomechanical targets.
- **Oyama subset в Karate Motion Capture Database:** https://cci.up.krakow.pl/gdl2/oyama.htm . Исключён как Oyama/Киокушин-контекст; на странице прямо указано `Copyright 2020 Tomasz Hachaj. All rights reserved.`


### Дополнительные 3D- и анатомические ресурсы, подключённые в v13

- **G1 Moves (karate subset):** https://huggingface.co/datasets/exptech/g1-moves — BVH-скелеты, исходные MP4, FBX и производные файлы движений. В проекте преобразуются только BVH в generic 3D-шаблоны; конкретная стилевой принадлежность для них не предполагается.
- **MyoSuite / MyoHub:** https://myosuite.org/models/ и https://github.com/MyoHub/myo_sim — модельный каталог включает MyoArm (38 DOF/63 привода), MyoLeg (29 DOF/80 приводов) и MyoTorso (18 DOF/210 приводов). В v13 индексируются доступные XML-топологии, суставы, сегменты, сайты и пути мышечно-сухожильных цепей отдельно для каждого модуля.
- **OpenSim Rajagopal:** https://github.com/opensim-org/opensim-models/tree/master/Models/Rajagopal — нижнеконечностная мышечно-сухожильная модель. Верхняя часть тела в данной модели не является детально мышечно-скелетной.

- **MyoSuite / MyoHub musculoskeletal models:** https://myosuite.org/models/ и https://github.com/MyoHub/myo_sim — каталог документирует MyoArm (38 DOF, 63 мышцы), MyoLeg (29 DOF, 80 мышц), MyoTorso (18 DOF, 210 мышц) и MyoFullBody composition (up to 416 actuators / 123 DOF; статус полной MuJoCo-композиции оговорён источником). v13 скачивает XML-модули arm/leg/body и индексирует доступную анатомическую топологию; не выдаёт сумму независимых модулей за уже решённую единую full-body динамическую модель.
- **Shotokan Multiview Karate Dataset:** публичные CSV дают четыре класса, хотя статья описывает восемь действий. Классификатор ограничен доступными метками, а не названиями из текста статьи.
- **MS-KARD:** статья сообщает 23 класса Годзю-рю, но доступный для скачивания архив в ходе подготовки v13 не подтверждён. До появления файлов это таксономия, не веса.

## 7. Выводы для модели

- Распознавание: иерархия `семейство движения → тип техники → название → стиль/вариант → контекст ката`.
- Стиль — не визуальная догадка. Если в метаданных нет достоверного стиля, пример остаётся `unspecified` и не смешивается со style-labelled образцами.
- Автоподсказка названия включается только при не менее чем трёх независимых видео-сессиях, достаточном сходстве и отрыве от второго кандидата. Similarity — не вероятность правильного ответа.
- Оптимизатор не копирует ката из изображений и не приводит спортсмена к одной учебной картинке. Он должен сохранять последовательность событий, назначение техники, опорные фазы и требования конкретной линии.
- В v13 добавлен локальный установщик данных и воспроизводимый pipeline обучения: SKMD CSV → узкий Shotokan ExtraTrees и временные шаблоны; G1 BVH → generic 3D motion templates без стилевой атрибуции; Pavani → отдельные динамические/статические распределения измерений; OpenSim Rajagopal и MyoSuite arm/leg/body → анатомические индексы. Обучение выполняется на машине пользователя после загрузки исходников; готовые обученные веса не включены в архив релиза, если загрузка не была выполнена. Внешние данные Годзю-рю MS-KARD (23 класса) пока доступны только как схема разметки, а не как загруженный архив. Сито-рю и Рюэй-рю не получают вымышленных внешних весов.

## Библиография и ссылки

- WKF. *Kata Competition Rules, Version 2026.0*. https://www.wkf.net/documents
- Liao J. et al. *HardMo: A Large-Scale Hardcase Dataset for Motion Capture*. CVPR. 2024. DOI: 10.1109/CVPR52733.2024.00161. https://openaccess.thecvf.com/content/CVPR2024/html/Liao_HardMo_A_Large-Scale_Hardcase_Dataset_for_Motion_Capture_CVPR_2024_paper.html
- Zhu Z. et al. *HardMo++: A Large-Scale Hard-Case Dataset for Motion Capture*. Electronics. 2026;15(17):3870. DOI: 10.3390/electronics.15173870. https://www.mdpi.com/2075-1702/15/17/3870
- Pavani L. et al. *A biomechanical dataset of fundamental karate-dō stances: Markerless kinematics and ground reaction forces in twelve karateka* [data set]. Figshare. 2026. DOI: 10.6084/m9.figshare.32288943. https://doi.org/10.6084/m9.figshare.32288943
- Pavani L. et al. *karate-stances-dataset-scripts* (MIT code; linked dataset CC BY 4.0). https://github.com/luiz-pavani/karate-stances-dataset-scripts
- Zhang W. et al. *Martial Arts, Dancing and Sports dataset: A challenging stereo and multi-view dataset for 3D human pose estimation*. Image and Vision Computing. 2017;61:22–39. DOI: 10.1016/j.imavis.2017.02.002. https://doi.org/10.1016/j.imavis.2017.02.002
- Japan Karate Association. *Techniques*. https://www.jka.or.jp/en/about-jka/techniques/
- Japan Karate Association. *Technical Manual for Instructor*. https://www.jka.or.jp/wp/wp-content/uploads/2017/04/tech_manual_instructor.pdf
- Shito-Ryu International Karate Do Kai. *Essential Curriculum / Syllabus*. https://seitoshitoryu.com/syllabus.php
- World Shito Ryu Federation. *Grading Syllabus*. https://wsshrf.org/wp-content/uploads/2021/03/Grading-Syllabus-WSSHRF.pdf
- Ryukyu Karate Goju-Ryu Bujutsukan. *Curriculum*. https://goju-ryu.jp/en/practice.html
- Goju-Ryu Karate-Do International. https://www.gki.org.uk/
- Ryuei Ryu International. *History and organization*. https://ryueiryu-international.com/
- Ryueiryu Karate Kobudo Association. https://www.ryueiryu.org/index.html
- Karate Do Alliance. *Ryuei-Ryu kata demonstrations index*. https://www.karatedoalliance.com/ryuei-ryu/
- Hachaj T. et al. *Application of Assistive Computer Vision Methods to Oyama Karate Techniques Recognition* (2015). Методологический источник; Oyama-корпус в данном проекте исключён.
- Hachaj T. et al. *Human Actions Analysis: Templates Generation, Matching and Visualization Applied to MoCap of Highly-Skilled Karate Athletes* (2017). https://pubmed.ncbi.nlm.nih.gov/29125560/
- VencesBrito A.M. et al. Choku-zuki kinematics/EMG (2011). https://pubmed.ncbi.nlm.nih.gov/22005009/
- Rinaldi M. et al. *Biomechanical characterization of the Junzuki karate punch: indexes of performance*. Eur J Sport Sci. 2018. https://pubmed.ncbi.nlm.nih.gov/29609507/
- Zago M. et al. *Multi-segmental movements as a function of experience in karate*. J Sports Sci. 2017. https://pubmed.ncbi.nlm.nih.gov/27560105/
- Gavagan C.J., Sayers M.G.L. *A biomechanical analysis of the roundhouse kicking technique of expert practitioners: A comparison between the martial arts disciplines of Muay Thai, Karate, and Taekwondo*. PLoS One. 2017;12(8):e0182645. PMID 28841670; DOI 10.1371/journal.pone.0182645. https://pubmed.ncbi.nlm.nih.gov/28841670/
- Silva C.M. et al. *A pilot study of a mobile application for postural analysis and training support in Shotokan Karate*. Sci Rep. 2026. https://www.nature.com/articles/s41598-026-41414-5
- Uhlrich S.D. et al. *OpenCap: Human movement dynamics from smartphone videos*. PLoS Comput Biol. 2023. https://pmc.ncbi.nlm.nih.gov/articles/PMC10586693/
- Kalichman L. *Myofascial continuity: Review of anatomical and functional evidence*. J Bodyw Mov Ther. 2025. https://pubmed.ncbi.nlm.nih.gov/41316622/
- Kolykhalova K. et al. *A Multimodal Dataset for the Analysis of Movement Qualities in Karate Martial Art*. INTETAIN/EAI. 2015. DOI: 10.4108/icst.intetain.2015.260039. https://eudl.eu/doi/10.4108/icst.intetain.2015.260039
- Camomilla V. et al. *Comparison of two variants of a kata technique (unsu): the neuromechanical point of view*. J Sports Sci Med. 2009;8(CSSI3):29–35. PMID 24474884. https://pubmed.ncbi.nlm.nih.gov/24474884/
- Lovecchio N. et al. *Dynamic balance in elite karateka*. J Electromyogr Kinesiol. 2015. PMID 26499923. https://pubmed.ncbi.nlm.nih.gov/26499923/
- Mele C. et al. *A longitudinal study on karate parallel punch and front kick biomechanics: performance indicators and the effect of training*. JOMAR. 2026;9:63. DOI: 10.25847/jomar.2026.63. https://doi.org/10.25847/jomar.2026.63
- Fathalla A. et al. *Real-Time and Automatic System for Performance Evaluation of Karate Skills Using Motion Capture Sensors and Continuous Wavelet Transform*. Int J Intell Syst. 2023. DOI: 10.1155/2023/1561942. https://doi.org/10.1155/2023/1561942
- Gaweł E. et al. *Current trends in physical and physiological profile of elite WKF karate athletes: a systematic review*. BMC Sports Sci Med Rehabil. 2025;17:6. PMID 39794812. https://pmc.ncbi.nlm.nih.gov/articles/PMC11724538/
- Liao J. et al. *HardMo: A Large-Scale Hardcase Dataset for Motion Capture*. CVPR. 2024. DOI: 10.1109/CVPR52733.2024.00161. https://openaccess.thecvf.com/content/CVPR2024/html/Liao_HardMo_A_Large-Scale_Hardcase_Dataset_for_Motion_Capture_CVPR_2024_paper.html
- Zhu Z. et al. *HardMo++: A Large-Scale Hard-Case Dataset for Motion Capture*. Electronics. 2026;15(17):3870. DOI: 10.3390/electronics.15173870. https://www.mdpi.com/2075-1702/15/17/3870
- Pavani L. et al. *A biomechanical dataset of fundamental karate-dō stances: Markerless kinematics and ground reaction forces in twelve karateka*. Figshare dataset. 2026. https://doi.org/10.6084/m9.figshare.32288943
- OpenSim Moco: optimal-control methods for musculoskeletal systems; ongoing development moved into OpenSim Core. https://github.com/opensim-org/opensim-moco


## Дополнение v14: доступные исходные видеозаписи и marker-based C3D

### Стилевые видеотеки

- Karateka.org, каталог целевых линий и разделов: https://karateka.org/ . Карточки записей содержат `Category` и `Section`; детальная страница, например, Sanseiru by Sakumoto Tsuguo, прямо указывает `Category: Ryuei-ryu`, `Section: Learning Kata`: https://karateka.org/video=6337a1bef05ef2ba . Скрипт загружает только `Learning Kata` и `Learning Kihon`; `Kata Competitions` — по opt-in; `Kumite` исключается.
- Cambridge University Karate Club, технический видео-каталог: https://cukc.org/videos.php . На странице перечислены ката Сётокан, Годзю-рю (Seisan, Kururunfa, Sepai, Suparinpei) и Сито-рю (Paiku, Shisochin, Anan). Ссылки извлекаются только при наличии указанного стилевого заголовка.

### ACCAD / Ohio State University

Официальная страница лаборатории: https://accad.osu.edu/research/motion-lab/mocap-system-and-data . Указаны raw C3D / BVH / FBX data; для Male 2 Martial Arts перечислены архивы kicks (21), punches (15), stances (15), walks/turns (22) и extended. Установщик получает прямые ZIP endpoints, проверяет целостность, распаковывает архивы, а `ezc3d` извлекает 3D marker trajectories. Эти данные относятся к общим martial-arts motion и не маркируются как Shotokan/Shito-ryu/Goju-ryu/Ryuei-ryu.

### Не включённые датасеты

Оптический C3D набор 37 Kyokushin спортсменов (1,411 файлов / 3,229 ударов) явно исключён из загрузки и обучения: https://www.nature.com/articles/s41597-021-00801-5 . Это прямое следование ограничению проекта: Kyokushin не является технической основой данного анализатора.

### KinemIQ / Open Motion Project (дополнительный указатель)

Страница каталога: https://kinemiq.app/free-motion-capture-data/ ; источники и кредиты: https://kinemiq.app/sources/ . Каталог указывает 115 martial-arts clips ACCAD и 170 locomotion clips 100STYLE, с экспортом BVH/FBX/GLB. Исходный ACCAD набор доступен напрямую через страницу Ohio State; KinemIQ является интерфейсом для предпросмотра/ретаргетинга, а не дополнительными независимыми записями. 100STYLE — общая локомоция одного актёра и не karate technique dataset; в v14 она не скачивается целиком.

Прямые C3D endpoints ACCAD: `Male2MartialArtsExtended_c3d.zip`, `Male2MartialArtsKicks_c3d.zip`, `Male2MartialArtsPunches_c3d.zip`, `Male2MartialArtsStances_c3d.zip`, `Male2MartialArtsWalksTurns_c3d.zip` на официальном `accad.osu.edu`.


### Расширение стилевых видеокаталогов v14

К базовым каталогам в v14 добавлены источники с явным стилевым заголовком и прямыми медиа-ссылками:

- Nidoshinkan: https://www.nidoshinkan.cz/video/ — отдельные секции `Kata (Goju Ryu)` и `Kata (Ryuei Ryu)`; доступны списки Gekisai, Saifa, Seiyunchin, Sanseru, Shisochin, Seipai, Seisan, Kururunfa, Suparinpei, Sanchin и Ryuei-ryu Seisan, Sanseiru, Pachu, Niseishi, Annan, Paiku, Heiku, Anan-Dai, Ohan.
- Ichikawa-ha International Sosuikai: https://seitogojuryu.com/videos/ — отдельная линия Годзю-рю и именованные исполнения Suparinpei, Seipai, Gekisai, Saifa, Seisan, Kururunfa, Tensho.
- Seigokan Goju-ryu: https://www.seigokan.com/p/kata-videos.html — каталог ката с явной оговоркой, что тайминг и отдельные техники могут различаться между инструкторами; это важная причина не превращать один клип в универсальный эталон.
- Karate Do Alliance Ryuei-ryu: https://www.karatedoalliance.com/ryuei-ryu/ — Paiho, Heiku, Paiku, Pachu, Anan, Niseishi.
- LSKC/JKA Shotokan: https://www.lskc.co.uk/vids.html — список ката и базовых демонстраций JKA.
- Chowa Academy Shito-ryu: https://www.karate-chowa.com/technique-videos — Pinan, Bassai, Seienchin и отдельные kihon dosa; стилевой контекст указан страницей академии.

Загрузчик сохраняет `catalogue_source`, `style_evidence`, `section` и исходную ссылку. Временные признаки целого ката получаются из 16 равномерных позных срезов и используются для preliminary whole-sequence retrieval в пределах выбранного стиля. Это не вероятностная модель и не независимая оценка технической правильности.
