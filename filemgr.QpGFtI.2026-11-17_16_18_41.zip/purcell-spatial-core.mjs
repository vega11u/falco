/** Experimental 3D trajectory hypotheses; no OpenSim forward dynamics or force measurement.
 * Works only when pose-world landmarks exist; NEVER synthesizes world geometry from 2D alone. */
import {candidateDefinition1000} from './purcell-search-core.mjs?v=23.0.9';
const clamp=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
const valid=p=>Array.isArray(p)&&p.length>=3&&p.slice(0,3).every(Number.isFinite)&&(p[3]??1)>=.18;
const bones=[[11,13],[13,15],[12,14],[14,16],[23,25],[25,27],[24,26],[26,28],[11,23],[12,24],[23,24],[11,12]];
const chains={left_arm:[11,13,15,17,19,21],right_arm:[12,14,16,18,20,22],left_leg:[23,25,27,29,31],right_leg:[24,26,28,30,32],trunk:[11,12,23,24]};
const mag=p=>Math.hypot(...p);
export function spatialReadiness(frames){
 if(!Array.isArray(frames)||frames.length<7)return {available:false,reason:'Недостаточно кадров'};
 let covered=0,reliable=0,torso=[],depthAgreement=[],depthFrames=0,reconstructionQuality=[];
 for(const f of frames){
  if(Number.isFinite(f.body_reconstruction?.quality_3d))reconstructionQuality.push(f.body_reconstruction.quality_3d);
  const a=(f.depth_agreement_values||f.render_depth_agreement_values||[]).filter?.(x=>Number.isFinite(x))||[];
  if(a.length>=6){depthAgreement.push(a.reduce((x,y)=>x+y,0)/a.length);depthFrames++;}
  if(!Array.isArray(f.w))continue;const ids=[11,12,23,24,25,26,27,28];const hits=ids.filter(i=>valid(f.w[i])).length;
  if(hits>=6)covered++;
  if(hits===8){reliable++;torso.push(mag([0,1,2].map(k=>(f.w[11][k]+f.w[12][k]-f.w[23][k]-f.w[24][k])*.5)));}
 }
 const coverage=covered/frames.length;const sorted=torso.sort((a,b)=>a-b),median=sorted.length?sorted[Math.floor(sorted.length/2)]:null;
 const reconstruction_quality=reconstructionQuality.length?reconstructionQuality.reduce((a,b)=>a+b,0)/reconstructionQuality.length:null;
 const available=coverage>=.65&&reliable>=Math.min(7,frames.length)&&median>.20&&median<1.1&&(reconstruction_quality==null||reconstruction_quality>=.28);
 const depth_agreement=depthAgreement.length?depthAgreement.reduce((a,b)=>a+b,0)/depthAgreement.length:null;
 // Independent 3D landmarks are the starting evidence. Sparse consensus depth
 // increases confidence only; uncalibrated depth must never create metric claims.
 const reliability=clamp(coverage*(depth_agreement==null?.62:(.66+.34*clamp(depth_agreement)))*(reconstruction_quality==null?1:clamp(reconstruction_quality/.75,.35,1)));
 return {available,coverage,reliability,reconstruction_quality,depth_agreement,depth_samples:depthFrames,torso_m:median,reason:available?null:`3D-ориентиры недостаточно надёжны (${Math.round(coverage*100)}% кадров с опорными суставами). 3D-карточки не строятся.`};
}
function delta3(mode,p,a,sign){const e=Math.sin(Math.PI*p),w=Math.sin(2*Math.PI*p),s=sign;
 switch(mode){
 case 'open_hip':return [a*e,0,s*a*.7*e];case 'close_hip':return [-a*e,0,-s*a*.6*e];
 case 'counter_rotate':return [s*a*w,0,-s*a*e];case 'rotate_left':return [-a*e,0,s*a*.8*w];case 'rotate_right':return [a*e,0,-s*a*.8*w];
 case 'spiral_in':return [a*e*Math.cos(2*Math.PI*p),a*.35*e*Math.sin(2*Math.PI*p),-a*e*Math.sin(2*Math.PI*p)];
 case 'spiral_out':return [-a*e*Math.cos(2*Math.PI*p),-a*.35*e*Math.sin(2*Math.PI*p),a*e*Math.sin(2*Math.PI*p)];
 case 'side_path':return [s*a*e,-a*.3*w,a*.5*w];case 'center_path':return [-s*a*e,-a*.25*w,-a*.6*w];
 case 'arc_up':return [s*a*.3*w,-a*e,a*.3*e];case 'arc_down':return [s*a*.25*w,a*e,-a*.3*e];
 case 'lift':return [a*.20*w,-a*e,a*.25*e];case 'forward':return [s*a*.3*e,0,-a*e];case 'retract':return [s*a*.25*e,0,a*e];
 case 'rise':return [0,-a*e,0];case 'lower':return [0,a*e,0];
 case 'vertical':return [0,-a*e,a*.15*w];case 'lateral':return [s*a*e,0,a*.25*w];
 case 'delayed_peak':return [s*a*e**4,-a*.20*w,a*.50*e**4];
 case 'reverse_path':return [-s*a*w,a*.3*e,-a*.6*e];default:return [s*a*w,-a*.12*e,a*.55*w];
 }}
function clone(frames){return frames.map(f=>({...f,im:(f.im||[]).map(p=>Array.isArray(p)?p.slice():p),w:(f.w||[]).map(p=>Array.isArray(p)?p.slice():p),_spatial_hypothesis:true}));}
function imageScale(f){const a=f.im?.[11],b=f.im?.[12],c=f.w?.[11],d=f.w?.[12];if([a,b,c,d].every(valid)){const m=Math.hypot(a[0]-b[0],a[1]-b[1]),w=mag(c.slice(0,3).map((v,i)=>v-d[i]));if(w>.1)return clamp(m/w,.10,1.35);}return .55;}
export function generateSpatialCandidate(frames,index,{amplitudeScale=1,readiness=null}={}){
 if(!(readiness||spatialReadiness(frames)).available)throw Error('Нет достаточной 3D-схемы спортсмена');
 const def=candidateDefinition1000(index),out=clone(frames),ids=chains[def.chain];
 // Local-world metres are approximate; short bounded perturbations are intentional, not optimized motions.
 const a=[.025,.055,.095,.145,.210][def.intensity]*clamp(amplitudeScale,.5,1.5);
 for(let i=1;i<out.length-1;i++){
  let phase=i/(out.length-1);phase=def.phaseShift?phase**1.5:Math.sqrt(phase);
  const envelope=Math.sin(Math.PI*i/(out.length-1))**2,delta=delta3(def.mode,phase,a,def.sign),k2=imageScale(out[i]);
  for(let k=0;k<ids.length;k++){
   const id=ids[k],p=out[i].w[id];if(!valid(p))continue;
   if(def.chain.includes('leg')&&id>=29)continue;
   const factor=(def.chain==='trunk'?.65:k===0?.06:k===1?.30:k===2?.72:1)*envelope;
   for(let d=0;d<3;d++)p[d]+=delta[d]*factor;
   const q=out[i].im[id];if(valid(q)){q[0]=clamp(q[0]+delta[0]*factor*k2,.005,.995);q[1]=clamp(q[1]+delta[1]*factor*k2,.005,.995);}
  }
  if(def.chain==='trunk'&&/hip|rotate/.test(def.mode)){
   const l=out[i].w[23],r=out[i].w[24];if(valid(l)&&valid(r)){l[2]-=delta[2]*.55*envelope;r[2]+=delta[2]*.55*envelope;}
  }
 }
 return {...def,frames:out,amplitude:a,modality:'3d',family:def.family};
}
function jointDistance(f,x,y){const a=f.w?.[x],b=f.w?.[y];return valid(a)&&valid(b)?mag([0,1,2].map(j=>a[j]-b[j])):null;}
/** Gravity 9.81m/s², COM, ground and contact are approximate estimates from kinematics.
 * A single camera does not observe ground reaction force or real mechanical efficiency. */
export function evaluateSpatialGravity(original,altered,{g=9.81}={}){
 if(!Array.isArray(original)||!Array.isArray(altered)||original.length!==altered.length||altered.length<7)return {passed:false,reason:'Missing sequence'};
 const masses={11:.08,12:.08,13:.045,14:.045,15:.025,16:.025,23:.30,24:.30,25:.05,26:.05,27:.05,28:.05};
 let work=0,boneErr=0,maxBoneErr=0,maxVelocity=0,maxAcceleration=0,contactError=0,validPairs=0,hipShift=0;
 let prev=null,prevV=null;
 for(let i=0;i<altered.length;i++){
  const f=altered[i],o=original[i];
  for(const [x,y] of bones){const a=jointDistance(o,x,y),b=jointDistance(f,x,y);if(a&&b&&a>.04){const e=Math.abs(b-a)/a;boneErr+=e;maxBoneErr=Math.max(maxBoneErr,e);validPairs++;}}
  for(const [idx,mass] of Object.entries(masses)){const a=o.w?.[idx],b=f.w?.[idx];if(valid(a)&&valid(b))work+=Math.max(0,a[1]-b[1])*g*mass;}
  // Foot-contact anchors were unchanged. But a displaced pelvis over planted feet must not extend an impossible leg.
  for(const foot of [27,28]){const a=jointDistance(o,foot===27?25:26,foot),b=jointDistance(f,foot===27?25:26,foot);if(a&&b)contactError=Math.max(contactError,Math.abs(b-a)/a);}
  const root=f.w?.[23],other=f.w?.[24],old=o.w?.[23];
  if(valid(root)&&valid(other)&&valid(old))hipShift=Math.max(hipShift,Math.hypot(...[0,1,2].map(d=>root[d]-old[d])));
  if(i>0&&valid(root)&&valid(prev?.w?.[23])){const dt=f.t-prev.t;if(dt>.005&&dt<.55){const vel=[0,1,2].map(d=>(root[d]-prev.w[23][d])/dt);maxVelocity=Math.max(maxVelocity,mag(vel));if(prevV){maxAcceleration=Math.max(maxAcceleration,mag(vel.map((x,j)=>(x-prevV[j])/dt)));}prevV=vel;}}
  prev=f;
 }
 const distortion=boneErr/Math.max(1,validPairs);
 // Not inverse dynamics: penalty is a relative, mass-normalized gravitational effort proxy.
 const effort=work/Math.max(1,altered.length-2),gravityPenalty=clamp(effort*50,0,45),speedPenalty=clamp(maxVelocity*3,0,30);
 const pass=distortion<.09&&maxBoneErr<.40&&contactError<.30&&maxVelocity<7.5&&maxAcceleration<200&&hipShift<.25;
 return {passed:pass,gravity_m_s2:g,positive_potential_j_per_kg_proxy:effort,max_segment_error:maxBoneErr,mean_segment_error:distortion,foot_contact_distortion:contactError,
  max_local_speed_m_s_proxy:maxVelocity,max_local_accel_m_s2_proxy:maxAcceleration,hip_shift_m:hipShift,score:clamp(100-gravityPenalty-speedPenalty-distortion*140-contactError*25,0,100),
  reason:pass?null:'Нарушены геометрические/динамические ограничения 3D-гипотезы',evidence:'Pose-relative 3D estimate, not calibrated inverse dynamics'};
}
/** Perspective projection of a world-landmark skeleton for user-requested replay only. */
export function spatialReplayPoints(frame,{yaw=-.45,pitch=.26}={}){
 const pts=frame?.w||[],ca=Math.cos(yaw),sa=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);
 const hipL=pts[23],hipR=pts[24];const cx=valid(hipL)&&valid(hipR)?(hipL[0]+hipR[0])/2:0,cy=valid(hipL)&&valid(hipR)?(hipL[1]+hipR[1])/2:0,cz=valid(hipL)&&valid(hipR)?(hipL[2]+hipR[2])/2:0;
 return pts.map(p=>{if(!valid(p))return null;const x=p[0]-cx,y=p[1]-cy,z=p[2]-cz,X=x*ca+z*sa,Z=z*ca-x*sa,Y=y*cp-Z*sp,D=2.4+(z*ca-x*sa)*cp+y*sp;return {x:X/Math.max(1.2,D),y:Y/Math.max(1.2,D),z:Z,confidence:p[3]??1};});
}
export const spatialBones=bones;


/** Ten-fold broader 3D population. Keeps all geometry in measured world-landmark space. */
export function generateSpatialCandidate10000(frames,index,{amplitudeScale=1,readiness=null}={}){
 if(!Number.isInteger(index)||index<0||index>=10000)throw Error('3D 10k candidate index out of range');
 const layer=Math.floor(index/1000),baseIndex=index%1000;
 const c=generateSpatialCandidate(frames,baseIndex,{amplitudeScale,readiness});
 const ids=chains[c.chain],mode=['spiral_in','spiral_out','open_hip','close_hip','counter_rotate','side_path','center_path','delayed_peak','reverse_path','lateral'][layer];
 const sign=(layer%2)?-1:1,a=[.012,.022,.034,.048,.064,.082,.103,.127,.153,.182][layer]*clamp(amplitudeScale,.5,1.5);
 for(let i=1;i<c.frames.length-1;i++){
  const f=c.frames[i],phase=i/(c.frames.length-1),q=layer%3===0?phase:layer%3===1?phase**1.7:Math.sqrt(phase),env=Math.sin(Math.PI*i/(c.frames.length-1))**2,d=delta3(mode,q,a,sign),scale=imageScale(f);
  for(let k=0;k<ids.length;k++){const id=ids[k],pt=f.w?.[id];if(!valid(pt))continue;if(c.chain.includes('leg')&&id>=29)continue;const factor=(c.chain==='trunk'?.58:k===0?.05:k===1?.24:k===2?.62:1)*env;for(let axis=0;axis<3;axis++)pt[axis]+=d[axis]*factor;const im=f.im?.[id];if(valid(im)){im[0]=clamp(im[0]+d[0]*factor*scale,.005,.995);im[1]=clamp(im[1]+d[1]*factor*scale,.005,.995);}}
 }
 return {...c,id:'hyp-'+String(index+1).padStart(5,'0'),mode:`${c.mode}+${mode}-v${layer+1}`,layer,amplitude:Math.max(c.amplitude,a)};
}
