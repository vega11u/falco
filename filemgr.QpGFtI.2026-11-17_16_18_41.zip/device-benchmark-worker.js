self.onmessage = event => {
  const durationMs = Math.max(80, Math.min(350, Number(event.data?.durationMs) || 180));
  const start = performance.now();
  let operations = 0;
  let a = 0.123456789, b = 0.987654321, c = 0.314159265;
  while (performance.now() - start < durationMs) {
    for (let i = 0; i < 4096; i++) {
      a = (a * 1.000000119 + b * 0.00000031) % 1.7;
      b = (b * 0.99999971 + c * 0.00000017) % 1.3;
      c = (c * 1.00000007 + a * 0.00000023) % 1.1;
    }
    operations += 4096 * 9;
  }
  const elapsedMs = performance.now() - start;
  self.postMessage({ available: true, operationsPerSecond: operations / (elapsedMs / 1000), elapsedMs, method: 'Web Worker scalar throughput; device baseline, not a neural-inference benchmark', checksum: a + b + c });
};
