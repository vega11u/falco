/** Motion-observation sanity guard: excludes implausible isolated avatar poses from rendering only.
 * Does not alter measured landmarks, source frames, timing, or learning features. */
export const REALITY_SCHEMA='falco-avatar-reality-v1';
const bones=[[11,13],[13,15],[12,14],[14,16],[23,25],[25,27],[24,26],[26,28],[11,23],[12,24],[11,12],[23,24]];
const ok=p=>Array.isArray(p)&&Number.isFinite(p[0])&&Number.isFinite(p[1])&&(p[3]??1)>=.50;
const len=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
const med=a=>{if(!a.length)return null;const s=[...a].sort((x,y)=>x-y);return s[Math.floor(s.length/2)];};
export function auditAvatarReality(frames){
 const refs=new Map(),tracks=new Map(),items=[],bad=new Set();
 for(const [a,b] of bones){const dims=[];for(const f of frames){const p=f.im||[];if(ok(p[a])&&ok(p[b]))dims.push(len(p[a],p[b]));}refs.set(a+':'+b,med(dims));}
 const torso=med(frames.flatMap(f=>{const p=f.im||[];return ok(p[11])&&ok(p[23])?[len(p[11],p[23])]:[];}))||.25;
 for(let i=0;i<frames.length;i++){
   const f=frames[i],p=f.im||[],reason=[];
   let observable=0,distorted=0;
   for(const [a,b] of bones){const ref=refs.get(a+':'+b);if(!ok(p[a])||!ok(p[b])||!(ref>.015))continue;observable++;const ratio=len(p[a],p[b])/ref;if(ratio<.46||ratio>1.95)distorted++;}
   if(observable>=6&&distorted>=3)reason.push('multiple_bone_length_discontinuities');
   const shoulder=ok(p[11])&&ok(p[12])?len(p[11],p[12]):null,hip=ok(p[23])&&ok(p[24])?len(p[23],p[24]):null;
   if(shoulder!==null&&hip!==null&&shoulder<torso*.13&&hip<torso*.12)reason.push('implausible_full_body_collapse');
   if(i>0){const prev=frames[i-1],dt=Number(f.t)-Number(prev.t);
    if(dt>.003&&dt<.25&&(prev.camera_segment_id??0)===(f.camera_segment_id??0)){
      let fast=0;
      for(const j of [11,12,13,14,15,16,23,24,25,26,27,28])if(ok(p[j])&&ok(prev.im?.[j])&&len(p[j],prev.im[j])/torso/dt>12)fast++;
      if(fast>=2)reason.push('multiple_joint_teleport');
      else if(fast===1&&i+1<frames.length){const nxt=frames[i+1];
       const spikes=[15,16,27,28].filter(j=>ok(p[j])&&ok(prev.im?.[j])&&ok(nxt.im?.[j])&&len(p[j],prev.im[j])/torso/dt>11&&len(p[j],nxt.im[j])/torso/Math.max(.003,nxt.t-f.t)>11&&len(prev.im[j],nxt.im[j])/torso<.55);
       if(spikes.length)reason.push('isolated_extremity_spike');
      }
    }
   }
   if(reason.length)bad.add(i);
   items.push({index:i,invalid:reason.length>0,reasons:reason});
 }
 // Protect both sides of an impossible jump from interpolation without deleting data.
 return {schema:REALITY_SCHEMA,invalid_indices:[...bad],flags:items.filter(x=>x.invalid),checked:frames.length,invalid_count:bad.size,usable_render_frames:frames.length-bad.size};
}
export function safeAvatarFramePair(frames,index){
 const f=frames[index];if(!f)return null;
 if(!f.avatar_render_invalid)return f;
 for(let j=1;j<=6;j++)for(const k of [index-j,index+j])if(k>=0&&k<frames.length&&!frames[k].avatar_render_invalid&&Math.abs(frames[k].t-f.t)<=.20&&(frames[k].camera_segment_id??0)===(f.camera_segment_id??0))return frames[k];
 return null;
}
