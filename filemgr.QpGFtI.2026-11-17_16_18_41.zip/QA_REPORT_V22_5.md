# QA report — Falco Jugger 22.5.0

## Backend and compatibility

- `bash tests/verify.sh`: required PHP syntax, shell syntax, intelligence data, release API contracts, local video, learning API, report archive, Lully sync, Purcell store and feedback, optimizer, biomechanical/recognition/depth/player tests, media import and Lux-only CRON fallback.
- `php tests/release-smoke.php`: PHP release and API contracts.
- `php tests/learning-api-smoke.php`: learning storage, confirmed-only examples, idempotent updates and archive behavior.
- `bash tests/server-report-library-smoke.sh`: report persistence, owner isolation, list/get/delete, streaming and learning archive immutability.
- `bash tests/purcell-and-report-api-smoke.sh`: Purcell private store, feedback and report API.
- `php tests/local-video-smoke.php`: local file upload, codec inspection, no-transcode path and fallback runtime contract.
- `bash tests/media-import-smoke.sh` and `bash tests/lux-only-cron-smoke.sh`: verbose marker isolation, importer fallback order, chunk transfer, SHA-256, ACK, privacy and Lux-only CRON without PHP `proc_open`.
- `node` smoke tests: biomechanics, technique planning, 2D avatar, depth reconstruction, Lully recognition, Purcell baseline and optimizer constraints.

## Frontend and layout

- PHP-generated `index.php`, `uppurcell.php` and `Memories.php` rendered in Chromium at 1440 px and 390 px.
- Checked page width against viewport at 1440 px and 390 px, header/nav, upload target, trim editor, video stage, report rows and buttons.
- Ran a computed-style audit on rendered pages: zero linear/radial gradients, zero box shadows, no rounded cards; only the server-status dot and numbered process markers remain circular.
- Checked the stylesheet has no glow, glass surfaces, fabricated brand marks or rounded dashboard tiles.
- Checked project wordmark, IM Fell English SC + local EB Garamond SC fallback, and Times New Roman UI contract.
- Checked trim and player DOM IDs remain present.

## Manual local HTTP smoke

A PHP 8.4.24 development server was started against the release tree. `GET /index.php?api=health` returned HTTP 200 with `ok:true` and `server_learning:true`. The clean release tree correctly reported the local Mediabunny/ProRes/FFmpeg runtime and social downloaders as not installed; those pinned runtime assets are downloaded by `bash setup-release.sh` during deployment and are intentionally not embedded in the release ZIP. The private classifier showed zero examples because the deployment archive does not contain a user's private learning data.

`bash tests/media-import-cron-smoke.sh` was run separately and passed: two browser sessions, serialized CRON queue, active-job lock, single extractor, bounded range transfer, SHA-256 acknowledgement and cleanup. A combined `RUN_CRON_INTEGRATION=1 bash tests/verify.sh` exceeded the execution window after the default suite; this is why the CRON test is recorded by its successful standalone run, not by that combined invocation.

## Data compatibility

- No database schema or private storage migration.
- No changes to Lully classifier formats, Purcell knowledge schema, report payload schema, ownership cookie or report archive paths.
- The private installed model/report data is not in the deployment archive and was not modified.

## Limits

Local automated tests cannot verify the user's actual REG.RU account, installed private model contents, external YouTube/Instagram access from the hosting IP, or GPU performance on the user's device. `RUN_CRON_INTEGRATION=1 bash tests/verify.sh` is a separate detached-process integration test and is not part of the default suite. Browser rendering checks static layout; actual video decode and inference should be confirmed after installation with a short test clip.
