#!/usr/bin/env bash
# Falco Jugger GC 27.2.2: explicit allowlist only, quarantine outside webroot.
# It never deletes PHP/JS fragments, CSS declarations, data, reports or model assets.
set -Eeuo pipefail
umask 077

TARGET="${1:-$PWD}"
MODE="${2:---dry-run}"
[[ -d "$TARGET" ]] || { echo "Target directory missing: $TARGET" >&2; exit 2; }
[[ "$MODE" == --dry-run || "$MODE" == --apply ]] || {
  echo "Usage: falco-gc.sh TARGET [--dry-run|--apply]" >&2; exit 2;
}
TARGET="$(cd -- "$TARGET" && pwd -P)"
[[ -f "$TARGET/index.php" && -f "$TARGET/VERSION" ]] || {
  echo "Not a Falco site root" >&2; exit 2;
}
: "${HOME:?HOME is required}"
ALLOW="$TARGET/FALCO25_GC_ALLOWLIST.txt"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)-$$"
QROOT="$HOME/.falco-quarantine"
QUARANTINE="$QROOT/$STAMP"
REPORT="$QROOT/gc-$STAMP.txt"
mkdir -p "$QROOT"
chmod 700 "$QROOT"
: > "$REPORT"
chmod 600 "$REPORT"

log(){ printf '%s\n' "$*" | tee -a "$REPORT"; }
log "Falco GC $MODE · $TARGET"
log "Policy: explicit allowlist; quarantine only; no source-fragment deletion."

referenced(){
  local base="$1"
  grep -RIlF \
    --include='*.php' --include='*.html' --include='*.js' --include='*.mjs' --include='*.css' \
    --exclude='FALCO25_GC_ALLOWLIST.txt' \
    --exclude-dir='.falco-rollback' --exclude-dir='.falco-quarantine' \
    --exclude-dir='backups' --exclude-dir='training-data' --exclude-dir='data' \
    --exclude-dir='reports' --exclude-dir='private' --exclude-dir='vendor' \
    --exclude-dir='node_modules' --exclude-dir='.git' --exclude-dir='tests' --exclude-dir='docs' \
    -- "$base" "$TARGET" >/dev/null 2>&1
}

count=0
moved=0
absent=0
kept=0
unsafe=0
if [[ ! -f "$ALLOW" ]]; then
  log "ALLOWLIST: missing; no files eligible for quarantine."
else
  while IFS= read -r entry || [[ -n "$entry" ]]; do
    entry="${entry%%#*}"
    entry="$(printf '%s' "$entry" | xargs)"
    [[ -n "$entry" ]] || continue
    if [[ "$entry" == /* || "$entry" == *'..'* || "$entry" == *' '* || "$entry" == *'\'* ]]; then
      log "SKIP_UNSAFE_ALLOWLIST_PATH: $entry"
      unsafe=$((unsafe+1))
      continue
    fi
    path="$TARGET/$entry"
    if [[ ! -e "$path" ]]; then
      log "ALLOWLIST_ENTRY_ABSENT: $entry"
      absent=$((absent+1))
      continue
    fi
    if [[ -L "$path" || ! -f "$path" ]]; then
      log "SKIP_NON_REGULAR_OR_SYMLINK: $entry"
      unsafe=$((unsafe+1))
      continue
    fi
    base="${entry##*/}"
    if referenced "$base"; then
      log "KEEP_REFERENCED: $entry"
      kept=$((kept+1))
      continue
    fi
    count=$((count+1))
    log "STALE_ALLOWLIST_CANDIDATE: $entry"
    if [[ "$MODE" == --apply ]]; then
      mkdir -p "$QUARANTINE/$(dirname "$entry")"
      mv -- "$path" "$QUARANTINE/$entry"
      log "QUARANTINED_OUTSIDE_WEBROOT: $entry"
      moved=$((moved+1))
    fi
  done < "$ALLOW"
fi

log "ALLOWLIST_SUMMARY: candidates=$count quarantined=$moved absent=$absent referenced=$kept unsafe=$unsafe"
if [[ -f "$TARGET/tools/falco-ui-cleanup-audit.php" ]]; then
  log "----- READ-ONLY UI CLEANUP AUDIT -----"
  php "$TARGET/tools/falco-ui-cleanup-audit.php" "$TARGET" >> "$REPORT" 2>&1 || {
    log "WARNING: UI audit reports items requiring review; no additional cleanup was attempted."
  }
else
  log "WARNING: tools/falco-ui-cleanup-audit.php is missing."
fi

if [[ "$MODE" == --apply ]]; then
  log "QUARANTINE_DIR: $QUARANTINE"
  log "QUARANTINED_FILES: $moved"
else
  log "DRY_RUN: no project files changed."
fi
log "REPORT: $REPORT"
