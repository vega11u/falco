<?php
declare(strict_types=1);
$root = $argv[1] ?? '';
$script = __DIR__ . '/falco-ui-cleanup-audit.php';
if (!is_file($script)) { fwrite(STDERR, "Cleanup audit tool missing\n"); exit(2); }
$cmd = escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg($script) . ' ' . escapeshellarg($root);
passthru($cmd, $status);
exit($status);
