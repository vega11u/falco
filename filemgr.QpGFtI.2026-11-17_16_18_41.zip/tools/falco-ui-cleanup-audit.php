<?php
declare(strict_types=1);

/**
 * Falco Jugger UI cleanup audit.
 * Read-only: never edits, moves or deletes project files.
 */
$root = realpath($argv[1] ?? '');
$summaryOnly = in_array('--summary', $argv, true);
if ($root === false || !is_file($root . '/index.php') || !is_file($root . '/falco-jugger-ui.css')) {
    fwrite(STDERR, "Invalid Falco site root\n");
    exit(2);
}
$pages = ['index.php', 'models.php', 'Memories.php', 'lully.php', 'purcell-lab.php'];
$excludeDirs = ['.falco-rollback', '.falco-quarantine', 'backups', 'data', 'vendor', 'node_modules', '.git', 'tests', 'docs', 'private', 'reports', 'training-data'];

function isExcludedPath(string $relative, array $excludeDirs): bool {
    $parts = explode('/', str_replace('\\', '/', $relative));
    foreach ($parts as $part) if (in_array($part, $excludeDirs, true)) return true;
    return false;
}
function htmlStyleAttributes(string $source): array {
    $out = [];
    if (!preg_match_all('~(?<=\s)style\s*=\s*(["\'])(.*?)\1~is', $source, $matches, PREG_OFFSET_CAPTURE)) return $out;
    foreach ($matches[0] as $i => $full) {
        $offset = $full[1];
        $prefix = substr($source, 0, $offset);
        $lt = strrpos($prefix, '<');
        $gt = strrpos($prefix, '>');
        if ($lt === false || ($gt !== false && $lt < $gt)) continue;
        $end = strpos($source, '>', $offset);
        if ($end === false) continue;
        $tag = substr($source, $lt, $end - $lt + 1);
        if (!preg_match('~^<[a-z][a-z0-9:-]*\b~i', $tag)) continue;
        $out[] = trim($matches[2][$i][0]);
    }
    return $out;
}
function relativePath(string $root, string $path): string {
    return ltrim(substr($path, strlen($root)), DIRECTORY_SEPARATOR);
}

echo "FALCO UI CLEANUP AUDIT · READ ONLY\n";
echo "Root: {$root}\n";
$cssCount = 0;
$cssFiles = [];
$iter = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($iter as $file) {
    if (!$file->isFile() || strtolower($file->getExtension()) !== 'css') continue;
    $rel = relativePath($root, $file->getPathname());
    if (isExcludedPath($rel, $excludeDirs)) continue;
    $cssCount++;
    $cssFiles[] = $rel;
}
sort($cssFiles);
echo "ACTIVE_CSS_FILES: {$cssCount}\n";
foreach ($cssFiles as $file) if (!$summaryOnly) echo "CSS_FILE: {$file}\n";

$stylesheetRefs = 0;
$badVersionRefs = [];
$staticInline = 0;
$dynamicInline = 0;
$styleBlocks = 0;
$jsStyleAssignments = 0;
foreach ($pages as $page) {
    $path = $root . '/' . $page;
    if (!is_file($path)) continue;
    $source = (string)file_get_contents($path);
    if (preg_match_all('~<link\b[^>]*rel\s*=\s*["\']stylesheet["\'][^>]*>~i', $source, $links)) {
        foreach ($links[0] as $tag) {
            if (preg_match('~href\s*=\s*["\']([^"\']+)~i', $tag, $m)) {
                $stylesheetRefs++;
                if (!$summaryOnly) echo "STYLESHEET_REF: {$page} -> {$m[1]}\n";
                if (!str_contains($m[1], 'falco-jugger-ui.css?v=27.2.2-C.D2')) $badVersionRefs[] = $page . ': ' . $m[1];
            }
        }
    }
    $attrs = htmlStyleAttributes($source);
    foreach ($attrs as $value) {
        if (str_contains($value, '${') || str_contains($value, '<?php')) {
            $dynamicInline++;
            if (!$summaryOnly) echo "DYNAMIC_INLINE_STYLE: {$page} -> {$value}\n";
        } else {
            $staticInline++;
            if (!$summaryOnly) echo "STATIC_INLINE_STYLE: {$page} -> {$value}\n";
        }
    }
    $styleBlocks += preg_match_all('~<style\b~i', $source);
    $jsStyleAssignments += preg_match_all('~\.style\.[A-Za-z_$][\w$]*\s*=~', $source);
}
echo "STYLESHEET_REFERENCES: {$stylesheetRefs}\n";
echo "STATIC_INLINE_STYLE_ATTRIBUTES: {$staticInline}\n";
echo "DYNAMIC_INLINE_STYLE_ATTRIBUTES: {$dynamicInline}\n";
echo "INLINE_STYLE_BLOCKS_IN_RUNTIME_PAGES: {$styleBlocks}\n";
echo "JS_STYLE_PROPERTY_ASSIGNMENTS_IN_RUNTIME_PAGES: {$jsStyleAssignments}\n";
if ($badVersionRefs) foreach ($badVersionRefs as $ref) echo "STALE_STYLESHEET_VERSION: {$ref}\n";

$cssPath = $root . '/falco-jugger-ui.css';
$css = is_file($cssPath) ? (string)file_get_contents($cssPath) : '';
if ($css !== '') {
    $imports = preg_match_all('~@import\b~i', $css);
    $balanced = substr_count($css, '{') === substr_count($css, '}');
    echo "CSS_IMPORTS: {$imports}\n";
    echo "CSS_BRACES_BALANCED: " . ($balanced ? 'YES' : 'NO') . "\n";
    echo "LEGACY_LAYER_MARKERS: " . (preg_match('~26\.(?:1\.0|2\.2|2\.3|3)\b~', $css) ? 'FOUND' : 'NONE') . "\n";
} else {
    echo "CSS_FILE_MISSING: falco-jugger-ui.css\n";
    $balanced = false;
    $imports = 0;
}

$ok = ($cssCount === 1 && $stylesheetRefs >= 5 && $staticInline === 0 && $styleBlocks === 0 && $balanced && !$badVersionRefs);
echo "AUDIT_RESULT: " . ($ok ? 'PASS' : 'REVIEW_REQUIRED') . "\n";
exit($ok ? 0 : 1);
