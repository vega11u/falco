# Falco 24.2 — отчёт завершения интерфейсной интеграции

## Цель
Убрать переходы-заглушки из Lully Academy и Purcell Evolution Lab: рабочие процессы должны быть доступны внутри соответствующих центров, при этом исходные алгоритмы и обработчики должны остаться единственными источниками функциональности.

## Реализовано

### Lully Pattern Academy
- Встроен существующий `index.php?workspace=lully`.
- Сохранены исходные DOM IDs и обработчики загрузки/декодирования видео.
- Встроенный анализатор показывает существующую панель повторяющихся паттернов.
- Доступны повторный поиск, связь с серверной Lully, синхронизация модели, карточки кандидатов, 2D replay, подтверждение/отклонение и обратная связь.
- Сводная библиотека с фильтрами продолжает читать текущие `library` и `model-status`.
- Архивные карточки не выдают числовые признаки за видео: исходное видео не хранится в серверной библиотеке.

### Purcell Evolution Lab
- Встроен существующий `uppurcell.php?workspace=purcell`.
- Сохранены потоковая очередь до 100 видео, просмотр, разметка, оценки, признаки и подтверждённое сохранение.
- После анализа в focused workspace раскрываются существующие `optimizerPanel` и `baroqueModelJournal`.
- Доступны Purcell optimizer, выбранный момент, поиск гипотез, Bach evolution, остановка и просмотр фактического результата.
- В библиотеке показывается фактическое распределение положительных/нейтральных/отрицательных оценок, а не искусственный процент эволюции.
- Сводные карточки продолжают читать `purcell-library` и `purcell-status`.

### Интеграция
- Рабочие панели встроены через same-origin iframe, чтобы не дублировать IDs и не создавать второй набор обработчиков.
- Контентный resize bridge измеряет высоту `.shell`, а не viewport; события объединяются через `requestAnimationFrame`, чтобы избежать цикла роста iframe.
- Scroll bridge принимает только same-origin сообщения и ограниченный allow-list целевых ID.
- Режимы `workspace=lully|purcell` включаются только явно. Стандартные `index.php` и `uppurcell.php` без параметра сохраняют прежний интерфейс.
- Новые серверные endpoints, таблицы и схемы хранения не добавлялись.

## Проверки
- PHP lint: 39 PHP-файлов, ошибок синтаксиса нет.
- `node --check falco24-learning-centers.js`: PASS.
- `node --check falco24-aero-science-lab.js`: PASS.
- CSS parse: 2 файла, 0 синтаксических ошибок.
- Workspace integration smoke: 19 проверок PASS; Learning Centers compatibility smoke: 10 проверок PASS.
- Полный `bash tests/verify.sh`: exit 0; все developer release checks passed.
- CLI render: `index.php?workspace=lully` и `uppurcell.php?workspace=purcell` корректно выводят разрешённый `data-workspace` и подключают focused CSS.

## Ограничения проверки
Браузерный live preview через локальный HTTP/file origin был заблокирован средой выполнения (ERR_BLOCKED_BY_ADMINISTRATOR), поэтому screenshot/visual acceptance в реальном браузере не заявляется. Обработка реального пользовательского видео отдельно не запускалась. Для этого релиза подтверждены PHP render, синтаксис, CSS parsing, интеграционные контракты и полный существующий regression suite.

## Совместимость
Изменён только `index.php` (opt-in workspace mode + bridge + Purcell workspace reveal), новые центры, их CSS/JS, release docs и tests. API endpoints, storage schema, core analysis modules, user learning records и report storage не мигрировались и не очищались.


## 5. Installer and aggressive garbage collection 24.2.1
- Added `install-falco24.sh` for one-command overlay installation.
- Backups are written outside the document root before changes.
- Garbage collection is limited to three reviewed legacy files and rechecks runtime code references.
- Private learning data, reports, videos, model stores, CRON/setup scripts and tests are excluded.
- Failed post-install checks trigger automatic rollback.
- Installer simulation passed, including a forced-failure rollback simulation.


## 24.2.2 interface redesign
- Added the exact nine-item side anchor navigation: upload, results, highlights, kime, patterns, Purcell weak points, Purcell hypothesis optimizer, Purcell evolution, detailed metrics.
- Moved the existing synchronized player dock into the main grid and kept it sticky alongside results on desktop.
- Mobile layout changes the rail into a bottom horizontal navigation and stacks the player without overlap.
- Current-video Lully/Purcell workflows remain on the main page.
- Lully/Purcell subpages are library-only and contain no embedded analyzer iframe.
- Empty Lully replay preview blocks are no longer rendered.
- Approved typography and brand copy are applied globally.


## Superseded by 24.2.3 — Unified Workspace

The 24.2.2 shell did not meet visual acceptance. Its top bar repeated the sidebar brand, and its rail/player introduced nested scrolling. Release 24.2.3 replaces that shell with a single document-flow layout and a compact player column. Do not use 24.2.2 layout screenshots or old styling claims as acceptance criteria. Current details are in `FALCO24_RELEASE_NOTES_24_2_3.md` and `FALCO24_QA_REPORT_24_2_3.md`.
