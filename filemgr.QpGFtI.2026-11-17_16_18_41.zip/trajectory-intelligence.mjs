/**
 * Phase-aware, browser-only movement observations. All positions remain projected
 * body-relative kinematics; phase names are hypotheses, never muscle activation.
 * Raw observations and alternative avatar tracks are always separate objects.
 */
const finite=Number.isFinite;
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const median=a=>{const v=a.filter(finite).sort((a,b)=>a-b);return v.length?v[(v.length-1)>>1]:null;};
const point=(p,c=.65)=>Array.isArray(p)&&p.slice(0,2).every(finite)&&(p[3]??1)>=c;
const norm=v=>Math.hypot(...v);
const distance=(a,b)=>norm(a.map((v,i)=>v-b[i]));
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
const CHAINS={left_hand:[11,13,15],right_hand:[12,14,16],left_foot:[23,25,27],right_foot:[24,26,28]};
const NAMES={left_hand:'левая кисть',right_hand:'правая кисть',left_foot:'левая стопа',right_foot:'правая стопа'};
const PHASE_NAMES={preparation:'подготовка',acceleration:'разгон',transfer:'окрестность пика',braking:'торможение',recovery:'возврат / готовность'};
const segment=f=>f?.camera_segment_id??f?.segment_id??0;

// Weighted local polynomial over actual timestamps. Unlike equal-step central
// differences it stays valid on variable-frame-rate video. No gap is bridged.
function localDerivative(rows,index){
  const t0=rows[index].t,center=rows[index].p;
  const subset=rows.slice(Math.max(0,index-2),Math.min(rows.length,index+3));
  if(subset.length<3)return null;
  const moments=Array(5).fill(0),rhs=[Array(3).fill(0),Array(3).fill(0)];
  for(const row of subset){const dt=row.t-t0,w=row.confidence/(1+Math.abs(dt)*12),powers=[1,dt,dt*dt,dt**3,dt**4];for(let k=0;k<5;k++)moments[k]+=w*powers[k];for(let axis=0;axis<2;axis++)for(let k=0;k<3;k++)rhs[axis][k]+=w*powers[k]*(row.p[axis]-center[axis]);}
  const solve=b=>{const m=[[moments[0],moments[1],moments[2],b[0]],[moments[1],moments[2],moments[3],b[1]],[moments[2],moments[3],moments[4],b[2]]];for(let k=0;k<3;k++){let pivot=k;for(let r=k+1;r<3;r++)if(Math.abs(m[r][k])>Math.abs(m[pivot][k]))pivot=r;[m[k],m[pivot]]=[m[pivot],m[k]];if(Math.abs(m[k][k])<1e-12)return null;const d=m[k][k];for(let c=k;c<4;c++)m[k][c]/=d;for(let r=0;r<3;r++)if(r!==k){const z=m[r][k];for(let c=k;c<4;c++)m[r][c]-=z*m[k][c];}}return m.map(r=>r[3]);};
  const x=solve(rhs[0]),y=solve(rhs[1]);
  return x&&y?{velocity:[x[1],y[1]],acceleration:[2*x[2],2*y[2]]}:null;
}

function buildTrack(frames,chain,aspect){
  const rows=[];
  for(const f of frames){const im=f.im||[],ids=[11,12,23,24,...chain];if(!ids.every(id=>point(im[id])))continue;const hip=[(im[23][0]+im[24][0])/2,(im[23][1]+im[24][1])/2],shoulder=[(im[11][0]+im[12][0])/2,(im[11][1]+im[12][1])/2],scale=Math.hypot((shoulder[0]-hip[0])*aspect,shoulder[1]-hip[1]);if(scale<.06||scale>1.5)continue;const p=im[chain[2]];rows.push({t:Number(f.t),p:[(p[0]-hip[0])*aspect/scale,(p[1]-hip[1])/scale],scale,confidence:Math.min(...ids.map(id=>im[id][3]??1)),segment:segment(f)});}
  if(rows.length<9)return null;
  const dts=rows.slice(1).map((r,i)=>r.t-rows[i].t),period=median(dts);
  if(!period||dts.some(dt=>dt<=0||dt>Math.max(.085,period*2.1))||rows.some(r=>r.segment!==rows[0].segment))return null;
  // Abrupt scale changes/camera zoom invalidate body-relative velocity estimates.
  const scaleMedian=median(rows.map(r=>r.scale));
  if(rows.some((r,i)=>i&&Math.abs(r.scale-rows[i-1].scale)/scaleMedian>.16))return null;
  // A single robust scale avoids turning small torso-length jitter into false
  // effector acceleration. Camera zoom must be resolved before using this track.
  if(rows.some(r=>Math.abs(r.scale-scaleMedian)/scaleMedian>.22))return null;
  for(const row of rows)row.p=row.p.map(v=>v*row.scale/scaleMedian);
  const smoothed=rows.map((row,i)=>({...row,derivative:localDerivative(rows,i)}));
  for(const r of smoothed)r.speed=r.derivative?norm(r.derivative.velocity):0;
  const travel=rows.slice(1).reduce((s,r,i)=>s+distance(r.p,rows[i].p),0);
  return {rows:smoothed,period,travel,coverage:rows.length/frames.length};
}

/** A bounded window must identify one action, rather than a complete kata. */
export function analyzeMovementPhases(frames,{start,end,kind='movement',label='',aspect=1,confirmed=false,knowledge={}}={}){
  if(!Array.isArray(frames)||!finite(start)||!finite(end)||end<=start)return {available:false,reason:'invalid_window'};
  const selected=frames.filter(f=>finite(Number(f?.t))&&f.t>=start-.00001&&f.t<=end+.00001);
  if(selected.length<9||end-start>5)return {available:false,reason:'insufficient_temporal_support'};
  const safeAspect=finite(aspect)&&aspect>0?aspect:1;
  const effectors=kind==='kick'?['left_foot','right_foot']:kind==='hand_strike'||kind==='block'?['left_hand','right_hand']:Object.keys(CHAINS);
  const tracks=effectors.map(id=>({id,track:buildTrack(selected,CHAINS[id],safeAspect)})).filter(x=>x.track&&x.track.coverage>=.85).sort((a,b)=>b.track.travel-a.track.travel);
  if(!tracks.length)return {available:false,reason:'visibility_gap_or_camera_cut'};
  const {id,track}=tracks[0],{rows,period}=track;
  const peakIndex=rows.reduce((best,r,i)=>r.speed>rows[best].speed?i:best,0),peak=rows[peakIndex].speed;
  if(peak<.12||track.travel<.08)return {available:false,reason:'no_resolved_motion'};
  // A peak at an edge means the requested window truncated the action.
  const truncated=peakIndex<2||peakIndex>rows.length-3;
  const threshold=Math.max(.08,peak*.16);
  let onset=peakIndex,offset=peakIndex;
  while(onset>0&&rows[onset-1].speed>threshold)onset--;
  while(offset<rows.length-1&&rows[offset+1].speed>threshold)offset++;
  // Include earlier resolved bursts for the same action; this exposes pauses in
  // the acceleration instead of hiding them by declaring a second new movement.
  for(let i=0;i<onset;i++)if(rows[i].speed>peak*.35){onset=i;break;}
  const startP=rows[onset].p,peakP=rows[peakIndex].p,direction=peakP.map((v,k)=>v-startP[k]),length=norm(direction);
  const unit=length>.04?direction.map(v=>v/length):null;
  let outboundPath=0,backwards=0,outboundSteps=0;
  for(let i=onset+1;i<=peakIndex;i++){const v=rows[i].p.map((x,k)=>x-rows[i-1].p[k]);outboundPath+=norm(v);if(unit&&norm(v)>.004){outboundSteps++;if(dot(v,unit)<-.002)backwards++;}}
  const directness=outboundPath>.02?clamp(length/outboundPath,0,1):null;
  const confidence=clamp(median(rows.map(r=>r.confidence))*track.coverage*(truncated?.65:1),0,1);
  const phases=[{id:'preparation',start:rows[0].t,end:rows[onset].t},{id:'acceleration',start:rows[onset].t,end:rows[peakIndex].t},{id:'transfer',start:Math.max(rows[onset].t,rows[peakIndex].t-period),end:Math.min(rows[offset].t,rows[peakIndex].t+period)},{id:'braking',start:rows[peakIndex].t,end:rows[offset].t},{id:'recovery',start:rows[offset].t,end:rows.at(-1).t}].map(p=>({...p,label:PHASE_NAMES[p.id],duration_s:Math.max(0,p.end-p.start),observed:p.end-p.start>=period*.5}));
  const chain=CHAINS[id],chainTiming=[];
  // Shoulder/hip, elbow/knee and distal timing all use the same camera space;
  // differences below two sampling periods are deliberately unresolved.
  for(const joint of chain){const local=buildTrack(selected,[...chain.slice(0,2),joint],safeAspect);if(!local)continue;const r=local.rows.reduce((best,row)=>row.speed>best.speed?row:best,local.rows[0]);chainTiming.push({joint,peak_time_s:r.t,peak_speed_torso_s:r.speed,resolved_motion:r.speed>=.12});}
  const findings=[];
  const straightTechnique=/^(?:(?:gyaku|oi|kizami|choku|tate|jun)[ -]?(?:zuki|tsuki)|(?:гяку|ои|кидзами|чоку|татэ|дзюн)[ -]?цуки)$/iu.test(String(label).trim()) || (knowledge?.trajectory_rules?.straight_punch_aliases||[]).some(alias=>String(alias).trim().toLocaleLowerCase('ru')===String(label).trim().toLocaleLowerCase('ru'));
  let pause=null;
  for(let i=onset+2;i<peakIndex-2;i++){
    if(rows[i].speed>peak*.23)continue;
    let j=i;while(j+1<peakIndex-1&&rows[j+1].speed<=peak*.23)j++;
    const before=rows.slice(onset,i).some(r=>r.speed>=peak*.42),after=rows.slice(j+1,peakIndex+1).some(r=>r.speed>=peak*.65);
    if(before&&after&&rows[j].t-rows[i].t>=Math.max(.055,period*1.5)){pause={start:rows[i].t,end:rows[j].t};break;}i=j;
  }
  if(pause&&!truncated&&confidence>=.76&&period<=.045&&confirmed&&straightTechnique&&directness>=.83){
    const ms=Math.round((pause.end-pause.start)*1000);
    findings.push({source:'purcell_trajectory',rule_id:'interrupted_outbound_acceleration',kind,pattern:label,priority:2,confidence:Math.min(.87,confidence),time_s:(pause.start+pause.end)/2,start_s:start,end_s:end,title:'Проверить паузу внутри разгона',why:`${NAMES[id]} заметно замедляется на ${ms} мс до основного пика скорости; прямолинейность разгона ${Math.round(directness*100)}/100.`,action:'Проверьте, нужна ли эта пауза рисунку ката. Если нет, попробуйте раньше завершить подготовку плеча и локтя и соединить два участка разгона; конечную позицию и контролируемое торможение сохраните.',evidence:`${rows.length} видимых кадров · шаг ${Math.round(period*1000)} мс · только участок разгона`,baseline_note:'Пауза может быть намеренной. Вариант аватара показывает временную гипотезу, а не доказанную прибавку силы.',trajectory_candidate:{mode:'phase_retiming',effector:id,start_s:rows[onset].t,end_s:rows[offset].t,pause_start_s:pause.start,pause_end_s:pause.end,max_time_shift_s:Math.min(.18,(rows[offset].t-rows[onset].t)*.2),max_joint_delta_deg:24,hypothesis:true}});
  }
  const timingPairs=chainTiming.slice(1).map((distal,i)=>{const proximal=chainTiming[i],delay=distal.peak_time_s-proximal.peak_time_s;return {from_joint:proximal.joint,to_joint:distal.joint,delay_s:delay,order_resolved:proximal.resolved_motion&&distal.resolved_motion&&Math.abs(delay)>=2*period,interpretation:'peak timing, not muscle activation order'};});
  const recoveryDisplacement=distance(rows.at(-1).p,rows[offset].p);
  return {schema:'falco-phase-profile-v1',available:true,kind,label,confirmed,start_s:start,end_s:end,effector:id,confidence,coverage:track.coverage,temporal_resolution_s:period,temporal_order_tolerance_s:2*period,truncated,space:'image_projection_torso_lengths',phases,chain_peak_timing:chainTiming,chain_peak_delays:timingPairs,metrics:{peak_speed_torso_s:peak,peak_time_s:rows[peakIndex].t,onset_time_s:rows[onset].t,offset_time_s:rows[offset].t,outbound_directness:directness,outbound_reverse_fraction:outboundSteps?backwards/outboundSteps:null,path_length_torso:track.travel,recovery_displacement_torso:recoveryDisplacement,braking_duration_s:Math.max(0,rows[offset].t-rows[peakIndex].t),preparation_duration_s:Math.max(0,rows[onset].t-rows[0].t)},summary_ru:`${NAMES[id]}: начало ${rows[onset].t.toFixed(2)} с, пик ${rows[peakIndex].t.toFixed(2)} с, завершение активной фазы ${rows[offset].t.toFixed(2)} с. Различия порядка короче ${Math.round(2*period*1000)} мс неразличимы.`,findings,limits:['Фазы выделены по видимой кинематике; пик не означает контакт с целью.','Скорость дана в видимых длинах корпуса в секунду; это не м/с, сила или мощность.','Порядок пиков не задаёт обязательную последовательность активации мышц.']};
}

/** Alternative local avatar: redistribute time along the OBSERVED joint-angle
 * trajectory. Fixed current root, fixed lengths and original endpoints. A hard
 * angular cap and quality/cut guards reject invalid candidates. No raw edit. */
export function applyPhaseRetimingCandidate(frames,candidate,{aspect=1}={}){
  const empty={frames,changedFrames:0,changedLandmarks:0,changedHandLandmarks:0};
  const chain=CHAINS[candidate?.effector],a=Number(candidate?.start_s),b=Number(candidate?.end_s);
  if(!chain||candidate?.mode!=='phase_retiming'||!finite(a)||!finite(b)||b-a<.12)return empty;
  // Foot contacts cannot be solved by this 2D arm retiming model.
  if(candidate.effector!=='left_hand'&&candidate.effector!=='right_hand')return empty;
  const active=frames.map((f,i)=>({f,i})).filter(x=>finite(x.f?.t)&&x.f.t>=a&&x.f.t<=b);
  if(active.length<7||active.some(x=>segment(x.f)!==segment(active[0].f)))return empty;
  const aspectSafe=finite(aspect)&&aspect>0?aspect:1,maxShift=clamp(Number(candidate.max_time_shift_s)||0,0,.18),maxAngle=clamp(Number(candidate.max_joint_delta_deg)||0,0,24)*Math.PI/180;
  const [root,mid,tip]=chain,sideExtras=tip===15?[17,19,21]:tip===16?[18,20,22]:tip===27?[29,31]:[30,32];
  const angle=(p,q)=>Math.atan2(q[1]-p[1],(q[0]-p[0])*aspectSafe),wrap=v=>Math.atan2(Math.sin(v),Math.cos(v));
  const useful=active.filter(x=>[root,mid,tip].every(id=>point(x.f.im?.[id],.72)));
  if(useful.length!==active.length||active.some((x,i)=>i&&(x.f.t-active[i-1].f.t<=0||x.f.t-active[i-1].f.t>.085)))return empty;
  // Arc length gives a monotone target phase parameter and removes a stall while
  // retaining the exact observed path in angle space. Smoothstep bounds speeds
  // at window endpoints; maxShift bounds how much micro-order may change.
  const poses=active.map(x=>{const im=x.f.im;return {t:x.f.t,angles:[angle(im[root],im[mid]),angle(im[mid],im[tip])]};});
  const arc=[0];for(let i=1;i<poses.length;i++)arc.push(arc[i-1]+Math.hypot(...poses[i].angles.map((v,k)=>wrap(v-poses[i-1].angles[k]))));
  const total=arc.at(-1);if(total<.08)return empty;
  const relative=poses.map(p=>wrap(p.angles[1]-p.angles[0]));
  // Preserve the observed signed flexion envelope. This is a projection bound,
  // not an anatomical hyperextension or injury test.
  const envelopeMin=Math.min(...relative),envelopeMax=Math.max(...relative);
  const side=tip===15?'left':'right';
  let output=null,changedFrames=0,changedLandmarks=0,changedHandLandmarks=0,previousMappedTime=poses[0].t;
  for(let i=1;i<active.length-1;i++){
    const {f,index}= {f:active[i].f,index:active[i].i},u=(f.t-a)/(b-a),desiredArc=(u*u*(3-2*u))*total;
    let j=1;while(j<arc.length-1&&arc[j]<desiredArc)j++;
    const w=(desiredArc-arc[j-1])/Math.max(arc[j]-arc[j-1],1e-9),desiredTime=poses[j-1].t+(poses[j].t-poses[j-1].t)*clamp(w,0,1);
    const proposedTime=f.t+clamp(desiredTime-f.t,-maxShift,maxShift)*Math.sin(Math.PI*u)**2;
    const mappedTime=clamp(proposedTime,previousMappedTime+Math.min(.001,(f.t-active[i-1].f.t)*.1),poses.at(-1).t-.001);
    previousMappedTime=mappedTime;
    let k=1;while(k<poses.length-1&&poses[k].t<mappedTime)k++;
    const ratio=clamp((mappedTime-poses[k-1].t)/(poses[k].t-poses[k-1].t),0,1);
    const target=poses[k-1].angles.map((v,n)=>v+wrap(poses[k].angles[n]-v)*ratio),old=poses[i].angles;
    const delta=target.map((v,n)=>clamp(wrap(v-old[n]),-maxAngle,maxAngle));
    if(Math.max(...delta.map(Math.abs))<.002)continue;
    const im=f.im,next=im.map(p=>Array.isArray(p)?p.slice():p),len1=Math.hypot((im[mid][0]-im[root][0])*aspectSafe,im[mid][1]-im[root][1]),len2=Math.hypot((im[tip][0]-im[mid][0])*aspectSafe,im[tip][1]-im[mid][1]);
    if(len1<.015||len2<.015)continue;
    const oldFlex=wrap(old[1]-old[0]),newFlex=wrap(old[1]+delta[1]-old[0]-delta[0]);
    if(newFlex<envelopeMin-.005||newFlex>envelopeMax+.005||Math.abs(wrap(newFlex-oldFlex))>maxAngle)continue;
    next[mid][0]=im[root][0]+Math.cos(old[0]+delta[0])*len1/aspectSafe;next[mid][1]=im[root][1]+Math.sin(old[0]+delta[0])*len1;
    next[tip][0]=next[mid][0]+Math.cos(old[1]+delta[1])*len2/aspectSafe;next[tip][1]=next[mid][1]+Math.sin(old[1]+delta[1])*len2;
    let changed=2;
    for(const id of sideExtras)if(point(im[id],.72)){const dx=(im[id][0]-im[tip][0])*aspectSafe,dy=im[id][1]-im[tip][1];next[id][0]=next[tip][0]+(dx*Math.cos(delta[1])-dy*Math.sin(delta[1]))/aspectSafe;next[id][1]=next[tip][1]+dx*Math.sin(delta[1])+dy*Math.cos(delta[1]);changed++;}
    const hands=(f.hands||[]).map(hand=>{
      const wrist=hand.landmarks?.[0];
      if(!point(wrist,.5))return hand;
      const other=im[tip===15?16:15],nearDistance=Math.hypot((wrist[0]-im[tip][0])*aspectSafe,wrist[1]-im[tip][1]),otherDistance=point(other,.5)?Math.hypot((wrist[0]-other[0])*aspectSafe,wrist[1]-other[1]):Infinity;
      const matches=hand.pose_side?hand.pose_side===side:nearDistance<.12&&otherDistance-nearDistance>.015;
      if(!matches)return hand;
      const landmarks=hand.landmarks.map(p=>{if(!point(p,0))return Array.isArray(p)?p.slice():p;const dx=(p[0]-im[tip][0])*aspectSafe,dy=p[1]-im[tip][1],q=p.slice();q[0]=next[tip][0]+(dx*Math.cos(delta[1])-dy*Math.sin(delta[1]))/aspectSafe;q[1]=next[tip][1]+dx*Math.sin(delta[1])+dy*Math.cos(delta[1]);changedHandLandmarks++;return q;});
      return {...hand,landmarks,proposal_space:'image_projection'};
    });
    if(!output)output=frames.slice();output[index]={...f,im:next,hands,synthetic_pose_2d:true,proposal_space:'image_projection'};changedFrames++;changedLandmarks+=changed;
  }
  return {frames:output||frames,changedFrames,changedLandmarks,changedHandLandmarks,candidate_space:'image_projection',hypothesis:true,method:'bounded-observed-angle-phase-retiming'};
}
