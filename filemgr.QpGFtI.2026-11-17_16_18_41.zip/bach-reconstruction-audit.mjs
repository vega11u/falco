/** Bach Reconstruction Quality Audit.
 * Measures consistency of observed reconstructed trajectories without treating pose
 * detector confidence as spatial reconstruction accuracy. No uncalibrated metres.
 * The original observations and projected geometry are compared separately.
 */
export const BACH_RECONSTRUCTION_AUDIT_VERSION='bach-reconstruction-audit-v1';
const BONES=[[11,12],[23,24],[11,13],[13,15],[12,14],[14,16],[23,25],[25,27],[24,26],[26,28]];
const KEY=[11,12,13,14,15,16,23,24,25,26,27,28];
const ok=(p,n=2)=>Array.isArray(p)&&p.length>=n&&p.slice(0,n).every(Number.isFinite)&&(p[3]??1)>=.24;
const dist=(a,b,n=2)=>Math.hypot(...Array.from({length:n},(_,i)=>a[i]-b[i]));
const median=xs=>{const a=xs.filter(Number.isFinite).sort((x,y)=>x-y);return a.length?a[Math.floor(a.length/2)]:null;};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const percentile=(xs,q)=>{const a=xs.filter(Number.isFinite).sort((x,y)=>x-y);return a.length?a[Math.min(a.length-1,Math.max(0,Math.floor(q*(a.length-1))))]:null;};
export function auditBachReconstruction(frames,{maxGap=.18}={}){
 if(!Array.isArray(frames)||!frames.length)return {schema:BACH_RECONSTRUCTION_AUDIT_VERSION,available:false,reason:'no_frames'};
 const segmentChanges=[],jumps=[],residuals=[],boneDeviations=[],validFrames=new Set(),total=frames.length;
 const reference=new Map();
 for(const [a,b] of BONES){let values=[];for(const f of frames){const p=f.render_im||f.im||[];if(ok(p[a])&&ok(p[b]))values.push(dist(p[a],p[b]));}reference.set(`${a}-${b}`,median(values));}
 for(let i=0;i<total;i++){
  const f=frames[i],p=f.render_im||f.im||[],raw=f.im||[];
  let visible=0;
  for(const j of KEY){if(ok(p[j])){visible++;if(ok(raw[j]))residuals.push(dist(p[j],raw[j]));}}
  if(visible>=8)validFrames.add(i);
  for(const [a,b] of BONES){const ref=reference.get(`${a}-${b}`);if(ref>.01&&ok(p[a])&&ok(p[b]))boneDeviations.push(Math.abs(dist(p[a],p[b])/ref-1));}
  if(i<2)continue;
  const prev=frames[i-1],pp=prev.render_im||prev.im||[],prev2=frames[i-2],pp2=prev2.render_im||prev2.im||[];
  const dt=f.t-prev.t,dt0=prev.t-prev2.t;
  if(!(dt>0&&dt<=maxGap&&dt0>0&&dt0<=maxGap)||f.camera_segment_id!==prev.camera_segment_id||prev.camera_segment_id!==prev2.camera_segment_id){segmentChanges.push(i);continue;}
  for(const j of KEY){if(!ok(p[j])||!ok(pp[j])||!ok(pp2[j]))continue;
   // Second temporal difference penalizes jumpiness but is NOT a measure of ground truth.
   const u=(p[j][0]-pp[j][0])/dt,v=(p[j][1]-pp[j][1])/dt;
   const u0=(pp[j][0]-pp2[j][0])/dt0,v0=(pp[j][1]-pp2[j][1])/dt0;
   const acceleration=Math.hypot(u-u0,v-v0)/((dt+dt0)*.5);
   if(Number.isFinite(acceleration))jumps.push(acceleration);
  }
 }
 const coverage=validFrames.size/total;
 const boneP95=percentile(boneDeviations,.95),jitterP95=percentile(jumps,.95),residualP95=percentile(residuals,.95);
 // Uncalibrated heuristics are warnings only, not model-confidence percentages.
 const warnings=[];
 if(coverage<.8)warnings.push('low_usable_joint_coverage');
 if(boneP95!==null&&boneP95>.18)warnings.push('segment_length_inconsistency');
 if(jitterP95!==null&&jitterP95>65)warnings.push('temporal_acceleration_outliers');
 if(residualP95!==null&&residualP95>.06)warnings.push('large_corrections_from_raw_detector');
 const state=coverage<.5?'insufficient_evidence':warnings.length?'review_required':'no_obvious_numeric_anomaly';
 return {schema:BACH_RECONSTRUCTION_AUDIT_VERSION,available:true,frame_count:total,
   usable_pose_frame_fraction:Number(coverage.toFixed(4)),
   segment_length_relative_error_p95:boneP95===null?null:Number(boneP95.toFixed(5)),
   normalized_joint_observation_residual_p95:residualP95===null?null:Number(residualP95.toFixed(5)),
   temporal_acceleration_proxy_p95:jitterP95===null?null:Number(jitterP95.toFixed(5)),
   camera_or_timestamp_breaks:segmentChanges.length,observations:{jitter:jumps.length,bones:boneDeviations.length},
   status:state,warnings,method:'measured pose consistency; distinct from joint confidence and visual fidelity',
   disclaimer:'Not measured 3D accuracy, not calibrated metres, not proof that noise is eliminated.'};
}
