/** Purcell experimental wide-search v1: 21 genuinely different, bounded 2D motion hypotheses.
 * No claims of force, injury risk, muscle activation or 3D reconstruction from 2D poses.
 * Deterministic and reproducible. Never mutates measured frames. */
export const SEARCH_VERSION='purcell-wide-search-v1';
const chains={left_arm:[11,13,15,17,19,21],right_arm:[12,14,16,18,20,22],left_leg:[23,25,27,29,31],right_leg:[24,26,28,30,32],trunk:[11,12,23,24]};
const variants=[
 ['left_arm','arc_up'],['left_arm','arc_down'],['left_arm','lateral'],['left_arm','vertical'],
 ['right_arm','arc_up'],['right_arm','arc_down'],['right_arm','lateral'],['right_arm','vertical'],
 ['left_leg','forward'],['left_leg','retract'],['left_leg','lift'],['left_leg','lateral'],
 ['right_leg','forward'],['right_leg','retract'],['right_leg','lift'],['right_leg','lateral'],
 ['trunk','rotate_left'],['trunk','rotate_right'],['trunk','rise'],['trunk','lower'],['trunk','lateral']
];
export function variantDefinitions(){return variants.map(([chain,mode],i)=>({id:`hyp-${String(i+1).padStart(2,'0')}`,chain,mode}));}
const finite=n=>typeof n==='number'&&Number.isFinite(n);
const valid=p=>Array.isArray(p)&&finite(p[0])&&finite(p[1])&&(p[3]??1)>=.25;
const mean=a=>a.length?a.reduce((s,x)=>s+x,0)/a.length:0;
function pointDelta(mode,phase,amp){const p=phase,arc=Math.sin(Math.PI*p),wave=Math.sin(Math.PI*2*p);switch(mode){
 case 'arc_up':return [amp*.45*wave,-amp*arc];case 'arc_down':return [amp*.45*wave,amp*arc];
 case 'lateral':return [amp*arc,0];case 'vertical':return [0,-amp*arc];
 case 'forward':return [amp*arc,-amp*.18*arc];case 'retract':return [-amp*arc,amp*.15*arc];
 case 'lift':return [amp*.2*wave,-amp*arc];case 'rotate_left':return [-amp*.75*arc,-amp*.08*wave];
 case 'rotate_right':return [amp*.75*arc,amp*.08*wave];case 'rise':return [0,-amp*.65*arc];
 case 'lower':return [0,amp*.65*arc];default:return [amp*.75*wave,amp*.13*arc];}}
function cloneFrames(frames){return frames.map(f=>({...f,im:(f.im||[]).map(p=>Array.isArray(p)?p.slice():p),w:[],pose3d:null}));} // Synthetic 2D variations must never silently reuse unchanged original 3D coordinates.
function modify(frames,{chain,mode},amplitude){const out=cloneFrames(frames);const ids=chains[chain];
 const n=frames.length;
 for(let i=1;i<n-1;i++){
   const phase=i/(n-1),ease=Math.sin(Math.PI*phase)**2;
   const [dx,dy]=pointDelta(mode,phase,amplitude);const points=out[i].im;
   for(let j=0;j<ids.length;j++){
     const id=ids[j],p=points[id];if(!valid(p))continue;
     // Maintain almost stationary joint roots; progressively larger distal motion.
     const strength=(chain==='trunk'?.75:j===0?.08:j===1?.34:j===2?.75:1);
     // Foot-contact toes/heels are never displaced by the generic generator.
     if((chain==='left_leg'||chain==='right_leg') && id>=29)continue;
     p[0]=Math.max(.01,Math.min(.99,p[0]+dx*strength*ease));p[1]=Math.max(.01,Math.min(.99,p[1]+dy*strength*ease));
   }
 }
 return out;
}
const bones=[[11,13],[13,15],[12,14],[14,16],[23,25],[25,27],[24,26],[26,28],[11,23],[12,24],[23,24],[11,12]];
function measures(original,altered){
 let path=0,jerk=0,boneError=0,maxBoneError=0,pointCount=0,clip=0,changed=0,speedChange=0;
 const focus=[11,12,13,14,15,16,23,24,25,26,27,28];
 for(let i=0;i<altered.length;i++){
  const a=original[i].im||[],b=altered[i].im||[];
  for(const id of focus){if(!valid(a[id])||!valid(b[id]))continue;const dx=b[id][0]-a[id][0],dy=b[id][1]-a[id][1];path+=Math.hypot(dx,dy);changed+=Math.hypot(dx,dy)>.002?1:0;pointCount++;if(b[id][0]<=.012||b[id][0]>=.988||b[id][1]<=.012||b[id][1]>=.988)clip++;}
  for(const [x,y] of bones){if(!valid(a[x])||!valid(a[y])||!valid(b[x])||!valid(b[y]))continue;const old=Math.hypot(a[x][0]-a[y][0],a[x][1]-a[y][1]);const next=Math.hypot(b[x][0]-b[y][0],b[x][1]-b[y][1]);if(old>.015){const err=Math.min(5,Math.abs(next-old)/old);boneError+=err;maxBoneError=Math.max(maxBoneError,err);}}
  if(i<2)continue;
  const t0=Number(altered[i-2].t),t1=Number(altered[i-1].t),t2=Number(altered[i].t);
  if(!(t0<t1&&t1<t2)||t2-t0>.6)continue;
  for(const id of focus){const p=b[id],q=altered[i-1].im?.[id],r=altered[i-2].im?.[id];if(!valid(p)||!valid(q)||!valid(r))continue;
   const ax=(p[0]-q[0])/(t2-t1),ay=(p[1]-q[1])/(t2-t1),bx=(q[0]-r[0])/(t1-t0),by=(q[1]-r[1])/(t1-t0);
   jerk+=Math.min(8,Math.hypot(ax-bx,ay-by));
   const ap=original[i].im?.[id],aq=original[i-1].im?.[id];if(valid(ap)&&valid(aq))speedChange+=Math.abs(Math.hypot(ax,ay)-Math.hypot((ap[0]-aq[0])/(t2-t1),(ap[1]-aq[1])/(t2-t1)));
  }
 }
 const total=Math.max(1,pointCount);return {mean_displacement:path/total,bone_distortion:boneError/Math.max(1,altered.length*bones.length),max_bone_distortion:maxBoneError,acceleration_proxy:jerk/total,speed_deviation:speedChange/total,clipped:clip,changed};
}
export function generate21Hypotheses({frames,goal='balanced',memory=[],context=[]}={}){
 if(!Array.isArray(frames)||frames.length<7)throw Error('Для 21 гипотез нужны минимум 7 кадров.');
 if(frames.length>600)throw Error('Для перебора выберите связку короче (до 600 кадров).');
 const prefs={};for(const entry of memory.slice(-500))if(entry&&entry.family&&['chosen','rejected'].includes(entry.decision)){
    const x=prefs[entry.family]||(prefs[entry.family]={good:0,bad:0});if(entry.decision==='chosen')x.good++;else x.bad++;
 }
 const cues=Array.isArray(context)?context.slice(0,30):[];
 const results=variantDefinitions().map((def,i)=>{
  const gain=prefs[def.chain+':'+def.mode]||{good:0,bad:0};
  const amplitude=Math.max(.012,Math.min(.048,.028*(1+Math.min(4,gain.good)*.07-Math.min(4,gain.bad)*.07)*(1+(i%3)*.10)));
  const altered=modify(frames,def,amplitude),metrics=measures(frames,altered);
  // A large deformation is a hypothesis, not an improvement. Metric is a screening score, not a biomechanics ground truth.
  const threshold=goal==='stability'?.075:goal==='speed'?.095:.085;
  const constraints={endpoints_fixed:true,foot_contacts_preserved:true,segment_distortion_ok:metrics.bone_distortion<threshold,frame_bounds_ok:metrics.clipped<Math.max(2,frames.length*.06),temporal_stability_ok:metrics.acceleration_proxy<1.5};
  const passed=Object.values(constraints).every(Boolean);
  const economy=100-Math.min(65,metrics.mean_displacement*1400);
  const anatomy=100-Math.min(85,metrics.bone_distortion*700);
  const smoothness=100-Math.min(70,metrics.acceleration_proxy*12);
  const speed=100-Math.min(70,metrics.speed_deviation*160);
  const stability=constraints.foot_contacts_preserved?100:0;
  const subScores={anatomical_consistency:anatomy,temporal_smoothness:smoothness,speed_preservation:speed,contact_preservation:stability,movement_economy:economy};
  const weights=goal==='speed'?[.20,.15,.40,.15,.10]:goal==='stability'?[.30,.20,.10,.35,.05]:goal==='economy'?[.25,.20,.10,.15,.30]:[.28,.22,.20,.20,.10];
  const relevant=cues.filter(c=>{
    const kind=String(c?.kind||'').toLowerCase();
    return (def.chain.includes('arm')&&/hand|strike|block|punch|arm/.test(kind)) ||
      (def.chain.includes('leg')&&/kick|stance|balance|transition|leg/.test(kind)) ||
      (def.chain==='trunk'&&/stance|balance|transition|trunk|rotation/.test(kind));
  });
  // Research only prioritizes relevant *families*; it does not certify a simulated trajectory.
  const references=[...new Set(relevant.flatMap(c=>(c.research_evidence||[]).map(e=>e.id).filter(Boolean)))].slice(0,8);
  const sourceBias=Math.min(2,relevant.length*.6)+Math.min(1,references.length*.15);
  const score=Math.round(Math.min(100,Object.values(subScores).reduce((a,x,j)=>a+x*weights[j],0)+sourceBias)*10)/10;
  return {...def,family:def.chain+':'+def.mode,score,passed,constraints,metrics,subScores,frames:altered,amplitude,feedback_prior:gain,knowledge_basis:{matched_findings:relevant.length,evidence_ids:references}};
 });
 const ranked=results.filter(x=>x.passed).sort((a,b)=>b.score-a.score);
 const picks=[];for(const item of ranked){if(picks.every(p=>p.chain!==item.chain)||picks.length>=2){picks.push(item);if(picks.length===3)break;}}
 for(const item of ranked)if(picks.length<3&&!picks.includes(item))picks.push(item);
 return {schema:SEARCH_VERSION,count:results.length,accepted:ranked.length,rejected:results.length-ranked.length,candidates:results,top:picks};
}

/** v2 reproducible bounded high-diversity search. Lazy: one full pose copy at a time. */
export const SEARCH_1000_VERSION='purcell-wide-search-v2-1000';
const modes1000=['arc_up','arc_down','lateral','vertical','forward','retract','lift','rotate_left','rotate_right','rise','lower','side_path','center_path','open_hip','close_hip','counter_rotate','reverse_path','spiral_in','spiral_out','delayed_peak'];
function highDiversityDisplacement(mode,phase,amplitude,sign){
 const p=phase,arc=Math.sin(Math.PI*p),wave=Math.sin(2*Math.PI*p);
 switch(mode){
  case 'side_path':return [sign*amplitude*arc,-amplitude*.4*wave];
  case 'center_path':return [-sign*amplitude*arc,-amplitude*.35*wave];
  case 'open_hip':return [amplitude*arc,amplitude*.3*wave];
  case 'close_hip':return [-amplitude*arc,amplitude*.3*wave];
  case 'counter_rotate':return [sign*amplitude*wave,-amplitude*.30*arc];
  case 'reverse_path':return [-sign*amplitude*wave,amplitude*.5*arc];
  case 'spiral_in':return [amplitude*arc*Math.cos(3*Math.PI*p),amplitude*arc*Math.sin(3*Math.PI*p)];
  case 'spiral_out':return [-amplitude*arc*Math.cos(3*Math.PI*p),-amplitude*arc*Math.sin(3*Math.PI*p)];
  case 'delayed_peak':return [sign*amplitude*Math.sin(Math.PI*p)**4,amplitude*.6*Math.sin(2*Math.PI*p)];
  default:{const [dx,dy]=pointDelta(mode,p,amplitude);return [dx*sign,dy];}
 }
}
export function candidateDefinition1000(index){
 if(!Number.isInteger(index)||index<0||index>=1000)throw Error('Candidate index out of range');
 const chain=Object.keys(chains)[Math.floor(index/200)];
 const local=index%200,mode=modes1000[Math.floor(local/10)];
 const intensity=local%5,phaseShift=Math.floor(local%10/5);
 return {id:'hyp-'+String(index+1).padStart(4,'0'),chain,mode,intensity,phaseShift,sign:((Math.floor(index/5)%2)===0?1:-1),family:chain+':'+mode};
}
export function generateCandidate1000(frames,index,{memory=[]}={}){
 if(!Array.isArray(frames)||frames.length<7||frames.length>400)throw Error('Выберите связку длиной 7–400 отсчётов');
 const def=candidateDefinition1000(index);
 // Only gentle, bounded sampling bias from explicitly confirmed historical decisions.
 const same=(memory||[]).filter(x=>x?.family===def.family);
 const positive=same.filter(x=>['select','chosen'].includes(x.decision)).length,negative=same.filter(x=>['reject','rejected'].includes(x.decision)).length;
 const feedbackFactor=Math.max(.88,Math.min(1.12,1+(positive-negative)*.015));
 const amplitude=[.018,.038,.064,.095,.135][def.intensity]*feedbackFactor,out=cloneFrames(frames);
 const points=chains[def.chain],root=def.chain==='trunk'?null:def.chain.includes('arm')?(def.chain==='left_arm'?11:12):(def.chain==='left_leg'?23:24);
 for(let i=1;i<frames.length-1;i++){
  let phase=i/(frames.length-1);phase=def.phaseShift?phase**1.5:Math.sqrt(phase);
  const envelope=Math.sin(Math.PI*i/(frames.length-1))**2;
  const [dx,dy]=highDiversityDisplacement(def.mode,phase,amplitude,def.sign);
  for(let k=0;k<points.length;k++){
   const id=points[k],p=out[i].im?.[id];if(!valid(p))continue;
   if(def.chain.includes('leg')&&id>=29)continue;
   const strength=def.chain==='trunk'?.72:k===0?.08:k===1?.35:k===2?.80:1;
   const inversion=def.mode==='counter_rotate'&&k<=1?-1:1;
   p[0]=Math.min(.99,Math.max(.01,p[0]+dx*envelope*strength*inversion));
   p[1]=Math.min(.99,Math.max(.01,p[1]+dy*envelope*strength));
  }
  // Opposite hip compensation is intentionally part of open/closed pelvis exploration.
  if(def.chain==='trunk'&&['open_hip','close_hip','counter_rotate'].includes(def.mode)){
   const a=out[i].im?.[23],b=out[i].im?.[24];
   if(valid(a)&&valid(b)){a[0]=Math.min(.99,Math.max(.01,a[0]-dx*envelope*.45));b[0]=Math.min(.99,Math.max(.01,b[0]+dx*envelope*.45));}
  }
 }
 const metrics=measures(frames,out);
 // Severe hypotheses are logged as failing anatomical plausibility, never silently promoted.
 const constraints={endpoints_fixed:true,foot_contacts_preserved:true,segment_distortion_ok:metrics.bone_distortion<.16&&metrics.max_bone_distortion<.70,frame_bounds_ok:metrics.clipped<Math.max(3,frames.length*.08),temporal_stability_ok:metrics.acceleration_proxy<2.4};
 const passed=Object.values(constraints).every(Boolean);
 const anatomical=Math.max(0,100-metrics.bone_distortion*480);
 const smooth=Math.max(0,100-metrics.acceleration_proxy*10);
 const economy=Math.max(0,100-metrics.mean_displacement*850-metrics.speed_deviation*130);
 const speed=Math.max(0,100-metrics.speed_deviation*110);
 const score=Math.round((anatomical*.3+smooth*.25+economy*.25+speed*.2)*10)/10;
 return {...def,frames:out,amplitude,metrics,constraints,passed,score,subScores:{anatomical_consistency:anatomical,temporal_smoothness:smooth,movement_economy:economy,speed_preservation:speed}};
}


/** 10k expansion: ten independently phased/amplified trajectories for each of 1k base families. */
export const SEARCH_10000_VERSION='purcell-wide-search-v3-10000';
export function generateCandidate10000(frames,index,{memory=[]}={}){
 if(!Number.isInteger(index)||index<0||index>=10000)throw Error('10k candidate index out of range');
 const layer=Math.floor(index/1000),baseIndex=index%1000;
 const c=generateCandidate1000(frames,baseIndex,{memory});
 const ids=chains[c.chain];
 const mode=modes1000[(baseIndex*7+layer*3)%modes1000.length];
 const sign=((layer+Math.floor(baseIndex/5))%2)?-1:1;
 const amplitude=[.012,.024,.038,.052,.068,.084,.102,.122,.145,.17][layer];
 const out=c.frames;
 for(let i=1;i<out.length-1;i++){
   const phase=i/(out.length-1),shift=layer%3;
   const q=shift===0?phase:shift===1?phase**1.7:Math.sqrt(phase);
   const env=Math.sin(Math.PI*i/(out.length-1))**2;
   const [dx,dy]=highDiversityDisplacement(mode,q,amplitude,sign);
   for(let k=0;k<ids.length;k++){
     const id=ids[k],pt=out[i].im?.[id];if(!valid(pt))continue;
     const strength=c.chain==='trunk'?.58:k===0?.05:k===1?.24:k===2?.62:1;
     pt[0]=Math.max(.005,Math.min(.995,pt[0]+dx*env*strength));
     pt[1]=Math.max(.005,Math.min(.995,pt[1]+dy*env*strength));
   }
 }
 const metrics=measures(frames,out);
 const constraints={endpoints_fixed:true,foot_contacts_preserved:true,segment_distortion_ok:metrics.bone_distortion<.16&&metrics.max_bone_distortion<.70,frame_bounds_ok:metrics.clipped<Math.max(3,frames.length*.08),temporal_stability_ok:metrics.acceleration_proxy<2.4};
 const passed=Object.values(constraints).every(Boolean);
 const anatomical=Math.max(0,100-metrics.bone_distortion*480),smooth=Math.max(0,100-metrics.acceleration_proxy*10),economy=Math.max(0,100-metrics.mean_displacement*850-metrics.speed_deviation*130),speed=Math.max(0,100-metrics.speed_deviation*110);
 return {...c,id:'hyp-'+String(index+1).padStart(5,'0'),family:c.family,mode:`${c.mode}+${mode}-v${layer+1}`,layer,amplitude:Math.max(c.amplitude,amplitude),frames:out,metrics,constraints,passed,score:Math.round((anatomical*.3+smooth*.25+economy*.25+speed*.2)*10)/10,subScores:{anatomical_consistency:anatomical,temporal_smoothness:smooth,movement_economy:economy,speed_preservation:speed}};
}
