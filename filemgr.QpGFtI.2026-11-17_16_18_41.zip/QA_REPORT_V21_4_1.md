# QA report — Falco Jugger 21.4.1

Date: 2026-11-04

## Release checks

- `php -l index.php` — PASS.
- PHP lint for the release test set — PASS (executed by `tests/verify.sh`).
- Shell syntax checks for release and media-import installers — PASS.
- JavaScript syntax smoke tests — PASS.
- `tests/avatar-render-core-smoke.mjs` — PASS: monotone interpolation, bounded landmark interpolation, one-sided display fallback, relative near/far scale, world-normalized 2D/3D features, independent camera-segment baselines and no smoothing across cuts.
- Existing biomechanics, device profile, kata recognition, kick-window, learning API, optimizer, social-file lifecycle and media-import regression tests — PASS.
- Full `bash tests/verify.sh` — PASS.
- CSS stylesheet parsed with `tinycss2` — no syntax error tokens.
- Local PHP serving check — `index.php` returned HTTP 200; `avatar-render-core.mjs?v=21.4.1` returned HTTP 200 with JavaScript content type.

## Key implementation checks

- `.analysis-dock` is in normal document flow (`position:relative`, not sticky); player columns stack at 960 px and below; nested panels and media have zero minimum width and bounded maximum width.
- Avatar rendering uses `requestAnimationFrame` independently of the encoded video-frame callback rate. `requestVideoFrameCallback` supplies source PTS anchors; display poses are interpolated with monotonic cubic Hermite interpolation and cannot overshoot the two measured endpoints. The renderer does not blend across camera-segment boundaries.
- Canvas backing density is reduced adaptively if observed render cadence falls below target; the visible FPS counter reports measured render-loop cadence. A true 60 FPS guarantee is not possible across 30-Hz displays, throttled/background tabs, browser scheduling, or constrained CPU/GPU hardware.
- Relative depth prefers matched 2D projection / MediaPipe 3D body-segment lengths when enough points are reliable, and falls back to apparent size from multiple body regions. The baseline is recalculated per camera segment.
- Foot support adds world-space foot pitch and 2D plantar flatness to the existing heel/toe/ankle/shin geometry and temporal stability score. The avatar has a separately drawn plantar mesh with heel pad, forefoot pad and inferred medial arch.

## Limits and manual validation

The depth signal is relative to the median apparent scale of each camera segment; it is not metric depth. A monocular recording cannot reliably separate athlete depth motion from camera dolly or optical zoom without fixed-scene feature tracking and camera calibration. MediaPipe world landmarks improve foreshortening compensation but remain monocular pose estimates.

The foot surface is an inferred anatomical rendering from heel, toe and ankle landmarks, not a scan or pressure map. Neither support score nor plantar shading should be interpreted as measured ground-reaction force.

The automated release suite and CSS parsing passed. A physical 60-FPS benchmark and visual acceptance run with representative kata recordings on the target user device are still required to validate actual device/browser cadence and landmark quality under motion blur, loose clothing and camera cuts.
