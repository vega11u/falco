import {
  purgeFalcoOriginCaches,
  buildHardUpdateUrl,
  stripHardUpdateMarker
} from './hard-update-core-v23.0.19.mjs?v=23.0.19';

(() => {
  'use strict';
  const button = document.getElementById('hardUpdateBtn');
  if (!button || button.dataset.hardUpdateReady === '1') return;
  button.dataset.hardUpdateReady = '1';

  const RESULT_KEY = 'falco-hard-update-result-v23.0.19';
  function showCompletionToast(result) {
    const toast = document.createElement('div');
    toast.className = 'falco-hard-update-toast';
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');
    const deleted = Number(result?.deletedCaches || 0);
    const workers = Number(result?.workers || 0);
    const cacheNote = result?.cacheStorageAvailable ? `Удалено Cache Storage: ${deleted}` : 'Cache Storage недоступен';
    const httpNote = result?.httpCacheHeaderRequested ? ' · HTTP-кэш: команда браузеру отправлена' : ' · HTTP-кэш: серверная команда не подтверждена';
    toast.innerHTML = `<strong>HARD UPDATE завершён</strong><span>${cacheNote}${httpNote} · Service Workers: ${workers}. Модели при необходимости загрузятся заново.</span>`;
    document.body.append(toast);
    window.setTimeout(() => toast.classList.add('is-visible'), 30);
    window.setTimeout(() => {
      toast.classList.remove('is-visible');
      window.setTimeout(() => toast.remove(), 250);
    }, 6500);
  }

  // Remove the one-time navigation nonce after the fresh document has loaded.
  try {
    const current = new URL(window.location.href);
    if (current.searchParams.has('__falco_hard_update')) {
      current.searchParams.delete('__falco_hard_update');
      window.history.replaceState(window.history.state, '', current.href);
      const raw = window.sessionStorage.getItem(RESULT_KEY);
      if (raw) {
        window.sessionStorage.removeItem(RESULT_KEY);
        showCompletionToast(JSON.parse(raw));
      }
    }
  } catch (_) { /* Private browsing may deny sessionStorage; update still works. */ }

  function mountDialog() {
    let dialog = document.getElementById('falcoHardUpdateDialog');
    if (dialog) return dialog;
    dialog = document.createElement('dialog');
    dialog.id = 'falcoHardUpdateDialog';
    dialog.className = 'falco-hard-update-dialog';
    dialog.setAttribute('aria-labelledby', 'falcoHardUpdateTitle');
    dialog.innerHTML = `
      <div class="falco-hard-update-window">
        <div class="falco-hard-update-titlebar"><span class="falco-hard-update-orb" aria-hidden="true">↻</span><span>Falco Jugger · системное обновление</span><button type="button" class="falco-hard-update-x" data-hard-close aria-label="Закрыть">×</button></div>
        <div class="falco-hard-update-content">
          <div class="falco-hard-update-kicker">HARD UPDATE</div>
          <h2 id="falcoHardUpdateTitle">Очистить кэш и загрузить актуальную версию?</h2>
          <p>Команда отправит браузеру HTTP-заголовок <code>Clear-Site-Data: "cache"</code> (для очистки HTTP-кэша в поддерживающих браузерах), удалит все Cache Storage этого домена, включая веса Depth Anything / Transformers.js, и снимет Service Worker, если он управляет этой страницей.</p>
          <ul>
            <li><strong>Будут очищены:</strong> кэш приложения, браузерные Cache Storage и локальные кэшированные веса моделей.</li>
            <li><strong>Не будут удалены:</strong> обученные базы Lully/Purcell на сервере, отчёты, настройки, cookies, черновик страницы и IndexedDB.</li>
            <li><strong>После обновления:</strong> веса моделей при следующем анализе могут скачаться заново.</li>
          </ul>
          <p class="falco-hard-update-caution">Если анализ или серверный импорт сейчас выполняется, сначала остановите его. HARD UPDATE не отменяет серверные задания и не очищает серверные блокировки импорта. Очистка HTTP-кэша через Clear-Site-Data зависит от поддержки браузера.</p>
          <div class="falco-hard-update-progress" data-hard-status role="status" aria-live="polite">Кэш ещё не очищен.</div>
          <div class="falco-hard-update-actions"><button type="button" class="btn" data-hard-close>Отмена</button><button type="button" class="btn primary" data-hard-confirm><span aria-hidden="true">↻</span> Очистить кэш и обновить</button></div>
        </div>
      </div>`;
    document.body.append(dialog);
    dialog.querySelectorAll('[data-hard-close]').forEach(node => node.addEventListener('click', () => dialog.close()));
    dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
    dialog.querySelector('[data-hard-confirm]')?.addEventListener('click', runHardUpdate);
    return dialog;
  }

  async function runHardUpdate() {
    const dialog = mountDialog();
    const confirmButton = dialog.querySelector('[data-hard-confirm]');
    const status = dialog.querySelector('[data-hard-status]');
    if (confirmButton?.disabled) return;
    if (confirmButton) confirmButton.disabled = true;
    if (status) status.textContent = 'Удаляю Cache Storage и регистрации Service Worker…';
    button.disabled = true;
    button.setAttribute('aria-busy', 'true');
    try {
      let httpCacheHeaderRequested = false;
      let serverHeaderWarning = '';
      try {
        const response = await fetch(new URL('index.php?api=hard-update-clear-cache', document.baseURI), {
          method: 'POST', credentials: 'same-origin', cache: 'no-store',
          headers: { 'Accept': 'application/json', 'Content-Type': 'application/json', 'Cache-Control': 'no-cache' },
          body: '{}'
        });
        const payload = await response.json();
        if (!response.ok || payload?.ok !== true) throw new Error(payload?.error || `HTTP ${response.status}`);
        httpCacheHeaderRequested = payload.clear_site_data === 'cache';
      } catch (error) {
        serverHeaderWarning = String(error?.message || error);
      }
      const result = await purgeFalcoOriginCaches({
        cacheStorage: window.caches,
        serviceWorker: navigator.serviceWorker,
        currentUrl: window.location.href
      });
      if (result.errors.length) {
        const details = result.errors.map(item => `${item.scope}: ${item.message}`).join(' · ');
        throw new Error(`Не все кэши удалось очистить. ${details}`);
      }
      const report = {
        deletedCaches: result.deletedCacheNames.length,
        cacheStorageAvailable: result.cacheStorageAvailable,
        cacheCountBefore: result.cacheCountBefore,
        workers: result.serviceWorkersRemoved,
        httpCacheHeaderRequested,
        serverHeaderWarning,
        at: new Date().toISOString()
      };
      try { window.sessionStorage.setItem(RESULT_KEY, JSON.stringify(report)); } catch (_) {}
      if (status) status.textContent = `Очищено Cache Storage: ${report.deletedCaches}. ${httpCacheHeaderRequested ? 'Команда очистки HTTP-кэша отправлена.' : 'HTTP-кэш может потребовать ручного обновления браузера.'} Перезагружаю приложение…`;
      const next = buildHardUpdateUrl(window.location.href, Date.now());
      window.setTimeout(() => window.location.replace(next), 220);
    } catch (error) {
      if (status) status.textContent = `Ошибка HARD UPDATE: ${error?.message || error}. Повторите попытку или обновите страницу вручную.`;
      if (confirmButton) { confirmButton.disabled = false; confirmButton.textContent = 'Повторить очистку'; }
      button.disabled = false;
      button.removeAttribute('aria-busy');
    }
  }

  button.addEventListener('click', () => {
    const dialog = mountDialog();
    const confirmButton = dialog.querySelector('[data-hard-confirm]');
    const status = dialog.querySelector('[data-hard-status]');
    if (confirmButton) { confirmButton.disabled = false; confirmButton.innerHTML = '<span aria-hidden="true">↻</span> Очистить кэш и обновить'; }
    if (status) status.textContent = 'Кэш ещё не очищен.';
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else if (window.confirm('Удалить все Cache Storage этого домена, включая локально закэшированные веса моделей, и перезагрузить Falco Jugger? Обучение, отчёты, настройки и IndexedDB останутся.')) runHardUpdate();
  });
})();
