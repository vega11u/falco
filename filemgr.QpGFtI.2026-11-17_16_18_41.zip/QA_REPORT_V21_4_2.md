# Falco Jugger 21.4.2 — QA report

Date: 2026-11-04
Scope: per-limb depth, articulated hand display, garment-envelope cues and look-ahead trajectory refinement.

## Implemented and checked

- Pose/Hand data path: 33 Pose landmarks and up to 21 landmarks per detected hand. Hands with no explicit handedness are associated to the nearest visible Pose wrist when the distances are sufficiently unambiguous; one visible wrist is accepted as a fallback.
- Relative depth: shoulder, elbow, wrist, hip, knee, ankle, heel, toe and all five fingertips are measured independently against chest/pelvis reference planes. Values are normalized by torso length; depth velocity is differentiated only within a camera segment and across short valid time intervals.
- Report: `analysis.body_part_depth` contains per-side/per-landmark sample count, median, P10/P90, mean confidence, median depth velocity, direction proportions and a characteristic timestamp. The advanced report table links each row to that timestamp.
- Avatar: volumetric palm plate, five articulated phalange chains, joint nodes, fingertip markers and a palm-normal cue. Hand/finger landmarks are included in trajectory comparison and constrained correction.
- Garment envelope: person segmentation mask width is sampled along torso, sleeves and trouser axes. These geometric cues may adapt avatar volume. No semantic kimono classifier or clothing-trained model is shipped.
- Look-ahead optimization: observed movement onsets (low prior speed followed by a future motion vector) are stored in the readiness analysis and protected as launch-pose anchors. The optimizer preserves the empirically observed next-phase direction and rejects passes with material continuity degradation in sufficiently supported groups.
- User feedback: a low score for next-movement preparation increases directional protection on the following pass; high scores permit more filtering along the observed movement axis. Source observations are not overwritten.

## Automated checks

Executed `bash tests/verify.sh` after the final source changes.

Results:

- Karate intelligence data smoke: PASS.
- PHP release smoke: PASS (v21.4.2; 5 JSON assets validated).
- Local video and media-import smoke: PASS.
- Device profile and JavaScript syntax checks: PASS.
- Biomechanics core smoke: PASS (quality 98/100; acceleration reduction approximately 3.87% on the synthetic test sequence).
- Learning API smoke: PASS (confirmed-only examples, feedback separation and training archive integrity).
- Optimizer UI/constraints smoke: PASS.
- Avatar render core smoke: PASS.
- Temporal pattern recognition and kick-window smoke: PASS.
- Social file lifecycle and media-import resilience smoke: PASS.

The optional detached CRON integration smoke is separate and was not run as part of the standard verification command.

## Important limits

- Depth is a monocular relative estimate in torso-length units, not a metric distance in metres. MediaPipe world landmarks are model estimates; camera calibration, a known scene scale, or synchronized multi-view capture would be required for reliable room-space depth. Camera motion, zoom, occlusion and body rotation can still bias the estimate.
- Hand Landmarker supplies 21 landmarks per detected hand. The avatar's palm/finger surfaces between those points are a rendered geometric reconstruction, not extra independently sensed anatomical points. Severe occlusion, motion blur and small hands in the source video reduce accuracy.
- Person segmentation estimates the visible outer silhouette. Sleeve/trouser widths can help adapt the avatar to loose clothing, but the current pipeline does not identify kimono semantics, cloth type, folds or true hidden joint locations.
- Look-ahead optimization is conservative trajectory regularization, not inverse dynamics, optimal control or a trained karate coach. It can preserve an observed pre-onset pose and future movement direction; it cannot infer a uniquely optimal starting pose, muscle force, ground reaction force, energy expenditure or true performance efficiency without reference trajectories and calibrated biomechanical measurements.
- Automated smoke tests validate software contracts and synthetic edge cases; they do not establish sports-science accuracy on real athletes. Real-kata validation across frontal, diagonal, side and broadcast camera cuts remains necessary.

## Release status

Source lint and the standard automated release suite pass. The release package is a full application archive; preserve existing server-side training data and private media-import storage during deployment.
