# QA report — Falco Jugger 21.6.0

Date: 2026-11-05

## Automated checks

| Check | Result |
|---|---|
| `php -l index.php` | PASS |
| `php tests/intelligence-data-smoke.php` | PASS — 102 WKF entries, 35 references, 6 datasets, 24 anatomy groups |
| `php tests/release-smoke.php` | PASS — release v21.6.0 and required application contracts |
| `php tests/local-video-smoke.php` | PASS — local upload/decode and fallback contracts |
| `bash tests/javascript-syntax-smoke.sh` | PASS — all application module syntax checks and 7 focused smoke checks |
| `php tests/learning-api-smoke.php` | PASS — Q16, confirmed-only pattern storage, feedback isolation, complete archive |
| `bash tests/optimizer-smoke.sh` | PASS — optimizer UI/biomechanical constraints |
| `bash tests/media-import-smoke.sh` | PASS — URL allowlist, HLS/client fallbacks, range transfer and SHA-256 lifecycle |
| `bash tests/verify.sh` | PASS — all developer release checks |

The detached CRON integration test was not run; `tests/verify.sh` reports it as a separate opt-in check (`RUN_CRON_INTEGRATION=1`).

## Regression cases added

- The report renderer does not call renderer-block-local `sub3m` from the foot mesh; the foot mesh uses the outer-scope vector helper.
- Left/right support scores are kept numeric; visibility and geometry confidence are sourced from each foot record.
- Foot axis and ankle angle use different anatomical chains.
- Display-track smoothing reduces an isolated low-amplitude tracking spike, does not mutate source landmarks and does not smooth across a camera cut.
- Pose signature remains identical when arbitrary background/room metadata changes.
- The player has a current-frame metrics container and the feedback UI exposes the named rating dimensions.

## Scope and limitations

No user kata video or calibrated motion-capture reference was present in the work session. Therefore visual accuracy of the reconstructed avatar, foot contact, and pattern grouping on the user's own recording has not been empirically validated here. The available pose backend returns 33 body landmarks and optional 21 hand landmarks; its world coordinates are model estimates, not a complete measured surface mesh. The release improves display stability, procedural avatar geometry and landmark semantics, but does not claim an SMPL-X/full-body surface reconstruction, absolute camera calibration, measured contact force or validated sub-centimetre accuracy.
