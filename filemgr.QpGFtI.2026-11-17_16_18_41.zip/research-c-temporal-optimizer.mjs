/**
 * Falco Research C temporal optimizer v1.
 * Conservative, evidence-preserving refinement of existing 2D/3D tracks.
 * It never invents long-occlusion joints, never changes source timestamps, and
 * protects high-velocity events from smoothing. Coordinates remain relative
 * unless a separate verified calibration is present.
 */
export const RESEARCH_C_OPTIMIZER_VERSION = 'falco-research-c-temporal-optimizer-1.0.0';
const J = 33;
const finite = Number.isFinite;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const conf = p => Array.isArray(p) && finite(p[0]) && finite(p[1]) ? clamp(Number(p[3] ?? 0), 0, 1) : 0;
const dist = (a,b,n) => Math.hypot(...Array.from({length:n},(_,k)=>(a?.[k]||0)-(b?.[k]||0)));
const BONES = [[11,12],[11,13],[13,15],[12,14],[14,16],[11,23],[12,24],[23,24],[23,25],[25,27],[27,29],[24,26],[26,28],[28,30]];

function cameraSegment(frame) { return frame?.camera_segment_id ?? 0; }
function fastJointFrames(frames, key='im', threshold=1.25) {
  const fast = new Uint8Array(frames.length);
  const tracked = [15,16,19,20,21,22,27,28,31,32];
  for (let i=1;i<frames.length;i++) {
    const a=frames[i-1],b=frames[i],dt=Number(b.t)-Number(a.t);
    if (!(dt>0 && dt<=.12) || cameraSegment(a)!==cameraSegment(b)) continue;
    let peak=0;
    for (const j of tracked) {
      const p=a[key]?.[j],q=b[key]?.[j];
      if (conf(p)<.35 || conf(q)<.35) continue;
      peak=Math.max(peak,dist(p,q,2)/dt);
    }
    if (peak>=threshold) { fast[i-1]=1; fast[i]=1; }
  }
  // Expand the protected window by one frame on each side.
  const out=fast.slice();
  for(let i=0;i<fast.length;i++) if(fast[i]) { if(i)out[i-1]=1; if(i+1<out.length)out[i+1]=1; }
  return out;
}


function estimateBonePriors(frames) {
  const priors=new Map();
  for(const [a,b] of BONES){
    const values=[];
    for(const f of frames){const p=f.w?.[a],q=f.w?.[b];if(conf(p)>=.68&&conf(q)>=.68){const d=dist(p,q,3);if(d>.015&&d<1.5)values.push(d);}}
    if(values.length<8)continue;
    values.sort((x,y)=>x-y);const mid=values.length>>1,median=values.length%2?values[mid]:(values[mid-1]+values[mid])/2;
    const deviations=values.map(x=>Math.abs(x-median)).sort((x,y)=>x-y),mad=deviations[deviations.length>>1];
    priors.set(`${a}-${b}`,{a,b,length:median,mad:mad||.002,samples:values.length});
  }
  return priors;
}
function boneResidualSummary(frames,priors){
  const rows=[];
  for(const prior of priors.values()){
    const errors=[];
    for(const f of frames){const p=f.w?.[prior.a],q=f.w?.[prior.b];if(conf(p)>=.35&&conf(q)>=.35){const d=dist(p,q,3);if(finite(d))errors.push(Math.abs(d-prior.length));}}
    if(errors.length){errors.sort((a,b)=>a-b);rows.push({bone:`${prior.a}-${prior.b}`,samples:errors.length,median_abs_error:errors[errors.length>>1],prior_length_relative:prior.length});}
  }
  return rows;
}
function enforceResearchBoneConstraints(frames,priors,fast,stats,{iterations=6}={}){
  const before=boneResidualSummary(frames,priors);
  for(let pass=0;pass<iterations;pass++){
    for(let i=0;i<frames.length;i++){
      if(fast[i])continue;
      const f=frames[i];
      for(const prior of priors.values()){
        const p=f.w?.[prior.a],q=f.w?.[prior.b],cp=conf(p),cq=conf(q);
        if(cp<.35||cq<.35)continue;
        const delta=[0,1,2].map(k=>(q[k]||0)-(p[k]||0)),length=Math.hypot(...delta);
        if(!(length>.001))continue;
        const error=length-prior.length,tolerance=Math.max(.025,prior.length*.12,prior.mad*3);
        if(Math.abs(error)<=tolerance)continue;
        // High-confidence observations are anchors; only weak observations absorb most correction.
        const wp=Math.max(.025,1-cp),wq=Math.max(.025,1-cq),sum=wp+wq;
        const correction=clamp(error*.24,-.018,.018);
        for(let k=0;k<3;k++){
          const unit=delta[k]/length;
          p[k]+=unit*correction*(wp/sum);
          q[k]-=unit*correction*(wq/sum);
        }
        stats.bone_constraint_updates++;
      }
    }
  }
  stats.bone_residual_before=before;
  stats.bone_residual_after=boneResidualSummary(frames,priors);
}

function optimizeTrack(frames,key,dimension,fast,stats,{maxGap=.10}={}) {
  const confFloor=.24;
  for(let i=1;i<frames.length-1;i++) {
    const prev=frames[i-1],cur=frames[i],next=frames[i+1];
    const t0=Number(prev.t),t1=Number(cur.t),t2=Number(next.t),span=t2-t0;
    if (!(span>0 && span<=maxGap*2) || cameraSegment(prev)!==cameraSegment(cur) || cameraSegment(cur)!==cameraSegment(next)) continue;
    for(let j=0;j<J;j++) {
      const a=prev[key]?.[j],b=cur[key]?.[j],c=next[key]?.[j];
      const ca=conf(a),cb=conf(b),cc=conf(c);
      if(ca<confFloor || cb<.12 || cc<confFloor) continue;
      // Fast motion is evidence, not noise. Never smooth its event window.
      if(fast[i] || fast[i-1] || fast[i+1]) { stats.fast_frames_protected++; continue; }
      const u=(t1-t0)/span;
      const predicted=Array.from({length:dimension},(_,k)=>(a[k]||0)+((c[k]||0)-(a[k]||0))*u);
      const residual=Math.hypot(...predicted.map((v,k)=>v-(b[k]||0)));
      const displacement=dist(a,c,dimension);
      const threshold=dimension===2?.018:.035;
      // Only very-low-confidence, near-static local jitter is attenuated.
      if(cb>.58 || displacement>threshold*3 || residual>threshold || residual<.001) continue;
      const blend=clamp((.58-cb)*.18,.025,.095);
      for(let k=0;k<dimension;k++) b[k]=(b[k]||0)+(predicted[k]-(b[k]||0))*blend;
      stats.low_confidence_jitter_adjustments++;
    }
  }
}

function boneDiagnostics(frames) {
  const result={};
  for(const [a,b] of BONES) {
    const values=[];
    for(const f of frames) { const p=f.w?.[a],q=f.w?.[b]; if(conf(p)>=.5&&conf(q)>=.5) { const d=dist(p,q,3); if(finite(d)&&d>0&&d<2)values.push(d); } }
    if(values.length<5) { result[`${a}-${b}`]={samples:values.length,cv:null}; continue; }
    const mean=values.reduce((s,x)=>s+x,0)/values.length;
    const variance=values.reduce((s,x)=>s+(x-mean)**2,0)/values.length;
    result[`${a}-${b}`]={samples:values.length,mean_relative:mean,cv:mean>0?Math.sqrt(variance)/mean:null};
  }
  return result;
}

export function optimizeResearchSequence(frames,{onProgress=null}={}) {
  if(!Array.isArray(frames)||frames.length>120000) throw new Error('Research C: invalid frame sequence');
  const tracks=frames.map(f=>({t:Number(f.t),camera_segment_id:cameraSegment(f),im:Array.isArray(f.im)?f.im:[],w:Array.isArray(f.w)?f.w:[]}));
  const fast=fastJointFrames(tracks,'im');
  const stats={schema:RESEARCH_C_OPTIMIZER_VERSION,frames:tracks.length,fast_frames_protected:0,low_confidence_jitter_adjustments:0,bone_constraint_updates:0,fast_frame_count:fast.reduce((s,x)=>s+x,0),timestamps_unchanged:true,long_gap_interpolation:0,in_place_landmark_refinement:true,raw_tracks_preserved_by_caller:true};
  optimizeTrack(tracks,'im',2,fast,stats,{maxGap:.10});
  optimizeTrack(tracks,'w',3,fast,stats,{maxGap:.10});
  const priors=estimateBonePriors(tracks);enforceResearchBoneConstraints(tracks,priors,fast,stats,{iterations:6});
  stats.bone_consistency=boneDiagnostics(tracks);
  const cv=Object.values(stats.bone_consistency).map(x=>x.cv).filter(finite);
  stats.median_bone_length_cv=cv.length?cv.sort((a,b)=>a-b)[Math.floor(cv.length/2)]:null;
  stats.limitations=['Monocular depth is relative unless calibrated','Temporal refinement only attenuates low-confidence near-static jitter','No hidden joint is synthesized across long occlusion','Physical plausibility is a rejection/diagnostic signal, not proof of true 3D'];
  onProgress?.({phase:'research-c-temporal-optimizer',completed:tracks.length,total:tracks.length,progress:1,fast_frames_protected:stats.fast_frame_count});
  return {tracks,diagnostics:stats};
}
