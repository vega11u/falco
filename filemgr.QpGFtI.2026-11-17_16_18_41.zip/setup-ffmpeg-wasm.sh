#!/usr/bin/env bash
# Install a local, same-origin FFmpeg.wasm fallback with npm SRI verification.
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
command -v curl >/dev/null 2>&1 || { echo 'ERROR: curl is required.' >&2; exit 1; }
command -v tar >/dev/null 2>&1 || { echo 'ERROR: tar is required.' >&2; exit 1; }
command -v openssl >/dev/null 2>&1 || { echo 'ERROR: openssl is required for npm integrity verification.' >&2; exit 1; }
TMP="$(mktemp -d)"
cleanup(){ rm -rf "$TMP"; }
trap cleanup EXIT

fetch_npm(){
  local package="$1" version="$2" encoded="$3" label="$4"
  local metadata="$TMP/${label}.json" tarball="$TMP/${label}.tgz" unpack="$TMP/${label}-unpack"
  echo "Reading npm metadata: ${package}@${version}..." >&2
  curl --fail --location --retry 4 --connect-timeout 20 --max-time 120 "https://registry.npmjs.org/${encoded}/${version}" -o "$metadata"
  readarray -t info < <(php -r '$x=json_decode(file_get_contents($argv[1]), true); if (!is_array($x) || empty($x["dist"]["tarball"]) || empty($x["dist"]["integrity"])) { exit(1); } echo $x["dist"]["tarball"], "\n", $x["dist"]["integrity"], "\n";' "$metadata")
  [ "${#info[@]}" -ge 2 ] || { echo "ERROR: invalid npm metadata for ${package}." >&2; exit 1; }
  local url="${info[0]}" integrity="${info[1]}"
  [[ "$integrity" == sha512-* ]] || { echo "ERROR: npm package does not provide SHA-512 integrity: ${package}." >&2; exit 1; }
  echo "Downloading ${package}@${version}..." >&2
  curl --fail --location --retry 4 --connect-timeout 20 --max-time 600 "$url" -o "$tarball"
  local expected="${integrity#sha512-}" actual
  actual="$(openssl dgst -sha512 -binary "$tarball" | base64 | tr -d '\r\n')"
  [ "$actual" = "$expected" ] || { echo "ERROR: npm SHA-512 integrity verification failed for ${package}." >&2; exit 1; }
  mkdir -p "$unpack"
  tar -xzf "$tarball" -C "$unpack"
  echo "$unpack/package"
}

FFMPEG_DIR="$ROOT/vendor/ffmpeg"
mkdir -p "$FFMPEG_DIR/ffmpeg/esm" "$FFMPEG_DIR/core/umd"
FFMPEG_PKG="$(fetch_npm '@ffmpeg/ffmpeg' '0.12.15' '%40ffmpeg%2Fffmpeg' 'ffmpeg-js')"
CORE_PKG="$(fetch_npm '@ffmpeg/core' '0.12.10' '%40ffmpeg%2Fcore' 'ffmpeg-core')"
[ -f "$FFMPEG_PKG/dist/esm/index.js" ] || { echo 'ERROR: @ffmpeg/ffmpeg ESM entrypoint missing.' >&2; exit 1; }
[ -f "$CORE_PKG/dist/umd/ffmpeg-core.js" ] && [ -f "$CORE_PKG/dist/umd/ffmpeg-core.wasm" ] || { echo 'ERROR: @ffmpeg/core UMD runtime files missing.' >&2; exit 1; }
cp -a "$FFMPEG_PKG/dist/esm/." "$FFMPEG_DIR/ffmpeg/esm/"
cp -a "$CORE_PKG/dist/umd/." "$FFMPEG_DIR/core/umd/"
[ ! -f "$FFMPEG_PKG/LICENSE" ] || cp "$FFMPEG_PKG/LICENSE" "$FFMPEG_DIR/ffmpeg/LICENSE"
[ ! -f "$CORE_PKG/LICENSE" ] || cp "$CORE_PKG/LICENSE" "$FFMPEG_DIR/core/LICENSE"
printf '%s\n' 'ffmpeg-js=0.12.15' 'ffmpeg-core=0.12.10' > "$FFMPEG_DIR/VERSIONS.txt"
chmod -R a+rX "$FFMPEG_DIR"
echo
echo 'FFmpeg.wasm installed and SHA-512 verified.'
echo "Module: $FFMPEG_DIR/ffmpeg/esm/index.js"
echo "Core:   $FFMPEG_DIR/core/umd/ffmpeg-core.js"
echo 'The browser will load it from this origin only when a source format requires the fallback.'
echo 'Note: FFmpeg.wasm core is GPL-2.0-or-later; review licensing before redistribution.'
