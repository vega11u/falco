/** Panzoom-inspired, dependency-free camera math for the synchronized HTML5 player. */
export function clampZoomView(view, width, height, minScale = 1, maxScale = 4) {
  const w = Math.max(1, Number(width) || 1), h = Math.max(1, Number(height) || 1);
  const scale = Math.max(minScale, Math.min(maxScale, Number(view?.scale) || 1));
  const maxX = w * (scale - 1) / 2, maxY = h * (scale - 1) / 2;
  const x = Math.max(-maxX, Math.min(maxX, Number(view?.x) || 0));
  const y = Math.max(-maxY, Math.min(maxY, Number(view?.y) || 0));
  return { scale, x: Math.abs(x) < 1e-10 ? 0 : x, y: Math.abs(y) < 1e-10 ? 0 : y };
}

export function zoomAtPoint(view, nextScale, point, width, height, minScale = 1, maxScale = 4) {
  const current = clampZoomView(view, width, height, minScale, maxScale);
  const scale = Math.max(minScale, Math.min(maxScale, Number(nextScale) || minScale));
  const ratio = scale / current.scale;
  return clampZoomView({
    scale,
    x: Number(point?.x || 0) - (Number(point?.x || 0) - current.x) * ratio,
    y: Number(point?.y || 0) - (Number(point?.y || 0) - current.y) * ratio
  }, width, height, minScale, maxScale);
}

export function panBy(view, dx, dy, width, height, minScale = 1, maxScale = 4) {
  const current = clampZoomView(view, width, height, minScale, maxScale);
  return clampZoomView({ ...current, x: current.x + (Number(dx) || 0), y: current.y + (Number(dy) || 0) }, width, height, minScale, maxScale);
}

export function pinchZoom(initialView, startDistance, currentDistance, startMidpoint, currentMidpoint, width, height, minScale = 1, maxScale = 4) {
  const initial = clampZoomView(initialView, width, height, minScale, maxScale);
  const ratio = Number(startDistance) > 0 ? Number(currentDistance) / Number(startDistance) : 1;
  const translated = {
    ...initial,
    x: initial.x + (Number(currentMidpoint?.x || 0) - Number(startMidpoint?.x || 0)),
    y: initial.y + (Number(currentMidpoint?.y || 0) - Number(startMidpoint?.y || 0))
  };
  return zoomAtPoint(translated, initial.scale * ratio, startMidpoint, width, height, minScale, maxScale);
}
