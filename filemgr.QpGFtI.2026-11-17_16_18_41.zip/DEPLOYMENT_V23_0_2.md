# Deployment notes — v23.0.2

This release is a patch over v23.0.1. Follow `PATCH_23.0.2.md` for the exact overlay steps and compatibility notes. Keep private server-side report and learning directories untouched. The browser-local workspace database is independent for the analyzer and Purcell pages and is not the server report archive.

For QA, run `bash tests/v23-0-2-patch-smoke.sh` first, then `bash tests/verify.sh` on the target host with the same downloader/runtime dependencies used by the deployed installation.
