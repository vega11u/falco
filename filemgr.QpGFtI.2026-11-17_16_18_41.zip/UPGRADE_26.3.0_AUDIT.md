# Falco Jugger 26.3.0 — frontend and interaction upgrade

## Changes

- Added `skeleton-core.mjs`: canonical 33-joint articulated skeleton contract (`falco-canonical-skeleton-v1`) with one edge topology and shared confidence policy.
- Replaced the shortened replay edge list with the canonical topology. Existing `im`, `w`, `render_im`, `render_w` and legacy archives remain readable.
- Added the skeleton schema to new reconstruction training extras without changing the legacy 384-feature vector.
- Added capture-phase annotation delegation for dynamic cards. Kime and pattern answers visibly enter a saving state immediately, then switch to a server-confirmed state only after the API confirms persistence.
- Added portable report access keys. New saved reports are copied into a read-only shared store and can be opened with `?report=<id>&key=<access-key>` after cache/cookie loss or on another device. Existing cookie-based opening remains unchanged.
- Updated the report library with portable-link copying and responsive action layout.
- Added cache-busting version `26.3.0` for the new skeleton module.

## Compatibility

Legacy reports, 384-feature Lully examples, v2 512-vertex meshes, v3 2048-vertex meshes, and existing model stores are preserved. New fields are additive.

## Validation

Passed:

- `tests/avatar-render-core-smoke.mjs`
- `tests/body-reconstruction-23-0-13.mjs`

The existing `tests/personal-model-3d-archive.test.mjs` currently fails on its pre-existing synthetic mesh fixture before the modified archive path is exercised; no legacy archive code was removed.
