# Falco 26.0.1 QA

## Confirmed root cause

The 26.0.0 PHP-rendered HTML omits `pageModeLabel` but the analyzer module assigns `.textContent` to it during initialization. This was reproduced in a headless Chromium evaluation of the rendered application JS with external model imports mocked: `Cannot set properties of null (setting 'textContent')`. Core initialization then stopped before registering event listeners for file choice, run analysis, reset, save, etc.

## Verification performed

- After patch, the same browser harness completes boot without the above exception in analyzer and Purcell modes.
- Browser harness at desktop 1440 × 900 and mobile 390 × 844: listeners registered for 17 key action elements; theme changes exactly once per click; journal opens and closes; navigation toggles; trim and player auxiliary controls exist; desktop columns do not overlap.
- Entire original developer regression suite `bash tests/verify.sh` passes after integration. Tests cover backend learning/report APIs, media import, depth policy, Lully/Purcell numeric modules and server report storage.
- `node --check` validates the new UI JS, `php -l` validates PHP.
- Package installer is tested separately on an actual 26.0.0 clone and on a repeat 26.0.1 application, including preservation of user data.

## Limitations

The browser boot smoke uses stub implementations for external pose/depth/biomechanics ES modules, because this isolated test environment does not provide the production vendor/model installation and forbids direct browser network navigation. It verifies DOM integration and handler registration, **not** a full kata analysis on the production REG.RU hosting. A real upload, analysis, and save flow must still be verified after deploying to the live server. The full developer regression suite is not a substitute for that production acceptance check.
