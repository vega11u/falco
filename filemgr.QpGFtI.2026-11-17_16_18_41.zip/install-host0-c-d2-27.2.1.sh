#!/usr/bin/env bash
# Falco Jugger Research C / Vista Precision Lab D2 27.2.1 installer.
set -Eeuo pipefail
umask 077
SRC="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
TARGET="${1:-$PWD}"; MODE="${2:---dry-run}"
[[ "$MODE" == --install || "$MODE" == --dry-run ]] || { echo 'Usage: install-host0-c-d2-27.2.1.sh TARGET [--dry-run|--install]' >&2; exit 2; }
[[ -d "$TARGET" ]] || { echo "Target missing: $TARGET" >&2; exit 2; }
TARGET="$(cd -- "$TARGET" && pwd -P)"
[[ "$TARGET" != / && "$TARGET" != "$SRC" ]] || { echo 'Unsafe target path' >&2; exit 2; }
[[ -f "$TARGET/index.php" && -f "$TARGET/VERSION" && -f "$TARGET/depth-worker.js" && -f "$TARGET/pose-worker.js" ]] || { echo 'Target is not a Falco Jugger site root' >&2; exit 2; }
command -v php >/dev/null || { echo 'PHP CLI required' >&2; exit 2; }
php -r 'if(PHP_VERSION_ID<80100){fwrite(STDERR,"PHP 8.1+ required\n");exit(1);}'
BASE="$(tr -d '\r\n ' < "$TARGET/VERSION")"
[[ "$BASE" == 23.0.27 ]] || { echo "Unsupported core baseline: $BASE (expected 23.0.27)" >&2; exit 2; }

# Strict package manifest validation: exact allowlist, SHA-256, no traversal or symlinks.
php -r '
$root=$argv[1];$m=json_decode(file_get_contents($root."/FALCO_C_D2_RELEASE.json"),true,512,JSON_THROW_ON_ERROR);
$allowed=["index.php","uppurcell.php","lully.php","purcell-lab.php","Memories.php","models.php","falco-jugger-ui.css","falco-jugger-ui.js","pose-worker.js","body-reconstruction-worker.js","athlete-silhouette-core.mjs","research-c-temporal-optimizer.mjs","research-c-evidence-v3.mjs","research-c-checkpoint-store.mjs","research-c-run-coordinator.mjs","research-c-model-registry.mjs","reconstruction-evidence-v3.mjs","FALCO_RELEASE_VERSION.txt","FALCO25_GC_ALLOWLIST.txt","tools/falco-gc.sh","tools/audit-css-references.php","tests/research-c-integrated-272.test.mjs","tests/research-c-v3.test.mjs","tests/c-d2-evidence.test.mjs","tests/release-c-272-smoke.php","tests/release-integrity.php","install-host0-c-d2-27.2.1.sh","README_INSTALL_RU.md","QA_REPORT_27.2.1.md"];
if(($m["release"]??"")!=="27.2.1-C.D2"||($m["baseCore"]??"")!=="23.0.27")exit(2);$got=[];
foreach(($m["files"]??[]) as $f){$p=$f["path"]??"";if(!in_array($p,$allowed,true)||isset($got[$p])||str_contains($p,"..")||str_starts_with($p,"/")||is_link($root."/".$p)||!is_file($root."/".$p)||!hash_equals((string)$f["sha256"],hash_file("sha256",$root."/".$p))){fwrite(STDERR,"Manifest validation failed: $p\n");exit(3);} $got[$p]=true;}
sort($allowed);$keys=array_keys($got);sort($keys);if($keys!==$allowed){fwrite(STDERR,"Manifest file set mismatch\n");exit(4);}
' "$SRC"

FILES=(index.php uppurcell.php lully.php purcell-lab.php Memories.php models.php falco-jugger-ui.css falco-jugger-ui.js pose-worker.js body-reconstruction-worker.js athlete-silhouette-core.mjs research-c-temporal-optimizer.mjs research-c-evidence-v3.mjs research-c-checkpoint-store.mjs research-c-run-coordinator.mjs research-c-model-registry.mjs reconstruction-evidence-v3.mjs FALCO_RELEASE_VERSION.txt FALCO25_GC_ALLOWLIST.txt tools/falco-gc.sh tools/audit-css-references.php tests/research-c-integrated-272.test.mjs tests/research-c-v3.test.mjs tests/c-d2-evidence.test.mjs tests/release-c-272-smoke.php tests/release-integrity.php install-host0-c-d2-27.2.1.sh README_INSTALL_RU.md QA_REPORT_27.2.1.md FALCO_C_D2_RELEASE.json)
for f in "${FILES[@]}"; do [[ ! -L "$TARGET/$f" ]] || { echo "Refusing target symlink: $f" >&2; exit 2; }; done

for f in index.php uppurcell.php lully.php purcell-lab.php Memories.php models.php tests/release-c-272-smoke.php tests/release-integrity.php tools/audit-css-references.php; do php -l "$SRC/$f" >/dev/null; done
php "$SRC/tests/release-integrity.php"
php "$SRC/tests/release-c-272-smoke.php"

# JavaScript validation respects the execution mode and the actual Node feature set.
if command -v node >/dev/null 2>&1; then
  JS_CHECK_TMP="$(mktemp -d)"
  # Probe both ESM and modern syntax (optional chaining / nullish coalescing).
  # Old shared-host Node versions must not parse browser ESM workers as CommonJS.
  printf '%s\n' 'const probe = globalThis?.process?.versions?.node ?? "unknown"; export {probe};' > "$JS_CHECK_TMP/feature-probe.mjs"
  if node --check "$JS_CHECK_TMP/feature-probe.mjs" >/dev/null 2>&1 && node "$JS_CHECK_TMP/feature-probe.mjs" >/dev/null 2>&1; then
    node --check "$SRC/falco-jugger-ui.js"
    for f in research-c-temporal-optimizer.mjs research-c-evidence-v3.mjs research-c-checkpoint-store.mjs research-c-run-coordinator.mjs research-c-model-registry.mjs reconstruction-evidence-v3.mjs athlete-silhouette-core.mjs; do
      node --check "$SRC/$f"
    done
    cp "$SRC/body-reconstruction-worker.js" "$JS_CHECK_TMP/body-reconstruction-worker.mjs"
    cp "$SRC/pose-worker.js" "$JS_CHECK_TMP/pose-worker.mjs"
    node --check "$JS_CHECK_TMP/body-reconstruction-worker.mjs"
    node --check "$JS_CHECK_TMP/pose-worker.mjs"
    node "$SRC/tests/research-c-v3.test.mjs"
    node "$SRC/tests/c-d2-evidence.test.mjs"
    node "$SRC/tests/research-c-integrated-272.test.mjs"
  else
    echo 'WARNING: Host Node lacks the ESM/modern-syntax feature set required by the JS test harness. Server-side JS checks skipped; PHP integrity and integration checks passed. Browser module workers are still served with type=module.'
  fi
  rm -rf -- "$JS_CHECK_TMP"
else
  echo 'WARNING: Node.js absent; JS syntax/runtime tests skipped on host.'
fi

printf '\nFalco Jugger 27.2.1-C.D2 | target=%s | mode=%s\n' "$TARGET" "$MODE"
printf 'Files to install: %s\n' "${#FILES[@]}"
if [[ "$MODE" == --dry-run ]]; then echo 'Dry run PASS. No target files changed.'; exit 0; fi

LOCK="$TARGET/.falco-research-c-27.2.1-install.lock"
( set -C; : > "$LOCK" ) 2>/dev/null || { echo 'Install lock exists; inspect before retry.' >&2; exit 3; }
trap 'rm -f -- "$LOCK"' EXIT
HOME_BACKUP="${HOME:?HOME must be set}/.falco-backups"
mkdir -p "$HOME_BACKUP"; chmod 700 "$HOME_BACKUP"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)-$$"
BACKUP="$HOME_BACKUP/falco-c-d2-27.2.1-$STAMP"
mkdir -p "$BACKUP/original" "$BACKUP/installed"; chmod 700 "$BACKUP"
COMMITTED=0
rollback(){ local rc=$?; if [[ "$COMMITTED" -eq 0 ]]; then echo 'Install failed; rolling back changed code files.' >&2; for f in "${FILES[@]}"; do if [[ -f "$BACKUP/original/$f" ]]; then mkdir -p "$TARGET/$(dirname "$f")"; cp -p "$BACKUP/original/$f" "$TARGET/$f"; else rm -f -- "$TARGET/$f"; fi; done; fi; exit "$rc"; }
trap rollback ERR
# Backup only paths this release changes. No data/model/report/private path is in FILES.
for f in "${FILES[@]}"; do
  if [[ -e "$TARGET/$f" ]]; then mkdir -p "$BACKUP/original/$(dirname "$f")"; cp -p "$TARGET/$f" "$BACKUP/original/$f"; fi
  mkdir -p "$BACKUP/installed/$(dirname "$f")"; cp -p "$SRC/$f" "$BACKUP/installed/$f"
done
for f in "${FILES[@]}"; do mkdir -p "$TARGET/$(dirname "$f")"; tmp="$TARGET/$(dirname "$f")/.fj2721-$(basename "$f").$$.tmp"; cp -p "$SRC/$f" "$tmp"; mv -f "$tmp" "$TARGET/$f"; done
for f in index.php uppurcell.php lully.php purcell-lab.php Memories.php models.php tests/release-c-272-smoke.php tests/release-integrity.php; do php -l "$TARGET/$f" >/dev/null; done
php "$TARGET/tests/release-integrity.php"
php "$TARGET/tests/release-c-272-smoke.php"
php "$TARGET/tools/audit-css-references.php" "$TARGET" > "$BACKUP/css-reference-audit.txt"
COMMITTED=1
trap 'rm -f -- "$LOCK"' EXIT
# GC only moves allowlisted, demonstrably unreferenced legacy CSS/JS files to a private quarantine.
if ! bash "$TARGET/tools/falco-gc.sh" "$TARGET" --apply > "$BACKUP/gc-report.txt" 2>&1; then echo 'WARNING: GC audit failed; no unlisted files were touched.'; fi
printf 'Installed successfully. External rollback snapshot: %s\n' "$BACKUP"
printf 'CSS reference audit: %s/css-reference-audit.txt\n' "$BACKUP"
printf 'GC report: %s/gc-report.txt\n' "$BACKUP"
echo 'No trained data, reports, private configuration, source media, model cache or rollback snapshots were deleted.'
echo 'Metric 3D remains unverified without calibration; native segmentation mask resolution is reported per frame.'
