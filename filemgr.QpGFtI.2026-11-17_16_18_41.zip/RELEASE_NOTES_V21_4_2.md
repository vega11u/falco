# Falco Jugger 21.4.2

## Part-relative depth

- Depth is reported independently for the two arms, legs and all five detected fingertips of each hand, relative to chest or pelvis reference planes.
- Depth derivatives distinguish movement away from the camera, toward the camera and stable depth, without differentiating across camera cuts.
- The report contains median depth, P10/P90 spread, point confidence, trend and a characteristic timecode for each segment.

## Hand articulation and loose-clothing cues

- The 3D avatar displays a palm surface, five articulated finger chains, joint points, fingertip markers and a palm-orientation normal.
- Handedness can be recovered from the nearest visible Pose wrist when the Hand Landmarker label is missing or ambiguous.
- Segmentation-mask thickness along the torso, sleeves and trouser legs adapts the avatar's silhouette when evidence is sufficient. This is geometric clothing-envelope estimation, not kimono classification.

## Look-ahead biomechanical refinement

- The optimizer reports short-horizon directional continuity separately for arms, hands, legs and trunk.
- Motion-onset candidates are protected as launch-pose anchors, while observed next-phase direction is protected during smoothing.
- A pass is rejected when supported body groups lose too much directional continuity or bone geometry becomes unstable. Hand geometry is guarded in both 3D world and 2D fallback coordinates.
- User feedback on the next movement changes directional protection for the next iteration. Source measurements remain unchanged.

## Validation

- Standard `bash tests/verify.sh` passes.
- Depth remains monocular and relative; the avatar's interpolated hand surfaces are geometric visualization, not additional measurements.
- No specialized kimono recognition model, camera calibration, force plates, EMG or inverse-dynamics solver is included.
