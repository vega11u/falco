/** Monteverdi 3-class feedback: motion detector stage.
 * Human labels fast_kime and fast_no_kime are FAST examples; not_fast is a
 * negative example for FAST detection, never a negative kime example.
 * All features are from observed 2D pose and are body-scale normalized.
 */
export const MONTEVERDI_MOTION_VERSION='monteverdi-fast-motion-human-supervised-v1';
export const MONTEVERDI_CHOICES=Object.freeze(['fast_kime','fast_no_kime','not_fast']);
const finite=Number.isFinite;
const limit=(x,a,b)=>Math.max(a,Math.min(b,x));
const good=p=>Array.isArray(p)&&p.length>=2&&finite(p[0])&&finite(p[1])&&(p[3]??1)>=.35;
const len=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
const mid=(a,b)=>[(a[0]+b[0])/2,(a[1]+b[1])/2];
const get=(f,id)=>f?.im?.[id];
function scaleFrame(f){
 const ankles=[get(f,27),get(f,28)].filter(good), shoulders=[get(f,11),get(f,12)].filter(good);
 if(!ankles.length||!shoulders.length)return null;
 const a=ankles.length===2?mid(...ankles):ankles[0],s=shoulders.length===2?mid(...shoulders):shoulders[0];
 const d=len(a,s);return d>.075&&d<1.6?d:null;
}
function leadRelative(f,id){
 const hand=get(f,id),hips=[get(f,23),get(f,24)].filter(good);
 if(!good(hand)||!hips.length)return null;
 const c=hips.length===2?mid(...hips):hips[0];return [hand[0]-c[0],hand[1]-c[1]];
}
/** Return null when a credible normalized motion signal cannot be measured. */
export function measureMonteverdiMotion(frames,event){
 if(!Array.isArray(frames)||!event)return null;
 const start=Math.max(0,Math.trunc(event.start)),end=Math.min(frames.length-1,Math.trunc(event.end));
 if(!finite(start)||!finite(end)||end-start<2)return null;
 const begin=Number(frames[start]?.t),finish=Number(frames[end]?.t);
 if(!finite(begin)||!finite(finish)||finish<=begin)return null;
 const id=event.type==='kick'?(event.side==='left'?27:28):(event.side==='left'?15:16);
 const scales=[],speeds=[];let previous=null,travel=0;
 for(let i=start;i<=end;i++){
  const f=frames[i],t=Number(f?.t),relative=leadRelative(f,id),scale=scaleFrame(f);
  if(scale!==null)scales.push(scale);
  if(finite(t)&&relative&&previous){
   const dt=t-previous.t;
   if(dt>.001&&dt<.25){const delta=len(relative,previous.relative);speeds.push({raw:delta/dt,scale:scale??previous.scale});travel+=delta;}
  }
  previous=relative&&finite(t)?{relative,t,scale}:null;
 }
 if(scales.length<2||speeds.length<3)return null;
 scales.sort((a,b)=>a-b);const height=scales[Math.floor(scales.length/2)];
 const values=speeds.map(v=>limit(v.raw/(v.scale??height),0,25)).sort((a,b)=>a-b);
 const peak=values[Math.min(values.length-1,Math.floor(values.length*.9))],mean=values.reduce((a,b)=>a+b,0)/values.length;
 return {duration_s:+limit(finish-begin,.01,30).toFixed(4),peak_speed_body_s:+peak.toFixed(4),mean_speed_body_s:+mean.toFixed(4),travel_body:+limit(travel/height,0,50).toFixed(4),observed_pairs:values.length};
}
const fields=['duration_s','peak_speed_body_s','mean_speed_body_s','travel_body'];
export function validatedMonteverdiMotion(value){
 if(!value||typeof value!=='object'||Array.isArray(value))return null;
 const out={};for(const key of fields){const v=value[key];if(typeof v!=='number'||!finite(v)||v<0||v>({duration_s:30,peak_speed_body_s:25,mean_speed_body_s:25,travel_body:50}[key]))return null;out[key]=v;}
 if(!(out.duration_s>.01))return null;
 out.observed_pairs=finite(value.observed_pairs)?limit(Math.trunc(value.observed_pairs),0,100000):0;
 return out;
}
function vector(m){return [1,Math.log1p(m.peak_speed_body_s),Math.log1p(m.mean_speed_body_s),Math.log1p(m.travel_body),Math.log1p(m.duration_s)];}
const dot=(a,b)=>a.reduce((sum,v,i)=>sum+v*(b[i]??0),0);
const sigmoid=x=>1/(1+Math.exp(-limit(x,-30,30)));
function balancedAccuracy(rows,predict){
 const pos=rows.filter(r=>r.fast),neg=rows.filter(r=>!r.fast);
 if(!pos.length||!neg.length)return null;
 return .5*(pos.filter(predict).length/pos.length+neg.filter(r=>!predict(r)).length/neg.length);
}
function newestLabels(rows){
 const byKey=new Map();
 for(const r of rows||[]){if(!MONTEVERDI_CHOICES.includes(r?.choice))continue;
  const m=validatedMonteverdiMotion(r.motion_features);if(!m)continue;
  const key=String(r.source_report??'')+'|'+String(r.event_id??'')+'|'+String(r.time_s??'');
  byKey.set(key,{key,fast:r.choice!=='not_fast',motion:m});
 }
 return [...byKey.values()].sort((a,b)=>a.key.localeCompare(b.key));
}
function fitLogistic(rows){
 let w=[0,0,0,0,0];const nPos=rows.filter(r=>r.fast).length,nNeg=rows.length-nPos;
 if(!nPos||!nNeg)return w;
 // Penalize overfitting; balanced per-class weights handle label imbalance.
 for(let epoch=0;epoch<420;epoch++){
  const grad=[0,0,0,0,0];
  for(const r of rows){const x=vector(r.motion),p=sigmoid(dot(x,w)),weight=r.fast?.5/nPos:.5/nNeg;
   for(let j=0;j<w.length;j++)grad[j]+=(p-(r.fast?1:0))*x[j]*weight;
  }
  const lr=.28/(1+epoch/260);
  for(let j=0;j<w.length;j++)w[j]-=lr*(grad[j]+(j===0?0:.035*w[j]));
 }
 return w.map(n=>+n.toFixed(7));
}
export function fitMonteverdiMotionClassifier(rows,{minLabels=12,minPerClass=4}={}){
 const data=newestLabels(rows),fast=data.filter(r=>r.fast).length,not_fast=data.length-fast;
 const fallback={schema:MONTEVERDI_MOTION_VERSION,active:false,reviewed:data.length,fast,not_fast,reason:'Недостаточно размеченных быстрых и небыстрых движений'};
 if(data.length<minLabels||fast<minPerClass||not_fast<minPerClass)return fallback;
 // Stratified deterministic holdout: both classes represented, even in short sets.
 const pos=data.filter(r=>r.fast),neg=data.filter(r=>!r.fast);
 const split=items=>({test:items.filter((_,i)=>i%4===0),train:items.filter((_,i)=>i%4!==0)});
 const p=split(pos),n=split(neg),train=[...p.train,...n.train],held=[...p.test,...n.test];
 const w=fitLogistic(train),prediction=r=>sigmoid(dot(vector(r.motion),w))>=.5;
 const baseline=r=>r.motion.duration_s<=1.2;
 const holdout=balancedAccuracy(held,prediction),baseHeld=balancedAccuracy(held,baseline);
 const trainScore=balancedAccuracy(train,prediction);
 if(holdout===null||baseHeld===null)return {...fallback,reason:'Недостаточно классов для контрольной выборки'};
 const accepted=holdout>=Math.max(.55,baseHeld-.001);
 // Retrain only after holdout approval; never train on a single unreviewed event.
 return {...fallback,active:accepted,weights:accepted?fitLogistic(data):null,holdout_balanced_accuracy:+holdout.toFixed(4),baseline_holdout_balanced_accuracy:+baseHeld.toFixed(4),train_balanced_accuracy:trainScore,reason:accepted?'Скорость движений обучена по трём классам и проверена на отложенных метках':'Контрольная выборка хуже базового детектора; он сохранён'};
}
export function predictMonteverdiFastMotion(features,model,{fallbackFast=false}={}){
 const motion=validatedMonteverdiMotion(features);
 if(!motion||!model?.active||!Array.isArray(model.weights)||model.weights.length!==5)return !!fallbackFast;
 return sigmoid(dot(vector(motion),model.weights))>=.5;
}
