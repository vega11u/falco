<?php
declare(strict_types=1);
/** Additive evolution-session log. Never rewrites Purcell/Lully exemplars or models. */
function fj_purcell_evolution_memory(string $directory, string $method, array $body=[]): array {
    if(!is_dir($directory)&&$method==='GET')return ['ok'=>true,'schema'=>'purcell-evolution-log-v1','runs'=>[],'count'=>0];
    if(!is_dir($directory)||is_link($directory))throw new RuntimeException('Purcell private directory is unavailable');
    $path=$directory.'/evolution-runs.json';$lockPath=$directory.'/evolution-runs.lock';
    $lf=@fopen($lockPath,'c+');if(!$lf)throw new RuntimeException('Evolution log lock unavailable');
    try{
        if(!flock($lf,$method==='POST'?LOCK_EX:LOCK_SH))throw new RuntimeException('Evolution lock denied');
        $runs=[];
        if(is_file($path)){
            if(is_link($path))throw new RuntimeException('Evolution log symlink rejected');
            $read=@file_get_contents($path);$data=json_decode((string)$read,true);
            if(!is_array($data)||!is_array($data['runs']??null))throw new RuntimeException('Existing evolution log invalid; not overwriting');
            $runs=$data['runs'];
        }
        if($method==='GET')return ['ok'=>true,'schema'=>'purcell-evolution-log-v1','runs'=>array_slice($runs,-25),'count'=>count($runs)];
        if($method!=='POST')throw new InvalidArgumentException('Method not allowed');
        if(($body['action']??'')!=='save')throw new InvalidArgumentException('Unknown action');
        $space=$body['modality']??'';if(!in_array($space,['2d','3d'],true))throw new InvalidArgumentException('Modality must be 2d/3d');
        $copies=filter_var($body['copies']??null,FILTER_VALIDATE_INT);if($copies===false||$copies<1||$copies>24)throw new InvalidArgumentException('Copies out of 1..24');
        $source=(string)($body['source_candidate_id']??'');if(!preg_match('/^hyp-\d{4}$/',$source))throw new InvalidArgumentException('Invalid source candidate');
        $name=substr(trim((string)($body['kata_name']??'')),0,90);
        $rows=$body['replicas']??[];if(!is_array($rows)||count($rows)!==$copies)throw new InvalidArgumentException('Replica count mismatch');
        $number=function($v,$min,$max){return is_numeric($v)&&is_finite((float)$v)&&$v>=$min&&$v<=$max?round((float)$v,5):null;};
        $clean=[];
        foreach($rows as $i=>$row){if(!is_array($row))throw new InvalidArgumentException('Invalid replica');
            $coherence=$number($row['coherence']??null,0,100);$overall=$number($row['overall']??null,0,100);
            $clean[]=['replica'=>$i+1,'attempted'=>max(0,min(120,(int)($row['attempted']??0))),'accepted'=>max(0,min(120,(int)($row['accepted']??0))),'reached'=>($row['reached']??false)===true,'coherence'=>$coherence,'overall'=>$overall];
        }
        $genome=[];
        foreach(($body['consolidated_genome']??[]) as $item){
            if(count($genome)>=5)break;if(!is_array($item))throw new InvalidArgumentException('Invalid genome');
            $chain=(string)($item['chain']??'');if(!in_array($chain,['left_arm','right_arm','left_leg','right_leg','trunk'],true))throw new InvalidArgumentException('Unknown chain');
            $params=[];foreach(['angle'=>[-.3,.3],'phase'=>[-.25,.25],'twist'=>[-.2,.2],'profile'=>[.5,3],'level'=>[0,1],'axis'=>[0,2]] as $field=>$range){$v=$number($item[$field]??null,$range[0],$range[1]);if($v===null)throw new InvalidArgumentException('Invalid genome parameter');$params[$field]=$v;}
            $genome[]=['chain'=>$chain]+$params;
        }
        $reached=(int)array_sum(array_map(static fn($r)=>$r['reached']?1:0,$clean));
        $aggregate=($body['aggregate_qualified']??false)===true&&$reached>=($copies===1?1:max(2,(int)ceil($copies*.45)))&&count($genome)===5;
        if(($body['aggregate_qualified']??false)===true&&!$aggregate)throw new InvalidArgumentException('Reported aggregate does not meet independent replica quorum or genome completeness');
        $score=$body['result_score']??[];
        $overall=$number($score['overall']??null,0,100);$coherence=$number($score['coherence']??null,0,100);
        if($aggregate&&($overall===null||$overall<60||$coherence===null||$coherence<100))throw new InvalidArgumentException('Aggregate does not meet minimum score or coherence');
        $run=['id'=>bin2hex(random_bytes(12)),'created_at'=>gmdate('c'),'modality'=>$space,'kata_name'=>$name,'source_candidate_id'=>$source,
            'source_run_id'=>substr((string)($body['source_run_id']??''),0,70),'copies'=>$copies,'seed'=>max(0,(int)($body['seed']??0)),'steps'=>max(1,min(80,(int)($body['steps']??55))),
            'successful_replicas'=>$reached,'aggregate_qualified'=>$aggregate,'aggregate_source'=>$aggregate?substr((string)($body['aggregate_source']??''),0,50):null,
            'result_score'=>['overall'=>$overall,'coherence'=>$coherence],'consolidated_genome'=>$aggregate?$genome:[], 'replicas'=>$clean,
            'note'=>'Kinematic hypothesis search, not validated forward physics simulation or verified athlete performance'];
        $runs[]=$run;$runs=array_slice($runs,-120);
        $json=json_encode(['schema'=>'purcell-evolution-log-v1','updated_at'=>gmdate('c'),'runs'=>$runs],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
        if(!is_string($json)||strlen($json)>2500000)throw new RuntimeException('Evolution log exceeds limit');
        $tmp=$path.'.tmp-'.bin2hex(random_bytes(5));
        if(@file_put_contents($tmp,$json,LOCK_EX)===false||!@rename($tmp,$path)){@unlink($tmp);throw new RuntimeException('Could not atomically write evolution log');}
        @chmod($path,0600);return ['ok'=>true,'saved'=>true,'id'=>$run['id'],'aggregate_qualified'=>$aggregate,'stored'=>count($runs)];
    }finally{flock($lf,LOCK_UN);fclose($lf);}
}
