# Falco Jugger 23.0.9 · QA

- Основа: полный ZIP 23.0.8.1, добавлен **только патч** 23.0.9.
- PHP: lint index.php, models.php, purcell-search-memory.php, research/install_sources.php, research/build_evidence_index.php.
- JavaScript: syntax main module, depth-worker.js, purcell-search-core.mjs, kata-pause-core.mjs, pose-reality-core.mjs.
- Regression: `bash tests/optimizer-smoke.sh`, `bash tests/purcell-and-report-api-smoke.sh`, прежние тесты 21 гипотез, мышечной динамики, PHP-only research indexing.
- New: `node tests/purcell-search-1000-23-0-9.mjs`; `php tests/purcell-search-memory-1000-23-0-9.php`; `php tests/purcell-evidence-3d-23-0-9.php`.
- Integration smoke: 1000 независимых вызовов biomech quality + next-movement readiness + technique planner + muscle dynamics on synthetic 90-frame linkage, verified distinct assessed trajectories.
- Site overlay: compare protected learning files and model JSON before/after overlay on test copy. The patch ZIP has no training directories, private data, or vendor payloads.

## Не проверено

- GUI в реальном браузере с видеодрайвером и фактические скорость/память на телефоне.
- Реальный одновременный сбор внешних библиотек на REG.RU; сервер может ответить HTTP 403, таймаутом или ограничением квоты.
- Фактическое качество новых глубинных сетей на конкретном видео или физическая истинность синтетических траекторий.
- Полноценные замеры мышечной активации / кинетических энергозатрат (не заявляются).
