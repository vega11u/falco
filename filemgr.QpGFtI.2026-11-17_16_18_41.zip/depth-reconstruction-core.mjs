/*
 * Relative monocular depth fusion for the display-only human avatar.
 * Depth Anything V2 provides inverse relative depth (larger = nearer), not metres.
 * Nothing in this module mutates measured MediaPipe landmarks or biomechanics data.
 */
const clamp = (value, lo, hi) => Math.max(lo, Math.min(hi, value));
const finitePoint = p => Array.isArray(p) && p.length >= 2 && Number.isFinite(p[0]) && Number.isFinite(p[1]) && (p[3] ?? 1) >= 0.08;
const quantile = (values, q) => {
  const sorted = values.filter(Number.isFinite).sort((a, b) => a - b);
  if (!sorted.length) return null;
  const position = (sorted.length - 1) * clamp(q, 0, 1);
  const lo = Math.floor(position), hi = Math.ceil(position);
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (position - lo);
};
const median = values => quantile(values, 0.5);

/** Subpixel bilinear sample; a local MAD guard rejects isolated depth-pixel spikes. */
export function sampleDepthMapAtLandmarks(values, width, height, landmarks, radius = 1) {
  if (!values || !Number.isInteger(width) || !Number.isInteger(height) || width < 2 || height < 2 || !Array.isArray(landmarks)) return null;
  const data = values instanceof Float32Array || values instanceof Float64Array ? values : Float32Array.from(values);
  if (data.length < width * height) return null;
  radius = Number.isFinite(radius) ? clamp(Math.floor(radius), 0, 4) : 1;
  const out = Array.from({ length: landmarks.length }, () => NaN);
  for (let i = 0; i < landmarks.length; i++) {
    const p = landmarks[i];
    // A joint outside the image has no depth evidence. Clamping it to the nearest
    // border used to manufacture a depth observation from unrelated background.
    if (!finitePoint(p) || p[0] < 0 || p[0] > 1 || p[1] < 0 || p[1] > 1) continue;
    const fx = p[0] * (width - 1), fy = p[1] * (height - 1);
    const x = Math.round(fx), y = Math.round(fy), neighborhood = [];
    for (let yy = Math.max(0, y - radius); yy <= Math.min(height - 1, y + radius); yy++) {
      for (let xx = Math.max(0, x - radius); xx <= Math.min(width - 1, x + radius); xx++) {
        const value = data[yy * width + xx];
        if (Number.isFinite(value)) neighborhood.push(value);
      }
    }
    if (!neighborhood.length) continue;
    const center = median(neighborhood), deviation = median(neighborhood.map(v => Math.abs(v - center)));
    const tolerance = Math.max(1e-6, 3 * deviation);
    const x0 = Math.floor(fx), y0 = Math.floor(fy), x1 = Math.min(width - 1, x0 + 1), y1 = Math.min(height - 1, y0 + 1);
    const u = fx - x0, v = fy - y0;
    let sum = 0, weight = 0;
    for (const [xx, yy, w] of [[x0, y0, (1-u)*(1-v)], [x1, y0, u*(1-v)], [x0, y1, (1-u)*v], [x1, y1, u*v]]) {
      const value = data[yy * width + xx];
      if (!Number.isFinite(value) || w <= 0) continue;
      sum += (radius > 0 ? clamp(value, center - tolerance, center + tolerance) : value) * w; weight += w;
    }
    out[i] = weight > 0 ? sum / weight : center;
  }
  return out;
}

function normalizeObservation(values, imageLandmarks, agreementValues = null) {
  const valid = [];
  for (let i = 0; i < values.length; i++) {
    const p = imageLandmarks?.[i];
    if (Number.isFinite(values[i]) && finitePoint(p)) valid.push(values[i]);
  }
  if (valid.length < 8) return null;
  const lo = quantile(valid, 0.10), hi = quantile(valid, 0.90), center = median(valid);
  const spread = hi - lo;
  if (!Number.isFinite(spread) || spread <= Math.max(1e-6, Math.abs(center || 0) * 1e-5)) return null;
  const normalized = Array.from({ length: values.length }, (_, i) => {
    const p = imageLandmarks?.[i];
    return Number.isFinite(values[i]) && finitePoint(p) ? clamp((values[i] - center) / spread, -0.75, 0.75) : NaN;
  });
  const hasAgreement = Array.isArray(agreementValues) && agreementValues.some(Number.isFinite);
  const agreements = values.map((value, k) => Number.isFinite(value) && finitePoint(imageLandmarks?.[k]) ? (Number.isFinite(Number(agreementValues?.[k])) ? clamp(Number(agreementValues[k]), 0, 1) : 0.55) : NaN).filter(Number.isFinite);
  const modelAgreement = hasAgreement && agreements.length ? agreements.reduce((a,b)=>a+b,0)/agreements.length : null;
  const confidenceAgreement = Number.isFinite(modelAgreement) ? (.45 + .55 * modelAgreement) : .75;
  return { values: normalized, agreements: Array.from({length:values.length},(_,i)=>Number.isFinite(Number(agreementValues?.[i]))?clamp(Number(agreementValues[i]),0,1):0.55), spread, valid_count: valid.length, model_agreement: modelAgreement, confidence: clamp(valid.length / 22, 0.30, 1) * confidenceAgreement };
}

function torsoLength(world) {
  const good = id => Array.isArray(world?.[id]) && world[id].slice(0, 3).every(Number.isFinite) && (world[id][3] ?? 1) >= 0.08;
  if (![11, 12, 23, 24].every(good)) return null;
  const shoulder = [0, 1, 2].map(a => (world[11][a] + world[12][a]) * 0.5);
  const hip = [0, 1, 2].map(a => (world[23][a] + world[24][a]) * 0.5);
  const d = Math.hypot(...shoulder.map((v, i) => v - hip[i]));
  return Number.isFinite(d) && d > 0.06 && d < 1.4 ? d : null;
}

/**
 * Interpolates sparse depth observations within camera cuts and fuses them into a
 * separate render_w track. This is intentionally conservative: scene depth is a
 * visual prior, while original world landmarks stay untouched for all metrics.
 */
export function fuseDepthLandmarkTrack(frames, { strength = 0.42, maxObservationGap = 1.35, maxHold = 0.52 } = {}) {
  if (!Array.isArray(frames) || !frames.length) return { available: false, observations: 0, enhanced_frames: 0, coverage: 0, mean_confidence: 0 };
  const observations = [];
  for (let i = 0; i < frames.length; i++) {
    const frame = frames[i];
    if (!Array.isArray(frame?.depth_landmark_values)) continue;
    const normalized = normalizeObservation(frame.depth_landmark_values, frame.im, frame.depth_agreement_values);
    if (!normalized) continue;
    if (!Number.isFinite(Number(frame.t))) continue;
    observations.push({ index: i, t: Number(frame.t), segment: frame.camera_segment_id ?? 0, image: frame.im, model: frame.depth_model || null, mode: frame.depth_mode || null, ...normalized });
  }
  if (!observations.length) return { available: false, observations: 0, enhanced_frames: 0, coverage: 0, mean_confidence: 0 };

  let enhanced = 0, touched = 0, confidenceSum = 0, agreementSum = 0, agreementCount = 0, depthFrames = 0;
  let obsCursor = 0;
  for (let i = 0; i < frames.length; i++) {
    const frame = frames[i], world = frame.w;
    const time = Number(frame.t), segment = frame.camera_segment_id ?? 0;
    while (obsCursor < observations.length && observations[obsCursor].t < time) obsCursor++;
    let left = observations[obsCursor - 1] || null, right = observations[obsCursor] || null;
    if (left && left.segment !== segment) left = null;
    if (right && right.segment !== segment) right = null;
    if (left && right && (right.t - left.t) > maxObservationGap) {
      if (time - left.t > maxHold) left = null;
      if (right.t - time > maxHold) right = null;
    }
    if (!left && !right) continue;
    let u = 0;
    if (left && right && right.t > left.t) u = clamp((time - left.t) / (right.t - left.t), 0, 1);
    else if (right && !left) { if (right.t - time > maxHold) continue; left = right; }
    else if (left && !right) { if (time - left.t > maxHold) continue; right = left; }
    const nearestAge = Math.min(Math.abs(time - left.t), Math.abs(right.t - time));
    const temporalConfidence = Math.exp(-0.5 * (nearestAge / Math.max(.05, maxHold)) ** 2);
    const sourceDepth = Array.from({length:33},(_,joint)=>{const a=left.values[joint],b=right.values[joint];return Number.isFinite(a)&&Number.isFinite(b)?a+(b-a)*u:Number.isFinite(a)?a:Number.isFinite(b)?b:NaN;});
    const sourceAgreement = Array.from({length:33},(_,joint)=>{const a=left.agreements?.[joint],b=right.agreements?.[joint];return Number.isFinite(a)&&Number.isFinite(b)?a+(b-a)*u:Number.isFinite(a)?a:Number.isFinite(b)?b:.55;});
    frame.render_depth_landmark_values = sourceDepth;
    frame.render_depth_agreement_values = sourceAgreement;
    const modelAgreement=Number.isFinite(left.model_agreement)&&Number.isFinite(right.model_agreement)?Number(Math.min(left.model_agreement,right.model_agreement).toFixed(3)):null;
    const selectedModel=left.model||right.model||frame.depth_model||'Depth Anything V2 selected model';
    const selectedMode=left.mode||right.mode||frame.depth_mode||(/small/i.test(selectedModel)?'small':(/base/i.test(selectedModel)?'base':null));
    const modelLabel=selectedMode==='small'?'Depth Anything V2 Small (выбрана пользователем)':selectedMode==='base'?'Depth Anything V2 Base':'Depth Anything V2 (режим в исходном отчёте не сохранён)';
    frame.depth_fusion = {observed:nearestAge<1e-5,interpolated:nearestAge>=1e-5,nearest_observation_age_s:Number(nearestAge.toFixed(3)),temporal_confidence:Number(temporalConfidence.toFixed(3)),model_agreement:modelAgreement,source:`${modelLabel} · single-model depth + MediaPipe world landmarks (display-only)`};
    depthFrames++; if(Number.isFinite(modelAgreement)){agreementSum += modelAgreement;agreementCount++;}
    if (!Array.isArray(world) || world.length < 12) continue;
    const goodWorld = world.filter(p => Array.isArray(p) && p.slice(0, 3).every(Number.isFinite) && (p[3] ?? 1) >= 0.08).length;
    const scale = torsoLength(world);
    if (goodWorld < 12 || !scale) continue;
    const source = world.map(p => Array.isArray(p) ? p.slice() : p);
    let frameEnhanced = false, frameConfidence = 0, joints = 0;
    for (let joint = 0; joint < Math.min(33, source.length); joint++) {
      const point = source[joint], imagePoint = frame.im?.[joint];
      if (!Array.isArray(point) || !point.slice(0, 3).every(Number.isFinite) || (point[3] ?? 1) < 0.08 || !finitePoint(imagePoint)) continue;
      const score = sourceDepth[joint];
      if (!Number.isFinite(score)) continue;
      // Depth Anything V2 is inverse relative depth: brighter/larger values are nearer.
      // MediaPipe world-z convention is opposite (positive points away from camera).
      const targetZ = clamp(-score * scale * 0.78, -scale * 0.34, scale * 0.34);
      const agreement = sourceAgreement[joint];
      const reference = u < .5 ? left.image?.[joint] : right.image?.[joint];
      const motion = finitePoint(reference) ? Math.hypot(imagePoint[0] - reference[0], imagePoint[1] - reference[1]) : Infinity;
      // Sparse depth cannot follow a rapidly displaced hand/foot through a long hold.
      // Fade this visual prior as the image joint moves; pose landmarks remain intact.
      const motionConfidence = Math.exp(-0.5 * (motion / .12) ** 2);
      const observationConfidence = (left.confidence + (right.confidence - left.confidence) * u) * (.45 + .55 * agreement) * temporalConfidence * motionConfidence;
      const visibility = clamp(Math.min(point[3] ?? 1, imagePoint[3] ?? 1), 0, 1);
      const mix = clamp(strength * observationConfidence * visibility, 0, 0.52);
      if (visibility < .18 || mix < .025) continue;
      point[2] = point[2] * (1 - mix) + targetZ * mix;
      frameEnhanced = true; joints++; frameConfidence += observationConfidence * visibility;
    }
    if (frameEnhanced) {
      frame.render_w = source;
      frame.depth_fusion = { ...frame.depth_fusion, joints, confidence: Number((frameConfidence / Math.max(1, joints)).toFixed(3)), source: frame.depth_fusion.source };
      enhanced++; touched += joints; confidenceSum += frameConfidence / Math.max(1, joints);
    }
  }
  const coverage = frames.length ? enhanced / frames.length : 0;
  return {
    available: enhanced > 0,
    observations: observations.length,
    enhanced_frames: enhanced,
    enhanced_joints: touched,
    coverage: Number(coverage.toFixed(4)),
    mean_confidence: Number((enhanced ? confidenceSum / enhanced : 0).toFixed(3)),
    mean_model_agreement: agreementCount ? Number((agreementSum / agreementCount).toFixed(3)) : null,
    depth_available_frames: depthFrames,
    method: 'Sparse monocular inverse-depth estimation from one explicitly selected Depth Anything V2 model (Base by default, Small only when the user enables lightweight mode), camera-cut-aware temporal interpolation with age, visibility and image-motion confidence decay; fused into a separate display-only world track. No automatic model-family fallback or ensemble is used.',
    limitations: 'Relative depth only; a single selected model does not provide cross-model agreement. No metric distances, hidden-backside reconstruction or recovered clothing/body topology.'
  };
}
