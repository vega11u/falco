/** Confidence-aware depth stabilization. Never treat monocular relative depth as metres.
 * A bad auxiliary model cannot override the anchor, and a moving athlete is not frozen.
 */
const finite=Number.isFinite;
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const med=a=>{if(!a.length)return NaN;const s=[...a].sort((x,y)=>x-y),m=s.length>>1;return s.length%2?s[m]:(s[m-1]+s[m])/2;};
export function stabilizeConsensusMap(current,previous=null,{landmarks=[],previousLandmarks=[],elapsed=1,agreement=null}={}){
 if(!current?.values||current.width<3||current.height<3)throw Error('Invalid depth map');
 const {width:w,height:h}=current,n=w*h,raw=current.values,out=new Float32Array(n),confidence=new Float32Array(n);
 const canUsePrevious=previous?.values?.length===n&&previous.width===w&&previous.height===h&&elapsed>0&&elapsed<4;
 let dx=0,dy=0,tracked=0,motion=0;
 if(canUsePrevious&&Array.isArray(landmarks)&&Array.isArray(previousLandmarks)){
  const vx=[],vy=[],speeds=[];
  for(let j=0;j<Math.min(landmarks.length,previousLandmarks.length);j++){
   const a=landmarks[j],b=previousLandmarks[j];if(!a||!b||Math.min(a[3]??1,b[3]??1)<.65)continue;
   if(![a[0],a[1],b[0],b[1]].every(finite))continue;
   const ux=a[0]-b[0],uy=a[1]-b[1];if(Math.hypot(ux,uy)>.32)continue;
   vx.push(ux);vy.push(uy);speeds.push(Math.hypot(ux,uy));
  }
  if(vx.length>=6){dx=med(vx);dy=med(vy);motion=med(speeds);tracked=vx.length;}
 }
 // A global shift is only a crude registration proxy. If athlete landmarks
 // disagree, disable temporal fusion instead of creating ghost limbs.
 let register=canUsePrevious&&tracked>=6&&motion<.15;
 const p=previous?.values;
 let accepted=0,spatialReplaced=0,temporalRejected=0;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){
  const i=y*w+x,center=raw[i];if(!finite(center)){out[i]=NaN;confidence[i]=0;continue;}
  // Edge-aware spatial denoising. Do not blur across depth discontinuities.
  let sum=center,weight=1,neighbors=[];
  for(let oy=-1;oy<=1;oy++)for(let ox=-1;ox<=1;ox++){
   if(!ox&&!oy)continue;const xx=x+ox,yy=y+oy;if(xx<0||yy<0||xx>=w||yy>=h)continue;
   const v=raw[yy*w+xx];if(!finite(v))continue;
   neighbors.push(v);const delta=Math.abs(v-center);
   const ww=Math.exp(-delta*delta/(2*.065*.065))*(ox&&oy?.6:1);
   sum+=v*ww;weight+=ww;
  }
  let value=sum/weight;
  // Isolated one-pixel spikes are corrected only when neighborhood consensus is strong.
  if(neighbors.length>=5){const m=med(neighbors),mad=med(neighbors.map(v=>Math.abs(v-m)));
   if(Math.abs(center-m)>Math.max(.16,4*mad)&&mad<.045){value=m;spatialReplaced++;}
  }
  const agree=agreement?.length===n&&finite(agreement[i])?clamp(agreement[i]):.4;
  confidence[i]=agree;
  if(register){
   const px=Math.round(x-dx*(w-1)),py=Math.round(y-dy*(h-1));
   if(px>=0&&py>=0&&px<w&&py<h){const old=p[py*w+px];
    if(finite(old)){
     const delta=Math.abs(old-value);
     // High motion and model disagreement reduce temporal inertia. Never replace
     // an abrupt plausible change with an older frame.
     const limit=.09+Math.min(.12,motion*1.2)+(.5-agree)*.035;
     if(delta<limit){const alpha=clamp(.16+.38*motion/.15+.25*(1-agree),.16,.72);
      value=alpha*value+(1-alpha)*old;accepted++;
     }else temporalRejected++;
    }
   }
  }
  out[i]=clamp(value);
 }
 return {values:out,width:w,height:h,agreement_values:confidence,diagnostics:{spatial_spikes:spatialReplaced,temporal_blended:accepted,temporal_rejected:temporalRejected,temporal_registration:register,tracked_joints:tracked,motion}};
}
/** Reject a bad frame-wide consensus if disagreement dominates and anchor is sane. */
export function guardConsensus(anchor,fused,{minAgreement=.40}={}){
 if(!anchor?.values||!fused?.values||anchor.values.length!==fused.values.length)return anchor;
 const a=fused.agreement_values;let weak=0,total=0;
 for(let i=0;i<fused.values.length;i+=Math.max(1,Math.floor(fused.values.length/500))){if(!finite(fused.values[i]))continue;total++;if(a?.length===fused.values.length&&a[i]<minAgreement)weak++;}
 if(total&&weak/total>.68)return {...anchor,agreement_values:a||null,contributors:['base'],partial:true,guard_reason:'auxiliary_models_disagree'};
 return fused;
}
