/** Lightweight image-space perspective evidence from a small set of sparse background lines. */
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const median=values=>{const a=values.filter(Number.isFinite).sort((x,y)=>x-y);if(!a.length)return null;const m=a.length>>1;return a.length%2?a[m]:(a[m-1]+a[m])/2;};
function lineIntersection(a,b){
  const ta=(Number(a.theta_deg)||0)*Math.PI/180,tb=(Number(b.theta_deg)||0)*Math.PI/180;
  const ca=Math.cos(ta),sa=Math.sin(ta),cb=Math.cos(tb),sb=Math.sin(tb),det=ca*sb-sa*cb;
  if(Math.abs(det)<.035)return null;
  const ra=Number(a.rho),rb=Number(b.rho);if(!Number.isFinite(ra)||!Number.isFinite(rb))return null;
  return {x:(ra*sb-sa*rb)/det,y:(ca*rb-ra*cb)/det,weight:Math.sqrt(Math.max(1,Number(a.votes)||1)*Math.max(1,Number(b.votes)||1))};
}
/**
 * Samples contain at most a dozen low-resolution frames. This function does no image
 * decoding and no per-video-frame work. It estimates candidate vanishing-point/horizon
 * cues only; it does not calibrate camera intrinsics or recover metric world coordinates.
 */
export function estimateScenePerspectiveEvidence(samples=[],{width=144,height=81,maxSamples=12}={}){
  const rows=(Array.isArray(samples)?samples:[]).slice(0,maxSamples),intersections=[],orientations=[];
  for(let si=0;si<rows.length;si++){
    const lines=Array.isArray(rows[si]?.background_lines)?rows[si].background_lines:(Array.isArray(rows[si]?.lines)?rows[si].lines:[]);
    const usable=lines.filter(x=>Number.isFinite(Number(x.theta_deg))&&Number.isFinite(Number(x.rho))&&(Number(x.votes)||0)>=5).slice(0,8);
    for(const l of usable)orientations.push(Number(l.line_angle_deg??(Number(l.theta_deg)-90)));
    for(let i=0;i<usable.length;i++)for(let j=i+1;j<usable.length;j++){
      const a=usable[i],b=usable[j],ang=Math.abs(Number(a.theta_deg)-Number(b.theta_deg));
      if(ang<4||ang>70)continue;
      const p=lineIntersection(a,b);if(!p)continue;
      if(p.x<-.9*width||p.x>1.9*width||p.y<-.9*height||p.y>1.9*height)continue;
      intersections.push({...p,sample:si});
    }
  }
  // Deterministic weighted clustering of line intersections. Requiring independent frames
  // and multiple line pairs prevents one noisy frame from defining the horizon.
  const clusters=[];
  intersections.sort((a,b)=>b.weight-a.weight);
  for(const p of intersections){let best=null,bestD=Infinity;for(const c of clusters){if(c.samples.has(p.sample))continue;const d=Math.hypot((p.x-c.x)/width,(p.y-c.y)/height);if(d<.22&&d<bestD){best=c;bestD=d;}}if(!best){best={points:[],samples:new Set(),x:p.x,y:p.y,weight:0};clusters.push(best);}best.points.push(p);best.samples.add(p.sample);best.weight+=p.weight;best.x=median(best.points.map(x=>x.x));best.y=median(best.points.map(x=>x.y));}
  clusters.sort((a,b)=>b.samples.size-a.samples.size||b.weight-a.weight);const best=clusters[0],support=best?.samples.size||0,coverage=rows.length?support/rows.length:0;
  const confidence=rows.length?clamp(coverage*Math.min(1,(best?.points.length||0)/5)*Math.min(1,(best?.weight||0)/120),0,1):0;
  const detected=!!best&&support>=2&&best.points.length>=3&&confidence>=.12;
  const angle=median(orientations);
  return {schema:'falco-sparse-scene-perspective-v1',detected,confidence:Number(confidence.toFixed(3)),sampled_frames:rows.length,max_sample_frames:maxSamples,background_line_count:orientations.length,vanishing_point_image_px:detected?{x:Number(best.x.toFixed(2)),y:Number(best.y.toFixed(2))}:null,vanishing_point_normalized:detected?{x:Number((best.x/width).toFixed(4)),y:Number((best.y/height).toFixed(4))}:null,horizon_y_normalized:detected&&best.y>=0&&best.y<=height?Number((best.y/height).toFixed(4)):null,dominant_background_line_angle_deg:angle==null?null:Number(angle.toFixed(2)),supporting_frames:support,method:'sparse low-resolution Sobel edges + bounded Hough candidates + cross-frame vanishing-point consensus',runtime_budget:'No extra video decoding; at most 12 frames at 144×81 px; line voting capped to a few hundred edge samples per frame.',limitations:detected?'Image-space perspective cue only. Not camera calibration, metric depth, floor plane, or guaranteed horizon; only used as a weak context cue.':'No stable vanishing-point consensus. Perspective fusion is disabled and pose-only relative depth remains active.'};
}

const modAngle = (a, b) => {
  let d = Math.abs((Number(a) - Number(b)) % 180);
  return Math.min(d, 180 - d);
};
function solveLinearSystem(A, b) {
  const n = b.length, m = A.map((row, i) => [...row, b[i]]);
  for (let c = 0; c < n; c++) {
    let pivot = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(m[r][c]) > Math.abs(m[pivot][c])) pivot = r;
    if (Math.abs(m[pivot][c]) < 1e-9) return null;
    [m[c], m[pivot]] = [m[pivot], m[c]];
    const divisor = m[c][c];
    for (let k = c; k <= n; k++) m[c][k] /= divisor;
    for (let r = 0; r < n; r++) if (r !== c) {
      const factor = m[r][c];
      for (let k = c; k <= n; k++) m[r][k] -= factor * m[c][k];
    }
  }
  return m.map(row => row[n]);
}
function homographyFromFourPoints(source, target) {
  const A = [], b = [];
  for (let i = 0; i < 4; i++) {
    const [x, y] = source[i], [u, v] = target[i];
    A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u);
    A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v);
  }
  const h = solveLinearSystem(A, b);
  return h ? [...h, 1] : null;
}
function invertHomography(h) {
  if (!Array.isArray(h) || h.length !== 9) return null;
  const [a,b,c,d,e,f,g,k,i] = h;
  const A=e*i-f*k, B=c*k-b*i, C=b*f-c*e, D=f*g-d*i, E=a*i-c*g, F=c*d-a*f, G=d*k-e*g, H=b*g-a*k, I=a*e-b*d;
  const det=a*A+b*D+c*G;
  if (!Number.isFinite(det) || Math.abs(det)<1e-10) return null;
  return [A,B,C,D,E,F,G,H,I].map(x=>x/det);
}
function meanPoint2(points) {
  return {x:median(points.map(p=>p.x)),y:median(points.map(p=>p.y))};
}
function polygonArea(points) {
  let area=0;for(let i=0;i<points.length;i++){const a=points[i],b=points[(i+1)%points.length];area+=a.x*b.y-b.x*a.y;}return Math.abs(area)*.5;
}
function tatamiCandidatesForSample(sample, width, height, sampleIndex) {
  const lines=(Array.isArray(sample?.lines)?sample.lines:[]).filter(l=>Number.isFinite(Number(l.theta_deg))&&Number.isFinite(Number(l.rho))&&(Number(l.votes)||0)>=7).slice(0,14);
  const candidates=[];
  for(let i=0;i<lines.length;i++)for(let j=i+1;j<lines.length;j++){
    const A=lines[i],B=lines[j],angle=modAngle(A.theta_deg,B.theta_deg);
    if(angle<62||angle>118)continue;
    const aPairs=[],bPairs=[];
    for(let k=0;k<lines.length;k++){
      if(k===i||k===j)continue;const q=lines[k];
      if(modAngle(q.theta_deg,A.theta_deg)<=8&&Math.abs(Number(q.rho)-Number(A.rho))>=4&&Math.abs(Number(q.rho)-Number(A.rho))<=80)aPairs.push(q);
      if(modAngle(q.theta_deg,B.theta_deg)<=8&&Math.abs(Number(q.rho)-Number(B.rho))>=4&&Math.abs(Number(q.rho)-Number(B.rho))<=80)bPairs.push(q);
    }
    for(const a2 of aPairs)for(const b2 of bPairs){
      if(modAngle(a2.theta_deg,A.theta_deg)>8||modAngle(b2.theta_deg,B.theta_deg)>8)continue;
      const q=[lineIntersection(A,B),lineIntersection(a2,B),lineIntersection(a2,b2),lineIntersection(A,b2)];
      if(q.some(p=>!p||p.x<0||p.x>=width||p.y<height*.34||p.y>=height))continue;
      const area=polygonArea(q);if(area<Math.max(24,width*height*.003)||area>width*height*.58)continue;
      const center=meanPoint2(q);if(center.y<height*.50)continue;
      const edgeLengths=q.map((p,n)=>Math.hypot(p.x-q[(n+1)%4].x,p.y-q[(n+1)%4].y));
      if(edgeLengths.some(x=>x<3))continue;
      const score=Math.min(1,(area/(width*height*.16)))*Math.min(1,edgeLengths.reduce((s,x)=>s+x,0)/(width+height)*.28)*Math.min(1,((Number(A.votes)||0)+(Number(a2.votes)||0)+(Number(B.votes)||0)+(Number(b2.votes)||0))/72);
      candidates.push({quad:q.map(p=>({x:p.x,y:p.y})),center,area,score,sample:sampleIndex,votes:[A.votes,a2.votes,B.votes,b2.votes].map(Number)});
    }
  }
  candidates.sort((a,b)=>b.score-a.score);
  const out=[];for(const q of candidates){if(out.some(p=>Math.hypot((p.center.x-q.center.x)/width,(p.center.y-q.center.y)/height)<.035))continue;out.push(q);if(out.length>=8)break;}
  return out;
}
/**
 * Detects a repeated floor-tile quadrilateral from two approximately orthogonal line families.
 * One accepted cell is treated as 1×1 m by user convention; the result is a visual calibration
 * prior, not proof that the marking is a standard tatami or a metric camera calibration.
 */
export function estimateTatamiGridEvidence(samples=[],{width=144,height=81,maxSamples=12}={}) {
  const rows=(Array.isArray(samples)?samples:[]).slice(0,maxSamples),all=[];
  rows.forEach((sample,index)=>all.push(...tatamiCandidatesForSample(sample,width,height,index)));
  const clusters=[];
  for(const item of all.sort((a,b)=>b.score-a.score)){
    let best=null,bestDistance=Infinity;
    for(const c of clusters){if(c.samples.has(item.sample))continue;const d=Math.hypot((c.x-item.center.x)/width,(c.y-item.center.y)/height);if(d<.07&&d<bestDistance){best=c;bestDistance=d;}}
    if(!best){best={items:[],samples:new Set(),x:item.center.x,y:item.center.y,score:0};clusters.push(best);}
    best.items.push(item);best.samples.add(item.sample);best.x=median(best.items.map(x=>x.center.x));best.y=median(best.items.map(x=>x.center.y));best.score=median(best.items.map(x=>x.score))||0;
  }
  clusters.sort((a,b)=>b.samples.size-a.samples.size||b.score-a.score);
  const best=clusters[0],support=best?.samples.size||0,required=Math.max(2,Math.ceil(rows.length*.20));
  if(!best||support<required||best.items.length<required||!rows.length){
    return {schema:'falco-tatami-grid-v1',detected:false,confidence:0,sampled_frames:rows.length,supporting_frames:support,unit:'m',cell_size_m:null,reference_quad_normalized:null,image_to_floor_homography:null,floor_to_image_homography:null,method:'two-family Hough line pairing + quadrilateral persistence across sparse frames',limitations:'No stable repeated 1×1 floor-cell quadrilateral. A metric grid is not drawn; only a relative floor projection may be shown.'};
  }
  const medianQuad=Array.from({length:4},(_,i)=>({x:median(best.items.map(x=>x.quad[i].x)),y:median(best.items.map(x=>x.quad[i].y))}));
  const src=medianQuad.map(p=>[p.x/width,p.y/height]),dst=[[0,0],[1,0],[1,1],[0,1]],imgToFloor=homographyFromFourPoints(src,dst),floorToImage=imgToFloor?invertHomography(imgToFloor):null;
  const coverage=support/rows.length,confidence=clamp(coverage*Math.min(1,best.score*1.35)*Math.min(1,support/3),0,1);
  const detected=!!(imgToFloor&&floorToImage&&confidence>=.10&&polygonArea(medianQuad)>width*height*.004);
  return {schema:'falco-tatami-grid-v1',detected,confidence:Number((detected?confidence:0).toFixed(3)),sampled_frames:rows.length,supporting_frames:support,unit:'m',cell_size_m:detected?1:null,reference_quad_normalized:detected?src.map(p=>p.map(v=>Number(v.toFixed(5)))):null,image_to_floor_homography:detected?imgToFloor.map(v=>Number(v.toFixed(8))):null,floor_to_image_homography:detected?floorToImage.map(v=>Number(v.toFixed(8))):null,method:'two approximately orthogonal floor-line families; paired parallel lines define one candidate tile; median quadrilateral consensus across frames',assumption:'The accepted visible quadrilateral is one tatami square = 1×1 m, per user convention.',limitations:'Monocular planar homography assumes a flat floor and a stationary camera segment. The 1 m scale is an explicit tatami-square assumption, not independently measured. Perspective, lens distortion, partial tiles and look-alike floor patterns can bias scale.'};
}
