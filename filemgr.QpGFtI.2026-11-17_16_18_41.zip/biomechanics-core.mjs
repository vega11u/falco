/**
 * Falco Jugger biomechanics core (browser-native, PHP-host compatible).
 * No Python, Node service, remote inference, or model-training dependency.
 * The module deliberately separates observed measurements from derived estimates.
 */
const MAIN_JOINTS = [11,12,13,14,15,16,23,24,25,26,27,28,29,30,31,32];
const GROUPS = {
  trunk: [11,12,23,24],
  arms: [11,12,13,14,15,16],
  legs: [23,24,25,26,27,28],
  feet: [27,28,29,30,31,32]
};
const FOOT_IDS = { left: [27,29,31], right: [28,30,32] };
const BONES = [[11,13],[13,15],[12,14],[14,16],[11,12],[11,23],[12,24],[23,24],[23,25],[25,27],[24,26],[26,28],[27,29],[29,31],[28,30],[30,32]];

function finitePoint(p, minConfidence = 0.05, dimensions = 2) {
  return Array.isArray(p) && p.length >= dimensions && p.slice(0, dimensions).every(Number.isFinite) && Number(p[3] ?? 1) >= minConfidence;
}
function clamp(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }
function mean(values) { const v = values.filter(Number.isFinite); return v.length ? v.reduce((a,b)=>a+b,0)/v.length : null; }
function median(values) { const v=values.filter(Number.isFinite).sort((a,b)=>a-b); if(!v.length)return null; const m=v.length>>1; return v.length%2?v[m]:(v[m-1]+v[m])/2; }
function pct(value) { return Number((100 * (value || 0)).toFixed(1)); }

/**
 * Robust body-scale normalisation for the perspective avatar.
 * Uses MediaPipe world landmarks when enough of the head/feet chain is visible;
 * falls back to image coordinates only for display scaling. Returns a finite positive
 * multiplier so partial poses can never crash rendering.
 */
export function estimatePose3DNormalization(frames, aspect = 1) {
  if (!Array.isArray(frames) || !frames.length) return 1;
  const safeAspect = Number.isFinite(aspect) ? clamp(aspect, 0.25, 4) : 1;
  const spans = [];
  const valid = p => finitePoint(p, 0.05, 3);
  const midpoint = (a, b) => valid(a) && valid(b)
    ? [0,1,2].map(k => (Number(a[k]) + Number(b[k])) * 0.5)
    : valid(a) ? [Number(a[0]),Number(a[1]),Number(a[2])] : valid(b) ? [Number(b[0]),Number(b[1]),Number(b[2])] : null;
  const stride = Math.max(1, Math.floor(frames.length / 240));
  for (let i = 0; i < frames.length; i += stride) {
    const frame = frames[i] || {};
    const world = Array.isArray(frame.w) ? frame.w : [];
    const image = Array.isArray(frame.im) ? frame.im : [];
    const worldUsable = MAIN_JOINTS.filter(id => valid(world[id])).length >= 8;
    const source = worldUsable ? world : image;
    const imageMode = !worldUsable;
    const good = p => Array.isArray(p) && p.length >= 2 && p.slice(0, imageMode ? 2 : 3).every(Number.isFinite) && Number(p[3] ?? 1) >= 0.05;
    const head = good(source[0]) ? source[0] : midpoint(source[7], source[8]);
    const heel = midpoint(source[29], source[30]);
    const toe = midpoint(source[31], source[32]);
    const ankle = midpoint(source[27], source[28]);
    const foot = heel || toe || ankle;
    if (!head || !foot) continue;
    const dx = (Number(head[0]) - Number(foot[0])) * (imageMode ? safeAspect : 1);
    const dy = Number(head[1]) - Number(foot[1]);
    const dz = imageMode ? 0 : Number(head[2] || 0) - Number(foot[2] || 0);
    const span = Math.hypot(dx, dy, dz);
    const plausible = imageMode ? span >= 0.12 && span <= 2.5 : span >= 0.45 && span <= 2.8;
    if (plausible && Number.isFinite(span)) spans.push(span);
  }
  const reference = median(spans);
  if (!Number.isFinite(reference) || reference <= 1e-6) return 1;
  return clamp(1 / reference, 0.25, 5);
}

/** Evaluate whether a sequence is suitable for biomechanics, not merely whether the detector returned something. */
export function assessPoseSequence(frames, options = {}) {
  const n = Array.isArray(frames) ? frames.length : 0;
  if (!n) return { schema:'falco-pose-quality-v1', score:0, level:'unusable', frames:0, warnings:['Нет кадров для оценки.'] };
  const groupCounts = Object.fromEntries(Object.keys(GROUPS).map(k=>[k,0]));
  let fullBody=0, partialBody=0, worldFrames=0, confidenceSum=0, confidenceCount=0, validTimestamp=0;
  const dt=[], warnings=[];
  const knownFrameTimes=new Set((frames||[]).map(f=>Number(f?.t)).filter(Number.isFinite));
  const segmentBreaks=new Set((options.segmentBreakBeforeTimes||[]).map(Number).filter(t=>Number.isFinite(t)&&knownFrameTimes.has(t)));
  for (let i=0;i<n;i++) {
    const f=frames[i]||{}, im=Array.isArray(f.im)?f.im:[];
    const count=MAIN_JOINTS.reduce((s,id)=>s+(finitePoint(im[id],.12,2)?1:0),0);
    if(count>=14)fullBody++; else if(count>=8)partialBody++;
    for(const [name,ids] of Object.entries(GROUPS)) {
      const have=ids.reduce((s,id)=>s+(finitePoint(im[id],.12,2)?1:0),0);
      const threshold=name==='trunk'?3:name==='arms'?4:name==='legs'?4:3;
      if(have>=threshold)groupCounts[name]++;
    }
    for(const id of MAIN_JOINTS){const p=im[id];if(finitePoint(p,.01,2)){const c=Number(p[3]??1);confidenceSum+=clamp(c,0,1);confidenceCount++;}}
    const w=Array.isArray(f.w)?f.w:[];
    if(MAIN_JOINTS.filter(id=>finitePoint(w[id],.05,3)).length>=10)worldFrames++;
    const t=Number(f.t); if(Number.isFinite(t))validTimestamp++;
    if(i&&!segmentBreaks.has(t)){const d=t-Number(frames[i-1]?.t);if(Number.isFinite(d)&&d>0)dt.push(d);}
  }
  const rates=Object.fromEntries(Object.entries(groupCounts).map(([k,v])=>[k,v/n]));
  const medianDt=median(dt), duplicates=Math.max(0,n-1-segmentBreaks.size-dt.length);
  const gapLimit=medianDt?Math.max(.12,medianDt*3):.12;
  const gaps=dt.filter(d=>d>gapLimit).length;
  const intervalCount=Math.max(1,n-1-segmentBreaks.size);
  const intervalValidity=dt.length/intervalCount;
  const timestampValidity=validTimestamp/n;
  const cadenceScore=dt.length?clamp((1-(gaps/dt.length)*2-(duplicates/intervalCount)*2)*Math.sqrt(intervalValidity*timestampValidity),0,1):0;
  const bodyRate=(fullBody+partialBody)/n;
  const confidence=confidenceCount?confidenceSum/confidenceCount:0;
  const diag=options.sourceDiagnostics||{};
  const inferenceErrors=Math.max(0,Number(diag.inferenceFailedFrames)||0);
  const inferenceErrorRate=clamp(inferenceErrors/n,0,1);
  const decodedSamples=Number.isFinite(Number(diag.decodedSamples))?Number(diag.decodedSamples):null;
  const pipelineRecordCount=Number.isFinite(Number(diag.frameRecordsWritten))?Number(diag.frameRecordsWritten):n;
  const recordCountMatches=decodedSamples===null?null:decodedSamples===n&&pipelineRecordCount===n;
  const inferenceReliable=inferenceErrorRate<=.02;
  const pipelineConsistent=recordCountMatches!==false;
  const gapRate=gaps/Math.max(1,dt.length);
  const duplicateRate=duplicates/intervalCount;
  const cadenceUsable=cadenceScore>=.85&&gapRate<=.02&&duplicateRate<=.01&&timestampValidity>=.98&&inferenceReliable&&pipelineConsistent;
  // Visibility and time integrity are separate inputs: a visually complete but temporally broken clip is not safe for kinematic correction.
  const coverageScore=.27*rates.trunk+.16*rates.arms+.23*rates.legs+.14*rates.feet+.05*bodyRate+.10*cadenceScore+.05*timestampValidity;
  const score=Math.round(100*clamp(coverageScore*(.72+.28*confidence)*(1-.45*inferenceErrorRate),0,1));
  const level=score>=88?'high':score>=72?'good':score>=52?'limited':'low';
  if(rates.trunk<.75)warnings.push('Корпус/таз недостаточно устойчиво виден; углы корпуса и перенос центра масс ненадёжны.');
  if(rates.legs<.65)warnings.push('Ноги часто закрыты или теряются; стойки, коленные углы и траектории ног требуют осторожной интерпретации.');
  if(rates.feet<.45)warnings.push('Стопы видны не во всех фазах; выводы об опоре и контакте ограничены.');
  if(rates.arms<.60)warnings.push('Руки/кисти часто частично скрыты; распознавание ударов и блоков может быть неполным.');
  if(gaps)warnings.push(`Обнаружено ${gaps} крупных разрывов временных меток; производные скорости/ускорения вблизи них менее надёжны.`);
  if(segmentBreaks.size)warnings.push(`Проверка временной шкалы учитывает ${segmentBreaks.size} явно заданных границ диапазонов; кинематические производные через эти границы не рассчитываются.`);
  if(duplicates||timestampValidity<.98)warnings.push(`Временная шкала неполна: валидные метки ${pct(timestampValidity)}%, повторные/невалидные интервалы ${duplicates}. Оптимизация временной кинематики ограничена.`);
  if(inferenceErrors)warnings.push(`MediaPipe завершил с ошибкой ${inferenceErrors} кадров (${pct(inferenceErrorRate)}%). Эти кадры сохранены в последовательности, но оценка точек для них отсутствует или неполна.`);
  if(recordCountMatches===false)warnings.push('Число записей покадрового анализа не совпадает с числом декодированных образцов. Кинематическая коррекция заблокирована.');
  if(worldFrames/n<.70)warnings.push('3D world landmarks неполные; часть биомеханики доступна только как 2D/относительная оценка.');
  if(score<52)warnings.push('Качество входных данных недостаточно для автоматических биомеханических рекомендаций. Лучше переснять ролик целиком, не пытаться компенсировать плохой ракурс сглаживанием.');
  return {
    schema:'falco-pose-quality-v1', score, level, frames:n,
    frame_coverage:{full_body:pct(fullBody/n),partial_body:pct(partialBody/n),any_body:pct(bodyRate),trunk:pct(rates.trunk),arms:pct(rates.arms),legs:pct(rates.legs),feet:pct(rates.feet),world_3d:pct(worldFrames/n)},
    confidence_mean:Number(confidence.toFixed(3)),
    frame_pipeline:{inference_errors:inferenceErrors,inference_error_rate:Number(inferenceErrorRate.toFixed(4)),decoded_samples:decodedSamples,frame_records_written:pipelineRecordCount,record_count_matches_source_samples:recordCountMatches},
    temporal:{median_frame_interval_s:medianDt?Number(medianDt.toFixed(5)):null,estimated_fps:medianDt?Number((1/medianDt).toFixed(2)):null,large_gaps:gaps,large_gap_rate:Number(gapRate.toFixed(4)),duplicate_or_invalid_intervals:duplicates,duplicate_interval_rate:Number(duplicateRate.toFixed(4)),valid_timestamps:validTimestamp,valid_timestamp_rate:Number(timestampValidity.toFixed(4)),cadence_score:Number(cadenceScore.toFixed(3)),cadence_usable:cadenceUsable},
    suitability:{kata_recognition:score>=65?'usable_with_caveats':score>=45?'manual_review':'not_recommended',biomechanics:score>=78&&cadenceScore>=.75?'comparative_kinematics':score>=55&&cadenceScore>=.65?'limited_kinematics':'not_recommended',optimization:score>=72&&rates.trunk>=.75&&rates.legs>=.65&&cadenceUsable?'candidate_allowed':'blocked_or_manual_review'},
    warnings
  };
}

/**
 * Foot lift relative to the athlete's own stance baseline. This is a 2D proxy, not a
 * world-space height measurement. A baseline can be supplied to avoid recalculating it
 * inside per-frame candidate detection.
 */
export function estimateFootLiftAtFrame(frames, index, side, baselineOverride = null) {
  if (!Array.isArray(frames) || !['left','right'].includes(side) || !Number.isInteger(index) || index < 0 || index >= frames.length) return null;
  const heelId = side === 'left' ? 29 : 30;
  const toeId = side === 'left' ? 31 : 32;
  const hipId = side === 'left' ? 23 : 24;
  const relative = frame => {
    const points = [frame?.im?.[heelId], frame?.im?.[toeId], frame?.im?.[hipId]];
    if (points.some(p => !Array.isArray(p) || !Number.isFinite(p[1]) || Number(p[3] ?? 1) < .35)) return null;
    return (points[0][1] + points[1][1]) * .5 - points[2][1];
  };
  const current = relative(frames[index]);
  if (!Number.isFinite(current)) return null;
  let baseline = baselineOverride == null ? NaN : Number(baselineOverride);
  if (!Number.isFinite(baseline)) {
    const values = frames.map(relative).filter(Number.isFinite).sort((a,b)=>a-b);
    if (!values.length) return null;
    const pos = (values.length - 1) * .84, lo = Math.floor(pos), hi = Math.ceil(pos);
    baseline = values[lo] + (values[hi] - values[lo]) * (pos - lo);
  }
  return baseline - current;
}

/**
 * Repair only isolated low-confidence heel/toe/ankle spikes. This is deliberately not
 * a blanket low-pass filter: high-confidence fast kicks and reversals remain untouched.
 * The returned count is diagnostic; callers retain the original detector confidence.
 */
export function stabilizeFootLandmarkOutliers(frames) {
  if (!Array.isArray(frames) || frames.length < 3) return { repaired: 0 };
  const ids = [27,28,29,30,31,32];
  let repaired = 0;
  for (const field of ['im','w']) {
    const dims = field === 'im' ? 2 : 3;
    const threshold = field === 'im' ? .025 : .035;
    for (let i = 1; i < frames.length - 1; i++) {
      const prev = frames[i-1], cur = frames[i], next = frames[i+1];
      const dt0 = Number(cur?.t) - Number(prev?.t), dt1 = Number(next?.t) - Number(cur?.t);
      if (!(dt0 > 0 && dt1 > 0 && dt0 <= .12 && dt1 <= .12)) continue;
      for (const id of ids) {
        const a = prev?.[field]?.[id], b = cur?.[field]?.[id], c = next?.[field]?.[id];
        if (!finitePoint(a,.62,dims) || !finitePoint(c,.62,dims) || !finitePoint(b,.05,dims)) continue;
        if (Number(b[3] ?? 1) >= .58) continue; // never smooth confident fast motion
        const u = dt0 / (dt0 + dt1);
        const predicted = Array.from({length:dims},(_,k)=>a[k] + (c[k]-a[k])*u);
        const deviation = Math.hypot(...predicted.map((v,k)=>v-b[k]));
        if (!(deviation > threshold)) continue;
        for (let k=0;k<dims;k++) b[k]=predicted[k];
        b[3]=Math.min(Number(a[3]??1),Number(c[3]??1))*.65;
        repaired++;
      }
    }
  }
  return { repaired };
}

function pointConfidence(p) { return clamp(Number(p?.[3] ?? 1), 0, 1); }
function pointValid(p, dims) { return finitePoint(p, .12, dims); }
function ensurePointCopy(p) { return Array.isArray(p) ? p.slice(0,4) : [NaN,NaN,NaN,0]; }
function distance(a,b,dims) { if(!pointValid(a,dims)||!pointValid(b,dims))return null;let s=0;for(let k=0;k<dims;k++)s+=(a[k]-b[k])**2;return Math.sqrt(s); }

function accelerationRms(frames, field, dims) {
  const values=[];
  for(let i=1;i<frames.length-1;i++){
    const a=frames[i-1][field]||[],b=frames[i][field]||[],c=frames[i+1][field]||[];
    const dt0=Number(frames[i].t)-Number(frames[i-1].t),dt1=Number(frames[i+1].t)-Number(frames[i].t);
    if(!(dt0>0&&dt1>0&&dt0<.20&&dt1<.20))continue;
    for(const id of MAIN_JOINTS){if(!pointValid(a[id],dims)||!pointValid(b[id],dims)||!pointValid(c[id],dims))continue;
      const weight=Math.min(pointConfidence(a[id]),pointConfidence(b[id]),pointConfidence(c[id]));if(weight<.15)continue;
      for(let k=0;k<dims;k++){
        const v0=(b[id][k]-a[id][k])/dt0,v1=(c[id][k]-b[id][k])/dt1;
        const acc=2*(v1-v0)/(dt0+dt1);if(Number.isFinite(acc))values.push(acc*acc*weight);
      }
    }
  }
  return values.length?Math.sqrt(values.reduce((a,b)=>a+b,0)/values.length):null;
}
function boneLengthDispersion(frames, field) {
  const out=[];
  for(const [a,b] of BONES){const lengths=[];for(const f of frames){const d=distance(f[field]?.[a],f[field]?.[b],3);if(d!=null&&d>1e-4)lengths.push(d);}if(lengths.length>=5){const m=median(lengths);if(m>1e-4){const mad=median(lengths.map(x=>Math.abs(x-m)));out.push(mad/m);}}}
  return mean(out);
}

const HAND_BONES = [[0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],[0,9],[9,10],[10,11],[11,12],[0,13],[13,14],[14,15],[15,16],[0,17],[17,18],[18,19],[19,20],[5,9],[9,13],[13,17]];

function resolveHandPoseSide(hand, imagePoints = []) {
  if (hand?.pose_side === 'left' || hand?.pose_side === 'right') return hand.pose_side;
  const wrist = hand?.landmarks?.[0], left = imagePoints?.[15], right = imagePoints?.[16];
  const xy = p => Array.isArray(p) && p.slice(0, 2).every(Number.isFinite) && (p[3] ?? 1) >= .12;
  if (!xy(wrist)) return null;
  const dL = xy(left) ? Math.hypot(wrist[0] - left[0], wrist[1] - left[1]) : Infinity;
  const dR = xy(right) ? Math.hypot(wrist[0] - right[0], wrist[1] - right[1]) : Infinity;
  const nearest = Math.min(dL, dR), separation = Math.abs(dL - dR);
  return nearest <= .32 && (separation >= .012 || !Number.isFinite(Math.max(dL, dR))) ? (dL <= dR ? 'left' : 'right') : null;
}
function cloneHands(hands, imagePoints = []) {
  return (Array.isArray(hands) ? hands : []).map(h => ({
    ...h,
    pose_side: resolveHandPoseSide(h, imagePoints),
    landmarks: Array.isArray(h.landmarks) ? h.landmarks.map(ensurePointCopy) : [],
    world_landmarks: Array.isArray(h.world_landmarks) ? h.world_landmarks.map(ensurePointCopy) : []
  }));
}

function handBoneLengthDispersion(frames, field) {
  const groups = [];
  for (const side of ['left','right']) for (const [a,b] of HAND_BONES) {
    const lengths=[];
    for (const f of frames) {
      const h=(f.hands||[]).find(x=>resolveHandPoseSide(x,f.im)===side);
      const pts=h?.[field]||[];
      const d=distance(pts[a],pts[b],field==='world_landmarks'?3:2);
      if(d!=null&&d>1e-5)lengths.push(d);
    }
    if(lengths.length>=5){const m=median(lengths);if(m>1e-5){const mad=median(lengths.map(x=>Math.abs(x-m)));groups.push(mad/m);}}
  }
  return mean(groups);
}

/**
 * Describes how measured motion continues into the next 160 ms. It is a trajectory
 * continuity diagnostic, not a prediction of the technically ideal karate action.
 */
export function analyzeNextMovementReadiness(frames, lookAheadSeconds = 0.16) {
  const rows=Array.isArray(frames)?frames:[];
  const groups={arms:[13,14,15,16],hands:[],legs:[25,26,27,28,29,30,31,32],trunk:[11,12,23,24]};
  const result={schema:'falco-next-movement-v2',lookahead_seconds:clamp(Number(lookAheadSeconds)||.16,.08,.32),groups:{},notes:['Оценивается сохранность направления наблюдаемой траектории на коротком горизонте. Это не прогноз намерения, силы или единственно правильной техники.','Кисти анализируются в собственной системе координат Hand Landmarker и не подменяют координаты корпуса.']};
  const collect=(name, getter, dims, threshold)=>{
    const cosines=[],onsets=[];let usable=0;
    for(let i=1;i<rows.length-1;i++){
      const a=rows[i-1],b=rows[i],seg=b.camera_segment_id??0;
      if((a.camera_segment_id??0)!==seg)continue;
      const t0=Number(a.t),t1=Number(b.t);if(!(t1>t0))continue;
      let j=i+1;
      while(j<rows.length&&(rows[j].camera_segment_id??0)===seg&&Number(rows[j].t)<t1+result.lookahead_seconds)j++;
      if(j>=rows.length||(rows[j].camera_segment_id??0)!==seg)continue;
      const c=rows[j],dtPast=t1-t0,dtFuture=Number(c.t)-t1;if(!(dtFuture>0&&dtFuture<=.42))continue;
      const entries=getter(a,b,c);
      for(const entry of entries){
        const {p0,p1,p2,weight=1}=entry,entryDims=entry.dims||dims;
        const valid=p=>Array.isArray(p)&&p.length>=entryDims&&p.slice(0,entryDims).every(Number.isFinite)&&(p[3]??1)>=.18;
        if(!valid(p0)||!valid(p1)||!valid(p2)||weight<.18)continue;
        const vp=Array.from({length:entryDims},(_,k)=>(p1[k]-p0[k])/dtPast),vf=Array.from({length:entryDims},(_,k)=>(p2[k]-p1[k])/dtFuture);
        const sp=Math.hypot(...vp),sf=Math.hypot(...vf);if(sf<threshold)continue;usable++;
        if(sp<threshold*.35){onsets.push({time:t1,lookahead_time:Number(c.t)});continue;}
        const cosine=clamp(vp.reduce((sum,v,k)=>sum+v*vf[k],0)/(sp*sf),-1,1);cosines.push(cosine*weight);
      }
    }
    const avg=mean(cosines),continuity=Number.isFinite(avg)?Number(((avg+1)*50).toFixed(1)):null;
    result.groups[name]={directional_continuity_score:continuity,comparable_transitions:cosines.length,detected_motion_onsets:onsets.length,motion_onsets:onsets.slice(0,500),usable_future_vectors:usable,interpretation:continuity==null?'недостаточно непрерывных данных':continuity>=75?'направления последовательных фаз в основном согласованы':continuity>=50?'есть заметные изменения направления':'частые развороты или смены направления'};
  };
  const bodyGroups={arms:[13,14,15,16],legs:[25,26,27,28,29,30,31,32],trunk:[11,12,23,24]};
  for(const [name,ids] of Object.entries(bodyGroups))collect(name,(a,b,c)=>ids.map(id=>{
    const useWorld=[a.w?.[id],b.w?.[id],c.w?.[id]].every(p=>finitePoint(p,.18,3));
    const field=useWorld?'w':'im';return {p0:a[field]?.[id],p1:b[field]?.[id],p2:c[field]?.[id],dims:useWorld?3:2,weight:Math.min(a[field]?.[id]?.[3]??1,b[field]?.[id]?.[3]??1,c[field]?.[id]?.[3]??1)};
  }),2,.055);
  collect('hands',(a,b,c)=>{
    const out=[];
    for(const side of ['left','right']){
      const A=(a.hands||[]).find(h=>resolveHandPoseSide(h,a.im)===side),B=(b.hands||[]).find(h=>resolveHandPoseSide(h,b.im)===side),C=(c.hands||[]).find(h=>resolveHandPoseSide(h,c.im)===side);
      if(!A||!B||!C)continue;
      const useWorld=[A.world_landmarks?.[0],B.world_landmarks?.[0],C.world_landmarks?.[0]].every(p=>finitePoint(p,.18,3));
      const field=useWorld?'world_landmarks':'landmarks',dims=useWorld?3:2;
      for(let id=1;id<21;id++)out.push({p0:A[field]?.[id],p1:B[field]?.[id],p2:C[field]?.[id],weight:Math.min(A[field]?.[id]?.[3]??1,B[field]?.[id]?.[3]??1,C[field]?.[id]?.[3]??1),dims});
    }
    return out;
  },3,.025);
  result.total_comparable_transitions=Object.values(result.groups).reduce((sum,x)=>sum+x.comparable_transitions,0);
  return result;
}

/**
 * Conservative trajectory refinement. Only short, low-confidence temporal jitter is reduced.
 * Event timing/order and contact-foot positions are hard anchors. There is no time warping.
 */
export async function optimizeKinematicTrajectory({frames, supportTrack=[], eventTimes=[], goal='balanced', quality=null, maxImageShift=.006, maxWorldShift=.010, regionWeights={}, speedPreservation=1, futureDirectionPreservation=.14, onProgress=null}={}) {
  if(!Array.isArray(frames)||frames.length<7)throw new Error('Для кинематической коррекции требуется не менее 7 последовательных кадров.');
  const assessedQuality=quality||assessPoseSequence(frames);
  if(assessedQuality.suitability?.optimization!=='candidate_allowed')throw new Error('Качество или временная целостность данных недостаточны для кинематической коррекции. Проверьте видимость корпуса/ног, временные метки и пропуски кадров.');
  const n=frames.length;
  const cloneFrame=f=>({t:Number(f.t),sample_index:f.sample_index,camera_segment_id:f.camera_segment_id,im:(f.im||[]).map(ensurePointCopy),w:(f.w||[]).map(ensurePointCopy),hands:cloneHands(f.hands,f.im),surface:f.surface||null});
  const copy=frames.map(cloneFrame);
  const original=frames.map(cloneFrame);
  const strengths={speed:.065,balanced:.13,stability:.17,economy:.19};
  const strength=strengths[goal]??strengths.balanced;
  const normalizedRegionWeights={arms:clamp(Number(regionWeights.arms??1),.45,1.45),legs:clamp(Number(regionWeights.legs??1),.45,1.45),trunk:clamp(Number(regionWeights.trunk??1),.45,1.45),hands:clamp(Number(regionWeights.hands??1),.45,1.45),other:clamp(Number(regionWeights.other??1),.45,1.45)};
  const speedFactor=clamp(Number(speedPreservation??1),.42,1.08);
  const futureAxisFactor=clamp(Number(futureDirectionPreservation??.14),.05,.45);
  const groupForJoint=id=>[11,12,23,24].includes(id)?'trunk':id>=13&&id<=22?'arms':id>=25&&id<=32?'legs':'other';
  const lookAheadSeconds=.16;
  const initialNextReadiness=analyzeNextMovementReadiness(original,lookAheadSeconds);
  const eventIdx=new Set([0,n-1]);let detectedMotionOnsetAnchors=0;
  for(const t of eventTimes){const target=Number(t);if(!Number.isFinite(target))continue;let best=0,err=Infinity;for(let i=0;i<n;i++){const e=Math.abs(copy[i].t-target);if(e<err){err=e;best=i;}}if(err<=.10)eventIdx.add(best);}
  // Preserve the observed pre-onset pose: it is the launch position for the next phase.
  // Onsets are detected from low prior velocity followed by a clear short-horizon motion.
  for(const group of Object.values(initialNextReadiness.groups||{}))for(const onset of group.motion_onsets||[]){
    const target=Number(onset.time);if(!Number.isFinite(target))continue;let best=0,err=Infinity;
    for(let i=0;i<n;i++){const e=Math.abs(copy[i].t-target);if(e<err){err=e;best=i;}}
    if(err<=.035&&!eventIdx.has(best)){eventIdx.add(best);detectedMotionOnsetAnchors++;}
  }
  const supportAnchors=new Set();
  for(let i=0;i<n;i++){
    const s=supportTrack[copy[i].sample_index??i]||supportTrack[i];
    if(!s||Number(s.confidence??0)<.68)continue;
    for(const id of FOOT_IDS[s.side]||[])supportAnchors.add(`${i}:${id}`);
  }
  const lookAheadPoint=(series,index)=>{
    const start=copy[index].t,segment=copy[index].camera_segment_id??0,target=start+lookAheadSeconds;
    let best=-1,bestError=Infinity;
    for(let j=index+1;j<n;j++){
      if((copy[j].camera_segment_id??0)!==segment)break;
      const dt=copy[j].t-start;if(!(dt>0)||dt>.30)break;
      const err=Math.abs(dt-lookAheadSeconds);if(err<bestError){best=j;bestError=err;}
      if(dt>=lookAheadSeconds)break;
    }
    return best>index?series[best]:null;
  };
  let futureDirectionProtectedSamples=0;
  const yieldToUI = () => new Promise(resolve => setTimeout(resolve, 0));
  const handStrength=normalizedRegionWeights.hands;
  async function refineField(field,dims,cap){
    let adjusted=0,total=0,maxShift=0,sumShift=0;
    for(let jointIndex=0;jointIndex<MAIN_JOINTS.length;jointIndex++){
      const id=MAIN_JOINTS[jointIndex];
      const originalCoords=original.map(f=>f[field]?.[id]);
      let series=copy.map(f=>f[field]?.[id]);
      for(let i=0;i<n;i++)if(series[i]&&originalCoords[i])series[i]=series[i].slice();
      for(let pass=0;pass<4;pass++){
        const next=series.map(p=>p?.slice()||null);
        for(let i=1;i<n-1;i++){
          if(eventIdx.has(i)||supportAnchors.has(`${i}:${id}`))continue;
          const p0=series[i-1],p1=series[i],p2=series[i+1];
          const dt0=copy[i].t-copy[i-1].t,dt1=copy[i+1].t-copy[i].t;
          if(!(dt0>0&&dt1>0&&dt0<=.12&&dt1<=.12)||!pointValid(p0,dims)||!pointValid(p1,dims)||!pointValid(p2,dims))continue;
          const conf=Math.min(pointConfidence(p0),pointConfidence(p1),pointConfidence(p2));
          // Time-aware linear prediction at t_i; this avoids bias with variable-frame-rate video.
          const den=dt0+dt1,rel=clamp(1-conf,.04,.90),jointStrength=clamp(strength*normalizedRegionWeights[groupForJoint(id)]*speedFactor,.008,.30);
          for(let k=0;k<dims;k++){
            const prediction=(p0[k]*dt1+p2[k]*dt0)/den;
            let delta=(prediction-p1[k])*jointStrength*rel;
            const base=originalCoords[i]?.[k];
            if(Number.isFinite(base))delta=clamp(delta,base-cap-series[i][k],base+cap-series[i][k]);
            // Look-ahead protection: preserve most of the correction component along the
            // observed next-motion vector, while allowing cross-axis jitter to be reduced.
            // This prevents a denoiser from flattening the initiation/withdrawal direction.
            const future=lookAheadPoint(originalCoords,i);
            if(pointValid(future,dims)&&pointValid(base,dims)){
              const direction=Array.from({length:dims},(_,k)=>future[k]-base[k]),magnitude=Math.hypot(...direction);
              const threshold=dims===3?.035:.018;
              if(magnitude>threshold){
                const unit=direction.map(v=>v/magnitude),allDelta=Array.from({length:dims},(_,k)=>(prediction-p1[k])*jointStrength*rel);
                const parallel=allDelta.reduce((sum,v,k)=>sum+v*unit[k],0);
                const axisDelta=allDelta.map((v,k)=>v-parallel*unit[k]+parallel*unit[k]*futureAxisFactor);
                delta=clamp(axisDelta[k],base-cap-series[i][k],base+cap-series[i][k]);
                if(pass===0&&k===0)futureDirectionProtectedSamples++;
              }
            }
            next[i][k]=p1[k]+delta;
          }
          if(pass===0)total++;
        }
        series=next;
      }
      for(let i=0;i<n;i++){
        const p=series[i],base=originalCoords[i];if(!pointValid(p,dims)||!pointValid(base,dims))continue;
        const shift=distance(p,base,dims);if(shift==null)continue;
        if(shift>cap){const scale=cap/shift;for(let k=0;k<dims;k++)p[k]=base[k]+(p[k]-base[k])*scale;}
        const finalShift=distance(p,base,dims)||0;if(finalShift>1e-7){adjusted++;sumShift+=finalShift;maxShift=Math.max(maxShift,finalShift);}
        if(copy[i][field]?.[id])copy[i][field][id]=p;
      }
      if((jointIndex+1)%4===0||jointIndex===MAIN_JOINTS.length-1){onProgress?.({field,completedJoint:jointIndex+1,totalJoints:MAIN_JOINTS.length});await yieldToUI();}
    }
    return {adjusted,total,maxShift,meanShift:adjusted?sumShift/adjusted:0};
  }
  const imageStats=await refineField('im',2,maxImageShift);
  const hasWorld=copy.filter(f=>MAIN_JOINTS.filter(id=>pointValid(f.w[id],3)).length>=10).length/n>=.60;
  const worldStats=hasWorld?await refineField('w',3,maxWorldShift):{adjusted:0,total:0,maxShift:0,meanShift:0};
  async function refineHandField(field,dims,cap){
    let adjusted=0,candidates=0,maxShift=0,sumShift=0;
    for(const side of ['left','right'])for(let joint=1;joint<21;joint++){
      const get=(rows,i)=>rows[i]?.hands?.find(h=>resolveHandPoseSide(h,rows[i]?.im)===side)?.[field]?.[joint]||null;
      const source=original.map((_,i)=>get(original,i));let series=copy.map((_,i)=>get(copy,i)?.slice()||null);
      if(source.filter(p=>pointValid(p,dims)).length<6)continue;
      for(let i=0;i<n;i++)if(series[i]&&source[i])series[i]=series[i].slice();
      for(let pass=0;pass<2;pass++){
        const next=series.map(p=>p?.slice()||null);
        for(let i=1;i<n-1;i++){
          if(eventIdx.has(i))continue;
          const p0=series[i-1],p1=series[i],p2=series[i+1],dt0=copy[i].t-copy[i-1].t,dt1=copy[i+1].t-copy[i].t;
          if((copy[i-1].camera_segment_id??0)!==(copy[i].camera_segment_id??0)||(copy[i+1].camera_segment_id??0)!==(copy[i].camera_segment_id??0))continue;
          if(!(dt0>0&&dt1>0&&dt0<=.12&&dt1<=.12)||!pointValid(p0,dims)||!pointValid(p1,dims)||!pointValid(p2,dims))continue;
          const conf=Math.min(pointConfidence(p0),pointConfidence(p1),pointConfidence(p2));if(conf>.94)continue;
          const den=dt0+dt1,alpha=.075*handStrength*clamp(1-conf,.04,.85);
          const future=lookAheadPoint(source,i),dir=pointValid(future,dims)?Array.from({length:dims},(_,k)=>future[k]-source[i][k]):null,mag=dir?Math.hypot(...dir):0;
          for(let k=0;k<dims;k++){
            const prediction=(p0[k]*dt1+p2[k]*dt0)/den;let delta=(prediction-p1[k])*alpha;
            if(mag>(dims===3?.014:.012)){
              const unit=dir.map(v=>v/mag),raw=Array.from({length:dims},(_,z)=>((p0[z]*dt1+p2[z]*dt0)/den-p1[z])*alpha),parallel=raw.reduce((sum,v,z)=>sum+v*unit[z],0);
              delta=raw[k]-parallel*unit[k]+parallel*unit[k]*futureAxisFactor;
            }
            const base=source[i]?.[k];if(Number.isFinite(base))delta=clamp(delta,base-cap-series[i][k],base+cap-series[i][k]);
            next[i][k]=p1[k]+delta;
          }
          if(pass===0)candidates++;
        }
        series=next;
      }
      for(let i=0;i<n;i++){
        const p=series[i],base=source[i];if(!pointValid(p,dims)||!pointValid(base,dims))continue;
        const shift=distance(p,base,dims);if(shift==null)continue;
        if(shift>cap){const ratio=cap/shift;for(let k=0;k<dims;k++)p[k]=base[k]+(p[k]-base[k])*ratio;}
        const finalShift=distance(p,base,dims)||0;if(finalShift>1e-7){adjusted++;sumShift+=finalShift;maxShift=Math.max(maxShift,finalShift);}
        const hand=copy[i].hands.find(h=>resolveHandPoseSide(h,copy[i].im)===side);if(hand?.[field]?.[joint])hand[field][joint]=p;
      }
      if(joint%5===0)await yieldToUI();
    }
    return {adjusted,candidates,maxShift,meanShift:adjusted?sumShift/adjusted:0};
  }
  const handImageStats=await refineHandField('landmarks',2,.0035);
  const handWorldStats=await refineHandField('world_landmarks',3,.0045);
  const handBoneBefore=handBoneLengthDispersion(original,'world_landmarks'),handBoneAfter=handBoneLengthDispersion(copy,'world_landmarks');
  const handImageBoneBefore=handBoneLengthDispersion(original,'landmarks'),handImageBoneAfter=handBoneLengthDispersion(copy,'landmarks');
  const worldHandGeometryOk=!Number.isFinite(handBoneBefore)||!Number.isFinite(handBoneAfter)||handBoneAfter<=handBoneBefore*1.035+1e-6;
  const imageHandGeometryOk=!Number.isFinite(handImageBoneBefore)||!Number.isFinite(handImageBoneAfter)||handImageBoneAfter<=handImageBoneBefore*1.05+1e-6;
  const handGeometryAcceptable=worldHandGeometryOk&&imageHandGeometryOk;
  if(!handGeometryAcceptable){for(let i=0;i<n;i++)copy[i].hands=cloneHands(original[i].hands,original[i].im);}
  const nextReadinessBefore=initialNextReadiness,nextReadinessAfter=analyzeNextMovementReadiness(copy,lookAheadSeconds);
  const readinessDrops=Object.entries(nextReadinessBefore.groups).filter(([name,before])=>Number.isFinite(before.directional_continuity_score)&&before.comparable_transitions>=8).map(([name,before])=>({name,before:before.directional_continuity_score,after:nextReadinessAfter.groups[name]?.directional_continuity_score??null})).filter(x=>Number.isFinite(x.after)&&x.after<x.before-8);
  const futureContinuityAcceptable=readinessDrops.length===0;
  const beforeAcc=hasWorld?accelerationRms(original,'w',3):accelerationRms(original,'im',2);
  const afterAcc=hasWorld?accelerationRms(copy,'w',3):accelerationRms(copy,'im',2);
  const beforeBone=hasWorld?boneLengthDispersion(original,'w'):null;
  const afterBone=hasWorld?boneLengthDispersion(copy,'w'):null;
  const accelerationImproved=Number.isFinite(beforeAcc)&&Number.isFinite(afterAcc)&&afterAcc<beforeAcc*.999;
  const geometryAcceptable=!hasWorld||!Number.isFinite(beforeBone)||!Number.isFinite(afterBone)||afterBone<=beforeBone*1.05+1e-6;
  const improved=accelerationImproved&&geometryAcceptable&&futureContinuityAcceptable;
  if(!improved){
    // Do not ship an output that only moves landmarks without improving the declared objective.
    for(let i=0;i<n;i++){copy[i].im=original[i].im.map(ensurePointCopy);copy[i].w=original[i].w.map(ensurePointCopy);copy[i].hands=cloneHands(original[i].hands);}
  }
  const finalAcc=improved?afterAcc:beforeAcc;
  const contactAnchorCount=supportAnchors.size;
  return {
    frames:copy,
    stats:{
      changed_landmarks:improved?imageStats.adjusted+worldStats.adjusted:0,
      candidate_landmarks:imageStats.total+worldStats.total,
      changed_hand_landmarks:improved&&handGeometryAcceptable?handImageStats.adjusted+handWorldStats.adjusted:0,
      candidate_hand_landmarks:handImageStats.candidates+handWorldStats.candidates,
      hand_geometry_relative_mad_before:handBoneBefore,
      hand_geometry_relative_mad_after:handGeometryAcceptable?handBoneAfter:handBoneBefore,
      hand_geometry_image_relative_mad_before:handImageBoneBefore,
      hand_geometry_image_relative_mad_after:handGeometryAcceptable?handImageBoneAfter:handImageBoneBefore,
      hand_geometry_acceptable:handGeometryAcceptable,
      future_direction_protected_samples:futureDirectionProtectedSamples,
      future_lookahead_seconds:lookAheadSeconds,
      maximum_image_shift_normalized:improved?imageStats.maxShift:0,
      maximum_world_shift_m:improved?worldStats.maxShift:0,
      mean_image_shift_normalized:improved?imageStats.meanShift:0,
      acceleration_rms_before:beforeAcc,
      acceleration_rms_after:finalAcc,
      acceleration_reduction_pct:beforeAcc>0&&improved?Number(((1-finalAcc/beforeAcc)*100).toFixed(2)):0,
      bone_length_relative_mad_before:beforeBone,
      bone_length_relative_mad_after:improved?afterBone:beforeBone,
      endpoint_and_event_anchors:eventIdx.size,detected_motion_onset_anchors:detectedMotionOnsetAnchors,
      contact_foot_joint_anchors:contactAnchorCount,
      world_landmarks_used:hasWorld,
      objective_improved:improved,
      future_continuity_acceptable:futureContinuityAcceptable,
      future_continuity_drops:readinessDrops,
      next_movement_readiness_before:nextReadinessBefore,
      next_movement_readiness_after:nextReadinessAfter,
      no_op_reason:improved?null:(accelerationImproved&&!geometryAcceptable?'Улучшение ускорения чрезмерно ухудшило согласованность длин сегментов; исходные траектории сохранены.':(!futureContinuityAcceptable?'Коррекция ухудшает согласованность с наблюдаемой следующей фазой; исходные траектории сохранены.':'Коррекция не улучшила метрику временной согласованности; исходные траектории сохранены.'))
    },
    method:{
      name:'confidence-weighted time-aware trajectory regularization',
      objective:'reduce high-frequency acceleration jitter while preserving observed high-confidence coordinates, temporal timestamps and contact/event anchors',
      strength,passes:4,region_weights:normalizedRegionWeights,speed_preservation_weight:speedFactor,lookahead_seconds:lookAheadSeconds,future_direction_protection_factor:futureAxisFactor,future_direction_protected_samples:futureDirectionProtectedSamples,hand_refinement:{passes:2,image_max_shift:.0035,world_max_shift_m:.0045,geometry_guard:1.035},maximum_displacement:{image_normalized:maxImageShift,world_m:maxWorldShift},
      constraints:['No time warping or event reordering.','First and last frames, confirmed event boundaries and detected movement-onset poses are hard anchors.','High-confidence joints are changed less than uncertain joints.','Detected stance-foot ankle/heel/toe landmarks are hard anchors.','World-space bone-length dispersion is monitored; it is not forced to an assumed anthropometric template.','Short-horizon future direction is protected: most correction parallel to observed next motion is suppressed; cross-axis jitter can still be reduced.','Hand/finger landmarks receive a separate low-amplitude temporal correction with wrist anchoring and hand-bone geometry guard.'],
      next_movement_strategy:'short-horizon direction-preserving regularization; movement onsets from a low-velocity pre-onset state to a clear future vector become hard pose anchors. The observed next phase is preserved and passes that materially degrade continuity are rejected; no target pose is invented.',
      limitations:['This is conservative kinematic regularization, not inverse dynamics or optimal control.','It cannot infer muscle forces, EMG, joint moments, GRF or injury risk.','It only corrects short temporal jitter; genuine explosive acceleration must remain in the measured signal.']
    }
  };
}
