#!/usr/bin/env bash
# Optional independent downloader for REG.RU Host-0: Lux, a precompiled Go CLI.
# Does not modify yt-dlp, QuickJS, user reports or model storage.
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
PROJECT_HASH="$(printf '%s' "$ROOT" | sha256sum | awk '{print substr($1,1,12)}')"
MEDIA_DIR="${KATA_MEDIA_IMPORT_DIR:-$(dirname "$ROOT")/.kata-media-import-${PROJECT_HASH}}"
case "$MEDIA_DIR/" in "$ROOT/"*) echo 'ERROR: binary storage must be outside web root' >&2; exit 1;; esac
case "$MEDIA_DIR" in /*) ;; *) echo 'ERROR: KATA_MEDIA_IMPORT_DIR must be absolute' >&2; exit 1;; esac
for cmd in curl sha256sum tar mktemp; do command -v "$cmd" >/dev/null || { echo "ERROR: $cmd required" >&2; exit 1; }; done
VERSION='0.24.1' # Pinned official GitHub release; verified by its published checksums.
case "$(uname -m)" in x86_64|amd64) ARCH=x86_64;; aarch64|arm64) ARCH=arm64;; *) echo 'Lux: unsupported server architecture, yt-dlp remains installed.' >&2; exit 1;; esac
BASE="https://github.com/iawia002/lux/releases/download/v${VERSION}"
NAME="lux_${VERSION}_Linux_${ARCH}.tar.gz"
DIR="$MEDIA_DIR/bin"; mkdir -p "$DIR"; chmod 700 "$MEDIA_DIR" "$DIR" 2>/dev/null || true
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
# Existing binary verified during a previous installation can be retained offline.
if [[ -x "$DIR/lux" && -f "$DIR/lux-sha256.txt" && -f "$DIR/lux-version.txt" ]]; then
  STAMP="$(cat "$DIR/lux-sha256.txt")"; ACTUAL="$(sha256sum "$DIR/lux" | awk '{print $1}')"
  if [[ "$STAMP" == "$ACTUAL" && "$(cat "$DIR/lux-version.txt")" == "$VERSION" ]] && "$DIR/lux" -v >/dev/null 2>&1; then
    echo "Lux $VERSION already installed and verified; no changes."; exit 0
  fi
fi
curl -fLSs --retry 3 --connect-timeout 20 --max-time 120 "$BASE/lux_${VERSION}_checksums.txt" -o "$TMP/checksums"
EXPECTED="$(awk -v f="$NAME" '$2==f || $2=="*"f {print $1}' "$TMP/checksums" | head -n1)"
[[ "$EXPECTED" =~ ^[a-fA-F0-9]{64}$ ]] || { echo "Lux: official SHA-256 for $NAME not found" >&2; exit 1; }
curl -fLSs --retry 3 --connect-timeout 20 --max-time 450 "$BASE/$NAME" -o "$TMP/$NAME"
printf '%s  %s\n' "$EXPECTED" "$TMP/$NAME" | sha256sum --check --status || { echo 'Lux SHA-256 mismatch' >&2; exit 1; }
mkdir "$TMP/unpack"
tar -xzf "$TMP/$NAME" -C "$TMP/unpack" --no-same-owner --no-same-permissions
CANDIDATE="$(find "$TMP/unpack" -maxdepth 3 -type f -name lux -print -quit)"
[[ -n "$CANDIDATE" && -s "$CANDIDATE" ]] || { echo 'Lux binary absent in verified archive' >&2; exit 1; }
chmod 700 "$CANDIDATE"
"$CANDIDATE" -v >/dev/null 2>&1 || { echo 'Lux executable did not start on this host' >&2; exit 1; }
cp "$CANDIDATE" "$DIR/lux.new"; chmod 700 "$DIR/lux.new"; mv -f "$DIR/lux.new" "$DIR/lux"
sha256sum "$DIR/lux" | awk '{print $1}' > "$DIR/lux-sha256.txt"
printf '%s\n' "$VERSION" > "$DIR/lux-version.txt"
chmod 600 "$DIR/lux-sha256.txt" "$DIR/lux-version.txt"
echo "Lux $VERSION ready. Private directory: $MEDIA_DIR"
