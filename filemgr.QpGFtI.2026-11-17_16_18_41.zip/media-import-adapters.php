<?php
declare(strict_types=1);

/** Optional v23 adapters. No database writes, Python, public proxy list or web endpoint. */
function fj_media_adapter_config(string $privateDir): array {
    $file = $privateDir . '/adapters.json';
    $raw = is_file($file) && filesize($file) <= 32768 ? @file_get_contents($file) : false;
    $config = is_string($raw) ? json_decode($raw, true) : [];
    return is_array($config) ? $config : [];
}

function fj_media_adapter_url(string $url, array $allowedHosts): array {
    if (strlen($url) > 8192 || preg_match('/[\x00-\x20\x7f\\\\]/', $url)) throw new RuntimeException('Недопустимая ссылка загрузчика.');
    $p = parse_url($url);
    if (!is_array($p) || ($p['scheme'] ?? '') !== 'https' || isset($p['user']) || isset($p['pass']) || (isset($p['port']) && $p['port'] !== 443)) throw new RuntimeException('Загрузчик принимает только HTTPS на порту 443 без учётных данных.');
    $host = strtolower((string)($p['host'] ?? ''));
    if (!preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/D', $host)) throw new RuntimeException('Недопустимое имя сервера загрузки.');
    $allowed = false;
    foreach ($allowedHosts as $rule) {
        if (!is_string($rule)) continue;
        $rule = strtolower($rule);
        if ($host === $rule || (str_starts_with($rule, '*.') && str_ends_with($host, substr($rule, 1)) && $host !== substr($rule, 2))) { $allowed = true; break; }
    }
    if (!$allowed) throw new RuntimeException('Хост загрузки не входит в список разрешённых для этого адаптера.');
    unset($p['fragment']);
    return ['host' => $host, 'url' => preg_replace('/#.*$/', '', $url)];
}

function fj_media_adapter_public_ip(string $ip): bool {
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return false;
    if (!str_contains($ip, ':')) {
        $n = (int)sprintf('%u', ip2long($ip));
        // PHP 8.1's NO_PRIV_RANGE omits shared/test/benchmark ranges. Reject these too.
        foreach ([['0.0.0.0',8],['100.64.0.0',10],['192.0.0.0',24],['192.0.2.0',24],['192.88.99.0',24],['198.18.0.0',15],['198.51.100.0',24],['203.0.113.0',24],['224.0.0.0',4],['240.0.0.0',4]] as [$base,$bits]) {
            $mask = (0xffffffff << (32-$bits)) & 0xffffffff;
            if (($n & $mask) === ((int)sprintf('%u',ip2long($base)) & $mask)) return false;
        }
    }
    // Reject mapped IPv4, NAT64 and transition ranges whose embedded address may be local.
    if (str_contains($ip, ':')) {
        $bytes = @inet_pton($ip);
        if (!is_string($bytes) || strlen($bytes) !== 16) return false;
        $hex = bin2hex($bytes);
        if ((hexdec($hex[0]) & 14) !== 2 || str_starts_with($hex, '20010db8')) return false;
        if (str_starts_with($hex, '00000000000000000000ffff') || str_starts_with($hex, '0064ff9b') || str_starts_with($hex, '2002') || str_starts_with($hex, '20010000')) return false;
    }
    return true;
}

function fj_media_adapter_ips(string $host): array {
    $ips = [];
    foreach (@dns_get_record($host, DNS_A | DNS_AAAA) ?: [] as $record) {
        $ip = $record['ip'] ?? $record['ipv6'] ?? null;
        if (!is_string($ip)) continue;
        if (!fj_media_adapter_public_ip($ip)) throw new RuntimeException('DNS загрузчика указывает на непубличный адрес.');
        $ips[] = $ip;
    }
    if (!$ips) throw new RuntimeException('DNS загрузчика не разрешается.');
    return array_values(array_unique($ips));
}

function fj_media_adapter_redirect(string $location, string $base): string {
    $location = trim($location);
    if (str_starts_with($location, '//')) return 'https:' . $location;
    if (str_starts_with($location, '/')) return 'https://' . (string)parse_url($base, PHP_URL_HOST) . $location;
    if (str_starts_with($location, 'https://')) return $location;
    throw new RuntimeException('Загрузчик вернул неподдерживаемое перенаправление.');
}

/** Bounded streaming HTTP; manually re-check and pin every redirect, never forward API keys. */
function fj_media_adapter_fetch(string $url, array $hosts, int $limit, ?string $target = null, ?array $json = null, string $apiKey = ''): array {
    if (!extension_loaded('curl')) throw new RuntimeException('Для дополнительных загрузчиков нужен PHP CLI cURL.');
    if ($limit < 1 || $limit > 750 * 1024 * 1024) throw new RuntimeException('Неверный предел размера ответа.');
    if ($apiKey !== '' && (strlen($apiKey) > 4096 || preg_match('/[\x00-\x20\x7f]/', $apiKey))) throw new RuntimeException('Недопустимый API key.');
    for ($hop = 0; $hop <= 4; $hop++) {
        $safe = fj_media_adapter_url($url, $hosts); $url = $safe['url']; $host = $safe['host'];
        $ips = fj_media_adapter_ips($host);
        $addresses = array_map(static fn($ip) => str_contains($ip, ':') ? '[' . $ip . ']' : $ip, $ips);
        $body = ''; $bytes = 0; $headers = []; $headerBytes = 0; $tooLarge = false; $lastProgress = 0.0;
        $file = $target !== null ? @fopen($target, 'wb') : null;
        if ($target !== null && !is_resource($file)) throw new RuntimeException('Не удалось открыть временный видеофайл.');
        $ch = curl_init($url);
        $requestHeaders = ['Accept: ' . ($json !== null ? 'application/json' : '*/*')];
        if ($json !== null) $requestHeaders[] = 'Content-Type: application/json';
        if ($apiKey !== '') {
            $requestHeaders[] = 'Authorization: Api-Key ' . $apiKey;
        }
        curl_setopt_array($ch, [CURLOPT_FOLLOWLOCATION => false, CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_CONNECTTIMEOUT => 15, CURLOPT_TIMEOUT => $target !== null ? 900 : 35,
            CURLOPT_LOW_SPEED_LIMIT => 512, CURLOPT_LOW_SPEED_TIME => 45,
            CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
            // Direct pinned connection makes DNS-rebinding checks effective on shared hosting.
            CURLOPT_PROXY => '', CURLOPT_RESOLVE => [$host . ':443:' . implode(',', $addresses)],
            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; FalcoJugger/23.0; public-video-import)',
            CURLOPT_HTTPHEADER => $requestHeaders, CURLOPT_ENCODING => '',
            CURLOPT_HEADERFUNCTION => static function ($curl, string $line) use (&$headers, &$headerBytes, &$tooLarge, $limit): int {
                $length = strlen($line); $headerBytes += $length;
                if ($headerBytes > 65536) return 0;
                if (str_starts_with($line, 'HTTP/')) $headers = [];
                $colon = strpos($line, ':');
                if ($colon !== false) {
                    $key = strtolower(trim(substr($line, 0, $colon))); $value = trim(substr($line, $colon + 1));
                    $headers[$key] = $value;
                    if ($key === 'content-length' && ctype_digit($value) && (float)$value > $limit) { $tooLarge = true; return 0; }
                }
                return $length;
            },
            CURLOPT_WRITEFUNCTION => static function ($curl, string $chunk) use (&$body, &$bytes, &$tooLarge, &$lastProgress, &$headers, $limit, $file): int {
                $length = strlen($chunk); $bytes += $length;
                if ($bytes > $limit) { $tooLarge = true; return 0; }
                if (is_resource($file)) {
                    $written = fwrite($file, $chunk);
                    if ($written !== $length) return 0;
                    if (microtime(true) - $lastProgress > 1.0) {
                        $lastProgress = microtime(true); $total = ctype_digit((string)($headers['content-length'] ?? '')) ? (int)$headers['content-length'] : 0;
                        $percent = $total > 0 ? min(99, 100 * $bytes / $total) : 0;
                        echo 'KATA_PROGRESS:' . round($percent, 1) . '%|' . $bytes . '|' . $total . '|NA' . PHP_EOL;
                    }
                } else $body .= $chunk;
                return $length;
            }]);
        if ($json !== null) curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode($json, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)]);
        $ok = curl_exec($ch); $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE); $curlCode = curl_errno($ch); curl_close($ch);
        if (is_resource($file)) fclose($file);
        if ($tooLarge) throw new RuntimeException('Превышен допустимый размер ответа загрузчика.');
        if ($ok === false) throw new RuntimeException('Соединение загрузчика прервано (cURL ' . $curlCode . ').');
        if (in_array($status, [301, 302, 303, 307, 308], true)) {
            if ($json !== null || $apiKey !== '') throw new RuntimeException('API endpoint перенаправляет запрос; укажите конечный адрес в приватной конфигурации.');
            $url = fj_media_adapter_redirect((string)($headers['location'] ?? ''), $url); continue;
        }
        if ($status < 200 || $status >= 300) throw new RuntimeException('Загрузчик вернул HTTP ' . $status . ($status === 429 ? '; повторите позже.' : '.'));
        return ['body' => $body, 'headers' => $headers, 'bytes' => $bytes, 'url' => $url];
    }
    throw new RuntimeException('Слишком много перенаправлений загрузчика.');
}

function fj_media_metadata_candidates(string $html): array {
    if (strlen($html) > 4194304) throw new RuntimeException('Страница слишком велика.');
    $urls = []; $title = '';
    if (class_exists('DOMDocument')) {
        $dom = new DOMDocument(); $prev = libxml_use_internal_errors(true);
        try { $dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING); }
        finally { libxml_clear_errors(); libxml_use_internal_errors($prev); }
        foreach ($dom->getElementsByTagName('meta') as $meta) {
            $key = strtolower($meta->getAttribute('property') ?: $meta->getAttribute('name'));
            $value = trim($meta->getAttribute('content'));
            if (in_array($key, ['og:video', 'og:video:url', 'og:video:secure_url'], true) && $value !== '') $urls[] = $value;
            if ($key === 'og:title') $title = $value;
        }
        $jsonScripts = [];
        foreach ($dom->getElementsByTagName('script') as $script) if (strtolower($script->getAttribute('type')) === 'application/ld+json') $jsonScripts[] = $script->textContent;
    } else {
        // Host-0 PHP builds may omit ext-dom. Keep the lightweight public-metadata
        // fallback functional without weakening URL/SSRF validation.
        if (preg_match_all('~<meta\b[^>]*>~i', $html, $tags)) foreach ($tags[0] as $tag) {
            $attrs = [];
            if (preg_match_all('~([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))~', $tag, $matches, PREG_SET_ORDER)) foreach ($matches as $match) $attrs[strtolower($match[1])] = html_entity_decode($match[2] !== '' ? $match[2] : ($match[3] !== '' ? $match[3] : ($match[4] ?? '')), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $key = strtolower($attrs['property'] ?? $attrs['name'] ?? ''); $value = trim($attrs['content'] ?? '');
            if (in_array($key, ['og:video','og:video:url','og:video:secure_url'], true) && $value !== '') $urls[] = $value;
            if ($key === 'og:title') $title = $value;
        }
        $jsonScripts = [];
        if (preg_match_all('~<script\b[^>]*type\s*=\s*["\']application/ld\+json["\'][^>]*>(.*?)</script\s*>~is', $html, $scripts)) $jsonScripts = $scripts[1];
    }
    $walk = static function ($value, int $depth = 0) use (&$walk, &$urls, &$title): void {
        if (!is_array($value) || $depth > 12 || count($urls) >= 16) return;
        $types = $value['@type'] ?? [];
        if ($types === 'VideoObject' || (is_array($types) && in_array('VideoObject', $types, true))) {
            if (is_string($value['contentUrl'] ?? null)) $urls[] = $value['contentUrl'];
            if ($title === '' && is_string($value['name'] ?? null)) $title = $value['name'];
        }
        foreach ($value as $child) if (is_array($child)) $walk($child, $depth + 1);
    };
    foreach ($jsonScripts as $jsonScript) $walk(json_decode((string)$jsonScript, true, 32));
    return ['urls' => array_slice(array_values(array_unique($urls)), 0, 8), 'title' => $title];
}

function fj_media_cobalt_candidate(array $reply): array {
    $status = $reply['status'] ?? '';
    if (in_array($status, ['tunnel', 'redirect'], true) && is_string($reply['url'] ?? null)) return ['url' => $reply['url'], 'title' => is_string($reply['filename'] ?? null) ? $reply['filename'] : ''];
    if ($status === 'picker') {
        $videos = array_values(array_filter(is_array($reply['picker'] ?? null) ? $reply['picker'] : [], static fn($v) => is_array($v) && ($v['type'] ?? '') === 'video' && is_string($v['url'] ?? null)));
        if (count($videos) === 1) return ['url' => $videos[0]['url'], 'title' => ''];
        throw new RuntimeException('Cobalt вернул несколько роликов или только фотографии. Нужна ссылка на один ролик.');
    }
    if ($status === 'local-processing') throw new RuntimeException('Cobalt требует локальную сборку дорожек. Этот адаптер принимает готовое видео; включите обработку на Cobalt instance.');
    $code = preg_replace('/[^a-zA-Z0-9._-]/', '', (string)($reply['error']['code'] ?? 'unexpected_response'));
    throw new RuntimeException('Cobalt: ' . substr($code, 0, 100));
}

function fj_media_adapter_source(string $source): array {
    $safe = fj_media_adapter_url($source, ['youtube.com','www.youtube.com','m.youtube.com','youtu.be','youtube-nocookie.com','www.youtube-nocookie.com','instagram.com','www.instagram.com','instagr.am','www.instagr.am']);
    $host = $safe['host']; $path = (string)parse_url($source, PHP_URL_PATH);
    if (in_array($host, ['instagram.com','www.instagram.com','instagr.am','www.instagr.am'], true)) {
        if (!preg_match('~^/(p|reel|reels|tv)/([A-Za-z0-9_-]{5,40})/?$~D', $path, $match)) throw new RuntimeException('Нужна ссылка на отдельный публичный ролик Instagram.');
        $kind = $match[1] === 'reels' ? 'reel' : $match[1];
        return ['type' => 'instagram', 'url' => 'https://www.instagram.com/' . $kind . '/' . $match[2] . '/'];
    }
    $id = '';
    if ($host === 'youtu.be') $id = trim($path, '/');
    elseif ($path === '/watch') { parse_str((string)parse_url($source, PHP_URL_QUERY), $q); $id = is_string($q['v'] ?? null) ? $q['v'] : ''; }
    elseif (preg_match('~^/(?:shorts|embed|live)/([A-Za-z0-9_-]{6,20})/?$~D', $path, $match)) $id = $match[1];
    if (!preg_match('/^[A-Za-z0-9_-]{6,20}$/D', $id)) throw new RuntimeException('Нужна ссылка на отдельный ролик YouTube.');
    return ['type' => 'youtube', 'url' => 'https://www.youtube.com/watch?v=' . $id];
}

function fj_media_adapter_download(string $url, array $hosts, string $directory, ?callable $fetch = null): void {
    // The optional callable is a local test seam; it is never supplied by HTTP/config.
    $fetch ??= 'fj_media_adapter_fetch';
    fj_media_adapter_url($url, $hosts);
    $part = $directory . '/video.part';
    try {
        $result = $fetch($url, $hosts, 750 * 1024 * 1024, $part);
        $fh = fopen($part, 'rb'); $head = (string)fread($fh, 512); fclose($fh);
        $ext = substr($head, 4, 4) === 'ftyp' ? 'mp4' : (substr($head, 0, 4) === "\x1a\x45\xdf\xa3" ? 'webm' : '');
        if ($result['bytes'] <= 1024 || $ext === '') throw new RuntimeException('Источник не вернул готовый MP4/WebM-файл.');
        if (!rename($part, $directory . '/video.' . $ext)) throw new RuntimeException('Не удалось завершить запись видео.');
        chmod($directory . '/video.' . $ext, 0600);
        echo 'KATA_PROGRESS:100%|' . $result['bytes'] . '|' . $result['bytes'] . '|0' . PHP_EOL;
    } finally { if (is_file($part)) @unlink($part); }
}

function fj_media_adapter_run(array $args, ?callable $fetch = null): int {
    $fetch ??= 'fj_media_adapter_fetch';
    if (count($args) !== 5 || !in_array($args[1], ['metadata', 'cobalt'], true)) throw new RuntimeException('Использование: php media-import-adapters.php metadata|cobalt HTTPS_URL ATTEMPT_DIR PRIVATE_DIR');
    [, $adapter, $sourceUrl, $directory, $privateDir] = $args;
    $root = realpath($privateDir); $out = realpath($directory);
    if ($root === false || $out === false || !is_dir($out) || !preg_match('~^' . preg_quote($root, '~') . '/[a-f0-9]{24}/attempt-[0-9]+$~D', $out) || is_link($directory)) throw new RuntimeException('Неверный приватный каталог задачи.');
    $config = fj_media_adapter_config($root); $source = fj_media_adapter_source($sourceUrl);
    $cdnHosts = ['*.cdninstagram.com','*.fbcdn.net','*.googlevideo.com'];
    if ($adapter === 'metadata') {
        if (($config['public_metadata_enabled'] ?? false) !== true || $source['type'] !== 'instagram') throw new RuntimeException('Metadata-адаптер не включён для этого источника.');
        $page = $fetch($source['url'], ['www.instagram.com','instagram.com'], 4194304);
        $metadata = fj_media_metadata_candidates($page['body']);
        $candidates = $metadata['urls']; $title = $metadata['title']; $hosts = $cdnHosts;
        if (!$candidates) throw new RuntimeException('В публичной странице нет прямого видео. Возможно, нужен вход или площадка изменила разметку.');
    } else {
        $endpoint = trim((string)($config['cobalt_endpoint'] ?? ''));
        if (($config['cobalt_enabled'] ?? false) !== true || $endpoint === '') throw new RuntimeException('Cobalt не настроен владельцем сайта.');
        $endpointHost = strtolower((string)parse_url($endpoint, PHP_URL_HOST));
        fj_media_adapter_url($endpoint, [$endpointHost]);
        $response = $fetch($endpoint, [$endpointHost], 1048576, null,
            ['url' => $source['url'], 'downloadMode' => 'auto', 'videoQuality' => 'max', 'youtubeVideoCodec' => 'h264', 'alwaysProxy' => true, 'localProcessing' => 'disabled'],
            (string)($config['cobalt_api_key'] ?? ''));
        $reply = json_decode($response['body'], true, 32);
        if (!is_array($reply)) throw new RuntimeException('Cobalt вернул неверный JSON.');
        $candidate = fj_media_cobalt_candidate($reply); $candidates = [$candidate['url']]; $title = $candidate['title'];
        $hosts = array_merge([$endpointHost], $cdnHosts, array_slice(is_array($config['cobalt_media_hosts'] ?? null) ? $config['cobalt_media_hosts'] : [], 0, 20));
    }
    $title = preg_replace('/[\x00-\x1f\x7f]/', ' ', $title) ?? '';
    $title = function_exists('mb_strcut') ? mb_strcut($title, 0, 220, 'UTF-8') : preg_replace('/[\x80-\xff]/', '', substr($title, 0, 220));
    if ($title !== '') echo 'KATA_TITLE:' . $title . PHP_EOL;
    $last = null;
    foreach ($candidates as $candidate) {
        try { fj_media_adapter_download($candidate, $hosts, $out, $fetch); return 0; }
        catch (Throwable $e) { $last = $e; }
    }
    throw $last ?? new RuntimeException('Нет подходящего видеофайла.');
}

if (isset($_SERVER['SCRIPT_FILENAME']) && realpath((string)$_SERVER['SCRIPT_FILENAME']) === __FILE__) {
    if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
    try { exit(fj_media_adapter_run($argv)); }
    catch (Throwable $e) { fwrite(STDERR, 'ERROR: ' . $e->getMessage() . PHP_EOL); exit(1); }
}
