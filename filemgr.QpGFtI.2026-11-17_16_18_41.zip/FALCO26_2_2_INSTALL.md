# Falco Jugger 26.2.2 installation

Target: existing Falco 26.2.1 Flight Deck UI, core 23.0.27, fixed personalized mesh build 26.2.0.

Requirements: Bash, PHP CLI 8.1+, `unzip`, `sha256sum`, `cp`, `mv`. Node.js/npm/npx are not required by the production installer.

Upload `Falco_Jugger_26.2.2_Interaction_Stability.zip` to `~/www/falcojugger.art/` and run:

```bash
cd "$HOME/www/falcojugger.art" && t="$(mktemp -d)" && (trap 'rm -rf "$t"' EXIT; unzip -q Falco_Jugger_26.2.2_Interaction_Stability.zip -d "$t" && bash "$t/install-falco26.2.2.sh" --source "$t" --target "$PWD")
```

The installer validates every source package checksum and every target precondition before writing. It only accepts the exact 26.2.1 UI files listed in the manifest (or files already matching 26.2.2). If the production files differ, it stops without overwriting them.

A rollback snapshot is created in `.falco-rollback/ui-26.2.2-*`. If copying, PHP lint, smoke tests, or installed SHA-256 verification fails, changed files are restored automatically.

No trained data, user settings, report archives, videos, heavy model files, `vendor/`, or reconstruction archives are part of this patch. No server-side cleanup is performed.
