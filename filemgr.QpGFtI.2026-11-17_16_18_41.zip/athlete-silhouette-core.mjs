/* Falco Jugger 27.2.0 — pose-anchored, temporally stabilized athlete segmentation.
 * Input: MediaPipe PoseLandmarker person-segmentation probability mask.
 * Output: one multi-seed athlete component, compact binary silhouette and QA metadata.
 * This is an observed 2D foreground mask; it is not a metric scan or a hidden-surface model.
 */
export const ATHLETE_SILHOUETTE_VERSION='falco-athlete-mask-v6-native-resolution';
const finite=Number.isFinite,clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const bitCache=new WeakMap();
function base64Encode(bytes){
 if(typeof btoa==='function'){let out='';for(let i=0;i<bytes.length;i+=0x8000)out+=String.fromCharCode(...bytes.subarray(i,Math.min(bytes.length,i+0x8000)));return btoa(out);}
 return Buffer.from(bytes).toString('base64');
}
function base64Decode(mask){
 if(mask?.bits)return mask.bits;
 if(mask&&typeof mask==='object'&&bitCache.has(mask))return bitCache.get(mask);
 if(typeof mask?.b64!=='string')return null;
 const raw=typeof atob==='function'?atob(mask.b64):Buffer.from(mask.b64,'base64').toString('latin1');
 const bytes=Uint8Array.from(raw,ch=>ch.charCodeAt(0));
 if(mask&&typeof mask==='object')bitCache.set(mask,bytes);
 return bytes;
}
function sampleBilinear(data,w,h,x,y){
 const fx=clamp(x,0,w-1),fy=clamp(y,0,h-1),x0=Math.floor(fx),y0=Math.floor(fy),x1=Math.min(w-1,x0+1),y1=Math.min(h-1,y0+1),tx=fx-x0,ty=fy-y0;
 const a=Number(data[y0*w+x0])||0,b=Number(data[y0*w+x1])||0,c=Number(data[y1*w+x0])||0,d=Number(data[y1*w+x1])||0;
 return (a*(1-tx)+b*tx)*(1-ty)+(c*(1-tx)+d*tx)*ty;
}
function morph(input,w,h,mode){
 const out=new Uint8Array(input.length);
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){
  let value=mode==='dilate'?0:1;
  for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
   const xx=x+dx,yy=y+dy,inside=xx>=0&&yy>=0&&xx<w&&yy<h,bit=inside?input[yy*w+xx]:0;
   if(mode==='dilate')value|=bit;else value&=bit;
  }
  out[y*w+x]=value;
 }
 return out;
}
function closeMask(input,w,h){return morph(morph(input,w,h,'dilate'),w,h,'erode');}
function components(mask,w,h){
 const labels=new Int32Array(mask.length),queue=new Int32Array(mask.length),items=[null];let label=0;
 for(let start=0;start<mask.length;start++){
  if(!mask[start]||labels[start])continue;
  label++;let head=0,tail=1,minX=w,minY=h,maxX=-1,maxY=-1,sumX=0,sumY=0,touchesEdge=false;queue[0]=start;labels[start]=label;
  while(head<tail){const i=queue[head++],x=i%w,y=(i/w)|0;minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);sumX+=x;sumY+=y;if(x===0||y===0||x===w-1||y===h-1)touchesEdge=true;
   for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){if(!dx&&!dy)continue;const xx=x+dx,yy=y+dy;if(xx<0||yy<0||xx>=w||yy>=h)continue;const j=yy*w+xx;if(mask[j]&&!labels[j]){labels[j]=label;queue[tail++]=j;}}
  }
  items[label]={id:label,size:tail,minX,minY,maxX,maxY,cx:sumX/tail,cy:sumY/tail,touchesEdge};
 }
 return {labels,items:items.slice(1)};
}
function fillSmallHoles(mask,w,h,maxHole){
 const seen=new Uint8Array(mask.length),queue=new Int32Array(mask.length),out=mask.slice();
 for(let start=0;start<mask.length;start++){
  if(mask[start]||seen[start])continue;
  let head=0,tail=1,touchesEdge=false;queue[0]=start;seen[start]=1;
  while(head<tail){const i=queue[head++],x=i%w,y=(i/w)|0;if(x===0||y===0||x===w-1||y===h-1)touchesEdge=true;
   const add=j=>{if(j>=0&&j<mask.length&&!mask[j]&&!seen[j]){seen[j]=1;queue[tail++]=j;}};
   if(x>0)add(i-1);if(x+1<w)add(i+1);if(y>0)add(i-w);if(y+1<h)add(i+w);
  }
  // Preserve the real background gap between separated limbs. Only tiny enclosed mask holes are filled.
  if(!touchesEdge&&tail<=maxHole)for(let j=0;j<tail;j++){const i=queue[j];out[i]=1;}
 }
 return out;
}
function pointInfo(p){
 if(Array.isArray(p))return finite(p[0])&&finite(p[1])?{x:p[0],y:p[1],confidence:clamp(Number(p[3]??1),0,1)}:null;
 if(p&&finite(p.x)&&finite(p.y))return {x:p.x,y:p.y,confidence:clamp(Number(p.visibility??p.presence??1),0,1)};
 return null;
}
const ANCHOR_IDS=[0,7,8,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32];
function poseAnchors(landmarks,w,h){
 const out=[];
 for(const id of ANCHOR_IDS){const p=pointInfo(landmarks?.[id]);if(!p||p.confidence<.12||p.x<-.06||p.x>1.06||p.y<-.06||p.y>1.06)continue;out.push({id,x:clamp(p.x,0,1)*(w-1),y:clamp(p.y,0,1)*(h-1),confidence:p.confidence});}
 return out;
}
function nearestForeground(mask,w,h,x,y,maxRadius){
 const cx=Math.round(x),cy=Math.round(y);
 for(let r=0;r<=maxRadius;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){
  if(Math.max(Math.abs(dx),Math.abs(dy))!==r)continue;
  const xx=cx+dx,yy=cy+dy;if(xx>=0&&yy>=0&&xx<w&&yy<h&&mask[yy*w+xx])return {x:xx,y:yy,index:yy*w+xx,distance:Math.hypot(dx,dy)};
 }
 return null;
}
function fitSimilarity(previous,current){
 const pairs=[];
 for(const id of ANCHOR_IDS){const p=pointInfo(previous?.[id]),q=pointInfo(current?.[id]);if(p&&q&&p.confidence>=.28&&q.confidence>=.28)pairs.push([p,q]);}
 if(pairs.length<4)return null;
 const pc=pairs.reduce((s,[p])=>[s[0]+p.x,s[1]+p.y],[0,0]).map(x=>x/pairs.length),qc=pairs.reduce((s,[,q])=>[s[0]+q.x,s[1]+q.y],[0,0]).map(x=>x/pairs.length);
 let den=0,aNum=0,bNum=0;
 for(const [p,q] of pairs){const x=p.x-pc[0],y=p.y-pc[1],u=q.x-qc[0],v=q.y-qc[1];den+=x*x+y*y;aNum+=x*u+y*v;bNum+=x*v-y*u;}
 if(den<.0002)return null;
 const a=aNum/den,b=bNum/den,scale=Math.hypot(a,b);if(!finite(scale)||scale<.62||scale>1.62)return null;
 const tx=qc[0]-(a*pc[0]-b*pc[1]),ty=qc[1]-(b*pc[0]+a*pc[1]);
 if(Math.hypot(tx,ty)>.18)return null; // Reject camera cuts or implausibly large one-frame root jumps.
 const residuals=pairs.map(([p,q])=>Math.hypot(a*p.x-b*p.y+tx-q.x,b*p.x+a*p.y+ty-q.y));
 residuals.sort((x,y)=>x-y);const residual=residuals[Math.floor(residuals.length/2)];
 if(!finite(residual)||residual>.055)return null;
 return {a,b,tx,ty,scale,residual,pairs:pairs.length};
}
function temporalPrior(prob,w,h,previousMask,previousLandmarks,landmarks,deltaMs){
 if(!previousMask||!previousLandmarks||!landmarks||!finite(deltaMs)||deltaMs<=0||deltaMs>460)return {weight:0,alignment:null};
 const alignment=fitSimilarity(previousLandmarks,landmarks);if(!alignment)return {weight:0,alignment:null};
 const bytes=base64Decode(previousMask);if(!bytes||bytes.length!==Math.ceil(previousMask.w*previousMask.h/8))return {weight:0,alignment:null};
 const weight=deltaMs<=120?.16:deltaMs<=260?.11:.06,den=alignment.a*alignment.a+alignment.b*alignment.b;
 if(den<.1)return {weight:0,alignment:null};
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){
  const i=y*w+x,p=prob[i];if(p<.24||p>.78)continue;
  const cx=x/(w-1),cy=y/(h-1),dx=cx-alignment.tx,dy=cy-alignment.ty;
  const px=(alignment.a*dx+alignment.b*dy)/den,py=(-alignment.b*dx+alignment.a*dy)/den;
  if(px<0||px>1||py<0||py>1)continue;
  const ix=Math.min(previousMask.w-1,Math.floor(px*previousMask.w)),iy=Math.min(previousMask.h-1,Math.floor(py*previousMask.h)),pi=iy*previousMask.w+ix;
  const wasForeground=!!((bytes[pi>>3]||0)&(1<<(pi&7)));
  // A weak temporal prior resolves only uncertain edge pixels; current strong evidence always wins.
  prob[i]=clamp(p+(wasForeground?weight:-weight*.42),0,1);
 }
 return {weight,alignment:{scale:alignment.scale,residual:alignment.residual,pairs:alignment.pairs}};
}
function seedComponents(weak,strong,prob,w,h,anchors,landmarks){
 const torso=[11,12,23,24].map(id=>pointInfo(landmarks?.[id])).filter(Boolean);
 if(torso.length<2)return null;
 const shoulderA=pointInfo(landmarks?.[11]),shoulderB=pointInfo(landmarks?.[12]);
 const shoulderSpan=shoulderA&&shoulderB?Math.hypot((shoulderA.x-shoulderB.x)*(w-1),(shoulderA.y-shoulderB.y)*(h-1)):w*.12;
 const radius=clamp(Math.round(shoulderSpan*.085),3,12),seeds=[];
 // Seed torso first, then every sufficiently confident visible joint. This keeps hands/feet
 // even when the segmentation model separates a limb from the trunk by a few pixels.
 const torsoCenter={x:torso.reduce((s,p)=>s+p.x,0)/torso.length*(w-1),y:torso.reduce((s,p)=>s+p.y,0)/torso.length*(h-1),confidence:1,id:'torso'};
 const ordered=[torsoCenter,...anchors.filter(p=>[11,12,23,24].includes(p.id)),...anchors.filter(p=>![11,12,23,24].includes(p.id))];
 const seen=new Set();
 for(const p of ordered){const key=p.id+':'+Math.round(p.x)+':'+Math.round(p.y);if(seen.has(key))continue;seen.add(key);
  const r=Math.max(radius,p.id==='torso'?radius*2:radius),hit=nearestForeground(strong,w,h,p.x,p.y,r)||nearestForeground(weak,w,h,p.x,p.y,Math.round(r*1.45));
  if(hit&&seeds.every(s=>s.index!==hit.index))seeds.push({...hit,anchorId:p.id,confidence:p.confidence??1});
 }
 return seeds.length>=2?seeds:null;
}
function multiSeedFlood(weak,w,h,seeds){
 const out=new Uint8Array(weak.length),queue=new Int32Array(weak.length);let head=0,tail=0;
 for(const s of seeds){if(weak[s.index]&&!out[s.index]){out[s.index]=1;queue[tail++]=s.index;}}
 while(head<tail){const i=queue[head++],x=i%w,y=(i/w)|0;
  for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){if(!dx&&!dy)continue;const xx=x+dx,yy=y+dy;if(xx<0||yy<0||xx>=w||yy>=h)continue;const j=yy*w+xx;if(weak[j]&&!out[j]){out[j]=1;queue[tail++]=j;}}
 }
 return out;
}
function poseCoverage(mask,w,h,anchors){
 if(!anchors.length)return 0;const r=Math.max(3,Math.round(Math.min(w,h)*.014));let hit=0,weight=0;
 for(const p of anchors){const wt=clamp(p.confidence,.15,1);weight+=wt;if(nearestForeground(mask,w,h,p.x,p.y,r))hit+=wt;}
 return weight?hit/weight:0;
}
export function packAthleteSilhouette(mask,landmarks,{width=null,height=null,sourceWidth=null,sourceHeight=null,threshold=.50,strongThreshold=.61,weakThreshold=.39,previousMask=null,previousLandmarks=null,deltaMs=null}={}){
 const mw=Number(mask?.width),mh=Number(mask?.height),data=mask?.getAsFloat32Array?.();
 if(!(mw>0&&mh>0)||!data?.length||data.length<mw*mh||!Array.isArray(landmarks))return null;
 const requestedW=width==null?mw:width,requestedH=height==null?mh:height;const w=clamp(Math.round(requestedW),64,1024),h=clamp(Math.round(requestedH),64,1024),prob=new Float32Array(w*h),weak=new Uint8Array(w*h),strong=new Uint8Array(w*h);
 let maxP=0;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){
  const p=clamp(sampleBilinear(data,mw,mh,(x+.5)*mw/w-.5,(y+.5)*mh/h-.5),0,1),i=y*w+x;prob[i]=p;if(p>maxP)maxP=p;
 }
 if(maxP<.42)return null;
 const temporal=temporalPrior(prob,w,h,previousMask,previousLandmarks,landmarks,deltaMs);
 for(let i=0;i<prob.length;i++){weak[i]=prob[i]>=weakThreshold?1:0;strong[i]=prob[i]>=strongThreshold?1:0;}
 const anchors=poseAnchors(landmarks,w,h),seeds=seedComponents(weak,strong,prob,w,h,anchors,landmarks);
 if(!seeds)return null;
 let candidate=multiSeedFlood(weak,w,h,seeds);
 candidate=closeMask(candidate,w,h);
 const comps=components(candidate,w,h),seedLabels=new Set();
 for(const s of seeds){const hit=nearestForeground(candidate,w,h,s.x,s.y,3);if(hit){const label=comps.labels[hit.index];if(label)seedLabels.add(label);}}
 if(!seedLabels.size)return null;
 const keep=new Uint8Array(w*h);let keptComponents=0;
 for(const c of comps.items){if(!seedLabels.has(c.id))continue;keptComponents++;for(let i=0;i<comps.labels.length;i++)if(comps.labels[i]===c.id)keep[i]=1;}
 // Only tiny enclosed holes are filled. The visible negative space between arms, legs and torso stays empty.
 const cleaned=fillSmallHoles(keep,w,h,Math.max(4,Math.round(w*h*.0018)));
 let area=0,minX=w,minY=h,maxX=-1,maxY=-1,probSum=0,boundarySum=0,boundaryN=0;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=y*w+x;if(!cleaned[i])continue;area++;minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);probSum+=prob[i];
  if(x===0||y===0||x===w-1||y===h-1||!cleaned[i-1]||!cleaned[i+1]||!cleaned[i-w]||!cleaned[i+w]){boundarySum+=prob[i];boundaryN++;}
 }
 const coverage=area/(w*h);if(area<Math.max(32,w*h*.00035)||coverage>.90||maxX<0)return null;
 const poseCov=poseCoverage(cleaned,w,h,anchors),meanProbability=probSum/area,boundaryConfidence=boundaryN?boundarySum/boundaryN:meanProbability;
 const frameEdge=minX===0||minY===0||maxX===w-1||maxY===h-1;
 const confidence=clamp(meanProbability*.52+poseCov*.30+boundaryConfidence*.18,0,1);
 const quality=confidence>=.77&&poseCov>=.68&&!frameEdge?'high':confidence>=.56&&poseCov>=.42?'review':'low';
 const bits=new Uint8Array(Math.ceil(w*h/8));for(let i=0;i<cleaned.length;i++)if(cleaned[i])bits[i>>3]|=1<<(i&7);
 return {
  schema:ATHLETE_SILHOUETTE_VERSION,w,h,source_width:Number.isFinite(sourceWidth)?sourceWidth:null,source_height:Number.isFinite(sourceHeight)?sourceHeight:null,native_mask_width:mw,native_mask_height:mh,source_resolution_available:Number.isFinite(sourceWidth)&&Number.isFinite(sourceHeight)&&w>=sourceWidth&&h>=sourceHeight,b64:base64Encode(bits),coverage:Number(coverage.toFixed(5)),mask_pixels:area,
  bbox:{x:minX/w,y:minY/h,width:(maxX-minX+1)/w,height:(maxY-minY+1)/h},
  bbox_pixels:{x:minX,y:minY,width:maxX-minX+1,height:maxY-minY+1},
  confidence:Number(confidence.toFixed(4)),mean_probability:Number(meanProbability.toFixed(4)),boundary_confidence:Number(boundaryConfidence.toFixed(4)),pose_coverage:Number(poseCov.toFixed(4)),
  pose_anchor_count:anchors.length,seed_count:seeds.length,component_count:keptComponents,touches_frame_edge:!!frameEdge,quality,
  temporal_prior_weight:temporal.weight,temporal_alignment:temporal.alignment,
  source:'mediapipe-pose-segmentation-mask',method:'native-resolution pose multi-seed hysteresis + component retention + small-hole fill + temporal similarity prior',
  limitations:['Boundary detail is bounded by the native MediaPipe segmentation-mask resolution','Clothing, hair, blur and self-occlusion affect the observed silhouette','A single RGB view cannot reveal the hidden back surface or absolute body scale']
 };
}
export function pointInAthleteSilhouette(mask,x,y){
 if(!(mask?.bits||mask?.b64)||!(mask.w>0&&mask.h>0)||!finite(x)||!finite(y)||x<0||x>1||y<0||y>1)return false;
 const px=Math.min(mask.w-1,Math.floor(x*mask.w)),py=Math.min(mask.h-1,Math.floor(y*mask.h)),i=py*mask.w+px,bits=base64Decode(mask);
 return !!((bits?.[i>>3]||0)&(1<<(i&7)));
}
export function projectInsideAthleteSilhouette(mask,center,vertex){
 if(!mask)return vertex;if(!Array.isArray(center)||!Array.isArray(vertex)||![...center,...vertex].every(finite))return null;
 if(!pointInAthleteSilhouette(mask,center[0],center[1]))return null;if(pointInAthleteSilhouette(mask,vertex[0],vertex[1]))return vertex;
 for(let i=1;i<=64;i++){const t=1-i/64,x=center[0]+(vertex[0]-center[0])*t,y=center[1]+(vertex[1]-center[1])*t;if(pointInAthleteSilhouette(mask,x,y))return [x,y,vertex[2]??0];}
 return center;
}
export function silhouetteImageData(mask){
 if(!(mask?.bits||mask?.b64)||!(mask.w>0&&mask.h>0))return null;const bits=base64Decode(mask);if(!bits||bits.length!==Math.ceil(mask.w*mask.h/8))return null;
 const out=new Uint8ClampedArray(mask.w*mask.h*4);for(let i=0;i<mask.w*mask.h;i++){const k=i*4;out[k]=255;out[k+1]=255;out[k+2]=255;out[k+3]=(bits[i>>3]&(1<<(i&7)))?255:0;}return out;
}
export function silhouetteContourImageData(mask){
 if(!(mask?.bits||mask?.b64)||!(mask.w>0&&mask.h>0))return null;const bits=base64Decode(mask);if(!bits||bits.length!==Math.ceil(mask.w*mask.h/8))return null;
 const w=mask.w,h=mask.h,out=new Uint8ClampedArray(w*h*4),inside=(x,y)=>x>=0&&y>=0&&x<w&&y<h&&!!((bits[(y*w+x)>>3]||0)&(1<<((y*w+x)&7)));
 for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(inside(x,y)&&(!inside(x-1,y)||!inside(x+1,y)||!inside(x,y-1)||!inside(x,y+1))){const k=(y*w+x)*4;out[k]=255;out[k+1]=255;out[k+2]=255;out[k+3]=255;}
 return out;
}
export function resizeAthleteSilhouette(mask,{width=128,height=128}={}){
 if(!(mask?.bits||mask?.b64)||!(mask.w>0&&mask.h>0))return null;
 const src=base64Decode(mask);if(!src||src.length!==Math.ceil(mask.w*mask.h/8))return null;
 const w=clamp(Math.round(width),32,192),h=clamp(Math.round(height),32,192),bits=new Uint8Array(Math.ceil(w*h/8));
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){
  const x0=Math.floor(x*mask.w/w),x1=Math.max(x0+1,Math.ceil((x+1)*mask.w/w)),y0=Math.floor(y*mask.h/h),y1=Math.max(y0+1,Math.ceil((y+1)*mask.h/h));let hit=0,total=0;
  for(let sy=y0;sy<Math.min(mask.h,y1);sy++)for(let sx=x0;sx<Math.min(mask.w,x1);sx++){const i=sy*mask.w+sx;total++;if((src[i>>3]>>(i&7))&1)hit++;}
  // 25% area coverage retains narrow wrists, fingers, toes and hems during compact training.
  if(total&&hit/total>=.25){const i=y*w+x;bits[i>>3]|=1<<(i&7);}
 }
 return {schema:ATHLETE_SILHOUETTE_VERSION,w,h,source_width:mask.source_width??null,source_height:mask.source_height??null,native_mask_width:mask.native_mask_width??mask.w,native_mask_height:mask.native_mask_height??mask.h,source_resolution_available:Number.isFinite(mask.source_width)&&Number.isFinite(mask.source_height)&&w>=mask.source_width&&h>=mask.source_height,b64:base64Encode(bits),coverage:mask.coverage??null,quality:mask.quality??'legacy',confidence:mask.confidence??null,pose_coverage:mask.pose_coverage??null,source:'downsampled-training-silhouette'};
}
export function compactAthleteSilhouette(mask){
 if(!mask?.b64||!(mask.w>0&&mask.h>0))return null;const pixels=mask.w*mask.h,bits=base64Decode(mask);if(!bits||bits.length!==Math.ceil(pixels/8))return null;
 const packed=[(bits[0]&1)?1:0];let prev=packed[0],run=0;const emit=n=>{do{let b=n&127;n=Math.floor(n/128);if(n)b|=128;packed.push(b);}while(n);};
 for(let i=0;i<pixels;i++){const bit=(bits[i>>3]>>(i&7))&1;if(bit!==prev){emit(run);prev=bit;run=0;}run++;}emit(run);
 const encoded=base64Encode(Uint8Array.from(packed));return encoded.length+1<mask.b64.length?'r'+encoded:'b'+mask.b64;
}
export function expandAthleteSilhouette(serialized,{w=128,h=128}={}){
 if(typeof serialized!=='string'||serialized.length<2||serialized.length>2097152||!Number.isInteger(w)||!Number.isInteger(h)||w<32||h<32||w>1024||h>1024)return null;
 const scheme=serialized[0],payload=serialized.slice(1),pixels=w*h;
 if(scheme==='b'){const bits=base64Decode({b64:payload});return bits?.length===Math.ceil(pixels/8)?{schema:ATHLETE_SILHOUETTE_VERSION,w,h,b64:payload,source:'archived-segmentation-mask',quality:'archived'}:null;}
 if(scheme!=='r')return null;const data=base64Decode({b64:payload});if(!data?.length)return null;
 const bits=new Uint8Array(Math.ceil(pixels/8));let next=Number(data[0]);if(next!==0&&next!==1)return null;let cursor=1,pos=0;
 while(cursor<data.length){let run=0,shift=0,terminated=false;while(cursor<data.length){const b=data[cursor++];run+=(b&127)*2**shift;shift+=7;if(shift>28)return null;if(!(b&128)){terminated=true;break;}}
  if(!terminated||!Number.isSafeInteger(run)||pos+run>pixels)return null;if(next)for(let i=pos;i<pos+run;i++)bits[i>>3]|=1<<(i&7);pos+=run;next^=1;
 }
 return pos===pixels?{schema:ATHLETE_SILHOUETTE_VERSION,w,h,b64:base64Encode(bits),source:'archived-segmentation-mask',quality:'archived'}:null;
}
