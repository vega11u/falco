# Falco 24.3.0 — design and interaction references

The implementation remains a vanilla PHP/HTML/CSS/JavaScript application. No React, Tailwind, Base UI, external fonts, CDN assets or third-party runtime dependencies were added. The repositories below informed interaction and composition decisions only; no source code was copied.

## GitHub references reviewed

- **shadcndashboard/shadcndashboard** — responsive dashboard shell, reusable component boundaries, predictable surface hierarchy and theme tokens.  
  https://github.com/shadcndashboard/shadcndashboard
- **elahlabs/elah** — modular browser video-editor architecture; a timeline is treated as a focused editing surface, with playback and editor concerns separated.  
  https://github.com/elahlabs/elah
- **ezeoleaf/opengait** — biomechanics workflow from capture to pose landmarks to view-specific metrics and debrief; supports keeping evidence, view and metric context close together.  
  https://github.com/ezeoleaf/opengait
- **yannamsellem/framecraft** — centralized player/timeline state, timeline scrubbing and keyboard transport patterns.  
  https://github.com/yannamsellem/framecraft

## Applied to Falco

- A consistent application shell and tokenized components instead of stacked theme files.
- One page scroll owner; sticky navigation/player do not become nested scroll containers.
- Player transport is one control group; secondary actions are in a disclosure panel.
- Trim editor is colocated with the source video and its range controls.
- Analysis output remains a linear evidence stream; the player is the persistent session tool.
- Scientific metrics retain their uncertainty and interpretation context; no new score or synthetic progress indicator was introduced.

## 60 / 30 / 10

- **60% — base:** graphite-blue workspace background, deliberately quiet and low-contrast.
- **30% — surfaces:** ocean-teal panels, cards, player chamber and navigation surface.
- **10% — accent:** mint-cyan for primary actions, focus, active navigation and selected states.

The ratio describes visual role and emphasis, not a literal pixel-count guarantee.
