# QA — Falco Jugger 23.0.12–23.0.19

## Проверенная сборка

Тестовая установка выполнена на копии присланного `falcojugger.art.zip`, затем наложены файлы объединения 23.0.12–23.0.15 и актуальные программные файлы 23.0.19. Для отсутствовавших файлов 16–18 добавлены совместимые восстановленные Vista CSS/JS; также восстановлены недостающие PHP/JS-модули контроля импорта.

## Результаты

- `php -l`: `index.php`, `models.php`, `Memories.php`, `uppurcell.php`, `media-import-control.php` — PASS.
- HTTP через локальный PHP server: `index.php`, `uppurcell.php`, `models.php`, `Memories.php` — HTTP 200.
- Проверка локальных CSS/JS/PHP импортов и ссылок четырёх страниц — отсутствующих файлов нет.
- `tinycss2`: CSS 23.0.15, Vista 23.0.16/17/18 и HARD UPDATE 23.0.19 — 0 parse errors.
- Node syntax: `media-owner-token-core.mjs`, Vista UX 17/18, HARD UPDATE core/JS и извлечённый из PHP HTML module — PASS.
- `tests/aero-studio-contract-23-0-15.mjs` — PASS.
- `tests/body-reconstruction-23-0-13.mjs` — PASS.
- `tests/body-reconstruction-worker-23-0-13.mjs` — PASS.
- `tests/depth-stability-23-0-11.mjs` — PASS.
- `tests/purcell-evolution-23-0-14.mjs` — PASS.
- `tests/purcell-evolution-memory-23-0-14.php` — PASS.
- `tests/reconstruction-memory-23-0-13.php` — PASS.
- `tests/reconstruction-api-23-0-13.sh` — PASS.
- `tests/velocity-and-quality-23-0-14.mjs` — PASS.
- `tests/hard-update-v23.0.19.mjs` — PASS.
- `tests/hard-update-endpoint-smoke.sh` против локального PHP server: same-origin POST 200 + `Clear-Site-Data`, GET 405, cross-origin POST 403 — PASS.
- `tests/media-import-control-23-0-17.php`: owner isolation, live PID protection, recovery of dead import lock within grace, preservation of queued CRON job — PASS.
- `tests/media-owner-token-23-0-17.mjs`: stable token, localStorage/sessionStorage fallback, no-crypto fallback — PASS.
- `tests/optimizer-smoke.sh`, `tests/purcell-and-report-api-smoke.sh`, `tests/v23-0-4-policy-smoke.sh` — PASS.

## Проверка защиты данных

На отдельной копии созданы контрольные файлы в `training-data/`, `data/trained/` и `reports/`. После наложения объединённого ZIP их SHA-256 остались идентичными. В самом архиве нет каталогов обучения, отчётов, vendor, пользовательских видео, приватных конфигураций и кэша.

## Что не проверено

- Chromium/Android визуальный E2E: среда ранее блокировала headless браузер; тесты HTML/CSS/JS не заменяют осмотр интерфейса на реальном устройстве.
- Фактическая очистка HTTP disk cache через `Clear-Site-Data` зависит от браузера.
- Реальная загрузка и остановка yt-dlp/Lux/CRON на сервере пользователя не выполнялась; PID/lock helper проверен изолированными PHP-тестами.
- Производительность на длинных реальных видео и тепловой режим телефона не измерялись.
- Оригинальные файлы релизов 23.0.16–23.0.18 не были приложены; соответствующие отсутствовавшие CSS/JS-зависимости восстановлены совместимым слоем, не оригинальными байтами.

**Вывод:** PHP/JS зависимости объединённого overlay разрешены, ключевые регрессионные тесты 12–15 и HARD UPDATE 19 проходят; тестовая установка не меняет контрольные обучающие/отчётные файлы. На реальном сайте всё равно следует проверить импорт видео и отображение на Android после установки.
