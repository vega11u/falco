# Falco Jugger 26.2.2 — QA results

## Automated checks

- Full `tests/verify.sh`: PASS.
- PHP syntax: all 41 PHP files in the uploaded source archive passed `php -l`.
- JavaScript syntax: all 107 JS/MJS files in the uploaded source archive passed `node --check` under Node 22.16.0.
- CSS parse: 483 top-level rules; 0 parser errors.
- Main rendered HTML: 370 IDs, all unique; 134 buttons, all with explicit `type`.
- Root stylesheet inventory: exactly one CSS file.
- Legacy import / compatibility-layer / `.f24-workspace-grid` scan: no matches.
- Fixed 2048-vertex topology and core version 23.0.27: preserved.
- PHP API, learning API, reports, video import, trim, depth, pose, biomechanics, Purcell, Lully, and server-report regressions: PASS.

## Installer checks

- Clean source archive -> 26.2.1 -> 26.2.2: PASS.
- All 24 target/package file checksums validated before writes.
- PHP lint and `falco-flightdeck-2622-smoke.php`: PASS.
- Installed SHA-256 verification: PASS.
- Re-running installer on 26.2.2: PASS, no-op (0 files changed).
- No Node.js/npm/npx dependency in production installer.

## What was not verified

A full interactive Chromium run against the complete PHP application did not complete in the isolated build environment. Therefore this report does not claim an end-to-end click-through of every external model/API workflow in a real browser. The release has static DOM/CSS checks and the full project regression suite; final production-browser verification on REG.RU remains required.
