#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
if [ "$#" -ne 1 ]; then echo "Usage: bash backup-learning.sh /absolute/backup/directory-outside-public-root" >&2; exit 2; fi
TARGET="$1"
case "$TARGET" in /*) ;; *) echo "Backup target must be absolute" >&2; exit 2;; esac
mkdir -p -- "$TARGET"
TARGET="$(cd "$TARGET" && pwd -P)"
case "$TARGET/" in "$ROOT/"*) echo "Refusing a backup inside the website root" >&2; exit 3;; esac
if [ "$TARGET" = "$ROOT" ]; then echo "Backup must be outside website root" >&2; exit 3; fi
cd "$ROOT"
paths=()
for path in training-data data/trained purcell lully reports report-library library private uploads user-data; do
 if [ -e "$path" ]; then paths+=("$path"); fi
done
if [ ${#paths[@]} -eq 0 ]; then echo "No default data paths found. Check custom application data paths manually." >&2; exit 4; fi
OUT="$TARGET/falco-learning-$(date -u +%Y%m%dT%H%M%SZ)-$$.tar.gz"
( umask 077; tar -czf "$OUT" -- "${paths[@]}" )
echo "Backup created at: $OUT"
echo "IMPORTANT: Also back up custom data paths and any database configured outside these directories."
