/**
 * Personal 3D archive v3 — fixed 2048-vertex athlete mesh.
 * v2 (512-vertex) snapshots remain readable for old reports.
 */
import {
 buildVivaldiFineMesh,getVivaldiMeshTopology,VIVALDI_MESH_TOPOLOGY,
 VIVALDI_MESH_VERTEX_COUNT,paintVivaldiMesh3D
} from './vivaldi-fine-mesh.mjs?v=26.2.0';

export const PERSONAL_3D_ARCHIVE_VERSION='falco-personalized-vivaldi-mesh-keyframes-v3-fixed2048';
export const PERSONAL_3D_ARCHIVE_LEGACY_VERSION='falco-personalized-vivaldi-mesh-keyframes-v2';
const finite=Number.isFinite;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const LEGACY_VERTICES=512,LEGACY_BYTES=LEGACY_VERTICES*7;
const CURRENT_BYTES=VIVALDI_MESH_VERTEX_COUNT*7;

function validPoint(p){return Array.isArray(p)&&p.length>=4&&p.slice(0,3).every(finite)&&(p[3]??1)>=.10;}
function hasMeasuredPersonal3D(frame,profile){
 const world=frame?.render_w||frame?.w||[];
 const joints=[11,12,13,14,15,16,23,24,25,26,27,28];
 const visible=joints.filter(i=>validPoint(world[i])).length;
 return visible>=9&&Number(profile?.profile_confidence)>=.08&&
  Object.values(profile?.width_profile||{}).some(stations=>Array.isArray(stations)&&stations.filter(x=>Array.isArray(x)&&finite(x[0])&&x[1]>=.12).length>=2);
}
function toBase64(bytes){
 let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,Math.min(bytes.length,i+0x8000)));
 return btoa(binary);
}
function fromBase64(value){try{const binary=atob(value),bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);return bytes;}catch(_){return null;}}
function legacyTriangles(){
 const out=[],first=0,rings=4,sides=14,segments=9;
 for(let s=0;s<segments;s++)for(let r=0;r<rings-1;r++)for(let k=0;k<sides;k++){
  const a=first+s*(rings*sides)+r*sides+k,b=first+s*(rings*sides)+r*sides+(k+1)%sides,c=first+s*(rings*sides)+(r+1)*sides+k,d=first+s*(rings*sides)+(r+1)*sides+(k+1)%sides;
  out.push(a,b,c,b,d,c);
 }
 return new Uint32Array(out);
}
const LEGACY_TRIANGLES=legacyTriangles();

export function encodeVivaldiMeshSnapshot(frame,profile,{time=null,frameIndex=null}={}){
 if(!hasMeasuredPersonal3D(frame,profile))return null;
 const mesh=buildVivaldiFineMesh(frame,profile,{resolution:'identity',space:'3d'});
 if(mesh.vertex_count!==VIVALDI_MESH_VERTEX_COUNT||mesh.visible_vertices<640||mesh.visible_triangles<450)return null;
 const bytes=new Uint8Array(CURRENT_BYTES),view=new DataView(bytes.buffer);
 for(let i=0;i<VIVALDI_MESH_VERTEX_COUNT;i++){
  const off=i*7,p=i*4;
  for(let k=0;k<3;k++){
   const value=clamp(Number(mesh.positions[p+k])||0,-2.65,2.65);
   view.setInt16(off+k*2,Math.round(value*12000),true);
  }
  bytes[off+6]=Math.round(clamp(mesh.positions[p+3]||0,0,1)*255);
 }
 return {
  schema:PERSONAL_3D_ARCHIVE_VERSION,topology:VIVALDI_MESH_TOPOLOGY,
  vertex_count:VIVALDI_MESH_VERTEX_COUNT,frame_index:Number.isInteger(frameIndex)?frameIndex:null,
  time_s:finite(time)?Number(time.toFixed(4)):finite(frame?.t)?Number(frame.t.toFixed(4)):null,
  encoding:'2048x-xyz-i16-conf-u8-le',scale:12000,vertex_bytes:7,
  visible_vertices:mesh.visible_vertices,visible_triangles:mesh.visible_triangles,
  quality:mesh.quality,bytes_base64:toBase64(bytes)
 };
}
export function decodeVivaldiMeshSnapshot(snapshot){
 if(!snapshot||typeof snapshot.bytes_base64!=='string')return null;
 const schema=snapshot.schema,legacy=schema===PERSONAL_3D_ARCHIVE_LEGACY_VERSION;
 if(!legacy&&schema!==PERSONAL_3D_ARCHIVE_VERSION)return null;
 const vertexCount=legacy?LEGACY_VERTICES:VIVALDI_MESH_VERTEX_COUNT;
 const expected=legacy?LEGACY_BYTES:CURRENT_BYTES;
 if(Number(snapshot.vertex_count)!==vertexCount||Number(snapshot.vertex_bytes)!==7)return null;
 if(!legacy&&(snapshot.topology!==VIVALDI_MESH_TOPOLOGY||snapshot.encoding!=='2048x-xyz-i16-conf-u8-le'))return null;
 const bytes=fromBase64(snapshot.bytes_base64);
 if(!bytes||bytes.length!==expected)return null;
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),positions=new Float32Array(vertexCount*4),confidence=new Float32Array(vertexCount),scale=Number(snapshot.scale);
 if(!(scale>=1000&&scale<=50000))return null;
 for(let i=0;i<vertexCount;i++){
  const off=i*7,p=i*4;
  for(let k=0;k<3;k++)positions[p+k]=view.getInt16(off+k*2,true)/scale;
  const c=bytes[off+6]/255;positions[p+3]=c;confidence[i]=c;
 }
 return {schema,topology:legacy?'legacy-v2-512':VIVALDI_MESH_TOPOLOGY,vertex_count:vertexCount,positions,confidence,bytes:bytes.length,visible_vertices:Number(snapshot.visible_vertices)||0,visible_triangles:Number(snapshot.visible_triangles)||0};
}
export function buildPersonalized3DArchive(frames,profile,{maxKeyframes=200}={}){
 const source=Array.isArray(frames)?frames:[],limit=clamp(Math.round(maxKeyframes)||200,12,400);
 if(source.length<8||!profile?.width_profile)return null;
 // Uniform temporal bins retain kata coverage. Within each bin, choose the frame
 // with the strongest joint + silhouette evidence rather than the first frame.
 const keyframes=[],bins=Math.min(limit,source.length),perBin=3;
 for(let bin=0;bin<bins;bin++){
  const start=Math.floor(bin*source.length/bins),end=Math.max(start+1,Math.floor((bin+1)*source.length/bins));
  let best=null;
  for(let s=0;s<perBin;s++){
   const index=Math.min(source.length-1,start+Math.floor((end-start)*(s+.5)/perBin)),frame=source[index];
   if(!hasMeasuredPersonal3D(frame,profile))continue;
   const snapshot=encodeVivaldiMeshSnapshot(frame,profile,{time:frame.t,frameIndex:index});
   if(!snapshot)continue;
   const world=frame.render_w||frame.w||[],joints=[11,12,13,14,15,16,23,24,25,26,27,28];
   const conf=joints.reduce((sum,id)=>sum+clamp(Number(world[id]?.[3])||0,0,1),0)/joints.length;
   const silhouette=clamp(Number(frame.surface?.confidence??frame.surface?.quality)||0,0,1);
   const score=conf*.68+silhouette*.12+(snapshot.visible_vertices/VIVALDI_MESH_VERTEX_COUNT)*.20;
   if(!best||score>best.score)best={snapshot,score};
  }
  if(best)keyframes.push(best.snapshot);
 }
 if(keyframes.length<Math.min(8,Math.ceil(limit*.08)))return null;
 keyframes.sort((a,b)=>(a.time_s??0)-(b.time_s??0));
 return {
  schema:PERSONAL_3D_ARCHIVE_VERSION,topology:VIVALDI_MESH_TOPOLOGY,
  vertex_count:VIVALDI_MESH_VERTEX_COUNT,frame_count:source.length,
  keyframe_count:keyframes.length,profile_confidence:Number(profile.profile_confidence)||0,
  mesh_generator:'vivaldi-fixed-athlete-mesh-v2',keyframes,
  limitations:[
   'The same 2048-vertex topology and vertex correspondence are used for every frame and device.',
   'Individual silhouette widths are fitted across the clip; per-frame mask widths do not resize the identity mesh.',
   'Single-camera hidden-side thickness is a bounded prior, not measured anatomy or a metric 3D scan.'
  ]
 };
}
export function validatePersonalized3DArchive(value,expectedFrameCount=null){
 if(!value||![PERSONAL_3D_ARCHIVE_VERSION,PERSONAL_3D_ARCHIVE_LEGACY_VERSION].includes(value.schema)||
  !Array.isArray(value.keyframes)||!value.keyframes.length||value.keyframes.length>400||
  Number(value.keyframe_count)!==value.keyframes.length||!(Number(value.frame_count)>=value.keyframes.length))return false;
 if(expectedFrameCount!=null&&Number(value.frame_count)!==Number(expectedFrameCount))return false;
 if(value.schema===PERSONAL_3D_ARCHIVE_VERSION&&(value.topology!==VIVALDI_MESH_TOPOLOGY||Number(value.vertex_count)!==VIVALDI_MESH_VERTEX_COUNT))return false;
 return value.keyframes.every(k=>!!decodeVivaldiMeshSnapshot(k));
}
function paintSavedPersonal3D(ctx,snapshot,{width=640,height=420,yaw=-.38,pitch=.16,centerX=width/2,centerY=height*.48,size=Math.min(width,height)*.48,color='#7ed9eb',alpha=.94}={}){
 const mesh=decodeVivaldiMeshSnapshot(snapshot);if(!mesh)return false;
 const legacy=mesh.vertex_count===LEGACY_VERTICES,tri=legacy?LEGACY_TRIANGLES:getVivaldiMeshTopology().triangles;
 const pts=mesh.positions,ca=Math.cos(yaw),sa=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch),projected=[];
 for(let i=0;i<mesh.vertex_count;i++){
  const x=pts[i*4],y=pts[i*4+1],z=pts[i*4+2],X=x*ca+z*sa,Z=z*ca-x*sa,Y=y*cp-Z*sp,D=Math.max(.65,2.45+Z*cp+y*sp);
  projected.push({x:centerX+X/D*size,y:centerY+Y/D*size,z:Z,c:pts[i*4+3]});
 }
 const faces=[];
 for(let i=0;i<tri.length;i+=3){
  const a=projected[tri[i]],b=projected[tri[i+1]],c=projected[tri[i+2]];
  if(!a||!b||!c||Math.min(a.c,b.c,c.c)<.12)continue;
  const area=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);if(Math.abs(area)<.02||Math.abs(area)>size*size*.9)continue;
  const nx=(b.y-a.y)*(c.z-a.z)-(b.z-a.z)*(c.y-a.y),ny=(b.z-a.z)*(c.x-a.x)-(b.x-a.x)*(c.z-a.z),nz=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
  const light=clamp(.58+.42*Math.abs(nz)/Math.max(1e-6,Math.hypot(nx,ny,nz)),.35,1);
  faces.push({a,b,c,z:(a.z+b.z+c.z)/3,light});
 }
 faces.sort((a,b)=>b.z-a.z);ctx.save();ctx.globalAlpha=alpha;ctx.lineWidth=.35;ctx.strokeStyle=color;
 for(const f of faces){ctx.beginPath();ctx.moveTo(f.a.x,f.a.y);ctx.lineTo(f.b.x,f.b.y);ctx.lineTo(f.c.x,f.c.y);ctx.closePath();ctx.fillStyle=`rgba(126,217,235,${(.22+f.light*.48).toFixed(3)})`;ctx.fill();ctx.stroke();}
 ctx.restore();return faces.length>=(legacy?80:450);
}
export function renderArchivedPersonal3D(ctx,frame,profile,archive,{width=640,height=420,time=null}={}){
 if(!ctx||!frame)return false;
 const t=finite(time)?time:Number(frame.t),keyframes=archive?.keyframes||[];
 let nearest=null,delta=Infinity;
 for(const k of keyframes){const d=Math.abs(Number(k.time_s)-t);if(finite(d)&&d<delta){nearest=k;delta=d;}}
 // Prefer a fresh projection from the current reconstructed frame. Stored snapshots
 // are a fallback for archives whose frame store does not contain render landmarks.
 if(frame.w?.length||frame.render_w?.length){
  if(paintVivaldiMesh3D(ctx,frame,profile,{resolution:'identity',centerX:width/2,centerY:height*.48,size:Math.min(width,height)*.48}))return true;
 }
 if(nearest&&delta<=.06)return paintSavedPersonal3D(ctx,nearest,{width,height});
 return false;
}
