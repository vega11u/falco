#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-}"
[ -n "$TARGET" ] || { echo "Usage: bash cleanup-legacy-styles-26.3.2.sh /path/to/falcojugger.art" >&2; exit 2; }
[ -d "$TARGET" ] || { echo "Target directory does not exist: $TARGET" >&2; exit 3; }
QUARANTINE="$TARGET/.falco-style-quarantine-26.3.2"
mkdir -p "$QUARANTINE"
# Only these historical stylesheet names/markers are eligible. JS, PHP, vendor,
# data and the active falco-jugger-ui.css are never touched.
patterns='(^|/)(falco24-learning-centers|baroque|baroque-ui|aero-legacy|legacy|old-style|styles|style|app|main)\.css$|FALCO[ _-]?(24|25)[ _-]?(UI|DESIGN)|BAROQUE[ _-]?(UI|STYLE)|NEO[ _-]?AERO[ _-]?LEGACY'
report="$QUARANTINE/cleanup-$(date +%Y%m%d-%H%M%S).log"
: > "$report"
while IFS= read -r -d '' file; do
  rel="${file#"$TARGET"/}"
  [ "$rel" = "falco-jugger-ui.css" ] && continue
  if [[ "$rel" =~ \.css$ ]] && { [[ "$rel" =~ $patterns ]] || grep -Eiq "$patterns" "$file" 2>/dev/null; }; then
    dest="$QUARANTINE/$rel"; mkdir -p "$(dirname "$dest")"; mv -- "$file" "$dest"; printf 'QUARANTINED %s\n' "$rel" >> "$report"
  else
    printf 'KEPT %s\n' "$rel" >> "$report"
  fi
done < <(find "$TARGET" -path "$QUARANTINE" -prune -o -type f -name '*.css' -print0)
printf 'Active stylesheet: %s/falco-jugger-ui.css\n' "$TARGET" >> "$report"
printf 'Cleanup report: %s\n' "$report"
