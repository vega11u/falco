# REG.RU Host-0 and media-import research (2026-11-03)

## Host-0 facts from REG.RU documentation

The 2026 tariff appendix lists Host-0 with 13 GB for site/mail files, 13 GB for databases, SSH, CGI scripts and CRON; the average daily CPU load allowance is 5.5%. REG.RU's current tariff comparison lists 36 maximum processes, 4 simultaneous PHP FastCGI processes and up to 1 GB allocated memory per process for the Host line. Python 2.7–3.14 is listed as available on non-Lite shared-hosting plans. The user's observed interpreter is Python 3.8.6.

These features allow lightweight Python CLI tasks without root. They do not make Host-0 a suitable ML inference server: its CPU allowance is shared and low, and the process memory ceiling is not a dedicated 1 GB reservation. Heavy inference can also contend with the web app and cause timeouts/throttling.

## Sports2D suitability

Current Sports2D requires Python >=3.11, so the observed Python 3.8.6 cannot run the current release. Sports2D supports body-with-feet models and 2D joint-angle output, but its README warns that accuracy depends on the pose model and that valid results require movement approximately parallel to the camera plane. It is a useful offline/reference pipeline, not a drop-in server backend for this account. Installing a second Python interpreter in the user home would not remove the CPU and shared-process constraints. Do not attempt to install Sports2D/OpenSim into the Host-0 production site.

## Video-download alternatives evaluated

- `yt-dlp`: actively maintained and currently the broadest extractor framework. YouTube extraction is complicated by per-client SABR and PO Token enforcement. The official guide recommends a PO Token provider for the `mweb` client; token requirements can vary by client and video. A Deno runtime alone does not create a valid PO Token.
- `lux`: independent Go downloader with YouTube and Instagram extractors, and a standalone Linux binary. However, its latest published release found in this review is v0.24.1 from 2024-05-06. It is too stale to be trusted as the main 2026 fallback for a service whose extractors are changing frequently. It was not added to production.
- Cobalt: supports YouTube and Instagram, but the project's API README says there is no public pre-hosted API and recommends self-hosting; the recommended setup uses Docker Compose and the server is built with Express. That is not compatible with this Host-0 PHP shared-hosting deployment. Arbitrary public Cobalt instances are not a dependable or privacy-safe backend.
- `bgutil-ytdlp-pot-provider`: technically addresses PO Tokens, but its maintained provider needs Node >=22 or Deno >=2 plus a provider server or per-download generation script. The Deno/npm cache previously exhausted memory on this account; installing another resident provider would be an unjustified risk on Host-0.

## Implemented choice

Keep yt-dlp as the maintained extractor, but use separate YouTube delivery-client profiles after the default profile: `web_safari` for HLS, `android_vr` for an alternate Innertube delivery path, and `web_embedded` for videos that permit embedding. This improves coverage without multiplying stale downloader binaries. It cannot guarantee access to videos blocked by IP reputation, private/age restrictions, authentication or unavailable PO Tokens. If all profiles fail, the app must return the actual extractor diagnosis instead of claiming the host can bypass YouTube controls.

## Sources

- REG.RU tariff appendix effective 2026-01-01: https://img.reg.ru/faq/prilozhenie_tarify_na_uslugi_hostinga_010126.pdf
- REG.RU shared-hosting comparison: https://www.reg.ru/hosting/reliable
- REG.RU SSH help: https://help.reg.ru/support/hosting/dostupy-i-podklyucheniye-panel-upravleniya-ftp-ssh/rabota-po-ssh-na-virtualnom-hostinge
- Sports2D requirements and documentation: https://github.com/davidpagnon/Sports2D and https://github.com/davidpagnon/Sports2D/blob/main/pyproject.toml
- yt-dlp PO Token guide: https://github.com/yt-dlp/yt-dlp/wiki/PO-Token-Guide
- yt-dlp EJS guide: https://github.com/yt-dlp/yt-dlp/wiki/EJS
- lux releases: https://github.com/iawia002/lux/releases
- Cobalt API: https://github.com/imputnet/cobalt/tree/main/api
- bgutil provider: https://github.com/Brainicism/bgutil-ytdlp-pot-provider
