/** Monteverdi: human-reviewed temporal kime calibration.
 * Legacy yes/no means agree/disagree with the predicted class (v1).
 * New fast_kime/fast_no_kime are ground truth; not_fast is for motion detection
 * only and MUST NEVER be treated as a failed kime.
 */
export const MONTEVERDI_LEARNING_VERSION='monteverdi-reviewed-kime-calibration-v2';
const valid=Number.isFinite;
const keyOf=r=>String(r.source_report??'')+'|'+String(r.event_id??'')+'|'+String(r.time_s??'');
export function fitMonteverdiThreshold(rows,{baselineMs=180,minLabels=12}={}){
 const latest=new Map();
 for(const r of rows||[]){
  if(!['yes','no','uncertain','fast_kime','fast_no_kime','not_fast'].includes(r?.choice))continue;
  const key=keyOf(r); latest.set(key,r); // later correction supersedes old label
 }
 const items=[];
 for(const [key,r] of latest){
  if(r.choice==='not_fast'||r.choice==='uncertain')continue;
  const spread=Number(r.spread_ms);
  if(!valid(spread)||spread<0||spread>2000)continue;
  let truth=null;
  if(r.choice==='fast_kime')truth='yes';
  else if(r.choice==='fast_no_kime')truth='no';
  else if(['yes','no'].includes(r.prediction))truth=(r.choice==='yes'?r.prediction:(r.prediction==='yes'?'no':'yes'));
  if(truth)items.push({spread,truth,key});
 }
 const positives=items.filter(q=>q.truth==='yes').length,negatives=items.length-positives;
 const fallback={schema:MONTEVERDI_LEARNING_VERSION,active:false,threshold_ms:baselineMs,reviewed:items.length,positives,negatives,reason:'Insufficient balanced fast-kime labels'};
 if(items.length<minLabels||positives<4||negatives<4)return fallback;
 const sorted=[...items].sort((a,b)=>a.key.localeCompare(b.key));
 const train=sorted.filter((_,i)=>i%5!==0),held=sorted.filter((_,i)=>i%5===0);
 const score=(xs,t)=>xs.reduce((sum,p)=>sum+(p.truth===(p.spread<=t?'yes':'no')?1:0),0)/Math.max(1,xs.length);
 const candidates=Array.from({length:41},(_,i)=>60+i*7);
 let best=baselineMs,bestS=score(train,best)-Math.abs(best-baselineMs)*.0003;
 for(const threshold of candidates){const value=score(train,threshold)-Math.abs(threshold-baselineMs)*.0003;if(value>bestS+.00001){best=threshold;bestS=value;}}
 const baseHeld=score(held,baselineMs),candidateHeld=score(held,best);
 const verified=held.length>=2&&candidateHeld>=baseHeld;
 return {...fallback,active:verified,threshold_ms:verified?best:baselineMs,candidate_threshold_ms:best,baseline_ms:baselineMs,train_accuracy:score(train,best),holdout_accuracy:candidateHeld,baseline_holdout_accuracy:baseHeld,reason:verified?'Kime threshold validated on held-out labelled fast events':'Insufficient holdout accuracy; baseline retained',measurement:'video-derived terminal-timing spread only'};
}
