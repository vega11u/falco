<?php
declare(strict_types=1);

/**
 * Purcell training workspace.
 * Reuses the exact same analyzer page, media pipeline, 2D avatar, metrics and APIs.
 * The mode constant changes only the purpose-specific interface and save workflow.
 */
define('FALCO_PURCELL_MODE', true);
require __DIR__ . '/index.php';
