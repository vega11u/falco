# Falco 24.3.0 — Precision Lab Interface

## Interface architecture
- One active interface stylesheet and one interface controller for the analyzer.
- The top bar contains the brand once; the left rail is navigation only.
- Desktop workspace: analysis stream on the left, sticky video/player tools on the right.
- Mobile workspace: upload, player, then analysis stream in normal document flow.
- The document owns vertical scrolling; rail, player and analysis stream do not scroll independently.
- Lully, Purcell, reports and models share the same 60/30/10 visual language.

## Player
- Primary controls: previous frame, play/pause, next frame and playback speed.
- Timeline seek and timecode are a single row.
- Continue/restart, 3D, screenshots and zoom are grouped in one collapsed tools section.
- The original clip workspace and range editor live together beside the source video.
- Current-frame metrics are in a separate disclosure.
- Existing player IDs, original video element and event handlers are preserved.

## Design
- 60% graphite-blue base, 30% ocean-teal surfaces, 10% mint-cyan accent.
- Times New Roman for interface copy; Consolas for timecodes and technical values.
- GitHub interaction references: `shadcndashboard`, `elahlabs/elah`, `ezeoleaf/opengait`, `yannamsellem/framecraft`.
- No new front-end framework, CDN, external font or runtime dependency.

## Compatibility
- Core remains 23.0.27.
- PHP APIs, workers, inference, biomechanics, Lully/Purcell storage, model archives and report schemas are unchanged.
- Lully and Purcell remain standalone library pages without analyzer iframe embedding.
- No training data, model payloads, uploaded videos or report data are included in the update patch.

## Verification
- `bash tests/verify.sh` — PASS.
- Focused UI, workspace integration, Learning Centers and security smoke tests — PASS.
- Browser screenshot acceptance could not be completed in the build environment; final staging visual review with a real video remains necessary.
