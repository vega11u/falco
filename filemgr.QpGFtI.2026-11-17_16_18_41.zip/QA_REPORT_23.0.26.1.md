# QA — Falco Jugger 23.0.26.1 port

Baseline: exact 23.0.26 files constructed from the user's 23.0.24 + 23.0.25 GLOBAL_EVOLUTION + 23.0.26 UI_SILHOUETTE ZIPs.

Unit tests: `tests/monteverdi-triclass.test.mjs`, `tests/personal-model-3d-archive.test.mjs`, `tests/port-23.0.26.1-integrity.test.mjs`, v23.0.26 mask and score tests.
PHP server integration: POST a `not_fast` sample with motion features, GET after POST; verified same record and numeric features round-trip.
Syntax: PHP lint for index/models/Memories; Node check for all patched MJS; Node check of PHP-rendered inline module.
Installer: checks source version 23.0.26 and SHA256 of 10 relevant files and self-checks patch SHA256; staged in-place replacement with rollback. Preserve private training and report test sentinels.


Legacy test exception: `tests/vivaldi-fine-mesh-23.0.25.mjs` expects a fake 2D surface to render WITHOUT a measured silhouette, which is deliberately forbidden since v23.0.26. That legacy expectation fails at line 24; the v23.0.26 silhouette test passes and verifies the new safety policy. This patch does not revert the stricter v23.0.26 policy.

Not tested: real browser GPU video, real athlete evaluation, quantitative mesh accuracy.
