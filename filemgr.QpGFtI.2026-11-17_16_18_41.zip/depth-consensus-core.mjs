/** Relative-depth consensus. No monocular metric-scale claims. Pure, testable arithmetic. */
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const finite=Number.isFinite;
export function athleteRegion(points,{margin=.12}={}){
  const xs=[],ys=[];
  for(const p of Array.isArray(points)?points:[]){if(!Array.isArray(p)||!finite(p[0])||!finite(p[1])||(p[3]??1)<.28||p[0]<0||p[0]>1||p[1]<0||p[1]>1)continue;xs.push(p[0]);ys.push(p[1]);}
  if(xs.length<8)return null;
  const x0=clamp(Math.min(...xs)-margin),y0=clamp(Math.min(...ys)-margin),x1=clamp(Math.max(...xs)+margin),y1=clamp(Math.max(...ys)+margin);
  if(x1-x0<.14||y1-y0<.16)return null;
  return {x:x0,y:y0,w:x1-x0,h:y1-y0};
}
export function sampleGrid(grid,x,y){
 if(!grid?.values||!(grid.width>1&&grid.height>1)||x<0||y<0||x>1||y>1)return NaN;
 const fx=x*(grid.width-1),fy=y*(grid.height-1),x0=Math.floor(fx),y0=Math.floor(fy),x1=Math.min(grid.width-1,x0+1),y1=Math.min(grid.height-1,y0+1),u=fx-x0,v=fy-y0;
 const a=grid.values[y0*grid.width+x0],b=grid.values[y0*grid.width+x1],c=grid.values[y1*grid.width+x0],d=grid.values[y1*grid.width+x1];
 return [a,b,c,d].every(finite)?a*(1-u)*(1-v)+b*u*(1-v)+c*(1-u)*v+d*u*v:NaN;
}
function sortMedian(a){a.sort((x,y)=>x-y);return a.length%2?a[(a.length-1)/2]:(a[a.length/2-1]+a[a.length/2])/2;}
/** Robust affine alignment for cross-model relative-depth values.
 * Both correlated and inverse-correlated orientation supported; no absolute metres. */
export function alignDepthToAnchor(anchor,other,{region=null}={}){
 if(!anchor?.values||!other?.values)throw Error('Missing depth map');
 const pairs=[];
 for(let y=0;y<anchor.height;y+=Math.max(1,Math.floor(anchor.height/24)))for(let x=0;x<anchor.width;x+=Math.max(1,Math.floor(anchor.width/30))){
  const u=x/(anchor.width-1),v=y/(anchor.height-1);
  if(region&&(u<region.x||v<region.y||u>region.x+region.w||v>region.y+region.h))continue;
  const a=anchor.values[y*anchor.width+x],b=sampleGrid(other,(u-(other.region?.x||0))/(other.region?.w||1),(v-(other.region?.y||0))/(other.region?.h||1));
  if(finite(a)&&finite(b))pairs.push([a,b]);
 }
 if(pairs.length<32)return {scale:1,shift:0,correlation:0,valid:false};
 let ma=0,mb=0;for(const [a,b] of pairs){ma+=a;mb+=b;}ma/=pairs.length;mb/=pairs.length;
 let cov=0,vb=0,va=0;for(const [a,b] of pairs){cov+=(a-ma)*(b-mb);vb+=(b-mb)**2;va+=(a-ma)**2;}
 const r=vb>1e-6&&va>1e-6?cov/Math.sqrt(va*vb):0;
 if(Math.abs(r)<.18)return {scale:1,shift:0,correlation:r,valid:false};
 const slope=clamp(cov/Math.max(vb,1e-6),-3.3,3.3);
 return {scale:slope,shift:ma-slope*mb,correlation:r,valid:true};
}
/** Grid fusion supports crop-only athlete evidence. Robust against model disagreement.
 * Maps have all been normalized to 0..1. Does not generate metric 3D geometry. */
export function fuseConsensusMaps(anchor,evidence,{athlete=null}={}){
 if(!anchor?.values||anchor.width<2||anchor.height<2)throw Error('Base map missing');
 const values=new Float32Array(anchor.values.length),agreement_values=new Float32Array(anchor.values.length);
 const aligned=[];
 for(const e of evidence||[]){if(!e?.map?.values)continue;const fit=alignDepthToAnchor(anchor,e.map,{region:e.region||null});if(!fit.valid)continue;
   aligned.push({...e,fit,weight:clamp(Number(e.weight)||.2,.05,.6)});
 }
 let disagreements=0;
 for(let y=0;y<anchor.height;y++)for(let x=0;x<anchor.width;x++){
  const k=y*anchor.width+x,u=x/(anchor.width-1),v=y/(anchor.height-1),base=anchor.values[k],votes=[{value:base,weight:.52}];
  for(const e of aligned){const reg=e.region;if(reg&&(u<reg.x||v<reg.y||u>reg.x+reg.w||v>reg.y+reg.h))continue;
   let w=e.weight;if(athlete){const inside=u>=athlete.x&&u<=athlete.x+athlete.w&&v>=athlete.y&&v<=athlete.y+athlete.h;w*=e.scope==='athlete'?(inside?1.4:.05):(inside?.9:1.1);}
   const raw=sampleGrid(e.map,reg?(u-reg.x)/reg.w:u,reg?(v-reg.y)/reg.h:v);if(!finite(raw))continue;
   const estimate=clamp(e.fit.scale*raw+e.fit.shift);votes.push({value:estimate,weight:w});
  }
  // Weighted median protects the anchor against a majority of weak, correlated
  // auxiliary models. Global model agreement alone cannot validate a joint.
  const ordered=[...votes].sort((a,b)=>a.value-b.value);const totalWeight=ordered.reduce((s,q)=>s+q.weight,0);
  let running=0,median=base;
  for(const q of ordered){running+=q.weight;if(running>=totalWeight*.5){median=q.value;break;}}
  const mad=sortMedian(votes.map(o=>Math.abs(o.value-median)));
  let sum=0,weight=0;
  for(const item of votes){const d=Math.abs(item.value-median),robust= d<=.10+mad*2?1:.20;sum+=item.value*item.weight*robust;weight+=item.weight*robust;}
  const proposal=clamp(weight?sum/weight:base);
  // At depth boundaries, a divergent vote can be a foreground/background swap.
  // Retain the anchor unless at least two independent models agree locally.
  const supporting=votes.slice(1).filter(q=>Math.abs(q.value-median)<.075).length;
  values[k]=supporting>=2?proposal:clamp(base*.78+proposal*.22);
  // Conservative: agreement is low with only one vote, not falsely 100%.
  const agreement=votes.length>1?clamp((1-mad*3-(Math.max(...votes.map(q=>q.value))-Math.min(...votes.map(q=>q.value)))*.65)*(supporting>=1?1:.65)):.25;
  agreement_values[k]=agreement;disagreements+=agreement;
 }
 return {values,agreement_values,width:anchor.width,height:anchor.height,agreement:disagreements/values.length,contributors:['base',...aligned.map(e=>e.name)],coverage:aligned.length,partial:aligned.length<2};
}
export function consensusBudget({memoryGiB=null,cores=2,backend='wasm'}={}){
 const low=memoryGiB!==null&&memoryGiB<=4;
 return {serial:true,max_loaded:low?1:(memoryGiB!==null&&memoryGiB>=8?3:2),alt_every:low?6:3,max_frame_edge:backend==='webgpu'?518:384,
  depth_min_interval_s:low?3.5:backend==='webgpu'?1.6:2.7,
  allow_alt:!low&&(memoryGiB!==null||backend==='webgpu'),allow_athlete:!low,parallel_models:0};
}
