/** Vivaldi/Bach multipass temporal fitting. Deterministic, conservative image-/world-space
 * optimization; never presents inferred 3D as calibrated measurements. 2026-11-13.
 * Identity is fixed across frames. Observations remain immutable in frame.im / frame.w.
 */
import {selectVivaldiAnchors,fitVivaldiIdentity} from './vivaldi-athlete-lattice.mjs';
import {bachAtlasFrame} from './bach-coordinate-atlas.mjs';
export const VIVALDI_MULTIPASS_VERSION='vivaldi-multipass-v2';
const BONES=[[11,13],[13,15],[12,14],[14,16],[23,25],[25,27],[24,26],[26,28],[11,23],[12,24],[11,12],[23,24]];
const finite=Number.isFinite;
const valid=(p,d,c=.16)=>Array.isArray(p)&&p.length>=d&&p.slice(0,d).every(finite)&&(p[3]??1)>=c;
const norm=(a,b,d)=>Math.hypot(...Array.from({length:d},(_,k)=>a[k]-b[k]));
const median=a=>{const v=a.filter(finite).sort((x,y)=>x-y);return v.length?v[Math.floor(v.length/2)]:null;};
const clip=(x,a,b)=>Math.max(a,Math.min(b,x));
const clone=a=>Array.isArray(a)?a.map(p=>Array.isArray(p)?p.slice():null):[];
function segments(frames){const out=[];let first=0;for(let i=1;i<=frames.length;i++)if(i===frames.length||(frames[i].camera_segment_id??0)!==(frames[first].camera_segment_id??0)||!finite(frames[i].t)||frames[i].t-frames[i-1].t>.6||frames[i].t<=frames[i-1].t){out.push([first,i]);first=i;}return out;}
function motion(a,b,c,d){const A=valid(a,d),B=valid(b,d),C=valid(c,d);return A&&B&&C?norm(a,c,d):null;}
function robustRefine(out,range,space,dim,metrics){
 const [first,end]=range;
 // Forward and backward low-confidence outlier correction, never interpolate across shot boundaries.
 for(let j=0;j<33;j++)for(let k=first+1;k<end-1;k++){
  const prev=out[k-1][space][j],cur=out[k][space][j],next=out[k+1][space][j];
  if(!valid(prev,dim,.32)||!valid(next,dim,.32))continue;
  const dt=out[k+1].t-out[k-1].t;
  if(!(dt>0&&dt<=.18))continue;
  const ratio=(out[k].t-out[k-1].t)/dt;
  const predicted=Array.from({length:dim},(_,a)=>prev[a]*(1-ratio)+next[a]*ratio);
  const travel=norm(prev,next,dim),threshold=dim===2?.023:.028;
  if(travel>threshold*2.3)continue; // fast motion stays untouched
  const confidence=valid(cur,dim,.01)?clip(cur[3]??0,0,1):0;
  if(confidence>.75)continue;
  const deviation=valid(cur,dim,.01)?Math.hypot(...predicted.map((v,a)=>v-cur[a])):Infinity;
  if(deviation<=threshold*.3)continue;
  if(deviation<threshold*1.2&&confidence>.4)continue;
  if(deviation>threshold*20&&confidence>.5)continue;
  const q=(confidence>=.35)? .36:.85;
  const update=valid(cur,dim,.01)?cur.slice():Array(dim+1).fill(0);
  for(let a=0;a<dim;a++)update[a]=finite(cur?.[a])?(1-q)*cur[a]+q*predicted[a]:predicted[a];
  update[3]=Math.min(.55,Math.min(prev[3]??1,next[3]??1)*.75);
  out[k][space][j]=update;metrics.temporal_repairs++;
 }
}
function constrainBones(out,range,identity,stats){
 const [first,end]=range;
 for(let i=first;i<end;i++){
  const frame=out[i],world=frame.render_w;
  if(!Array.isArray(world))continue;
  for(let pass=0;pass<3;pass++)for(const [a,b] of BONES){
   const goal=identity?.segment_lengths?.[`${a}-${b}`];
   if(!(goal>.015))continue;
   const A=world[a],B=world[b];if(!valid(A,3,.18)||!valid(B,3,.18))continue;
   const measured=norm(A,B,3),diff=measured-goal;
   if(measured<.005||Math.abs(diff)<Math.max(.008,goal*.045))continue;
   const ca=clip(A[3]??.3,0,1),cb=clip(B[3]??.3,0,1);
   // Low-confidence evidence may move; high confidence anchors are protected.
   const mobilityA=Math.pow(1-ca,2)+.005,mobilityB=Math.pow(1-cb,2)+.005;
   const delta=clip(diff*.38,-.020,.020),den=mobilityA+mobilityB;
   for(let axis=0;axis<3;axis++){
    const u=(B[axis]-A[axis])/measured;
    A[axis]+=delta*u*mobilityA/den;
    B[axis]-=delta*u*mobilityB/den;
   }
   stats.bone_refinements++;
  }
 }
}
function jitter(out,space,dim){let sum=0,n=0;
 for(const [first,end] of segments(out))for(let i=first+1;i<end-1;i++){
  const dt1=out[i].t-out[i-1].t,dt2=out[i+1].t-out[i].t;
  if(!(dt1>.0001&&dt2>.0001&&dt1<.2&&dt2<.2))continue;
  for(const j of [11,12,13,14,15,16,23,24,25,26,27,28]){
   const a=out[i-1][space]?.[j],b=out[i][space]?.[j],c=out[i+1][space]?.[j];
   if(!valid(a,dim,.4)||!valid(b,dim,.4)||!valid(c,dim,.4))continue;
   const v1=Array.from({length:dim},(_,k)=>(b[k]-a[k])/dt1),v2=Array.from({length:dim},(_,k)=>(c[k]-b[k])/dt2);
   const accel=Math.hypot(...v1.map((x,k)=>(v2[k]-x)/((dt1+dt2)/2)));
   if(finite(accel)){sum+=accel;n++;}
  }
 }
 return n?sum/n:null;
}
/** Multi-stage offline identity fitting. O(N) memory for pose transforms, never allocates
 * 2k/8k mesh vertices for every frame. Fine geometry is instantiated on-demand by renderer.
 */
export function vivaldiMultipass(frames,{maxAnchors=30,onStage=()=>{},profile=null}={}){
 if(!Array.isArray(frames)||!frames.length)return {frames:[],identity:null,metrics:{error:'empty'}};
 const original=frames.map(f=>({...f,render_im:clone(f.render_im||f.im),render_w:clone(f.render_w||f.w)}));
 const stages=[];const report=(name,data={})=>{stages.push({stage:name,...data});onStage(name,data);};
 const atlas=bachAtlasFrame(original[0]);report('Bach · coordinate atlas',{space:atlas.space,scene_calibrated:false});
 const anchors=selectVivaldiAnchors(original,{max:maxAnchors});report('Vivaldi · anchor selection',{selected:anchors.length,total:frames.length});
 const identity=fitVivaldiIdentity(original,{anchors,profile});report('Vivaldi · fixed athlete identity',{confidence:identity.confidence,segments:Object.keys(identity.segment_lengths||{}).length});
 const stats={temporal_repairs:0,bone_refinements:0,jitter_before:jitter(original,'render_im',2)};
 const shots=segments(original);
 for(const s of shots){robustRefine(original,s,'render_im',2,stats);robustRefine(original,s,'render_w',3,stats);}
 report('Vivaldi · temporal observation refinement',{repairs:stats.temporal_repairs,camera_segments:shots.length});
 for(const s of shots)constrainBones(original,s,identity,stats);
 report('Bach · segment geometry constraints',{corrections:stats.bone_refinements});
 stats.jitter_after=jitter(original,'render_im',2);
 const metrics={...stats,stages,anchors:anchors.length,world_coordinates_metric:false,mesh_resolution:'on-demand',fine_target_vertices:8192,standard_target_vertices:2048,actual_mesh_vertices_generated:0,neural_fitting:'not installed',limitations:['3D absolute dimensions unknown without calibrated camera','Missing occluded body surfaces are estimates, not unique measurements','Normalized image joint jitter is not a direct measure of perceptual surface fidelity']};
 report('Vivaldi · quality audit',{jitter_before:stats.jitter_before,jitter_after:stats.jitter_after});
 return {frames:original,identity,metrics};
}
