# QA report — Falco Jugger 22.0.0

## Checks executed in the project workspace

The complete `bash tests/verify.sh` developer release suite passed after the v22 changes.

| Check | Result |
|---|---|
| PHP syntax: `index.php`, `uppurcell.php`, `Memories.php`, `server-learning.php` | PASS |
| JavaScript syntax: rendered main module and `purcell-core.mjs` | PASS |
| `tests/release-smoke.php` | PASS |
| `tests/optimizer-smoke.sh` | PASS |
| `tests/server-report-library-smoke.sh` (legacy report API and owner isolation) | PASS |
| `tests/purcell-core-smoke.mjs` | PASS |
| `tests/purcell-and-report-api-smoke.sh` | PASS |
| `tests/v22-smoke.sh` | PASS |
| Existing biomechanics, player zoom and recognition smoke tests | PASS |

## What the new integration test verifies

- Purcell stores a 384D feature vector in its own private library, not in Lully.
- Purcell feedback votes are accepted and stored.
- Pattern-review feedback stores both decisions and quantized 384D signatures,
  so later pattern discovery can use cross-session positive and negative memory.
- Repeating the same Lully example upload stores zero duplicate rows.
- The classifier source hash matches the canonical classifier-relevant projection of confirmed examples.
- A second `model-sync` call is idempotent.
- Multi-part report upload (more than one 2 MiB chunk) verifies gzip integrity,
  SHA-256 and uncompressed size; a retried chunk is acknowledged idempotently.
  The report appears in the owner's library, is isolated from a second owner,
  restores through streamed JSON and deletes without changing Lully's files.
- Legacy report listing extracts metadata from a bounded gzip stream; the old
  whole-report PHP decode is no longer required merely to display the library.

The optional detached CRON integration (`RUN_CRON_INTEGRATION=1`) was not run;
these features do not require a new cron job or worker.

## Important limitation of this QA

The archive was tested locally with PHP's built-in server and a temporary
private storage directory. A live REG.RU Host-0 account was not available in
this workspace, so actual provider-specific `post_max_size`, disk quota,
filesystem permissions and browser-to-host latency still need a post-upload
smoke test. The new report path uses 2 MiB chunks and streamed PHP I/O to avoid
the old whole-report `json_decode` memory peak.
