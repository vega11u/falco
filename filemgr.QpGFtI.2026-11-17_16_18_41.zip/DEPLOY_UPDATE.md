# Update to Falco Jugger v21.12.0

1. Back up the site and all private directories: `.kata-biomechanics-*`, `.kata-reports-*`, `.kata-media-import-*`.
2. Upload the ZIP contents over the current v21.11.0 application and overwrite matching application files. Do not use mirror-delete/synchronization that removes server-only files.
3. Do not delete or replace `data/`, `data/trained/`, `vendor/`, `library.json`, `classifier-model.json`, any trained weights, or private `.kata-*` directories.
4. Run `bash setup-release.sh`.
5. Check `index.php?api=health`, then open `Memories.php` and test report listing.
6. For reports up to 120 MB, configure the reverse proxy/web server request limit to at least 128 MB and PHP `memory_limit` to at least 768 MB. The PHP endpoint raises its own execution/memory allowance where hosting permits; it cannot override a stricter proxy or hosting hard cap.
7. Keep one canonical site origin (same scheme and host, including www/non-www) so the durable report-owner cookie resolves to the same personal library.

The new user taxonomy overlay `taxonomy-custom.json` is written inside the private learning directory. It is additive and is not part of the release ZIP. Model feature dimensions and stored learning data are unchanged.
