# QA Report — Falco Jugger 27.2.2-C.D2

## Исходник
Проверен предоставленный ZIP `filemgr.8DODxS.2026-11-16_23_56_46.zip` (724 entries, ZIP CRC test passed). Базовая версия `VERSION=23.0.27`, release marker `27.2.1-C.D2`.

## Найдено в исходнике
- В активном webroot был один CSS-файл `falco-jugger-ui.css`, но внутри него сохранялись append-only блоки 26.1/26.2.2/26.2.3/26.3 и финальный D2 override.
- В таблице было 674 qualified CSS rules; 45 CSS-only class names не имели ссылок в runtime source corpus. Дополнительно `replay-visual` использовался только в устаревшем тестовом отрицательном assertion, но не в runtime.
- 97 статических inline-style атрибутов находились в index.php (87), models.php (7), purcell-lab.php (3).
- В models.php были 10 статических JS style assignments; в index.php — статическое назначение cursor и 4 цвета server-dot; в Memories.php — ещё 2 статических цвета server-dot.
- 4 динамических style-атрибута в index.php задавали вычисляемую геометрию progress/timeline и должны остаться динамическими.
- 21 путь из исторического GC allowlist отсутствовал в live-root. `hard-update-v23.0.19.js`, `falco24-learning-centers.js` и `falco-jugger-ui.js` имеют реальные ссылки и сохранены.

## Изменения
- Удалены 46 runtime-unreferenced CSS class selector names/branches, включая связанные правила для старых UI компонентов.
- Удалены 30 вручную проверенных superseded D2 declarations и 18 точных дубликатов. Fallback-пары с разными значениями сохранены.
- Удалены 7 полностью устаревших CSS rules (6 при pruning orphan-селекторов и отдельный `replay-visual`).
- Статические inline styles переведены в классы единого CSS; 4 динамических inline style атрибута оставлены по назначению.
- 17 статических JS style assignments переведены на классы/состояния.
- Обновлены stylesheet/UI-script cache keys на пяти основных страницах до `27.2.2-C.D2`.
- GC исправлен для реальных переносов строк; allowlist-only quarantine вне webroot сохранён.
- Добавлен read-only UI cleanup audit.

## Локальные проверки
- ZIP integrity: PASS.
- PHP lint для всех 48 PHP-файлов проекта: PASS.
- PHP regression test `ui-cleanup-27.2.2.php`: PASS.
- Read-only cleanup audit: PASS (1 active CSS, 5 stylesheet refs, 0 static inline styles, 4 dynamic inline styles, 0 inline style blocks in runtime pages, 0 @import, balanced braces).
- CSS parser (tinycss2): PASS, no parse errors.
- Все 14 inline script blocks пяти основных страниц прошли Node 22 `--check`; единственный PHP-generated CSRF literal в главном module script заменялся на нейтральный placeholder только в синтаксической проверке.
- GC `--apply` на изолированной полной копии проекта: PASS; 21 отсутствующая allowlist-запись, 0 файлов перемещено, audit PASS, переносы строк корректные.
- Установщик `--dry-run` на исходном архиве: PASS; тестовая установка на отдельную копию: PASS; 568 файлов вне allowlist не изменились.
- `models.php`: 0 inline style attributes and 0 `.style.*` assignments; `Memories.php`: server-dot states are class-driven.
- Regression checks `release-smoke.php`, `falco24-learning-centers-smoke.php` and `motion-studio-v23.0.27.mjs`: PASS.
- `purcell-lab.php`: 0 inline style attributes.
- `index.php`: 0 static inline style attributes; 4 dynamic computed geometry/progress style attributes intentionally retained.


## Исторические тесты исходного проекта
Несколько старых smoke-тестов не соответствуют уже установленной до этого патча компоновке 27.2.1: `falco24-ui-smoke.php`, `falco24-clean-ui-smoke.php`, `falco26-handler-recovery-smoke.php`, `falco-flightdeck-2621-smoke.php` и `falco-flightdeck-2622-smoke.php` ожидают CSS-контракт 26.x (фиксированный Flight Deck, старые grid/scroll-root правила). Те же проверки были воспроизведены на исходном архиве 27.2.1 с приведёнными cache-key литералами и дали те же ошибки. Они не использовались как критерий приёмки cleanup-патча и требуют отдельной актуализации под фактический D2 layout.
`port-23.0.26.1-integrity.test.mjs` и `aero-studio-contract-23-0-15.mjs` также содержат устаревшие требования к import/cache keys и старым helper API; это не изменения текущего cleanup-релиза.

## Безопасность миграции
- No analysis/worker/model JS module was deleted.
- No business event handler was removed.
- No training data, Lully/Purcell memory, reports, user settings, private configuration, model cache, media, `.falco-rollback` or backup files were changed.
- GC only moves an explicitly allowlisted regular file when it exists and has no live code reference; it never removes inline PHP/JS code.

## Ограничения
- Browser visual QA on the user's Host-0 device is not performed by this package build.
- The patch does not alter analysis/reconstruction algorithms or claim improved 3D accuracy.
