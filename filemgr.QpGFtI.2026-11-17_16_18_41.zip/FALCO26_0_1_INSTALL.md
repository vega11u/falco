# Falco Jugger 26.0.1 — installation

Upload `Falco_Jugger_26.0.1_Handler_Recovery.zip` to `~/www/falcojugger.art/` after installing Falco 26.0.0.

### One-line SSH command

```bash
cd "$HOME/www/falcojugger.art" && t="$(mktemp -d)" && (trap 'rm -rf "$t"' EXIT; unzip -q Falco_Jugger_26.0.1_Handler_Recovery.zip -d "$t" && bash "$t/install-falco26.0.1.sh" --source "$t" --target "$PWD")
```

Requirements: Bash, PHP CLI >=8.1, `unzip`, `tar`, `sha256sum`. Node.js/npm/npx are not required on the host.

If the installed UI is still 25.0.0 or 24.3.0, install 26.0.0 first; this small recovery package **does not** migrate older styles. Installer refuses any other base or multiple root CSS files.

After install use HARD UPDATE or Ctrl+Shift+R. The new JS URI carries `?v=26.0.1`. If PHP OPcache retains the old server HTML, wait for the host's OPcache invalidation or refresh it via the site's supported deployment procedure; do not delete trained data, reports or vendor.

A timestamped backup of all overwritten files is kept inside `~/www/falcojugger.art/.falco-rollback/`. Upon failure during installation the script automatically restores the previous files.

### Verification

After success inspect `index.php` (analyzer) and `uppurcell.php` (Purcell mode). Check choosing a local video, trim editor, 2D player, start analysis, journal, saving a report and both themes. Confirm the right player remains pinned on desktop. Browser/server permission problems unrelated to this patch will still be reported by the existing logging system.

### Manual rollback

When the installed script prints `Rollback: /absolute/path/....tar.gz`, you may restore that code snapshot *after* stopping ongoing operations:

```bash
cd "$HOME/www/falcojugger.art" && tar -xzf '/absolute/path/printed/at/install.tar.gz' -C "$PWD"
```

This restores overwritten code. New release-only files can remain; no trained data has been modified by the patch.
