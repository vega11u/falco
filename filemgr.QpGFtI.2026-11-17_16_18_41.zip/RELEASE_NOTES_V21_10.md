# Falco Jugger v21.10.0 — release notes

## User-facing changes

1. **Optimizer panel:** corrected the CSS layout so the title, scorecard grid and explanation stack vertically; scorecards remain responsive.
2. **Optimization suggestions:** each recommendation with a valid event time includes a source-video still with highlighted body regions and a side projection based on available MediaPipe world landmarks / relative depth. The side projection is explicitly marked as an estimate. If depth coverage/spread is insufficient, the panel says so instead of drawing a misleading synthetic side view.
3. **Timecodes:** metric/depth/scene/biomechanics/pattern time links now scroll to the synchronized analysis dock and seek the source video and pose/avatar render together.
4. **Pattern reconsideration:** the “Подумать ещё” loop stores the current draft name/type plus yes/no judgments and uses overlap/signature matching to inform the next detection/grouping pass. It can be repeated without a fixed pass limit. “Hint”/edited labels do not enter the training corpus; only the existing explicit confirm-and-save path does.
5. **Player zoom:** synchronized video+overlay zoom from 1× to 4×, slider and buttons, drag-to-pan, pinch-to-zoom, Ctrl/Cmd+wheel and double-click toggle. Pointer Events/CSS transform approach is inspired by the public Panzoom interaction model, but implemented locally without a shipped external dependency.
6. **Biomechanics knowledge:** new additive concepts and decision guardrails for coil/counter-rotation, proximal-distal segment timing, pull–push/hikite, knee-drive/chamber, support-foot tripod, braking/recoil and fascia-chain context. Recommendations disclose the knowledge concepts/evidence level used. The biomechanical plan now runs before kinematic refinement; measured phase peaks (pelvis, thorax, wrists, hips, knees, feet), transition timings and recommendation timestamps are added to optimizer event anchors so denoising cannot erase observed phase timing.

## Compatibility and retained data

- `VERSION`: 21.10.0.
- Existing anatomy schema remains `karate-functional-anatomy-v1`; 24 muscle groups and all previous fascia-chain records remain in place. The 7 movement concepts and 7 optimizer decision rules are additive JSON fields.
- Existing persistent learning feature contracts remain unchanged: 384-dimensional pattern windows and 1152-dimensional kata sequences. No conversion, retraining, initialization, manifest replacement or deletion of user examples is introduced by this release.
- The new zoom math is an isolated ES module. No package manager, CDN runtime dependency or server-side Node requirement is introduced.
- Deployment remains overlay-based. Upload the release over the existing app files; do not mirror-delete or replace `data/`, `data/trained/`, `training-data/`, `vendor/`, `.kata-biomechanics-*` or `.kata-media-import-*` runtime data directories. The bundled `data/anatomy-functional-model.json` is an additive public application resource; retain the site's own private learning directories.

## Scientific boundaries

A monocular RGB video cannot directly measure muscle activation/force, fascial tension, joint loading, ground reaction forces or actual metabolic/mechanical efficiency. Segment timing, relative pose/depth, support-foot geometry and within-video repeatability are used as observable kinematic proxies. Side views generated from a single camera are estimates, not a recovered second camera. The planner avoids presenting unobservable physiology as measured fact.
