# QA — Falco Jugger 23.0.23

## Automated checks in the build workspace
- `node --check personalized-body-surface-core.mjs`: PASS
- `node --check pose-worker.js`: PASS
- `php -l index.php`: PASS
- `php -l reconstruction-memory.php`: PASS
- `personalized-body-surface-v23.0.23.mjs`: PASS (profile aggregation, asymmetric left/right proportions, 288-point unit cloud, 8×144 Q16 surface clips, 2D/3D fit rejection)
- `personalized-body-surface-memory-v23.0.23.php`: PASS (raw compatibility, prepacked Q16 validation, preservation and counters)
- `purcell-search-memory-10k-v23.0.22.php`: PASS with additional persistence assertions for personalized surface-fit scores and diagnostics
- Host-0 installer simulation: PASS on a synthetic 23.0.19 target; trained database, reports, vendor, cache and config sentinel files remained unchanged
- Regression set: Aero studio, 2D/3D reconstruction, worker contract, depth stability, HARD UPDATE, media-owner isolation, velocity/quality, 10k search, Kime, temporal patterns, evolution, archive compatibility and new surface tests: PASS
- Existing 23.0.21/23.0.22 focused tests: run separately and reported in release notes.

## Runtime validation still required
No live REG.RU account was accessed. No real kata video or browser E2E session was available. The full monolithic `tests/verify.sh` was not run against the patch-only overlay because that overlay does not include the complete application tree (`uppurcell.php`, release scripts and other base files). Focused regression tests listed above were run. Validate segmentation-mask availability, memory use and visual fit on actual recordings and target browsers. The 3D surface remains a monocular silhouette-lifted estimate, not a calibrated scan.
