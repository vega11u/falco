# Falco Jugger v21.11.0 — QA report

Дата сборки: 2026-11-06

## Итог

**PASS** — все developer release checks из `tests/verify.sh` завершились успешно. Дополнительный API integration test также включён в набор и прошёл.

## Что проверено

- PHP syntax: `index.php`, `Memories.php`, release smoke, learning API smoke, report archive smoke.
- Shell syntax: setup scripts, Javascript runtime tests, optimizer smoke, media import tests, report archive integration.
- Карате-классификатор: 102 WKF entries, 35 research references, 6 datasets, 24 anatomy groups.
- Release smoke: version 21.11.0, local video pipeline, social import UI, pose quality / constrained kinematic optimization, manifest safety, JSON assets.
- Local video, codec handling, Mediabunny, upload semantics, local file handling and fallback.
- JavaScript syntax, device profile, biomechanics core, avatar renderer, monocular depth, temporal recognition, technique planner, zoom mathematics, scene perspective/camera-cut logic, kick windows and social media file lifecycle.
- Learning API: Q16 feature packing, confirmed-only pattern storage, subjective feedback isolation, whole-kata validation, 3,005 example / 1,002 feedback fixture.
- Server report library integration: save/get/list/delete, persistence after PHP session expiry, owner isolation, and training archive immutability after report deletion.
- Optimizer UI and biomechanical guardrails.
- Media import: URL validation, YouTube fallback sequence, cross-session lock, bounded Range transfer, per-chunk SHA-256 and acknowledgement/cleanup.

## Report archive integration details

`tests/server-report-library-smoke.sh` starts an isolated local PHP server with temporary report and learning directories. It verifies that the report can be saved, fetched and listed; remains available with the owner cookie after PHP session expiration; is not visible to another owner; and can be deleted without changing the hash of a sentinel file in the learning archive.

## Training compatibility

- Existing feature contract is unchanged: 48D/frame, 384D/pattern example, 1152D/whole-kata sequence.
- No schema migration or destructive reinitialization was added.
- Release archive excludes mutable runtime `data/trained/training-manifest.json`; it retains only `training-manifest.json.template` for clean installation.
- The report deletion endpoint only unlinks the selected `*.json.gz` report archive and does not call learning API or delete training files.

## Known limits / not run

- CRON integration test was not run because it launches detached workers; the regular media-import smoke passed.
- Real hardware browser validation of pinch gestures and cross-browser rendering on iOS Safari/Android Chrome was not available in this environment.
- A physical playback test against a real long-form kata video was not performed; deterministic module and data-pipeline tests passed.
- Server archives do not contain source-video pixels/audio. They store model poses, hands, metrics, camera segments and user review data so the avatar and annotations can be reconstructed.
