# Movement pattern library — implementation notes

## What the current implementation learns

This release uses a **persistent, human-confirmed labelled-example library**, not an online-trained neural network. The server stores compact vectors and labels as JSON; it does not receive or archive source video. The browser extracts examples from the analysed clip and compares them with confirmed examples already in the library.

- **Pose window (`pose-window-v1`)**: eight temporal samples × 16 selected MediaPipe landmarks × XYZ = 384 numbers. Coordinates are centered on the hip midpoint and normalized by shoulder-to-hip scale. A left/right mirror variant is compared so equivalent stances with the opposite leading side can be discovered.
- **Whole-kata sequence (`kata-sequence-v1`)**: 24 samples × 48 values = 1,152 numbers. A match is proposed by nearest-neighbour distance. It requires an analysis that covers essentially the full video; partial-range analysis is not treated as a whole-kata signature.
- **Candidate groups**: stable low-motion pose windows, candidate arm strikes from the existing strike detector, candidate kicks from the existing kick detector, and unclassified fast arm-motion windows. The latter are deliberately labelled *movement* rather than automatically asserting a block: an action's intent cannot be reliably inferred from a monocular trajectory alone.
- **Confirmation**: a user can name the stance/technique, choose its type, confirm all grouped occurrences, compare time ranges, or reject a false positive. Only confirmed named templates are returned by the matching API. Unconfirmed candidates are not persisted. A rejected candidate can be stored only as a short decision in the feedback record, without its pose vector.
- **Timeline**: record moments and pattern intervals have separate marker styles; clicking a marker pauses and seeks the video to that timestamp.
- **Body selection**: clicking a rendered 3D segment opens a focused panel with local coordinates, estimated segment length, approximate segment-relative speed/acceleration, length change, related angle if available, and endpoint confidence.

## Important interpretation limits

1. This is **example-based retrieval**, not gradient-based training or a neural network which improves its weights. The database can make matching quicker and more useful as correctly labelled examples accumulate, but cannot fix model failures or guarantee correct classifications.
2. Similarity percentages are monotonic transformations of normalized landmark distances. They are not probabilities, karate correctness grades, or validated confidence values.
3. The present mirror handling makes left/right geometric variants comparable. It does not prove that two actions are tactically or biomechanically equivalent.
4. A block cannot always be distinguished from a strike, guard transition, preparatory movement or recovery using only sparse monocular pose landmarks. Such events are suggested for human review.
5. MediaPipe's world landmarks are hip-centred model coordinates. Per-segment velocity in the click panel is therefore relative to the model's body-centred coordinate system, not calibrated room-space travel. Model units are not a laboratory speed estimate. Absolute 3D height/depth require camera calibration or a multi-view/depth sensor.
6. Candidate poses and matches are sensitive to occlusion, clothing, blur, camera angle, and low-confidence feet/hands. Confirm the label before using it as a reference.

## Server storage and operation

- Endpoint `GET ?api=library` returns at most 400 recent confirmed labelled examples plus 250 recent feedback records. Vectors are packed 16-bit values and decoded in the browser.
- Endpoint `POST ?api=learn` accepts only manually confirmed stance/strike/kick/block/movement patterns, validates dimensions/range, and allows at most 80 examples per request. Unconfirmed examples are discarded rather than written.
- Endpoint `POST ?api=feedback` stores subjective ratings and confirmed/rejected pattern decisions separately from objective biomechanics. A full kata/sequence can only be added after explicit identity confirmation and exact validation of its 1,152-value signature (24 temporal frames × 48 values).
- The default store is placed outside `DOCUMENT_ROOT` when the host permits it. If filesystem permissions/open_basedir restrictions prevent that, set `KATA_LEARNING_DIR` to a private, writable directory outside the public web root, for example in the PHP-FPM/Apache environment. Do not point it at a public URL directory.
- The current implementation is a shared library for all visitors of that installation. Labels and example data therefore need human confirmation and server access controls appropriate to the deployment. Do not store sensitive personal information in kata/label fields.
- Only numeric pose-feature vectors and source filename metadata are sent to the learning endpoints; the source video is never sent to these APIs. File names and kata names are stored as labels/metadata, so use a neutral filename if that metadata should not be shared.
- Vectors are quantised to unsigned 16-bit values mapped to [-8, 8], Base64-packed, and migrated from legacy float arrays when the library is next written. Storage is capped at 3,000 examples and 1,000 feedback records.
- Personal ratings are never used to calculate objective biomechanics. Technique, power, speed and balance can only be used as a secondary tie-breaker for matches whose pose similarity differs by at most one point; the subjective biomechanics rating is excluded.

## Validation coverage

`tests/patterns-smoke.py` exercises the actual browser-side feature/vector and grouping functions using synthetic left/right stance sequences and checks confirmed-template matching, time-coded record/pattern timeline entries, and 3D-segment hit testing. `tests/learning-api-smoke.sh` starts PHP with an isolated temporary data directory and checks pattern confirmation, packed-vector persistence/migration, explicit full-kata confirmation, score separation and rejection of truncated sequences. `tests/verify.sh` runs syntax, DOM, renderer/biomechanics synthetic, movement-pattern and API checks.

These tests confirm code paths and data contracts, not the accuracy of pattern discovery on real kata recordings. Before treating labels as reliable, build a small evaluation set with multiple athletes, camera angles and repeated examples, manually annotate the ground truth, and measure precision/recall separately for stances, hand strikes, kicks and blocks. A useful next step after enough reviewed data exists would be an explicitly trained temporal classifier with train/test separation; the current JSON library does not do that.

## v5: full kata versus a named sequence

The training form now distinguishes `kata` (the clip is intended to represent the whole kata) and `sequence` (a named combination or fragment). In range mode, selected time ranges are saved as individual sequence examples; they are never stored as a full-kata example. A sequence may carry `parent_kata`, a free-text origin label. Confirmed stance/strike/kick/block/movement patterns also inherit the current training-unit and parent-kata metadata so a pattern can be traced to the kata/sequence from which it was labelled.

Automatic suggestions require at least three distinct `source_session` values for the same confirmed label. Local stance/technique proposals require similarity >=67%; full-kata / sequence proposals require similarity >=65%. A user must review and confirm suggestions. These thresholds are safeguards against premature naming, not measured precision guarantees. Generic fast arm movements are not automatically called blocks: the user must classify such a candidate as `Блок` before the labelled example becomes a block template.

The upload and conversion pipeline now exposes separate progress bars and an event log. Direct HTTPS media URLs can be fetched by the browser only when CORS and access permissions permit. YouTube/Instagram embeds are preview-only: cross-origin iframes do not expose their decoded frames to the pose pipeline.


## v6 social-link import

The optional server-side yt-dlp importer can fetch a supported public YouTube or Instagram single-post URL, then hand the temporary video file to the browser's existing local analysis flow. The learning library still stores only confirmed numeric pose-pattern features and labels, not source videos. Import setup, path permissions, limits and known extractor failure modes are documented in [`MEDIA_IMPORT.md`](MEDIA_IMPORT.md).
