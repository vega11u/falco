# Personalized body surface 23.0.23

## What changed
- Pose Worker always requests the MediaPipe person-segmentation mask during a full analysis. The mask is read at 96×96 resolution and released immediately after profile extraction; source frames are not uploaded.
- For torso, upper/lower arms and upper/lower legs, the analyzer measures silhouette width at four normalized stations. Widths are normalized by the athlete's observed shoulder span and aggregated by per-station medians over the current clip.
- The 2D overlay draws a denser 2D silhouette point cloud. The 3D avatar uses per-athlete width profiles to adjust torso and limb radii and overlays a 3D point cloud with confidence-weighted rendering.
- Purcell's 2D and 3D hypothesis checks now include measured silhouette-to-segment proportion consistency. Candidates that distort the athlete-specific body proportions beyond the tolerance are rejected when enough profile evidence exists.
- Lully and Purcell training examples can store an 8-frame personalized surface clip in both spaces plus a compact 9-segment anthropometric width profile. The Purcell multi-video queue captures the surface extras while each source video is active and sends them with the later annotation; the local queue draft deliberately keeps only the legacy feature vector to avoid storing large frame arrays in localStorage. The legacy 384D feature vector and 8×33×4 reconstruction clips remain unchanged.
- Report archives persist compact per-frame silhouette profiles. Older archives without this field remain readable.

## Geometry and uncertainty
2D width samples are measured from the segmentation mask and include clothing. The 3D point cloud is not a metric scan: MediaPipe world landmarks provide articulated anchors, while the unseen-side depth radius is a conservative elliptical prior (0.52× silhouette half-width). Confidence for lifted 3D surface points is capped at 0.48. No force, muscle activation, sex, age or medical attributes are inferred.

## Performance
- Mask data is sampled and closed per frame; no segmentation bitmap is retained.
- Per-frame surface data is a compact 9×4×2 float profile (72 float values), not a persistent 288-point array.
- 288-point clouds are generated only for the displayed frame or selected training clip.
- Training clips use eight samples and four cross-section points per station (144 points per frame), quantized to Q16 Base64 before transmission. Each 2D or 3D clip is 9,216 bytes before Base64 expansion (about 12.3 KB), rather than a large JSON float array.
- Full mask segmentation adds processing cost. The system deliberately favours quality over peak FPS; existing video decoding and pose inference remain in the browser worker.

## Compatibility
The extension is additive. Old 384D vectors, old 33-point archives, prior reconstruction clips and existing Lully/Purcell data are not rewritten or removed. New surface fields are optional and validated server-side.
