/** WKF 2026 kata criteria mapping, NOT a WKF judging or tournament score.
 * 2026 rules §5.6, https://www.wkf.net/ ; no user-label/LLM score fabricated.
 */
export const WKF_KATA_CRITERIA_VERSION='wkf-2026-observable-v1';
export const WKF_2026_KATA_CRITERIA=[
 ['stances','Стойки','partial','Опора, геометрия суставов, устойчивость'],
 ['techniques','Техники','expert','Требуется известная техника и экспертно подтверждённый эталон'],
 ['transitions','Переходы','partial','Движение и устойчивость между техниками'],
 ['timing','Тайминг и синхронизация','partial','Последовательность и интервалы замедления'],
 ['breathing','Правильное дыхание','expert','По одному беззвучному видео достоверно не определяется'],
 ['kime','Кимэ','partial','Только наблюдаемая синхронность окончания быстрых движений'],
 ['kihon','Соответствие кихон','expert','Нужна подтверждённая разметка техники'],
 ['strength','Сила','expert','Видео не измеряет силу удара или мышечное усилие'],
 ['speed','Скорость','partial','Относительные скорости и временные профили'],
 ['balance','Баланс','partial','Опора и оценочные кинематические признаки устойчивости']
];
const finite=Number.isFinite;
export function mapWKFCriteria(report,{reconstruction=null}={}){
 const summary=report?.summary||{},analysis=report?.analysis||{};
 const reliable=reconstruction?.usable_fraction>=.65||(!reconstruction&&Number(summary.average_pose_confidence)>.55);
 const kime=analysis.kime||{},kimeSamples=Number(kime.measured)||0;
 const evidence={
  stances:report?.analysis?.ground_contact?{source:'ground_contact',note:'Есть оценка контактов стоп; не измеряются реакции опоры'}:null,
  transitions:Array.isArray(report?.orientation_segments)&&report.orientation_segments.length>0?{source:'orientation_segments',note:'Оценены переходы ориентации/позы; правильность ката не доказана'}:null,
  timing:finite(Number(summary.sequencing_index))?{source:'sequencing_index',value:Number(summary.sequencing_index),note:'Только межсегментный тайминг'}:null,
  kime:kimeSamples>0?{source:'monteverdi',events:kimeSamples,synchronized:Number(kime.within_window)||0,note:'Кинематический прокси, не полная оценка кимэ'}:null,
  speed:finite(Number(summary.average_fast_velocity_m_s))&&summary.average_fast_velocity_m_s!=null?{source:'relative_wrist_velocity',note:'Псевдометрические значения без калибровки камеры'}:null,
  balance:finite(Number(summary.median_com_margin_body_heights))&&summary.median_com_margin_body_heights!=null?{source:'com_projection',note:'COM 2D прокси, не измерение центра давления'}:null
 };
 const rows=WKF_2026_KATA_CRITERIA.map(([id,title,kind,description])=>{
  const ev=evidence[id]||null;
  return {id,title,kind,description,status:kind==='expert'?'expert_required':ev&&reliable?'proxy_available':ev?'low_confidence':'insufficient_evidence',evidence:ev,confidence:ev&&reliable?'relative_only':null};
 });
 return {schema:WKF_KATA_CRITERIA_VERSION,rules_version:'2026.0',scope:'individual_kata_performance',criteria:rows,observable_count:rows.filter(x=>x.status==='proxy_available').length,subjective_criteria_not_scored:true,official_wkf_score:null,not_a_judge_score:true,reference:'WKF Kata Competition Rules 2026, paragraph 5.6',limitations:'WKF official judges evaluate the performance; these proxies are coaching observations, not an official WKF score.'};
}
