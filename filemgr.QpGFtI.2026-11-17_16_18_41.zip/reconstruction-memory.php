<?php
declare(strict_types=1);
/** Optional dual-space feature extensions. Never rewrite legacy features_q16/model weights. */

/** Validate compact bit-mask transport before retaining personal silhouette evidence. */
function fj_recon_valid_silhouette_mask($encoded, int $width, int $height): bool {
    if (!is_string($encoded) || strlen($encoded) < 5 || strlen($encoded) > 8192 || $width < 32 || $height < 32 || $width > 192 || $height > 192) return false;
    $scheme = $encoded[0];
    if ($scheme !== 'r' && $scheme !== 'b') return false;
    $payload = substr($encoded, 1);
    $bytes = base64_decode($payload, true);
    if (!is_string($bytes) || base64_encode($bytes) !== $payload) return false;
    $pixels = $width * $height;
    if ($scheme === 'b') return strlen($bytes) === (int)ceil($pixels / 8);
    if (strlen($bytes) < 2) return false;
    $next = ord($bytes[0]);
    if ($next !== 0 && $next !== 1) return false;
    $cursor = 1; $position = 0; $length = strlen($bytes);
    while ($cursor < $length) {
        $run = 0; $factor = 1; $terminated = false; $shift = 0;
        while ($cursor < $length) {
            $byte = ord($bytes[$cursor++]);
            $run += ($byte & 127) * $factor;
            $factor *= 128; $shift += 7;
            if ($shift > 28) return false;
            if (($byte & 128) === 0) { $terminated = true; break; }
        }
        if (!$terminated || $run < 1 || $position + $run > $pixels) return false;
        $position += $run; $next ^= 1;
    }
    return $position === $pixels;
}
function fj_recon_optional_features(array $row, callable $pack): array {
    $out=[];
    foreach (['2d','3d'] as $space) {
        $features=$row['features_'.$space]??null;
        if ($features===null) continue;  // old examples and temporarily missing 3D stay valid
        if(!is_array($features)||count($features)!==384)throw new InvalidArgumentException('Неверная длина признаков '.$space.' реконструкции.');
        $clean=[];
        foreach($features as $v){if(!is_numeric($v)||!is_finite((float)$v)||abs((float)$v)>8)throw new InvalidArgumentException('Некорректное значение '.$space.' реконструкции.');$clean[]=round((float)$v,4);}
        $out['features_'.$space.'_q16']=$pack($clean);
        $out['features_'.$space.'_version']='falco-reconstructed-space-'.$space.'-v1';
    }
    // Optional compact 8-frame / 33-joint reconstructed skeleton clips.
    // These preserve actual 2D/3D geometry, not only the 16-joint classifier signature.
    foreach(['2d','3d'] as $space){
        $clip=$row['reconstruction_clip_'.$space]??null;
        if($clip===null)continue;
        if(!is_array($clip)||count($clip)!==8*33*4)throw new InvalidArgumentException('Неверная длина 8×33×4 клипа реконструкции '.$space.'.');
        $clean=[];foreach($clip as $v){if(!is_numeric($v)||!is_finite((float)$v)||abs((float)$v)>8)throw new InvalidArgumentException('Некорректная координата клипа '.$space.'.');$clean[]=round((float)$v,4);}
        $out['reconstruction_clip_'.$space.'_q16']=$pack($clean);
        $out['reconstruction_clip_'.$space.'_schema']='falco-reconstructed-8x33x4-'.$space.'-v1';
    }
    // Athlete-specific silhouette surface descriptors and 8-frame point-cloud clips.
    // The 3D cloud is silhouette-lifted: hidden-side thickness is a bounded prior, not measured depth.
    $shape=$row['personalized_shape_profile']??null;
    if($shape!==null){
        if(!is_array($shape)||($shape['schema']??'')!=='falco-personalized-silhouette-surface-v1')throw new InvalidArgumentException('Неверная схема персонализированного профиля тела.');
        $width=$shape['width_profile']??null;$flat=[];
        $keys=['torso','left_arm_upper','left_arm_lower','right_arm_upper','right_arm_lower','left_leg_upper','left_leg_lower','right_leg_upper','right_leg_lower'];
        if(!is_array($width))throw new InvalidArgumentException('Отсутствуют пропорции персонализированного профиля.');
        foreach($keys as $key){$stations=$width[$key]??null;if(!is_array($stations)||count($stations)!==4)throw new InvalidArgumentException('Неверная длина профиля сегмента '.$key.'.');foreach($stations as $pair){if(!is_array($pair)||count($pair)<2||!is_numeric($pair[0])||!is_numeric($pair[1])||!is_finite((float)$pair[0])||!is_finite((float)$pair[1])||(float)$pair[0]<0||(float)$pair[0]>1.4||(float)$pair[1]<0||(float)$pair[1]>1)throw new InvalidArgumentException('Некорректная ширина или достоверность профиля '.$key.'.');$flat[]=(float)$pair[0];$flat[]=(float)$pair[1];}}
        $out['personalized_shape_profile_q16']=$pack($flat);
        $out['personalized_shape_profile_schema']='falco-personalized-silhouette-surface-v1-9x4x2';
        $out['personalized_shape_profile_confidence']=is_numeric($shape['profile_confidence']??null)?max(0,min(1,(float)$shape['profile_confidence'])):0;
    }
    // Fixed-topology athlete identity. Old rows remain untouched and readable.
    $identity=$row['personalized_mesh_identity']??null;
    if($identity!==null){
        if(!is_array($identity)||($identity['schema']??'')!=='falco-athlete-mesh-identity-v2'||
           ($identity['topology']??'')!=='falco-vivaldi-fixed-2048-v2'||(int)($identity['vertex_count']??0)!==2048)
            throw new InvalidArgumentException('Неверная схема персонализированной фиксированной сетки.');
        $ratios=$identity['bone_length_ratios']??null;
        if(!is_array($ratios)||count($ratios)!==12)throw new InvalidArgumentException('Неверный набор пропорций персональной сетки.');
        $referenceImage=$identity['reference_image_shoulder_span']??0;
        $referenceWorld=$identity['reference_world_shoulder_span']??0;
        $profileConfidence=$identity['profile_confidence']??0;
        foreach([$referenceImage,$referenceWorld,$profileConfidence] as $v)if(!is_numeric($v)||!is_finite((float)$v))throw new InvalidArgumentException('Некорректный масштаб персональной сетки.');
        if((float)$referenceImage<0||(float)$referenceImage>1.5||(float)$referenceWorld<0||(float)$referenceWorld>2.5||(float)$profileConfidence<0||(float)$profileConfidence>1)
            throw new InvalidArgumentException('Масштаб персональной сетки выходит за допустимые пределы.');
        $identityVector=[(float)$referenceImage,(float)$referenceWorld,(float)$profileConfidence];
        foreach($ratios as $v){if($v===null){$identityVector[]=0;continue;}if(!is_numeric($v)||!is_finite((float)$v)||(float)$v<0||(float)$v>8)throw new InvalidArgumentException('Некорректное отношение длины сегмента тела.');$identityVector[]=(float)$v;}
        $out['personalized_mesh_identity_q16']=$pack($identityVector);
        $out['personalized_mesh_identity_schema']='falco-athlete-mesh-identity-v2-q16-15';
        $out['personalized_mesh_identity_topology']='falco-vivaldi-fixed-2048-v2';
        $out['personalized_mesh_identity_vertices']=2048;
        $out['personalized_mesh_identity_confidence']=is_numeric($identity['confidence']??null)?max(0,min(1,(float)$identity['confidence'])):0;
        $out['personalized_mesh_identity_basis_schema']='vivaldi-body-frame-basis-v1';
    }
    foreach(['2d','3d'] as $space){
        $clip=$row['personalized_surface_clip_'.$space]??null;if($clip===null)continue;
        if(!is_array($clip)||($clip['schema']??'')!=='falco-personalized-silhouette-surface-v1'||($clip['space']??'')!==$space)throw new InvalidArgumentException('Неверная схема плотной поверхности '.$space.'.');
        $expected=8*144*4;$packed=null;
        if(is_string($clip['values_q16']??null)){$decoded=base64_decode($clip['values_q16'],true);if(!is_string($decoded)||strlen($decoded)!==$expected*2||base64_encode($decoded)!==$clip['values_q16'])throw new InvalidArgumentException('Некорректный Q16-пакет плотной поверхности '.$space.'.');$packed=$clip['values_q16'];}
        else{$values=$clip['values']??null;if(!is_array($values)||count($values)!==$expected)throw new InvalidArgumentException('Неверное число точек плотной поверхности '.$space.'.');$clean=[];foreach($values as $v){if(!is_numeric($v)||!is_finite((float)$v)||abs((float)$v)>8)throw new InvalidArgumentException('Некорректная координата плотной поверхности '.$space.'.');$clean[]=round((float)$v,4);}$packed=$pack($clean);}
        $out['personalized_surface_clip_'.$space.'_q16']=$packed;
        $out['personalized_surface_clip_'.$space.'_schema']='falco-personalized-surface-8x144x4-'.$space.'-v1';
        $out['personalized_surface_clip_'.$space.'_point_count']=1152;
    }
    // Four compact, per-example silhouette masks preserve the observed athlete boundary.
    // The 128×128 training representation is intentionally separate from the 256×256 report masks.
    $silhouette=$row['personalized_silhouette_clip']??null;
    if($silhouette!==null){
        if(!is_array($silhouette)||($silhouette['schema']??'')!=='falco-athlete-silhouette-clip-v1'||
           (int)($silhouette['width']??0)!==128||(int)($silhouette['height']??0)!==128||
           (int)($silhouette['frame_count']??0)!==4||($silhouette['encoding']??'')!=='rle-bitmask-v1'||
           !is_array($silhouette['masks']??null)||count($silhouette['masks'])!==4)
            throw new InvalidArgumentException('Неверная схема персональной маски спортсмена.');
        $masks=[];foreach(array_values($silhouette['masks']) as $encoded){if(!fj_recon_valid_silhouette_mask($encoded,128,128))throw new InvalidArgumentException('Повреждена маска персонального силуэта спортсмена.');$masks[]=$encoded;}
        $qualityRows=[];$qualityInput=is_array($silhouette['quality']??null)?array_values($silhouette['quality']):[];
        for($i=0;$i<4;$i++){$q=$qualityInput[$i]??[];$qualityRows[]=['quality'=>in_array(($q['quality']??''),['high','review','low','legacy'],true)?$q['quality']:'legacy','confidence'=>is_numeric($q['confidence']??null)?max(0,min(1,(float)$q['confidence'])):null,'pose_coverage'=>is_numeric($q['pose_coverage']??null)?max(0,min(1,(float)$q['pose_coverage'])):null];}
        $out['personalized_silhouette_clip']=['schema'=>'falco-athlete-silhouette-clip-v1','width'=>128,'height'=>128,'frame_count'=>4,'encoding'=>'rle-bitmask-v1','masks'=>$masks,'quality'=>$qualityRows];
    }
    $quality=$row['reconstruction_quality']??null;
    if(is_array($quality)){
        foreach(['2d','3d'] as $space){$v=$quality[$space]??null;if(is_numeric($v)&&is_finite((float)$v))$out['reconstruction_quality_'.$space]=round(max(0,min(1,(float)$v)),4);}
    }
    if($out)$out['reconstruction_source']='articulated-body-v3-fixed-mesh';
    return $out;
}
function fj_recon_preserve_extra(array $new,array $prior): array {
    foreach(['2d','3d'] as $space){foreach(['features_'.$space.'_q16','features_'.$space.'_version','reconstruction_clip_'.$space.'_q16','reconstruction_clip_'.$space.'_schema','reconstruction_quality_'.$space,'personalized_surface_clip_'.$space.'_q16','personalized_surface_clip_'.$space.'_schema','personalized_surface_clip_'.$space.'_point_count'] as $field)if(!array_key_exists($field,$new)&&array_key_exists($field,$prior))$new[$field]=$prior[$field];}
    foreach(['personalized_shape_profile_q16','personalized_shape_profile_schema','personalized_shape_profile_confidence','personalized_mesh_identity_q16','personalized_mesh_identity_schema','personalized_mesh_identity_topology','personalized_mesh_identity_vertices','personalized_mesh_identity_confidence','personalized_mesh_identity_basis_schema'] as $field)if(!array_key_exists($field,$new)&&array_key_exists($field,$prior))$new[$field]=$prior[$field];
    if(!array_key_exists('personalized_silhouette_clip',$new)&&array_key_exists('personalized_silhouette_clip',$prior))$new['personalized_silhouette_clip']=$prior['personalized_silhouette_clip'];
    if(!array_key_exists('reconstruction_source',$new)&&array_key_exists('reconstruction_source',$prior))$new['reconstruction_source']=$prior['reconstruction_source'];
    return $new;
}
function fj_recon_memory_counts(array $rows): array {
    $count=['total'=>0,'legacy_compatible'=>0,'reconstructed_2d'=>0,'reconstructed_3d'=>0,'paired_2d_3d'=>0,'legacy_only'=>0,'3d_only'=>0,'reconstructed_clips_2d'=>0,'reconstructed_clips_3d'=>0,'personalized_surface_2d'=>0,'personalized_surface_3d'=>0,'personalized_shape_profiles'=>0,'personalized_mesh_identities'=>0,'personalized_silhouette_clips'=>0];
    foreach($rows as $row){if(!is_array($row))continue;$count['total']++;
        $legacy=is_string($row['features_q16']??null)||is_array($row['features']??null);
        $two=is_string($row['features_2d_q16']??null)||is_array($row['features_2d']??null);
        $three=is_string($row['features_3d_q16']??null)||is_array($row['features_3d']??null);
        if($legacy)$count['legacy_compatible']++;if($two)$count['reconstructed_2d']++;if($three)$count['reconstructed_3d']++;
        foreach(['2d','3d'] as $space){if(is_string($row['reconstruction_clip_'.$space.'_q16']??null))$count['reconstructed_clips_'.$space]++;if(is_string($row['personalized_surface_clip_'.$space.'_q16']??null))$count['personalized_surface_'.$space]++;}if(is_string($row['personalized_shape_profile_q16']??null))$count['personalized_shape_profiles']++;if(is_string($row['personalized_mesh_identity_q16']??null)&&($row['personalized_mesh_identity_topology']??'')==='falco-vivaldi-fixed-2048-v2')$count['personalized_mesh_identities']++;if(($row['personalized_silhouette_clip']['schema']??'')==='falco-athlete-silhouette-clip-v1')$count['personalized_silhouette_clips']++;
        if($two&&$three)$count['paired_2d_3d']++;if($legacy&&!$two&&!$three)$count['legacy_only']++;if($three&&!$two&&!$legacy)$count['3d_only']++;
    }return $count;
}
