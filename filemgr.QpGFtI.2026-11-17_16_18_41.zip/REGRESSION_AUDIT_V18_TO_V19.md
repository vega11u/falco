# Regression audit — v18 to v19

## Findings in v18

1. **The REG.RU setup profile disabled social import.** `setup-regru.sh` wrote `server_social_import: false` to `data/hosting-runtime.json`, and did not call `setup-media-import.sh`. As a result, the site could not report the URL importer as available even though the main application had the importer code.
2. **The import panel was hidden by default.** The v18 markup added the `hidden` class to `.source-link-box`; its health-page script then removed the panel whenever `media_import.ready` was false. This made the removed installer look like a deleted product feature.
3. **The REG.RU path still inherited a Python virtual-environment requirement.** The v17 full installer already included a Python research/training toolchain, and its media installer also created a `gallery-dl` virtualenv. The v18 shared-hosting refactor removed the full Python/Node training setup but retained the `gallery-dl` venv step inside `setup-media-import.sh`. That left an unexpected Python/pip/venv dependency in the supposedly lightweight hosting profile.
4. **The regular installer did not invoke the media importer.** The shortened `setup-release.sh` correctly entered the shared-hosting profile, but that profile did not restore the original YouTube/Instagram install step.
5. **The health diagnostics did not support the shared-hosting queue case.** An account with `proc_open` disabled was reported as unable to import; there was no user-CRON fallback.

## Corrections in v19

- Social import is again installed by `bash setup-release.sh` through `setup-regru.sh` and `setup-media-import.sh`.
- The YouTube/Instagram URL control remains visible and tells the user which mode is available.
- `server_social_import` is set from actual installed capabilities, not hard-coded to false.
- Existing yt-dlp extraction profiles and the Deno JavaScript challenge runtime are retained. Instagram uses yt-dlp's native extractor retry profiles; the separate gallery-dl fallback is deliberately removed because it introduced the extra Python/pip/venv deployment dependency.
- If web PHP can start a process, the app uses direct mode. If not, it writes a private queue item and the account-owner CRON worker starts one queued task per run. The worker does not try to override PHP disable-functions or hosting policy.
- FFmpeg.wasm npm metadata parsing and integrity verification use PHP JSON + OpenSSL SHA-512; there is no Python check in `setup-ffmpeg-wasm.sh`. This removes the Python-only integrity helper rather than trying to install Python on the hosting account.
- Local-first MediaPipe asset selection, Falco Jugger brand styling, the hidden hero removal, full personal-library loading and original frame-sequential analysis path are retained.

## What is not included or not proven

- The official yt-dlp standalone binary is a self-contained PyInstaller build of the upstream Python project. The v19 installer does not install system Python, pip or a virtualenv, but the binary bundles its own interpreter. This is inherited from the original v17 social-import design; removing even this binary would require a different pure-JavaScript extraction implementation.
- `gallery-dl` is no longer installed. Instagram import remains through yt-dlp native retries, but a particular public post may fail if the platform blocks extraction.
- v17's research-corpus training scripts were Python-based. They are not part of the REG.RU PHP/JS application path and are removed from this shared-hosting release. The v17 training manifest marked the corpus models `ready: false`; there were no ready pretrained research weights in the archive. This does not remove the separate personal example library or its PHP/JS similarity matching.
- YouTube/Instagram import smoke tests use mock downloader executables. They verify the application control flow and file handling, not successful extraction of arbitrary real platform posts.
- CRON fallback was verified with PHP's built-in server and `proc_open` disabled, but actual REG.RU user-CRON scheduling must be configured in the user's control panel and verified on that account.
- No real user video or physical device/browser performance test was run as part of this package build.

## Core-analysis scope

The v19 `index.php` is based on the v17 application and keeps v18's brand/design, local model priority and research-manifest fallback while correcting import/hosting logic. The sequential decoded-sample analysis, per-frame record creation, MediaPipe inference, 3D avatar and personal-learning matcher were not intentionally redesigned in this regression fix. See `VALIDATION_REPORT.md` for exact synthetic checks and limits.
