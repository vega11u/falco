# Kime timing: operational biomechanical basis

Kime in kata is treated here as a visible terminal coordination event: the striking/blocking limb approaches its endpoint while the relevant proximal segments (pelvis/trunk) and support/stance chain settle into a stable configuration. The implementation compares the times at which selected landmarks reach their terminal low-velocity state within a fast, user-confirmed technique interval.

## What is measured
- Per-landmark terminal time estimated from image-space landmark velocity.
- Spread (milliseconds) between measurable terminal events.
- A coordination score that decreases as terminal-time spread approaches/exceeds the configurable 180 ms starter window.
- Per-technique results and an aggregate percentage among measurable fast techniques.

## What is not measured
- Impact force, target contact, ground-reaction force, muscle activation (EMG), internal joint torque or energy expenditure.
- True simultaneous muscular contraction. Video-derived kinematics cannot prove it.

## Guardrails
- Only reviewed strike, kick and block intervals are considered; intervals longer than 1.2 s are excluded from the fast-technique metric.
- A technique with fewer than three valid terminal landmark events is reported as unmeasurable, not as a miss.
- 180 ms is a tunable initial engineering threshold, not a universal karate standard. It must be calibrated against expert annotations and the recording frame rate.
- The aggregate percentage denominator is measurable fast techniques; the report also exposes measurable count and total eligible count so missing observations are visible.

This is a conservative coordination proxy based on proximal/distal segment timing and terminal stabilization, not a claim of direct measurement of the traditional concept's full mental, technical or impact components.
