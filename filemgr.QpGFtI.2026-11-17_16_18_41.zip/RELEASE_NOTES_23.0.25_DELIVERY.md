# Falco Jugger 23.0.25 — unified over unmodified 23.0.24

## Scope
A single patch containing all installed Bach, Vivaldi, Handel, Monteverdi and Purcell enhancements; no prior 23.0.25 stage patch is required.

- Bach: normalized athlete-coordinate identity; morphology is not part of technique identity.
- Vivaldi: anchor selection, locked segment proportions, two-way temporal constraints, compact/standard/fine deterministic vertex topology (512/2048/8192), on-demand surface rendering, measured silhouette-width profile.
- Handel: constrained correction of low-confidence 3D segment estimates; retains original observations.
- Depth consensus: sequential BASE, SMALL, GLPN and DPT, and explicit failure if any input is absent. These are relative-depth maps, not a trained human-mesh reconstructor.
- Monteverdi: kime replay, Yes/No/Uncertain feedback and calibration, initial displays «Есть точка» / «Нет точки».
- Purcell: independent evolution of full video or selected interval, without optimization priorities. Full-video training uses a motion-aware temporal subsample (up to 360 frames) to optimize ONE global genome, then applies that genome to all source frames and validates anatomical plausibility and continuity. It is NOT chunk-by-chunk training anymore. Full-resolution JSON is downloadable if accepted.
- Model journal: stage summaries without per-frame log spam.
- Server data: trained data, private reports, user configuration, media and vendor files are not included or modified.

## Important technical limitations
The system has NOT integrated neural SMPL-X or equivalent image-conditioned body/gi mesh recovery. A geometric 8192-vertex mesh is not 8192 independently observed points. Real mask/pose/depth observations and fitted priors remain uncertain under occlusion and cannot establish true unique metric shape from monocular video. Neural systems such as ExMR and GVHMR typically need GPU/Python and/or access-controlled weights, and cannot legitimately be claimed as host-0 JavaScript components. No end-to-end real-video browser performance or accuracy tests were conducted.

## Third-party research reviewed
- https://github.com/twehrbein/ExMR (weights gated; substantial GPU stack)
- https://github.com/ryanrudes/gvhmr (Python-centric reconstruction)
- https://github.com/google-ai-edge/mediapipe-samples/tree/main/examples/pose_landmarker/js
- https://onnxruntime.ai/docs/tutorials/web/ep-webgpu.html

## Compatibility and installation
Use install-host0-patch-23.0.25-unified.sh /absolute/path/to/falcojugger.art on the exact attached 23.0.24 baseline. The installer refuses hash mismatches and unsafe symlinks; it does not touch trained datasets or report storage. A temporary rollback directory inside the installation is removed after a successful installation.
