# Falco Jugger 25.0.0 — QA report

## Scope

UI overhaul and one Purcell optimizer objective change on top of analysis core `23.0.27` / UI base `24.3.0`.

## Passed checks

- `bash tests/verify.sh` — all developer release checks passed on the updated build and on a clean staging copy after installation.
- `install-falco25.sh` integration test against a fresh extraction of the supplied 24.3.0 archive — checksum preflight, in-place backup, allowlist cleanup, file overlay and post-install smoke tests passed.
- `php tests/falco24-ui-smoke.php` — one rail, no topbar, one stylesheet, preserved DOM contracts.
- `node tests/falco24-ui-smoke.mjs` — workspace controller, responsive behavior and stylesheet contracts.
- `node tests/falco25-purcell-overall-smoke.mjs` — one general optimizer score and one global feedback value; legacy score fields remain compatible.
- `php tests/falco24-clean-ui-smoke.php` — exactly one root CSS file.
- `php tests/falco24-learning-centers-smoke.php` — existing read-only Lully/Purcell library APIs.
- `node tests/aero-studio-contract-23-0-15.mjs` — original trim, player, 3D toggle, reset-preservation and frame-clock contracts.
- `node tests/port-23.0.26.1-integrity.test.mjs` — 2D/3D reconstruction, personalized model archive and three-class Kime labels.
- `node tests/motion-studio-v23.0.27.mjs` — motion/reconstruction integration contracts.
- PHP lint passed for all modified PHP files.
- `node --check falco-jugger-ui.js` passed.
- All secondary pages rendered through PHP CLI without PHP warnings/fatal errors.
- CSS parsed successfully with the development CSS parser; no parse errors.
- Root CSS inventory contains only `falco-jugger-ui.css`.
- Old CSS and superseded UI controllers are absent from the build tree; the staging install leaves exactly one root CSS file.

## Compatibility safeguards

- `VERSION` remains `23.0.27`.
- No trained data, server reports, uploads, user configuration, vendor assets or model caches were included in the patch file list.
- Installer backups only overwritten/deleted code assets to `.falco-rollback/` inside the target site; the tested backup did not include trained data, reports, videos or vendor assets.
- Cleanup is restricted to `FALCO25_GC_ALLOWLIST.txt` and guarded by a live-reference scan.

## Not claimed

A real browser screenshot/visual QA pass at 1920, 1440, 1280, 1024, 820, 390 and 360 CSS pixels was not executed in this build environment because no browser automation binary was available. Responsive rules and DOM contracts were checked statically; visual acceptance should still be performed on the deployed host/browser after `HARD UPDATE`.
