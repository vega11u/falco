# Falco Jugger 26.3.2 — typography and style hygiene

- Reworked text flow across headings, panel headers, pills, statuses, labels, cards and action rows so text wraps inside its component instead of hanging or colliding.
- Added explicit Times New Roman body typography and Bebas Neue display typography with safe local fallbacks.
- Adjusted contrast and accent colors for both themes; primary controls use one turquoise accent.
- Added `cleanup-legacy-styles-26.3.2.sh`. It quarantines only identified obsolete CSS files or files containing known legacy markers. It never touches the active stylesheet, PHP, JS, vendor files, data or model stores.
- Existing handlers, APIs, report formats and dependencies are preserved.
