# Falco Jugger 21.9.0 — release notes

## Scene depth and 2D avatar

- Added a browser-local ensemble of Depth Anything V2 Small and Base. Both maps are percentile-normalized, fused (Base 62%, Small 38%), and their pixel-wise disagreement is retained as a confidence cue. If Base cannot load or infer, the Small model remains available as a fallback.
- The ensemble is a display/scene-depth aid. It does not overwrite measured MediaPipe 2D landmarks, original world landmarks, or biomechanical metrics. The local report retains compressed per-frame 2D pose, MediaPipe world coordinates, display-fused coordinates, relative depth and agreement.
- Added a visible far-to-near depth legend and display-derived intermediate points on the 2D avatar.
- Main procedural 3D avatar is now generated only when the user presses the explicit action button. It is built from 2D landmarks, relative depth and whichever MediaPipe world landmarks are available.

## Tatami / floor plane

- Sparse image-space floor-line evidence is analysed across a maximum of 12 low-resolution frames in the active camera segment.
- Repeated candidate quadrilaterals defined by two approximately orthogonal line families can be treated as a 1×1 m tatami cell by the user's convention. The application then creates image-to-floor and floor-to-image homographies and overlays the projected grid.
- If the candidate is not repeated/credible, no metric unit is asserted. The 2D overlay can show only a conditional perspective grid and the top-down view remains relative.
- The floor plane in the 3D avatar remains horizontal in avatar-space. Without camera intrinsics/extrinsics, this does not reconstruct physical floor tilt or room dimensions.

## Muscle and pattern review

- The muscle-activity panel contains a synchronized top-down floor projection with its own play/pause, frame step and seek controls, all linked to the source video.
- Pattern review shows two snapshots at the same representative time: source-camera view and estimated side projection. Body regions used by the similarity evidence are highlighted in red.

## Privacy and training compatibility

- Per-frame spatial/depth series are compressed as Q16/Base64 and included in the local JSON report only. They are deleted from the server-session copy before report persistence.
- No learning schema migration was introduced. Pattern features remain 384 values per window / 1152 per full kata. The archive excludes the runtime `data/trained/training-manifest.json` and never packages `.kata-biomechanics-*` or `.kata-media-import-*`.
- Install as an overlay, never mirror-delete. Preserve `data/`, `data/trained/`, and the two private sibling directories.

## Important limits and model license

Depth Anything is monocular relative-depth estimation, not metric stereo reconstruction or a subject-specific mesh. A tatami cell provides only an assumed scale after repeated visible line evidence; it is not an independent measurement. Accuracy still depends on video quality, camera motion, occlusion, clothing and perspective.

The Small ONNX model is published under Apache-2.0. The Base model used by this ensemble is published under CC-BY-NC-4.0. Commercial use requires separate license review or replacement of Base with an appropriately licensed model. Model weights are fetched by the browser at runtime and are not included in the archive.
