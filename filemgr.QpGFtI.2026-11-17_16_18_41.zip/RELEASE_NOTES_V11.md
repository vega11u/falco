# Release notes — v11.0

## Karate technique recognition and functional anatomy

- Style-aware learning contexts for Shotokan, Shito-ryu, Goju-ryu and Ryuei-ryu; no Kyokushin/Oyama data is used as a target exemplar or training sample.
- Machine-readable WKF 2026 kata register with 102 numbered entries, preserving repeated names as separate numbered records.
- Expanded technique vocabulary for stances, hand techniques, kicks, blocks and transitions.
- Constrained dynamic time warping (DTW) with eight additional joint-angle terms per frame; style-compatible, manually confirmed samples only.
- Automatic label suggestions are gated by three independent video sessions, similarity threshold and runner-up margin. Similarity is not a calibrated probability.
- Twenty-four-group functional anatomy ontology with muscle actions, kata relevance, synergy hypotheses and evidence-limited myofascial continuities.
- Clickable anatomy notes in the interface and revised labels to distinguish kinematic proxies from EMG.
- Style reference catalog with source URLs, authority type, allowed use, rights status and caveats. Includes HardMo (2024) and HardMo++ (2026) as pose-estimation hard-case research leads for hand/foot errors only; source-media rights and target style labels are not assumed.
- Single installer: `bash setup-release.sh`. It fetches pinned inference assets and optional media-import tools. It does not fetch unlicensed karate training datasets.

## Known limits

This is not a neural network trained on external four-style data. It is an improved example-based matcher that learns from manually confirmed clips in the user's installation. Single-camera pose does not measure ground reaction force, joint moments, muscle activation, myofascial strain or true 3D motion out of plane. No validated optimum is calculated; recommendations remain constrained kinematic coaching candidates.
