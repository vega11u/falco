const safe = (value) => value === undefined || value === null || value === '' ? null : value;

function detectEngine(ua = navigator.userAgent || '') {
  if (/Edg\//.test(ua)) return 'Chromium / Edge';
  if (/Chrome\//.test(ua) && !/Edg\//.test(ua)) return 'Chromium / Chrome';
  if (/Firefox\//.test(ua)) return 'Gecko / Firefox';
  if (/Safari\//.test(ua) && !/Chrome\//.test(ua)) return 'WebKit / Safari';
  return 'Не определён';
}

function wasmSimdSupported() {
  if (!globalThis.WebAssembly?.validate) return false;
  // Minimal valid module containing a v128 instruction.
  const bytes = new Uint8Array([0,97,115,109,1,0,0,0,1,5,1,96,0,1,123,3,2,1,0,10,22,1,20,0,253,12,...Array(16).fill(0),11]);
  try { return WebAssembly.validate(bytes); } catch { return false; }
}

function inspectWebGL() {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2', { failIfMajorPerformanceCaveat: false });
    if (!gl) return { supported: false, renderer: null, vendor: null, maxTextureSize: null };
    let renderer = null, vendor = null;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    if (ext) {
      renderer = gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || null;
      vendor = gl.getParameter(ext.UNMASKED_VENDOR_WEBGL) || null;
    }
    const result = { supported: true, renderer, vendor, maxTextureSize: gl.getParameter(gl.MAX_TEXTURE_SIZE) || null };
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return result;
  } catch { return { supported: false, renderer: null, vendor: null, maxTextureSize: null }; }
}

async function inspectWebGPU() {
  if (!navigator.gpu?.requestAdapter) return { supported: false, adapter: null, features: [] };
  try {
    const adapter = await navigator.gpu.requestAdapter({ powerPreference: 'high-performance' });
    if (!adapter) return { supported: true, adapter: null, features: [] };
    let info = null;
    try {
      const raw = typeof adapter.requestAdapterInfo === 'function' ? await adapter.requestAdapterInfo() : adapter.info;
      if (raw) info = { vendor: safe(raw.vendor), architecture: safe(raw.architecture), device: safe(raw.device), description: safe(raw.description) };
    } catch { /* Browser may intentionally hide adapter identity. */ }
    return { supported: true, adapter: info, features: [...(adapter.features || [])] };
  } catch (error) { return { supported: true, adapter: null, features: [], error: String(error?.message || error).slice(0, 180) }; }
}

async function inspectVideoCodecs() {
  const out = { webCodecs: typeof VideoDecoder !== 'undefined', h264: null, vp9: null, av1: null };
  if (!out.webCodecs || typeof VideoDecoder.isConfigSupported !== 'function') return out;
  const probes = [
    ['h264', { codec: 'avc1.42E01E', codedWidth: 640, codedHeight: 360 }],
    ['vp9', { codec: 'vp09.00.10.08', codedWidth: 640, codedHeight: 360 }],
    ['av1', { codec: 'av01.0.04M.08', codedWidth: 640, codedHeight: 360 }]
  ];
  await Promise.all(probes.map(async ([key, config]) => {
    try { const result = await VideoDecoder.isConfigSupported(config); out[key] = !!result?.supported; }
    catch { out[key] = false; }
  }));
  return out;
}

export async function collectDeviceProfile() {
  const gl = inspectWebGL();
  const [gpu, codecs, storage] = await Promise.all([
    inspectWebGPU(), inspectVideoCodecs(),
    navigator.storage?.estimate ? navigator.storage.estimate().catch(() => null) : Promise.resolve(null)
  ]);
  const memory = safe(navigator.deviceMemory);
  const profile = {
    schema: 'falco-device-profile-v1',
    engine: detectEngine(),
    userAgent: navigator.userAgent || 'unknown',
    platform: safe(navigator.userAgentData?.platform) || safe(navigator.platform),
    logicalCores: safe(navigator.hardwareConcurrency),
    deviceMemoryGiB: memory,
    memoryEstimateKind: memory ? 'navigator.deviceMemory (rounded privacy estimate)' : 'unavailable',
    jsHeap: performance.memory ? { used: performance.memory.usedJSHeapSize, limit: performance.memory.jsHeapSizeLimit } : null,
    webgpu: gpu,
    webgl2: gl,
    wasm: { supported: typeof WebAssembly !== 'undefined', simd: wasmSimdSupported() },
    webCodecs: codecs,
    workers: typeof Worker !== 'undefined',
    offscreenCanvas: typeof OffscreenCanvas !== 'undefined',
    indexedDB: typeof indexedDB !== 'undefined',
    storage: storage ? { quotaBytes: storage.quota || null, usageBytes: storage.usage || null } : null,
    connection: navigator.connection ? { effectiveType: safe(navigator.connection.effectiveType), downlinkMbps: safe(navigator.connection.downlink), saveData: !!navigator.connection.saveData } : null,
    collectedAt: new Date().toISOString()
  };
  return profile;
}

export async function benchmarkCompute(durationMs = 180) {
  if (typeof Worker === 'undefined') return { available: false, operationsPerSecond: null, method: 'main-thread benchmark disabled' };
  const worker = new Worker(new URL('./device-benchmark-worker.js', import.meta.url));
  try {
    return await new Promise((resolve, reject) => {
      const timer = setTimeout(() => { worker.terminate(); reject(new Error('Benchmark timeout')); }, 5000);
      worker.onmessage = event => { clearTimeout(timer); resolve(event.data); };
      worker.onerror = event => { clearTimeout(timer); reject(new Error(event.message || 'Benchmark worker failed')); };
      worker.postMessage({ durationMs: Math.max(80, Math.min(350, durationMs)) });
    });
  } finally { worker.terminate(); }
}

export function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes < 0) return 'не определено';
  const units = ['Б', 'КБ', 'МБ', 'ГБ']; let n = bytes, i = 0;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(i ? 1 : 0)} ${units[i]}`;
}

export function formatDuration(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return 'уточняется';
  const s = Math.round(seconds);
  if (s < 60) return `около ${s} с`;
  return `около ${Math.floor(s / 60)} мин ${String(s % 60).padStart(2, '0')} с`;
}
