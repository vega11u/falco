/** Explicit provenance registry for the currently wired browser inference ensemble. */
export const RESEARCH_C_MODEL_REGISTRY_VERSION='falco-model-registry-1.0.0';
export const RESEARCH_C_MODELS=Object.freeze({
 pose:{id:'mediapipe/pose-landmarker',label:'MediaPipe Pose Landmarker',runtime:'MediaPipe Tasks Vision',license:'Apache-2.0',role:'33-point pose and person segmentation',sha256:null,hash_status:'not-pinned-in-source-archive'},
 hands:{id:'mediapipe/hand-landmarker',label:'MediaPipe Hand Landmarker',runtime:'MediaPipe Tasks Vision',license:'Apache-2.0',role:'21 landmarks per hand',sha256:null,hash_status:'not-pinned-in-source-archive'},
 depth_base:{id:'onnx-community/depth-anything-v2-base',label:'Depth Anything V2 Base',runtime:'Transformers.js / ONNX Runtime',license:'CC-BY-NC-4.0',role:'primary relative depth'},
 depth_small:{id:'onnx-community/depth-anything-v2-small-ONNX',label:'Depth Anything V2 Small',runtime:'Transformers.js / ONNX Runtime',license:'Apache-2.0',role:'secondary relative depth'},
 depth_glpn:{id:'Xenova/glpn-nyu',label:'GLPN NYU',runtime:'Transformers.js / ONNX Runtime',license:'VERIFY_UPSTREAM',role:'indoor scene depth'},
 depth_dpt:{id:'Xenova/dpt-hybrid-midas',label:'DPT Hybrid MiDaS',runtime:'Transformers.js / ONNX Runtime',license:'VERIFY_UPSTREAM',role:'athlete ROI depth'}
});
export function researchCModelPlan({depthMode='consensus',poseBackend='mediapipe-worker',depthBackend='unknown'}={}){
 const selected=depthMode==='consensus'?['depth_base','depth_small','depth_glpn','depth_dpt']:depthMode==='base'?['depth_base']:depthMode==='small'?['depth_small']:[];
 return [{module:'pose',model:RESEARCH_C_MODELS.pose.id,backend:poseBackend,sha256:null},...selected.map(key=>({module:'depth',model:RESEARCH_C_MODELS[key].id,backend:depthBackend,license:RESEARCH_C_MODELS[key].license,sha256:null,role:RESEARCH_C_MODELS[key].role}))];
}
