# Video and YouTube import audit — v19.5.0

## Confirmed defects in v19.4
1. `prepareCanvas()` was called by multiple render paths but had no definition anywhere in the shipped source. This causes a runtime `ReferenceError` when the relevant canvas render path executes.
2. When Mediabunny could not load, the local-file pipeline marked the demuxer unavailable and blocked analysis, even when the browser's native HTML video decoder could read a normal MP4/MOV/WebM file.
3. YouTube's fallback chain repeated many yt-dlp player profiles. These mostly reused the same server IP and extractor implementation; the watchdog could spend multiple minutes on each attempt, making total wait unreasonably long without adding independent extraction capability.
4. Health diagnostics still reported old timeout values after the runner logic had evolved.

## Changes in v19.5
- Added DPR-aware `prepareCanvas()` and kept all existing drawing coordinates in CSS pixels.
- Added a browser-native metadata probe using `HTMLVideoElement.canPlayType`, temporary object URL, `loadedmetadata`, dimensions and duration. If the browser can read the file, it proceeds as an original source; if playback later fails, existing FFmpeg WASM recovery remains available.
- Kept Mediabunny as the preferred source-container inspector and frame-sample demuxer when installed.
- Simplified YouTube to a smaller, materially distinct cascade: yt-dlp nightly → YouTube.js InnerTube WEB → yt-dlp stable → curl transport retry → optional PHP progressive fallback.
- Enforced 180 seconds per attempt, 120 seconds without log activity, and 900 seconds overall. Health endpoint reports those same values.

## Verification performed
- PHP syntax check.
- JavaScript syntax checks for the page module, pose worker and Deno YouTube.js worker.
- Local-video smoke tests, including native browser fallback and presence of `prepareCanvas()`.
- Import smoke tests for URL allowlists, progress/status, cross-session concurrency, retries, transfer and cleanup.
- YouTube.js mocked-worker test (not a live YouTube download).
- Learning API, optimizer, model/data integrity and PHP fallback security tests.

## Remaining external constraints
- `canPlayType` + `loadedmetadata` verifies that the browser recognizes the container and exposes a video track; actual frame decoding is ultimately verified by `canplay` and subsequent analysis. Rare codecs or damaged files may still fail.
- YouTube can deny requests based on account/session, region, CAPTCHA, PO Token/attestation, IP reputation, or protocol changes. No library can guarantee that every public/private video will download from every shared-hosting IP.
- Direct third-party MP4 URLs still depend on CORS when fetched in the browser. YouTube/Instagram use the server importer; ordinary local files remain browser-local.
