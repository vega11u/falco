/*
 * Display-only pose interpolation and camera-relative scale estimation.
 * This module never rewrites measured landmarks or biomechanics metrics.
 */
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const median = values => {
  const a = values.filter(Number.isFinite).sort((x, y) => x - y);
  if (!a.length) return null;
  const m = Math.floor(a.length / 2);
  return a.length % 2 ? a[m] : (a[m - 1] + a[m]) * 0.5;
};
const validPoint = p => Array.isArray(p) && p.length >= 2 && Number.isFinite(p[0]) && Number.isFinite(p[1]) && (p[3] ?? 1) >= 0.08;
const dist = (a, b, aspect) => validPoint(a) && validPoint(b)
  ? Math.hypot((a[0] - b[0]) * aspect, a[1] - b[1]) : null;
const mid = (a, b) => validPoint(a) && validPoint(b)
  ? [(a[0] + b[0]) * 0.5, (a[1] + b[1]) * 0.5, 0, Math.min(a[3] ?? 1, b[3] ?? 1)] : null;

function pointConfidence(p) { return Array.isArray(p) && Number.isFinite(p[0]) && Number.isFinite(p[1]) && (p[3] ?? 1) >= 0.08; }
function monotoneTangent(d, candidate) {
  if (!Number.isFinite(d) || !Number.isFinite(candidate) || Math.abs(d) < 1e-9 || Math.sign(d) !== Math.sign(candidate)) return 0;
  return Math.sign(d) * Math.min(Math.abs(candidate), 3 * Math.abs(d));
}

/** Cubic Hermite interpolation with monotonicity limits. Safe for fast karate motion. */
export function interpolateLandmarkArray(left, right, u, options = {}) {
  if (!Array.isArray(left) || !Array.isArray(right)) return Array.isArray(left) ? left : Array.isArray(right) ? right : null;
  const { previous = null, next = null, dt = 1, dtPrevious = dt, dtNext = dt, allowCubic = true } = options;
  const n = Math.max(left.length, right.length), out = new Array(n);
  const safeDt = Number.isFinite(dt) && dt > 1e-5 ? dt : 1;
  const cubicOk = allowCubic && safeDt <= 0.20 && Array.isArray(previous) && Array.isArray(next);
  for (let i = 0; i < n; i++) {
    const a = left[i], b = right[i];
    if (pointConfidence(a) && pointConfidence(b)) {
      const result = [0, 0, 0, 1];
      for (let axis = 0; axis < 3; axis++) {
        const delta = (b[axis] - a[axis]) / safeDt;
        let value = a[axis] + (b[axis] - a[axis]) * u;
        const p = cubicOk ? previous[i] : null, q = cubicOk ? next[i] : null;
        if (pointConfidence(p) && pointConfidence(q) && Number.isFinite(p[axis]) && Number.isFinite(q[axis])) {
          const d0 = Number.isFinite(dtPrevious) && dtPrevious > 1e-5 ? dtPrevious : safeDt;
          const d1 = Number.isFinite(dtNext) && dtNext > 1e-5 ? dtNext : safeDt;
          const m0 = monotoneTangent(delta, (a[axis] - p[axis]) / d0);
          const m1 = monotoneTangent(delta, (q[axis] - b[axis]) / d1);
          const u2 = u * u, u3 = u2 * u;
          const h00 = 2 * u3 - 3 * u2 + 1, h10 = u3 - 2 * u2 + u;
          const h01 = -2 * u3 + 3 * u2, h11 = u3 - u2;
          const candidate = h00 * a[axis] + h10 * safeDt * m0 + h01 * b[axis] + h11 * safeDt * m1;
          // Clamp to the measured interval: no invented overshoot at a strike endpoint.
          value = clamp(candidate, Math.min(a[axis], b[axis]), Math.max(a[axis], b[axis]));
        }
        result[axis] = value;
      }
      result[3] = Number.isFinite(a[3]) && Number.isFinite(b[3]) ? a[3] + (b[3] - a[3]) * u : (a[3] ?? b[3] ?? 1);
      out[i] = result;
    } else if (pointConfidence(a)) out[i] = [a[0], a[1], a[2] ?? 0, (a[3] ?? 1) * 0.78];
    else if (pointConfidence(b)) out[i] = [b[0], b[1], b[2] ?? 0, (b[3] ?? 1) * 0.78];
    else out[i] = [NaN, NaN, NaN, 0];
  }
  return out;
}


/**
 * Symmetric, confidence-weighted display smoothing for image and world landmarks.
 * It is deliberately separate from frame.im/frame.w: metrics and the report continue
 * to use the unfiltered observations. Fast distal motion receives almost no smoothing.
 */
export function buildDisplayPoseTrack(frames, { aspect = 1, radius = 2, maxWindowSeconds = 0.085 } = {}) {
  if (!Array.isArray(frames) || !frames.length) return [];
  const clamp01 = value => clamp(value, 0, 1);
  const valid3 = p => Array.isArray(p) && Number.isFinite(p[0]) && Number.isFinite(p[1]) && Number.isFinite(p[2]) && (p[3] ?? 1) >= 0.08;
  const displayPoints = (frame, key) => key === 'w' ? (frame?.render_w || frame?.w) : frame?.[key];
  const torsoScale = (frame, key) => {
    const pts = displayPoints(frame, key) || [];
    const midpoint = (a, b) => valid3(pts[a]) && valid3(pts[b])
      ? pts[a].slice(0, 3).map((v, i) => (v + pts[b][i]) * 0.5) : null;
    const sh = midpoint(11, 12), hp = midpoint(23, 24);
    return sh && hp ? Math.max(0.06, Math.hypot(...sh.map((v, i) => v - hp[i]))) : (key === 'im' ? 0.22 : 0.42);
  };
  const output = frames.map((frame, index) => {
    // Time/segment checks and Gaussian weights are shared by all 66 joint tracks.
    const neighbors = [];
    for (let offset = -radius; offset <= radius; offset++) {
      if (!offset) continue;
      const other = frames[index + offset];
      if (!other || (other.camera_segment_id ?? 0) !== (frame.camera_segment_id ?? 0)) continue;
      const dt = Math.abs(Number(other.t) - Number(frame.t));
      if (dt > 0 && dt <= maxWindowSeconds) neighbors.push({ frame: other, dt, temporal: Math.exp(-0.5 * (dt / .043) ** 2) });
    }
    const result = { im: Array.isArray(frame?.im) ? frame.im.map(p => Array.isArray(p) ? p.slice() : p) : null,
      w: Array.isArray(frame?.render_w || frame?.w) ? (frame.render_w || frame.w).map(p => Array.isArray(p) ? p.slice() : p) : null };
    for (const key of ['im', 'w']) {
      const source = key === 'w' ? (frame?.render_w || frame?.w) : frame?.[key];
      if (!Array.isArray(source) || !source.length) continue;
      const target = result[key], scale = torsoScale(frame, key);
      const pointScale = key === 'im' ? Math.max(0.18, scale) : Math.max(0.08, scale);
      const maxPointDrift = pointScale * (key === 'im' ? 0.26 : 0.20);
      for (let joint = 0; joint < source.length; joint++) {
        const center = source[joint];
        if (!valid3(center)) continue;
        let weight = 1, sumX = center[0], sumY = center[1], sumZ = center[2], nearest = null, nearestDt = Infinity;
        for (const neighbor of neighbors) {
          const point = displayPoints(neighbor.frame, key)?.[joint];
          if (!valid3(point)) continue;
          const drift = Math.hypot((point[0] - center[0]) * (key === 'im' ? aspect : 1), point[1] - center[1], point[2] - center[2]);
          if (drift > maxPointDrift) continue;
          const confidence = clamp01(point[3] ?? 1), w = neighbor.temporal * confidence * confidence;
          weight += w; sumX += point[0] * w; sumY += point[1] * w; sumZ += point[2] * w;
          if (neighbor.dt < nearestDt) { nearest = point; nearestDt = neighbor.dt; }
        }
        if (!nearest) continue;
        const average = [sumX / weight, sumY / weight, sumZ / weight];
        let speed = 0;
        const leftFrame = frames[index - 1], rightFrame = frames[index + 1];
        const left = displayPoints(leftFrame, key)?.[joint], right = displayPoints(rightFrame, key)?.[joint];
        const dt = Number(rightFrame?.t) - Number(leftFrame?.t), xScale = key === 'im' ? aspect : 1;
        if (valid3(left) && valid3(right) && dt > .001 && dt <= 2 * maxWindowSeconds && (rightFrame.camera_segment_id ?? 0) === (frame.camera_segment_id ?? 0) && (leftFrame.camera_segment_id ?? 0) === (frame.camera_segment_id ?? 0)) {
          speed = Math.hypot((right[0] - left[0]) * xScale, right[1] - left[1], right[2] - left[2]) / dt;
        } else {
          speed = Math.hypot((nearest[0] - center[0]) * xScale, nearest[1] - center[1], nearest[2] - center[2]) / Math.max(.001, nearestDt);
        }
        const normalizedSpeed = speed / pointScale;
        const smoothing = 0.28 * (1 - clamp01(normalizedSpeed / 4.8));
        target[joint] = [...center.slice(0, 3).map((v, axis) => v + (average[axis] - v) * smoothing), center[3] ?? 1];
      }
    }
    return result;
  });
  return output;
}

function sceneFeatures(frame, aspect) {
  const p = frame?.im || [];
  const w = frame?.w || [];
  const sh = mid(p[11], p[12]), hp = mid(p[23], p[24]);
  const image = {
    head_width: dist(p[7], p[8], aspect),
    shoulder_width: dist(p[11], p[12], aspect),
    hip_width: dist(p[23], p[24], aspect),
    torso_length: dist(sh, hp, aspect),
    left_thigh: dist(p[23], p[25], aspect),
    right_thigh: dist(p[24], p[26], aspect),
    left_shin: dist(p[25], p[27], aspect),
    right_shin: dist(p[26], p[28], aspect)
  };
  const validWorld = x => Array.isArray(x) && x.length >= 3 && x.slice(0, 3).every(Number.isFinite) && (x[3] ?? 1) >= 0.08;
  const worldDist = (a, b) => validWorld(w[a]) && validWorld(w[b])
    ? Math.hypot(w[a][0] - w[b][0], w[a][1] - w[b][1], w[a][2] - w[b][2]) : null;
  const worldMidDist = (a, b, c, d) => {
    if (![a, b, c, d].every(validWorld)) return null;
    const ma = [(w[a][0] + w[b][0]) * 0.5, (w[a][1] + w[b][1]) * 0.5, (w[a][2] + w[b][2]) * 0.5];
    const mb = [(w[c][0] + w[d][0]) * 0.5, (w[c][1] + w[d][1]) * 0.5, (w[c][2] + w[d][2]) * 0.5];
    return Math.hypot(ma[0] - mb[0], ma[1] - mb[1], ma[2] - mb[2]);
  };
  const world = {
    head_width: worldDist(7, 8),
    shoulder_width: worldDist(11, 12),
    hip_width: worldDist(23, 24),
    torso_length: worldMidDist(11, 12, 23, 24),
    left_thigh: worldDist(23, 25),
    right_thigh: worldDist(24, 26),
    left_shin: worldDist(25, 27),
    right_shin: worldDist(26, 28)
  };
  const result = {};
  for (const [key, value] of Object.entries(image)) {
    if (Number.isFinite(value) && value >= 0.008 && value <= 0.75) result[`im_${key}`] = value;
    const worldLength = world[key];
    // A matched image/world segment gives a perspective scale proxy. MediaPipe's 3D
    // landmarks compensate for segment foreshortening better than image width alone.
    if (Number.isFinite(value) && Number.isFinite(worldLength) && worldLength >= 0.025 && worldLength <= 2.2) {
      const ratio = value / worldLength;
      if (Number.isFinite(ratio) && ratio > 0.002 && ratio < 3) result[`cam_${key}`] = ratio;
    }
  }
  return result;
}

/**
 * Estimates only relative camera distance from apparent body scale.
 * scale > 1 means the athlete appears larger/closer than the segment median.
 * It is not metric depth and is not used by the measured biomechanics.
 */
export function estimateRelativeSceneDepth(frames, aspect = 1, sceneContext = {}) {
  const rows = Array.isArray(frames) ? frames : [];
  if (!rows.length) return [];
  const safeAspect = clamp(Number(aspect) || 1, 0.25, 4);
  const groups = new Map();
  const perspectiveBySegment = sceneContext?.perspectiveBySegment || {};
  const supportTrack = Array.isArray(sceneContext?.supportTrack) ? sceneContext.supportTrack : [];
  const features = rows.map(f => {
    const out = sceneFeatures(f, safeAspect);
    const seg = f?.camera_segment_id ?? 0;
    const perspective = perspectiveBySegment[seg] || perspectiveBySegment[String(seg)] || sceneContext?.perspective || null;
    const horizon = perspective?.horizon_y_normalized == null ? NaN : Number(perspective.horizon_y_normalized);
    const sampleIndex = Number.isInteger(f?.sample_index) ? f.sample_index : -1;
    const support = sampleIndex >= 0 ? supportTrack[sampleIndex] : null;
    if (perspective?.detected && Number(perspective?.confidence) >= .40 && Number.isFinite(horizon) && horizon >= 0 && horizon <= 1 && support && Number(support.confidence) >= .58 && ['left','right'].includes(support.side)) {
      const ankleId = support.side === 'left' ? 27 : 28;
      const ankle = f?.im?.[ankleId];
      if (Array.isArray(ankle) && Number.isFinite(ankle[1]) && (ankle[3] ?? 1) >= .38 && ankle[1] > horizon + .018) {
        // On a visible ground plane, distance from the horizon is a weak inverse-depth cue.
        // It is fused at low weight only for a confidently supported foot; it is not metric depth.
        const offset = ankle[1] - horizon;
        if (offset >= .025 && offset <= .8) out.persp_support_horizon_offset = offset;
      }
    }
    return out;
  });
  for (let i = 0; i < rows.length; i++) {
    const id = rows[i]?.camera_segment_id ?? 0;
    if (!groups.has(id)) groups.set(id, []);
    groups.get(id).push(i);
  }
  const baselineBySegment = new Map();
  for (const [id, indices] of groups) {
    const keys = new Set(indices.flatMap(i => Object.keys(features[i])));
    const baselines = {};
    for (const key of keys) baselines[key] = median(indices.map(i => features[i][key]).filter(Number.isFinite));
    baselineBySegment.set(id, baselines);
  }
  const raw = rows.map((frame, i) => {
    const baseline = baselineBySegment.get(frame?.camera_segment_id ?? 0) || {};
    const normalized = Object.entries(features[i]).map(([key, value]) => ({ key, value: baseline[key] > 0 ? value / baseline[key] : null })).filter(x => Number.isFinite(x.value) && x.value >= 0.52 && x.value <= 1.9);
    const cameraRatios = normalized.filter(x => x.key.startsWith('cam_')).map(x => x.value);
    const imageRatios = normalized.filter(x => x.key.startsWith('im_')).map(x => x.value);
    const perspectiveRatios = normalized.filter(x => x.key.startsWith('persp_')).map(x => x.value);
    const cameraScale = cameraRatios.length >= 3 ? median(cameraRatios) : null;
    const imageScale = imageRatios.length >= 2 ? median(imageRatios) : null;
    // Prefer matched 2D/3D segment ratios when enough tracked joints are reliable.
    // Blend the apparent-size fallback only when both channels agree on direction and magnitude.
    let scale, chosenRatios, source;
    if (cameraScale != null && imageScale != null && Math.abs(cameraScale - imageScale) <= 0.24) {
      scale = cameraScale * 0.72 + imageScale * 0.28;
      chosenRatios = [...cameraRatios, ...imageRatios]; source = 'world-normalized projection + apparent body scale';
    } else if (cameraScale != null) {
      scale = cameraScale; chosenRatios = cameraRatios; source = 'world-normalized projection scale';
    } else if (imageScale != null) {
      scale = imageScale; chosenRatios = imageRatios; source = 'apparent body scale fallback';
    } else {
      scale = 1; chosenRatios = []; source = 'insufficient landmarks';
    }
    const perspectiveScale = perspectiveRatios.length ? median(perspectiveRatios) : null;
    let perspectiveFused = false;
    if (Number.isFinite(perspectiveScale) && perspectiveRatios.length >= 1 && chosenRatios.length >= 2) {
      // Background geometry is deliberately a weak prior: pose/world scale remains dominant.
      scale = scale * .88 + clamp(perspectiveScale, .78, 1.28) * .12;
      chosenRatios = [...chosenRatios, ...perspectiveRatios];
      source += ' + low-weight supported-foot/horizon cue';
      perspectiveFused = true;
    }
    scale = clamp(scale, 0.72, 1.38);
    const spread = chosenRatios.length ? median(chosenRatios.map(v => Math.abs(v - median(chosenRatios)))) : null;
    const consistency = spread == null ? 0 : clamp(1 - spread / 0.28, 0, 1);
    const coverage = clamp(chosenRatios.length / (source.startsWith('world') ? 6 : 5), 0, 1);
    return { scale, confidence: Number((coverage * consistency * (perspectiveFused ? .92 : 1)).toFixed(3)), features_used: chosenRatios.length, world_features_used: cameraRatios.length, image_features_used: imageRatios.length, perspective_features_used: perspectiveRatios.length, perspective_fused: perspectiveFused, source, camera_segment_id: frame?.camera_segment_id ?? 0 };
  });
  // Short median filter smooths body-scale jitter but never crosses a cut.
  return raw.map((entry, i) => {
    const values = [];
    for (let j = Math.max(0, i - 2); j <= Math.min(raw.length - 1, i + 2); j++) {
      if (raw[j].camera_segment_id === entry.camera_segment_id && raw[j].features_used >= 2) values.push(raw[j].scale);
    }
    const scale = values.length >= 2 ? median(values) : entry.scale;
    return {
      scale: Number(scale.toFixed(4)),
      relative_distance: Number((1 / scale).toFixed(4)),
      confidence: entry.confidence,
      features_used: entry.features_used,
      world_features_used: entry.world_features_used,
      image_features_used: entry.image_features_used,
      perspective_features_used: entry.perspective_features_used || 0,
      perspective_fused: entry.perspective_fused === true,
      source: entry.source,
      camera_segment_id: entry.camera_segment_id,
      method: 'matched 2D/3D body-segment projection scale with per-camera-segment median normalization; apparent-size fallback; weak sparse-background perspective cue only when support foot and horizon are reliable'
    };
  });
}

export function assertDepthSeriesValid(series) {
  return Array.isArray(series) && series.every(x => Number.isFinite(x.scale) && x.scale >= 0.72 && x.scale <= 1.38 && Number.isFinite(x.relative_distance) && x.relative_distance > 0 && Number.isFinite(x.confidence) && x.confidence >= 0 && x.confidence <= 1);
}

/**
 * Per-part depth relative to the athlete's own torso / pelvis reference planes.
 * Positive values are farther from the camera, negative values closer. Pose world
 * landmarks are preferred; image-z is explicitly a lower-confidence fallback.
 * Hand world landmarks are local to the hand, so their offsets are attached to the
 * matched Pose wrist before comparing them with the chest plane.
 */
export function estimateBodyPartDepth(frame) {
  const im = Array.isArray(frame?.im) ? frame.im : [];
  const world = Array.isArray(frame?.w) ? frame.w : [];
  const finite = (p, dims = 3, min = 0.12) => Array.isArray(p) && p.length >= dims && p.slice(0, dims).every(Number.isFinite) && (p[3] ?? 1) >= min;
  const avg = (a, b) => finite(a) && finite(b) ? [
    (a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2,
    Math.min(a[3] ?? 1, b[3] ?? 1)
  ] : null;
  const length = (a, b, dims) => finite(a, dims) && finite(b, dims)
    ? Math.hypot(...Array.from({ length: dims }, (_, k) => a[k] - b[k])) : null;
  const worldSpace = [11, 12, 23, 24].every(i => finite(world[i]));
  const points = worldSpace ? world : im;
  const dims = 3;
  const chest = avg(points[11], points[12]);
  const pelvis = avg(points[23], points[24]);
  const torsoLength = chest && pelvis ? (worldSpace ? length(chest, pelvis, 3) : length(chest, pelvis, 2)) : null;
  const usableScale = Number.isFinite(torsoLength) && torsoLength > (worldSpace ? 0.08 : 0.03) ? torsoLength : null;
  const directionOf = value => !Number.isFinite(value) ? 'unknown' : value > .055 ? 'farther_from_camera' : value < -.055 ? 'closer_to_camera' : 'near_reference_plane';
  const depth = (point, reference = chest) => {
    if (!usableScale || !finite(point, 3) || !finite(reference, 3)) return null;
    return Number(((point[2] - reference[2]) / usableScale).toFixed(4));
  };
  const detail = (point, reference = chest) => {
    const value = depth(point, reference);
    return { depth_torso_lengths: value, direction: directionOf(value), confidence: value == null ? 0 : Math.min(point?.[3] ?? 1, reference?.[3] ?? 1) * (worldSpace ? .84 : .48) };
  };
  const body = {
    head: detail(points[0]),
    chest: { depth_torso_lengths: 0, direction: 'reference_plane', confidence: chest ? (worldSpace ? .84 : .48) : 0 },
    pelvis: detail(pelvis),
    torso_length: usableScale,
    source: worldSpace ? 'pose_world_landmarks' : 'pose_image_z'
  };
  const sideIds = {
    left: { shoulder: 11, elbow: 13, wrist: 15, hip: 23, knee: 25, ankle: 27, heel: 29, toe: 31 },
    right: { shoulder: 12, elbow: 14, wrist: 16, hip: 24, knee: 26, ankle: 28, heel: 30, toe: 32 }
  };
  const parts = {};
  for (const [side, ids] of Object.entries(sideIds)) {
    const record = {};
    for (const name of ['shoulder', 'elbow', 'wrist']) record[name] = detail(points[ids[name]], chest);
    for (const name of ['hip', 'knee', 'ankle', 'heel', 'toe']) record[name] = detail(points[ids[name]], pelvis || chest);

    const hand = (frame?.hands || []).find(h => {
      if (h.pose_side === side) return true;
      if (h.pose_side === 'left' || h.pose_side === 'right') return false;
      const hw = h.landmarks?.[0], leftWrist = im[15], rightWrist = im[16];
      const valid2 = p => Array.isArray(p) && p.slice(0, 2).every(Number.isFinite) && (p[3] ?? 1) >= .12;
      if (!valid2(hw)) return false;
      const dL = valid2(leftWrist) ? Math.hypot(hw[0] - leftWrist[0], hw[1] - leftWrist[1]) : Infinity;
      const dR = valid2(rightWrist) ? Math.hypot(hw[0] - rightWrist[0], hw[1] - rightWrist[1]) : Infinity;
      return Math.min(dL, dR) <= .32 && Math.abs(dL - dR) >= .012 && (dL <= dR ? 'left' : 'right') === side;
    });
    const handWorld = hand?.world_landmarks || [];
    const handImage = hand?.landmarks || [];
    const wrist = points[ids.wrist];
    const handDepths = [];
    if (worldSpace && finite(wrist) && handWorld.length >= 21 && finite(handWorld[0])) {
      const origin = handWorld[0];
      for (let i = 0; i < 21; i++) {
        const q = handWorld[i];
        if (!finite(q)) { handDepths.push(null); continue; }
        const attached = [wrist[0] + q[0] - origin[0], wrist[1] + q[1] - origin[1], wrist[2] + q[2] - origin[2], Math.min(wrist[3] ?? 1, q[3] ?? 1)];
        handDepths.push(depth(attached, chest));
      }
    } else if (!worldSpace && finite(wrist) && handImage.length >= 21 && finite(handImage[0])) {
      // The hand's image-z is wrist-relative. Normalize it by projected torso length.
      for (const q of handImage) handDepths.push(finite(q) ? Number((((wrist[2] - chest[2]) + (q[2] - handImage[0][2])) / usableScale).toFixed(4)) : null);
    }
    const fingerNames = ['thumb_tip', 'index_tip', 'middle_tip', 'ring_tip', 'pinky_tip'];
    const fingerIds = [4, 8, 12, 16, 20];
    record.hand = detail(points[ids.wrist], chest);
    record.thumb_tip = handDepths[4] == null ? null : { depth_torso_lengths: handDepths[4], direction: directionOf(handDepths[4]), confidence: worldSpace ? .78 : .40 };
    for (let i = 1; i < fingerNames.length; i++) {
      const value = handDepths[fingerIds[i]];
      record[fingerNames[i]] = value == null ? null : { depth_torso_lengths: value, direction: directionOf(value), confidence: worldSpace ? .78 : .40 };
    }
    record.fingers = handDepths.map((value, index) => value == null ? null : ({ landmark: index, depth_torso_lengths: value, direction: directionOf(value), confidence: worldSpace ? .78 : .40 }));
    const wristDepth = record.wrist.depth_torso_lengths;
    const validDepths = [record.shoulder, record.elbow, record.wrist, record.index_tip].map(x => x?.depth_torso_lengths).filter(Number.isFinite);
    record.wrist_direction = directionOf(wristDepth);
    record.wrist_vs_chest_torso_lengths = wristDepth;
    record.depth_span_torso_lengths = validDepths.length >= 2 ? Number((Math.max(...validDepths) - Math.min(...validDepths)).toFixed(4)) : null;
    record.confidence = record.wrist.confidence * Math.min(1, validDepths.length / 4);
    record.source = worldSpace ? 'world-space part depth relative to chest / pelvis plane' : 'normalized landmark z fallback relative to chest / pelvis plane';
    parts[side] = record;
  }
  return {
    schema: 'falco-body-part-depth-v2',
    camera_segment_id: frame?.camera_segment_id ?? 0,
    source: worldSpace ? 'pose_world_landmarks_plus_hand_world' : 'pose_image_z_fallback',
    units: 'torso_lengths',
    sign: 'positive = farther from camera; negative = closer to camera',
    reference_planes: { chest, pelvis },
    body,
    parts
  };
}

/**
 * Frame-aligned per-part depth + depth velocity. Derivatives are computed only inside
 * the same camera segment and short timestamp gaps; cuts/large gaps remain unknown.
 */
export function estimateBodyPartDepthSeries(frames) {
  const rows=Array.isArray(frames)?frames:[];
  const profiles=rows.map(estimateBodyPartDepth);
  const estimateVelocity=(i,getter)=>{
    const cur=rows[i],id=cur?.camera_segment_id??0;
    let a=i-1,b=i+1;
    if(a<0||(rows[a]?.camera_segment_id??0)!==id||!(Number(cur.t)-Number(rows[a]?.t)>0)||Number(cur.t)-Number(rows[a]?.t)>.18)a=-1;
    if(b>=rows.length||(rows[b]?.camera_segment_id??0)!==id||!(Number(rows[b]?.t)-Number(cur.t)>0)||Number(rows[b]?.t)-Number(cur.t)>.18)b=-1;
    if(a>=0&&b>=0){const va=getter(profiles[a]),vb=getter(profiles[b]),dt=Number(rows[b].t)-Number(rows[a].t);return Number.isFinite(va)&&Number.isFinite(vb)&&dt>0?(vb-va)/dt:null;}
    if(a>=0){const va=getter(profiles[a]),vc=getter(profiles[i]),dt=Number(cur.t)-Number(rows[a].t);return Number.isFinite(va)&&Number.isFinite(vc)&&dt>0?(vc-va)/dt:null;}
    if(b>=0){const vc=getter(profiles[i]),vb=getter(profiles[b]),dt=Number(rows[b].t)-Number(cur.t);return Number.isFinite(vc)&&Number.isFinite(vb)&&dt>0?(vb-vc)/dt:null;}
    return null;
  };
  const direction=v=>!Number.isFinite(v)?'unknown':v>.12?'moving_away_from_camera':v<-.12?'moving_toward_camera':'depth_stable';
  for(let i=0;i<profiles.length;i++){
    const profile=profiles[i];
    for(const side of ['left','right']){
      const part=profile.parts?.[side];if(!part)continue;
      for(const key of ['shoulder','elbow','wrist','hand','thumb_tip','index_tip','middle_tip','ring_tip','pinky_tip','hip','knee','ankle','heel','toe']){
        const detail=part[key];if(!detail||!Number.isFinite(detail.depth_torso_lengths))continue;
        const velocity=estimateVelocity(i,p=>p.parts?.[side]?.[key]?.depth_torso_lengths);
        detail.depth_velocity_torso_lengths_s=Number.isFinite(velocity)?Number(velocity.toFixed(4)):null;
        detail.depth_trend=direction(velocity);
      }
      if(Array.isArray(part.fingers))for(let j=0;j<part.fingers.length;j++){
        const finger=part.fingers[j];if(!finger||!Number.isFinite(finger.depth_torso_lengths))continue;
        const velocity=estimateVelocity(i,p=>p.parts?.[side]?.fingers?.[j]?.depth_torso_lengths);
        finger.depth_velocity_torso_lengths_s=Number.isFinite(velocity)?Number(velocity.toFixed(4)):null;
        finger.depth_trend=direction(velocity);
      }
    }
  }
  return profiles;
}

