# Falco Jugger 23.0.26.1 — Monteverdi tri-class and personal 3D archive

## Required baseline
Exactly version **23.0.26**, installed using `falco_jugger_patch_23.0.26_UI_SILHOUETTE_OVER_23.0.25_HOST0.zip` atop 23.0.25 GLOBAL_EVOLUTION. The installer checks 10 known baseline file hashes and refuses mismatched builds. Do NOT apply 23.0.25.4 first.

## Changes
* Monteverdi now offers exactly three labels for existing fast-motion candidates: **Быстрое движение с кимэ**, **Быстрое движение, кимэ нет**, **Это не быстрое движение**. Neither the model nor the UI injects deliberately slow movements into annotation.
* Training is divided into (a) fast/slow candidate detection, using all three choices including `not_fast`, and (b) kime ending coordination for the two `fast_*` choices only. Existing legacy `yes/no` reviews retain their agree/disagree-with-prediction meaning. Deterministic validation and conservative activation.
* The **23.0.26 inline kime replay**, seek bar and contribution to total score are preserved. Buttons use the three new ground-truth labels.
* Server reports now store a personal 3D archive: quantized mesh snapshots (up to ~200 512-vertex keyframes), the original per-frame 3D joint track, measured body shape profile, plus v23.0.26's losslessly compressed **per-frame athlete silhouette masks**; old reports are readable without fabricating a personal surface. Browser restore also retains the body profile and 3D archive.
* Models and Memories show archived 3D status. Archived playback uses Vivaldi surface geometry, with an explicit no-model message rather than stickman when an old archive lacks a personal mesh.
* The 23.0.26 Aero layout, silhouette-constrained 2D mesh, 3D renderer, live pipeline journal, Purcell view and kime-weighted score are retained. A small new CSS stylesheet makes tri-class feedback buttons responsive.

## Limitations
* Stored 3D mesh is an individualized **geometric** reconstruction derived from pose/silhouette evidence; it is not a photogrammetric scan or verified neural cloth fitting.
* Personal 3D mesh keyframes cannot be manufactured from past 33-point-only archives. Reanalyse the original video to create them.
* New report saving requires enough observed world landmarks and reliable personalized silhouette widths to construct an actual personal mesh; on insufficient input it fails visibly rather than storing a stickman under a new schema.
* Training/real-video performance and visual quality require the user's validation on real footage.

## User data policy
This patch does not install, overwrite, delete, migrate, or reset `data/`, `vendor/`, training libraries, private reports, cookies or configuration.

## Installation
Place the ZIP in the site root and run in ONE shell line:
```bash
cd "$HOME/www/falcojugger.art" && mkdir -p /tmp/fj261 && unzip -o falco_jugger_patch_23.0.26.1_TRICLASS_PERSONAL3D_OVER_23.0.26_HOST0.zip -d /tmp/fj261 >/dev/null && bash /tmp/fj261/install-host0-patch-23.0.26.1.sh "$HOME/www/falcojugger.art"
```
Press HARD UPDATE after installation.
