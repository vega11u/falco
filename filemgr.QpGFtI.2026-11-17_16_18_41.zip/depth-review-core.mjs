/* Falco 23.0.4 · conservative pose-depth review triggers.
   Heuristics are warnings, not proof of tracking failure; legitimate kicks are not rejected. */
const WATCH = [0,11,12,13,14,15,16,23,24,25,26,27,28,29,30,31,32];
const EDGES = [[11,13],[13,15],[12,14],[14,16],[23,25],[25,27],[24,26],[26,28],[27,31],[28,32]];
const xy = p => Array.isArray(p) && Number.isFinite(p[0]) && Number.isFinite(p[1]);
const vis = p => Number.isFinite(p?.[3]) ? p[3] : 1;
const dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
export const REVIEW_REASONS = Object.freeze({
  missing_pose:'Поза не обнаружена или обрезана',
  low_visibility:'Слабая видимость суставов',
  out_of_frame:'Сустав за границей кадра',
  off_body_limb:'Кисть или стопа обнаружена далеко от тела (фон / трибуны)',
  sudden_jump:'Неправдоподобный скачок сустава между соседними кадрами',
  limb_length_jump:'Внезапное изменение длины кости на изображении',
  broken_limb:'Разрыв или непропорциональная длина звена конечности',
  missing_heel:'Пятка потеряна при видимой стопе',
  toe_only:'Аватар выглядит стоящим на носке без убедительного движения',
  heel_toe_conflict:'Пятка и носок дают противоречивую геометрию',
  swapped_sides:'Подозрительная перестановка левой и правой стороны',
  strong_occlusion:'Перекрытие тела / частичная потеря скелета',
  fast_motion:'Очень быстрое движение, вероятен смазанный кадр',
  depth_discontinuity:'Сильный скачок глубины в соседних кадрах',
  model_disagreement:'Small и Base существенно расходятся в оценке глубины',
  background_confusion:'Сустав расположен вне разумной области спортсмена',
  feet_ground_conflict:'Стопа пересекает визуальную плоскость пола',
  abrupt_camera:'Возможная смена камеры или масштаба',
});
export function inspectPoseForDepthReview(points,previous=null,deltaS=1/30) {
  const reasons=new Set(), evidence={};
  if(!Array.isArray(points)||points.filter(xy).length<15)return {uncertain:true,priority:'critical',reasons:['missing_pose'],evidence};
  const core=[11,12,23,24].filter(i=>xy(points[i]));
  if(core.length<3)return {uncertain:true,priority:'critical',reasons:['strong_occlusion'],evidence};
  const shoulder=(dist(points[11],points[12])||.12), hips=xy(points[23])&&xy(points[24])?dist(points[23],points[24]):shoulder;
  const height=xy(points[11])&&xy(points[23])?dist(points[11],points[23]):.23;
  const scale=Math.max(.06,shoulder,hips,height);
  evidence.body_scale=+scale.toFixed(4);
  let weak=0,missing=0;
  for(const i of WATCH){const p=points[i];if(!xy(p)){missing++;continue;}if(vis(p)<.35)weak++;if(p[0]<-.08||p[0]>1.08||p[1]<-.08||p[1]>1.08)reasons.add('out_of_frame');}
  if(missing>=4)reasons.add('strong_occlusion');
  if(weak>=4)reasons.add('low_visibility');
  for(const [a,b] of EDGES){const p=points[a],q=points[b];if(!xy(p)||!xy(q))continue;const ratio=dist(p,q)/scale;
    if(ratio>3.6 && vis(p)>.4 && vis(q)>.4)reasons.add('broken_limb');
    if(Array.isArray(previous)&&xy(previous[a])&&xy(previous[b])){
      const prior=dist(previous[a],previous[b]);if(prior>.025&&dist(p,q)>0&&Math.abs(dist(p,q)-prior)/prior>1.4)reasons.add('limb_length_jump');
    }
  }
  const chest=[11,12,23,24].map(i=>points[i]).filter(xy);
  const middle=[chest.reduce((a,p)=>a+p[0],0)/chest.length,chest.reduce((a,p)=>a+p[1],0)/chest.length];
  for(const i of [15,16,27,28,29,30,31,32]){const p=points[i];if(xy(p)&&vis(p)>.4&&dist(p,middle)>scale*5.7)reasons.add('off_body_limb');}
  for(const [heel,toe,ankle] of [[29,31,27],[30,32,28]]){
    if(!xy(points[heel])&&xy(points[toe]))reasons.add('missing_heel');
    if(xy(points[heel])&&xy(points[toe])&&xy(points[ankle])){
      const ft=dist(points[heel],points[toe]);
      if(ft>scale*2.2 || ft<scale*.025)reasons.add('heel_toe_conflict');
      const heelLift=points[heel][1]-points[toe][1];
      // Image y grows downwards. A large persistent heel-above-toe offset is *suspect*, never definitive.
      if(heelLift<-.40*scale && Math.abs(points[heel][0]-points[toe][0])<scale*.55 && vis(points[heel])>.5 && vis(points[toe])>.5)reasons.add('toe_only');
    }
  }
  if(Array.isArray(previous)){
    const dt=Math.max(.012,Number(deltaS)||1/30);let jumps=0;
    for(const i of WATCH){if(!xy(points[i])||!xy(previous[i])||Math.min(vis(points[i]),vis(previous[i]))<.2)continue;
      if(dist(points[i],previous[i])/scale>Math.max(1.15,dt*16))jumps++;}
    if(jumps>=1)reasons.add('sudden_jump');
    if(jumps>=5)reasons.add('abrupt_camera');
    if(jumps>=3)reasons.add('fast_motion');
    if(xy(points[15])&&xy(previous[16])&&xy(points[16])&&xy(previous[15])){
      const swapped=dist(points[15],previous[16])+dist(points[16],previous[15]);
      const consistent=dist(points[15],previous[15])+dist(points[16],previous[16]);
      if(swapped<consistent*.40&&consistent>.12)reasons.add('swapped_sides');
    }
  }
  const found=[...reasons];
  return {uncertain:found.length>0,priority:found.some(x=>['off_body_limb','sudden_jump','toe_only','missing_heel','out_of_frame','broken_limb','missing_pose','feet_ground_conflict'].includes(x))?'critical':'review',reasons:found,evidence};
}
