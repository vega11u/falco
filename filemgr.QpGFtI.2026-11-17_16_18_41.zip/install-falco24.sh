#!/usr/bin/env bash
# Deprecated compatibility entry point. Do not run the old 24.x overlay installer.
set -Eeuo pipefail
cat >&2 <<'EOF'
Falco 24.x installer is retired.

Extract Falco_Jugger_25.0.0_Neo_Aero_Full_Update.zip to a temporary directory,
then run install-falco25.sh from that extracted package with --source and --target.
The package manifest must remain beside install-falco25.sh during installation.
EOF
exit 2
