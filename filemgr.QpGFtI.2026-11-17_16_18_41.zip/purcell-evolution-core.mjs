/** Falco 23.0.14: bounded, seeded kinematic hill climbing.
 * Never claims Isaac Gym/OpenSim forward simulation or guaranteed 100/100.
 * The optimizer searches *hypotheses* under hard geometry/contact constraints.
 */
import {evaluateMovementQuality} from './movement-quality-core.mjs';
import {evaluateSpatialGravity,spatialReadiness} from './purcell-spatial-core.mjs';
const cl=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const ok=(p,d=2)=>Array.isArray(p)&&p.length>=d&&p.slice(0,d).every(Number.isFinite)&&(p[3]??1)>=.18;
const chains={left_arm:[11,13,15,17,19,21],right_arm:[12,14,16,18,20,22],left_leg:[23,25,27,29,31],right_leg:[24,26,28,30,32],trunk:[11,12,13,14,15,16]};
const bones=[[11,13],[13,15],[12,14],[14,16],[23,25],[25,27],[24,26],[26,28],[11,23],[12,24],[23,24]];
const degrees=(a,b,c,d)=>{const p=a?.[b],q=a?.[c],r=a?.[d];if(!ok(p)||!ok(q)||!ok(r))return null;const v=[p[0]-q[0],p[1]-q[1]],w=[r[0]-q[0],r[1]-q[1]],den=Math.hypot(...v)*Math.hypot(...w);return den>.0001?Math.acos(cl((v[0]*w[0]+v[1]*w[1])/den,-1,1))*180/Math.PI:null;};
const distance=(a,b,d)=>Math.hypot(...Array.from({length:d},(_,k)=>a[k]-b[k]));
function rng(seed){let s=(Number(seed)>>>0)||0xa1b2c3d4;return ()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return (s>>>0)/4294967296;};}
const copy=frames=>frames.map(f=>({...f,im:(f.im||[]).map(p=>Array.isArray(p)?p.slice():p),w:(f.w||[]).map(p=>Array.isArray(p)?p.slice():p)}));
export function initialGenome(seed){const random=rng(seed);return Object.keys(chains).map((chain,i)=>({chain,angle:(random()-.5)*.085,phase:(random()-.5)*.18,twist:(random()-.5)*.07,profile:.75+random()*1.3,axis:Math.floor(random()*3),level:random()*.60}));}
export function mutateGenome(genome,random,step=.8){const next=genome.map(x=>({...x})),i=Math.floor(random()*next.length),which=Math.floor(random()*6),p=next[i];if(which===0)p.angle=cl(p.angle+(random()-.5)*.12*step,-.24,.24);else if(which===1)p.phase=cl(p.phase+(random()-.5)*.16*step,-.20,.20);else if(which===2)p.twist=cl(p.twist+(random()-.5)*.10*step,-.16,.16);else if(which===3)p.profile=cl(p.profile+(random()-.5)*.65*step,.55,2.6);else if(which===4)p.level=cl(p.level+(random()-.5)*.45*step,0,1);else p.axis=Math.floor(random()*3);return next;}
function rotate3(v,angle,axis){const a=v[axis],b=v[(axis+1)%3],c=Math.cos(angle),s=Math.sin(angle);const out=v.slice();out[axis]=a*c-b*s;out[(axis+1)%3]=a*s+b*c;return out;}
export function applyGenome(base,genome,{modality='2d'}={}){
 if(!Array.isArray(base)||base.length<7)throw Error('Training requires >=7 frames');const result=copy(base),n=base.length;
 for(let j=1;j<n-1;j++){
  const f=result[j],dt=(j/(n-1));let projectionScale=.50;
  const a=f.im?.[11],b=f.im?.[12],wa=f.w?.[11],wb=f.w?.[12];
  if([a,b,wa,wb].every(p=>ok(p))){const pw=distance(wa,wb,3);if(pw>.08)projectionScale=cl(distance(a,b,2)/pw,.18,1.2);}
  for(const op of genome){if(op.level<=.02)continue;
   const u=cl(dt-op.phase,.0,1),envelope=Math.sin(Math.PI*u)**op.profile*op.level;
   if(!(envelope>.00001))continue;
   const ids=chains[op.chain],root=f.im?.[ids[0]],rootW=f.w?.[ids[0]],angle=op.angle*envelope,twist=op.twist*envelope;
   if(!ok(root))continue;
   // Shoulder/hip anchor preserved, distal links rotated rigidly about a root.
   for(let k=1;k<ids.length;k++){
    const id=ids[k];if((op.chain.includes('leg')&&id>=27)||((op.chain==='trunk')&&id>=23))continue;
    const p=f.im?.[id];if(!ok(p))continue;
    const ratio=k===1?.56:k===2?.83:1;
    const dx=p[0]-root[0],dy=p[1]-root[1],ang=angle*ratio;
    const x=root[0]+dx*Math.cos(ang)-dy*Math.sin(ang),y=root[1]+dx*Math.sin(ang)+dy*Math.cos(ang);
    p[0]=cl(x,.005,.995);p[1]=cl(y,.005,.995);
    const q=f.w?.[id];if(ok(rootW,3)&&ok(q,3)){
     const w=[q[0]-rootW[0],q[1]-rootW[1],q[2]-rootW[2]],rot=rotate3(w,ang,op.axis);
     for(let d=0;d<3;d++)q[d]=rootW[d]+rot[d];
     // Small out-of-plane perturbations require real 3D; no invented depth for 2D-only.
     if(modality==='3d'&&twist){const r=rotate3([q[0]-rootW[0],q[1]-rootW[1],q[2]-rootW[2]],twist,2);for(let d=0;d<3;d++)q[d]=rootW[d]+r[d];}
    }
   }
  }
 }
 return result;
}
function angularDeviation(base,frames){let n=0,max=0,sum=0;const pairs=[[11,13,15],[12,14,16],[23,25,27],[24,26,28]];
 for(let i=0;i<frames.length;i+=Math.max(1,Math.floor(frames.length/48)))for(const [a,b,c] of pairs){const orig=degrees(base[i].im,a,b,c),next=degrees(frames[i].im,a,b,c);if(orig==null||next==null)continue;const e=Math.abs(next-orig);max=Math.max(max,e);sum+=e;n++;}
 return {max,mean:n?sum/n:0};}
/** Check all deformation constraints before scoring; nothing can be optimized by breaking anatomy. */
export function validateHypothesis(base,frames,{requireWorld=false}={}){
 let n=0,err=0,errMax=0,clipped=0,footDrift=0,feet=0;
 for(let i=0;i<frames.length;i++){
  const a=base[i],b=frames[i];for(const field of ['im','w']){
   const d=field==='im'?2:3;
   for(const [p,q] of bones){const x=a[field]?.[p],y=a[field]?.[q],u=b[field]?.[p],v=b[field]?.[q];if(![x,y,u,v].every(z=>ok(z,d)))continue;const original=distance(x,y,d),now=distance(u,v,d);if(original<.03)continue;const delta=Math.abs(now-original)/original;err+=delta;errMax=Math.max(errMax,delta);n++;}}
  for(let id=0;id<33;id++){const p=b.im?.[id];if(ok(p)&&(p[0]<=.0051||p[0]>=.9949||p[1]<=.0051||p[1]>=.9949))clipped++;}
  for(const id of [27,28,29,30,31,32]){const p=a.im?.[id],q=b.im?.[id];if(ok(p)&&ok(q)){footDrift=Math.max(footDrift,distance(p,q,2));feet++;}}
 }
 const angles=angularDeviation(base,frames),meanError=n?err/n:0,worldCoverage=frames.length?frames.filter(f=>[11,12,23,24].every(i=>ok(f.w?.[i],3))).length/frames.length:0;
 const geometry=errMax<=.28&&meanError<.05&&angles.max<28&&footDrift<=.025&&clipped<Math.max(4,frames.length*.09);
 const pass=geometry&&(!requireWorld||worldCoverage>=.65);
 return {passed:pass,geometry_pass:geometry,worldCoverage,mean_bone_error:meanError,max_bone_error:errMax,max_angle_change_deg:angles.max,mean_angle_change_deg:angles.mean,foot_drift_normalized:footDrift,clipped_points:clipped,reason:pass?null:'Превышены допуски анатомии/опоры/границ кадра'};
}
function speedRetention(base,candidate){let original=0,altered=0,n=0;
 for(let i=1;i<base.length;i++){const dt=base[i].t-base[i-1].t;if(!(dt>.012&&dt<.32))continue;
  for(const id of [15,16,27,28]){const a=base[i].im?.[id],b=base[i-1].im?.[id],c=candidate[i].im?.[id],d=candidate[i-1].im?.[id];if(![a,b,c,d].every(ok))continue;
   original+=distance(a,b,2)/dt;altered+=distance(c,d,2)/dt;n++;}}
 if(!n||original<.001)return {score:null,ratio:null};const ratio=altered/original;return {ratio,score:100*Math.exp(-2.7*Math.abs(Math.log(Math.max(.05,ratio))))};}
export function assessEvolutionCandidate(base,frames,{modality='2d',worldReady=false}={}){
 const anatomy=validateHypothesis(base,frames,{requireWorld:modality==='3d'});
 if(!anatomy.passed)return {passed:false,coherence:null,overall:null,anatomy,reason:anatomy.reason};
 const quality=evaluateMovementQuality({frames,allowPartial:true});if(!quality.measurable||quality.confidence<.28)return {passed:false,coherence:null,overall:null,anatomy,quality,reason:quality.reason||'Недостоверная кинематика'};
 const speed=speedRetention(base,frames);
 let gravity=null;if(worldReady||modality==='3d'){gravity=evaluateSpatialGravity(base,frames);if(!gravity.passed)return {passed:false,coherence:null,overall:null,anatomy,quality,gravity,reason:gravity.reason};}
 const sm=quality.breakdown.find(x=>x.key==='kinematic_smoothness')?.score,dir=quality.breakdown.find(x=>x.key==='directional_continuity')?.score;
 const evidenceWeight=Number(quality.available_weight)||0;
 // A single smoothness family cannot certify perfect coordination.
 const evidenceCap=evidenceWeight<.58?Math.min(95,85+evidenceWeight*15):100;
 const coherence=sm==null?null:Math.min(evidenceCap,cl((sm*.78+(dir??sm)*.22),0,100));
 const coverageFactor=cl(quality.confidence,.35,1);
 // The same movement score is used for the site and the training objective; no KE saturation.
 let overall=cl(quality.value*.86+(speed.score??quality.value)*.09+(gravity?.score??quality.value)*.05,0,100);
 if(speed.ratio!==null&&(speed.ratio<.82||speed.ratio>1.18))overall*=.88;
 return {passed:Number.isFinite(coherence)&&Number.isFinite(overall),overall:Math.round(overall*100)/100,coherence:Math.round(coherence*100)/100,quality,anatomy,gravity,speed,coverageFactor,adequate_evidence:quality.has_independent_evidence&&evidenceWeight>=.58&&quality.confidence>=.68};
}
function bestStateIsBetter(now,old){if(!now.passed)return false;
 if(!old.passed)return true;
 // Feasible hill climb: don't trade away movement coherence to game the overall score.
 return now.coherence>=old.coherence&&now.overall>=old.overall&&(now.coherence>old.coherence+.02||now.overall>old.overall+.02);
}
export function trainingConfig({copies=4,steps=55,seed=12345}={}){const n=Math.trunc(Number(copies));if(!Number.isSafeInteger(n)||n<1||n>100000)throw Error('Число копий — целое от 1 до 100 000');const it=Math.trunc(Number(steps)||55);if(!Number.isSafeInteger(it)||it<1||it>1000000)throw Error('Число итераций — целое от 1 до 1 000 000');return {copies:n,steps:it,seed:(Number(seed)>>>0)||12345,coherence_goal:100,min_overall:60,stop_per_avatar:true};}
/** Async on the main thread for fallback or in a separate Worker; reports progress every copy. */
export async function trainHypothesis({frames,modality='2d',copies=4,steps=55,seed=12345,onProgress=null,shouldStop=null}={}){
 const config=trainingConfig({copies,steps,seed}),original=copy(frames||[]);if(original.length<7||original.length>400)throw Error('Нужна связка от 7 до 400 кадров');
 const worldReady=spatialReadiness(original).available;
 if(modality==='3d'&&!worldReady)throw Error('Для 3D-тренировки недостаточно world landmarks');
 const baseScore=assessEvolutionCandidate(original,original,{modality,worldReady}),results=[];let bestOverall=baseScore.passed?{state:baseScore,frames:original,genome:initialGenome(config.seed),copy:0}:null;
 for(let cloneIndex=0;cloneIndex<config.copies;cloneIndex++){
  if(shouldStop?.())throw Error('Тренировка прервана');
  const random=rng(config.seed^Math.imul(cloneIndex+1,0x9e3779b9)),startGenome=initialGenome(config.seed+Math.imul(cloneIndex+1,9973));
  let currentGenome=startGenome,currentFrames=applyGenome(original,startGenome,{modality}),current=assessEvolutionCandidate(original,currentFrames,{modality,worldReady});
  if(!current.passed){currentFrames=original;current=baseScore;currentGenome=startGenome.map(g=>({...g,level:0}));}
  let accepted=0,attempted=0;
  for(let step=0;step<config.steps;step++){
   if(shouldStop?.())throw Error('Тренировка прервана');
   if(current.passed&&current.adequate_evidence&&current.coherence>=config.coherence_goal&&current.overall>=config.min_overall)break;
   const candidateGenome=mutateGenome(currentGenome,random,.9-(step/config.steps)*.48),candidateFrames=applyGenome(original,candidateGenome,{modality});
   const candidate=assessEvolutionCandidate(original,candidateFrames,{modality,worldReady});attempted++;
   if(step%8===7){onProgress?.({done:cloneIndex,total:config.copies,iteration:step+1,iterations:config.steps,accepted:results.filter(x=>x.reached).length,best:bestOverall?.state?.overall??null});await new Promise(resolve=>setTimeout(resolve,0));}
   if(bestStateIsBetter(candidate,current)){currentGenome=candidateGenome;currentFrames=candidateFrames;current=candidate;accepted++;}
  }
  const reached=current.passed&&current.adequate_evidence&&current.coherence>=config.coherence_goal&&current.overall>=config.min_overall;
  results.push({avatar:cloneIndex+1,seed:config.seed^Math.imul(cloneIndex+1,0x9e3779b9),attempted,accepted,adequate_evidence:!!current.adequate_evidence,reached,overall:current.overall,coherence:current.coherence,genome:currentGenome});
  if(current.passed&&(!bestOverall||current.overall>bestOverall.state.overall))bestOverall={state:current,frames:currentFrames,genome:currentGenome,copy:cloneIndex+1};
  onProgress?.({done:cloneIndex+1,total:config.copies,accepted:results.filter(x=>x.reached).length,best:bestOverall?.state?.overall??null});
  // Yield after each clone to allow worker cancellation and UI updates on fallback.
  await new Promise(resolve=>setTimeout(resolve,0));
 }
 const reached=results.filter(r=>r.reached),success=reached.length>=(config.copies===1?1:Math.max(2,Math.ceil(config.copies*.45)));
 let consolidated=null;
 if(success){
  const g=initialGenome(config.seed).map((x,i)=>({...x}));
  for(let i=0;i<g.length;i++)for(const field of ['angle','phase','twist','profile','level']){
   const sorted=reached.map(r=>r.genome[i][field]).sort((a,b)=>a-b);g[i][field]=sorted[Math.floor(sorted.length/2)];}
  const frame=applyGenome(original,g,{modality}),test=assessEvolutionCandidate(original,frame,{modality,worldReady});
  // A consensus of individually feasible motions can be invalid; never silently trust a mean skeleton.
  if(test.passed&&test.adequate_evidence&&test.overall>=config.min_overall&&test.coherence>=config.coherence_goal){consolidated={frames:frame,score:test,genome:g,source:'median-parameters'};}
  else {const winner=results.filter(r=>r.reached).sort((a,b)=>b.overall-a.overall)[0];const f=applyGenome(original,winner.genome,{modality}),q=assessEvolutionCandidate(original,f,{modality,worldReady});if(q.passed&&q.adequate_evidence&&q.coherence>=config.coherence_goal&&q.overall>=config.min_overall)consolidated={frames:f,score:q,genome:winner.genome,source:'best-feasible-replica'};}
 }
 // Provide up to 3 *distinct feasible personalized 3D motions*. Do not fill
 // missing slots with duplicate replicas and do not trust the median without re-check.
 const shortlist=[];
 if(modality==='3d'){
  const pool=[...results].filter(x=>Number.isFinite(x.overall)&&x.overall>0).sort((a,b)=>b.overall-a.overall).slice(0,Math.min(120,results.length));
  if(consolidated?.frames&&consolidated.score?.passed)shortlist.push({source:'consensus',frames:consolidated.frames,genome:consolidated.genome,score:consolidated.score});
  for(const row of pool){
   if(shortlist.length>=3)break;
   const sample=applyGenome(original,row.genome,{modality}),score=assessEvolutionCandidate(original,sample,{modality,worldReady});
   if(!score.passed||!score.adequate_evidence)continue;
   const apart=shortlist.every(item=>{
    let sum=0,n=0;const ids=[13,14,15,16,25,26,27,28];
    for(let k=0;k<Math.min(sample.length,80);k+=Math.max(1,Math.ceil(sample.length/80))){
     const torsoA=original[k]?.w?.[11],torsoB=original[k]?.w?.[23],scale=ok(torsoA,3)&&ok(torsoB,3)?Math.max(.15,distance(torsoA,torsoB,3)):.5;
     for(const id of ids){const a=sample[k]?.w?.[id],b=item.frames[k]?.w?.[id];if(ok(a,3)&&ok(b,3)){sum+=distance(a,b,3)/scale;n++;}}
    }
    return n>0&&sum/n>=.025;
   });
   if(apart)shortlist.push({source:`replica-${row.avatar}`,frames:sample,genome:row.genome,score});
  }
 }
 return {schema:'purcell-evolution-v1',modality,config,base_score:baseScore,results,successes:reached.length,quorum:success,shortlist:shortlist.map((v,i)=>({...v,rank:i+1})),consolidated:consolidated?{...consolidated,score:consolidated.score}:null,best:bestOverall?{...bestOverall,score:bestOverall.state}:null,
  reached_100:reached.length>0,stop_reason:reached.length?'goal_reached_by_some':'bounded_budget_exhausted',
  caveat:'Локальный поиск кинематических гипотез, не физический симулятор OpenSim/Isaac и не подтверждение мастерства.'};
}

/** Diverse bounded search. 10k means 10k distinct parameter candidates, not 10k full video copies. */
export async function trainHypothesisPopulation({frames,modality='3d',candidates=10000,seed=20261112,batchSize=24,onProgress=null,shouldStop=null}={}){
 const total=Math.max(1,Math.min(10000,Math.trunc(Number(candidates)||10000)));
 const original=copy(frames||[]);if(original.length<7||original.length>400)throw Error('Нужна связка от 7 до 400 кадров');
 const worldReady=spatialReadiness(original).available;if(modality==='3d'&&!worldReady)throw Error('Для 3D-поиска недостаточно достоверных world landmarks');
 const base=assessEvolutionCandidate(original,original,{modality,worldReady}),random=rng(seed),archive=[],seen=new Set();let best=null,valid=0;
 for(let i=0;i<total;i++){if(shouldStop?.())throw Error('Поиск гипотез прерван');
  let genome=initialGenome((seed+i*2654435761)>>>0);const mutations=1+(i%7);for(let m=0;m<mutations;m++)genome=mutateGenome(genome,random,1.8+(i%5)*.42);
  // Deduplicate parameter signatures to prevent near-identical percent tweaks dominating the pool.
  const signature=genome.map(g=>[g.chain,...['angle','phase','twist','profile','level','axis'].map(k=>Math.round(g[k]*100))].join(':')).join('|');
  if(seen.has(signature)){i--;continue;}seen.add(signature);
  const candidateFrames=applyGenome(original,genome,{modality}),score=assessEvolutionCandidate(original,candidateFrames,{modality,worldReady});
  if(score.passed){valid++;const row={index:i,genome,overall:score.overall,coherence:score.coherence,adequate_evidence:!!score.adequate_evidence,score};archive.push(row);if(!best||row.overall>best.overall)best=row;}
  if((i+1)%Math.max(1,batchSize)===0){onProgress?.({done:i+1,total,valid,best:best?.overall??null});await new Promise(resolve=>setTimeout(resolve,0));}
 }
 archive.sort((a,b)=>(Number(b.adequate_evidence)-Number(a.adequate_evidence))||(b.overall-a.overall));
 return {schema:'purcell-population-v2',modality,requested:total,evaluated:seen.size,valid,base_score:base,top:archive.slice(0,12),best,diversity:{unique_signatures:seen.size,mutation_depths:7,seed},caveat:'10k bounded kinematic candidates; not 10k full physical simulations. 3D candidates require measured/reconstructed world landmarks.'};
}
