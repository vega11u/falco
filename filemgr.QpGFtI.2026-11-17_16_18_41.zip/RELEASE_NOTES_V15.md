# Kata Biomechanics Analyzer v15 — bounded local training

## Main change

The previous v14 installer could attempt an oversized corpus acquisition (100 GB default video allowance, broad ACCAD/MyoSuite downloads, and multi-worker tree training). v15 changes the default to a small, sequential, resumable acquisition and training profile designed for a personal server.

## Hard default limits

- Training corpus download budget: 3.5 GiB across `training-data` (including extracted files counted by the downloader).
- Style video budget: 1.5 GiB total; 350 MiB per style; at most 8 clips per style; at most 150 MiB and 15 minutes per clip; 480p maximum.
- Extracted data budget: 6 GiB. ZIP members are path-checked and expansion is rejected before extraction if it exceeds the budget.
- Require at least 4.5 GiB free before creating the training venv/installing packages; preserve at least 3 GiB during data downloads.
- G1: at most 650 MiB, 12 BVH + 6 MP4 candidates; no FBX/PKL/NPZ/policies. Generic, style-unverified.
- SKMD original FastPose/ST-GCN Google Drive bundle is disabled by default; the compact CSV data is sufficient for the included ExtraTrees baseline.
- ACCAD and MyoSuite bulk archives are opt-in only because they are generic and comparatively heavy.
- Training and numerical libraries are restricted to one worker/thread; download and training steps run at reduced OS priority when `nice` is available.

All limits can be overridden by environment variables, but defaults intentionally favor safety. The installer logs actual downloads and model counts.

## What can actually be trained

1. **Shotokan frame classifier**: ExtraTrees model trained from the four actual labels in the SKMD CSV export, with grouped sequence/block validation. It is a narrow baseline, not a complete karate recognizer.
2. **Shotokan temporal templates**: 16-frame pose signatures from SKMD full-move sequences.
3. **Generic 3D karate motion templates**: BVH forward-kinematics features from the small G1 subset; never assigned to a target lineage.
4. **Generic video pose templates**: MediaPipe Lite features from the small G1 MP4 subset; never assigned to a target lineage.
5. **Style-specific video pose references**: pose signatures extracted from explicitly style-attributed kata/kihon videos. Whole kata remains a separate reference type; no single technique label is inferred from a whole kata.
6. **Pavani stance reference statistics**: dynamic and static measurements remain separate; style is assigned only when the source row itself carries style metadata.
7. **OpenSim muscle inventory**: anatomical parameter inventory, not estimated athlete-specific muscle activation.

## Exclusions

- No Kyokushin/Oyama data is downloaded or used.
- No generic combat dataset is merged into Shotokan/Shito/Goju/Ryuei labels.
- ACCAD martial-arts data and MyoSuite bulk models are not downloaded by default.
- Unavailable or failed downloads never create synthetic substitute records.

## Important reality check

The build environment for this archive has no external DNS/network access, so no remote raw corpora could be downloaded and no new model weights could be trained inside this archive-building session. The one-command installer performs the real downloads and training on the user's server, within the limits above. A model is marked ready only after the trainer writes a real model file and records sample/sequence/class counts.
