#!/usr/bin/env bash
# Falco Jugger v21.5.0: one upstream social-video extractor for YouTube + Instagram.
# Official yt-dlp standalone bundles the EJS scripts. QuickJS-NG executes YouTube
# challenge code without V8/Deno/Node. No system Python/pip/venv, Node.js service, Composer,
# npm dependency graph or root access is required.
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
PROJECT_HASH="$(printf '%s' "$ROOT" | sha256sum | awk '{print substr($1,1,12)}')"
MEDIA_DIR="${KATA_MEDIA_IMPORT_DIR:-$(dirname "$ROOT")/.kata-media-import-${PROJECT_HASH}}"
case "$MEDIA_DIR" in /*) ;; *) echo 'ERROR: KATA_MEDIA_IMPORT_DIR must be an absolute path.' >&2; exit 1 ;; esac
case "$MEDIA_DIR/" in "$ROOT/"*) echo 'ERROR: importer storage must be outside the public project directory.' >&2; exit 1 ;; esac
BIN_DIR="$MEDIA_DIR/bin"
TMP="$(mktemp -d)"
cleanup(){ rm -rf "$TMP"; }
trap cleanup EXIT

die(){ echo "ERROR: $*" >&2; exit 1; }
for c in curl sha256sum php chmod; do command -v "$c" >/dev/null 2>&1 || die "Required command is missing: $c"; done
php -r 'exit(class_exists("ZipArchive") && extension_loaded("openssl") && extension_loaded("hash") ? 0 : 1);' || die 'PHP CLI needs ZipArchive, OpenSSL and hash extensions.'
mkdir -p "$BIN_DIR"
chmod 700 "$MEDIA_DIR" "$BIN_DIR" 2>/dev/null || true
cat > "$MEDIA_DIR/.htaccess" <<'HT'
Require all denied
<IfModule !mod_authz_core.c>
Deny from all
</IfModule>
HT
: > "$MEDIA_DIR/index.html"

case "$(uname -m)" in
  x86_64|amd64)
    YTDLP_ASSET='yt-dlp_linux'
    QJS_FALLBACK_ASSET='qjs-linux-x86_64'
    QJS_FALLBACK_SHA256='85ded23b9fabe8c1644fc40a8d2bbdd71157affcbd807359c618cc717ee24d7d'
    ;;
  aarch64|arm64)
    YTDLP_ASSET='yt-dlp_linux_aarch64'
    QJS_FALLBACK_ASSET='qjs-linux-aarch64'
    QJS_FALLBACK_SHA256='2c005c7171424a598d31c53c8dc4a0ae2e4958eb6fbb37908c885a307c78187c'
    ;;
  *) die "Unsupported architecture $(uname -m); upstream yt-dlp has no matching binary." ;;
esac
# Prefer the official Cosmopolitan APE build: it avoids dependence on the host's
# glibc version. If the hosting kernel rejects APE execution, fall back to the
# architecture-specific native Linux build, also checksum-pinned upstream.
QJS_PRIMARY_ASSET='qjs-cosmo.com'
QJS_PRIMARY_SHA256='e80b0169d7c89d9c95a80f885f6de300450c664dfcdcc91245594e9bd89e14cf'
# Pin a release so installations are repeatable; update this constant deliberately with upstream.
YTDLP_VERSION='2026.10.26'
YT_BASE="https://github.com/yt-dlp/yt-dlp/releases/download/${YTDLP_VERSION}"
YT_DEST="$BIN_DIR/yt-dlp"
YT_VERSION_FILE="$BIN_DIR/yt-dlp-stable-version.txt"
YT_HASH_FILE="$BIN_DIR/yt-dlp-sha256.txt"
YT_EXPECTED=''
YT_EXISTING_VERSION="$("$YT_DEST" --version 2>/dev/null | tail -n1 || true)"
YT_EXISTING_HASH=""
[[ -f "$YT_DEST" ]] && YT_EXISTING_HASH="$(sha256sum "$YT_DEST" 2>/dev/null | awk '{print $1}' || true)"
YT_STAMPED_HASH="$(tr -d '\r\n' < "$YT_HASH_FILE" 2>/dev/null || true)"
if [[ -x "$YT_DEST" && "$YT_EXISTING_VERSION" == "$YTDLP_VERSION" && "$YT_STAMPED_HASH" =~ ^[a-fA-F0-9]{64}$ && "$YT_STAMPED_HASH" == "$YT_EXISTING_HASH" ]]; then
  # A previous install already verified this exact standalone binary against the
  # pinned upstream SHA-256 manifest. No network request is needed for this step.
  YT_EXPECTED="$YT_STAMPED_HASH"
else
  echo "Checking official yt-dlp ${YTDLP_VERSION} checksum manifest..."
  curl --fail --location --retry 4 --connect-timeout 20 --max-time 120 "$YT_BASE/SHA2-256SUMS" -o "$TMP/yt-dlp.sha256sums"
  YT_EXPECTED="$(awk -v f="$YTDLP_ASSET" '$2==f {print $1}' "$TMP/yt-dlp.sha256sums")"
  [[ "$YT_EXPECTED" =~ ^[a-fA-F0-9]{64}$ ]] || die "Official SHA-256 checksum for $YTDLP_ASSET was not found."
  if [[ ! -x "$YT_DEST" || "$YT_EXISTING_VERSION" != "$YTDLP_VERSION" || "$YT_EXISTING_HASH" != "$YT_EXPECTED" ]]; then
    echo "Downloading official yt-dlp ${YTDLP_VERSION} (${YTDLP_ASSET})..."
    curl --fail --location --retry 4 --connect-timeout 20 --max-time 900 "$YT_BASE/$YTDLP_ASSET" -o "$TMP/yt-dlp"
    printf '%s  %s\n' "$YT_EXPECTED" "$TMP/yt-dlp" | sha256sum --check --status || die 'yt-dlp SHA-256 verification failed.'
    cp "$TMP/yt-dlp" "$YT_DEST"
    chmod 700 "$YT_DEST"
  fi
fi
chmod 700 "$YT_DEST"
YT_VERSION="$("$YT_DEST" --version 2>&1 | tail -n1 || true)"
YT_HASH_ACTUAL="$(sha256sum "$YT_DEST" | awk '{print $1}')"
[[ "$YT_VERSION" == "$YTDLP_VERSION" ]] || die "yt-dlp did not start or returned unexpected version: $YT_VERSION"
[[ "$YT_HASH_ACTUAL" == "$YT_EXPECTED" ]] || die 'yt-dlp executable SHA-256 does not match the pinned official release manifest.'
printf '%s\n' "$YT_VERSION" > "$YT_VERSION_FILE"
printf '%s\n' "$YT_HASH_ACTUAL" > "$YT_HASH_FILE"
chmod 600 "$YT_VERSION_FILE" "$YT_HASH_FILE"

# QuickJS-NG is used instead of Deno on shared hosting. Deno 2.9.8 on the
# target account could print its version but crashed with SIGTRAP on JavaScript.
# Use an official QuickJS-NG release, first as a Cosmopolitan APE (no glibc
# dependency), then the architecture-specific ELF build if APE is unsupported.
QJS_VERSION='0.18.0'
QJS_BASE="https://github.com/quickjs-ng/quickjs/releases/download/v${QJS_VERSION}"
QJS_DEST="$BIN_DIR/qjs"
QJS_VERSION_FILE="$BIN_DIR/qjs-version.txt"
QJS_READY_FILE="$BIN_DIR/qjs-runtime-ok.txt"
QJS_HASH_FILE="$BIN_DIR/qjs-sha256.txt"
QJS_ACTUAL=''
QJS_SHA256_ACTUAL=''
QJS_ASSET_USED=''

qjs_exec_test(){
  local version_output actual
  if ! version_output="$("$QJS_DEST" --version 2>&1)"; then return 1; fi
  actual="$(printf '%s\n' "$version_output" | tail -n1 | tr -d '\r')"
  [[ "$actual" == "$QJS_VERSION" ]] || return 1
  if ! "$QJS_DEST" -e 'if (1 + 1 !== 2) throw new Error("QuickJS runtime test failed")' >/dev/null 2>&1; then return 1; fi
  QJS_ACTUAL="$actual"
  QJS_SHA256_ACTUAL="$(sha256sum "$QJS_DEST" | awk '{print $1}')"
  return 0
}

# Retain a previously installed official binary only if its published hash,
# version and actual execution all match. A stale readiness stamp is never trusted.
rm -f "$QJS_VERSION_FILE" "$QJS_READY_FILE" "$QJS_HASH_FILE"
if [[ -x "$QJS_DEST" ]]; then
  EXISTING_HASH="$(sha256sum "$QJS_DEST" | awk '{print $1}')"
  if [[ "$EXISTING_HASH" == "$QJS_PRIMARY_SHA256" || "$EXISTING_HASH" == "$QJS_FALLBACK_SHA256" ]]; then
    if qjs_exec_test; then
      QJS_ASSET_USED='existing verified upstream binary'
    fi
  fi
fi

install_qjs_asset(){
  local asset="$1" expected="$2" candidate="$TMP/qjs-candidate"
  echo "Downloading official QuickJS-NG ${QJS_VERSION} (${asset})..."
  curl --fail --location --retry 4 --connect-timeout 20 --max-time 600 "$QJS_BASE/$asset" -o "$candidate" || return 1
  printf '%s  %s\n' "$expected" "$candidate" | sha256sum --check --status || { echo "QuickJS-NG checksum failed for $asset." >&2; return 1; }
  cp "$candidate" "$QJS_DEST" || return 1
  chmod 700 "$QJS_DEST" || return 1
  if qjs_exec_test; then
    QJS_ASSET_USED="$asset"
    return 0
  fi
  echo "QuickJS-NG asset $asset did not pass the execution test; trying the alternate official build." >&2
  return 1
}

if [[ -z "$QJS_ACTUAL" ]]; then
  if ! install_qjs_asset "$QJS_PRIMARY_ASSET" "$QJS_PRIMARY_SHA256"; then
    install_qjs_asset "$QJS_FALLBACK_ASSET" "$QJS_FALLBACK_SHA256" || die 'Neither the official QuickJS-NG portable binary nor the native Linux binary can execute JavaScript on this hosting account.'
  fi
fi
[[ "$QJS_ACTUAL" == "$QJS_VERSION" && "$QJS_SHA256_ACTUAL" =~ ^[a-fA-F0-9]{64}$ ]] || die 'QuickJS-NG execution or integrity verification did not complete.'
printf '%s\n' "$QJS_ACTUAL" > "$QJS_VERSION_FILE"
printf '%s\n' "$QJS_SHA256_ACTUAL" > "$QJS_HASH_FILE"
printf 'quickjs-ng:%s:%s\n' "$QJS_ACTUAL" "$QJS_SHA256_ACTUAL" > "$QJS_READY_FILE"
chmod 600 "$QJS_VERSION_FILE" "$QJS_HASH_FILE" "$QJS_READY_FILE"

# Install browser-side MOV/ProRes decode assets through the same idempotent installer.
if ! bash "$ROOT/setup-video-runtime.sh"; then
  echo 'ERROR: Mediabunny/ProRes installation failed. The social downloader is installed, but local video codec support is incomplete.' >&2
  exit 1
fi

# Retire old auxiliary extractors from prior releases without touching queued jobs or user data.
# Also remove their obsolete PHP/JS entrypoints if this installer is run over an older deployment.
rm -f "$ROOT/media-import-youtubei.js" "$ROOT/media-import-php-fallback.php"
rm -f "$BIN_DIR/yt-dlp-nightly-version.txt" "$BIN_DIR/youtubei-js-ready" "$BIN_DIR/php-cli-path.txt"
rm -rf "$MEDIA_DIR/deno-cache-youtubei" "$MEDIA_DIR/php-youtube" "$MEDIA_DIR/composer-cache" "$MEDIA_DIR/composer-home"
printf '\nSocial-video loader installation finished.\n'
printf 'yt-dlp: %s\nyt-dlp SHA-256: %s\nQuickJS-NG: %s (%s)\nQuickJS-NG SHA-256: %s\n' "$YT_VERSION" "$YT_HASH_ACTUAL" "$QJS_ACTUAL" "$QJS_ASSET_USED" "$QJS_SHA256_ACTUAL"
printf 'Mediabunny: %s\nProRes decoder: %s\n' "$(cat "$ROOT/vendor/mediabunny/VERSION" 2>/dev/null || echo missing)" "$(cat "$ROOT/vendor/mediabunny-prores/VERSION" 2>/dev/null || echo missing)"
printf 'Private storage: %s\n' "$MEDIA_DIR"
printf '%s\n' 'YouTube and Instagram use the same official yt-dlp executable; QuickJS-NG executes YouTube EJS challenges without V8/Deno/Node.'
printf '%s\n' 'No system Python/pip/venv, Node.js service, Composer, root access or npm dependency cache is required.'
printf '%s\n' 'Instagram availability remains subject to public-page/API/rate-limit restrictions.'
