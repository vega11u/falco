<?php
declare(strict_types=1);
if (!defined('FALCO_JUGGER_BOOTSTRAPPED')) { http_response_code(404); exit; }
/** Read-only inspection + explicit confirmed canonicalization. Original numerical evidence is retained. */
function fj_normal_name(string $s): string {
 $s=function_exists('mb_strtolower')?mb_strtolower(trim($s),'UTF-8'):strtolower(trim($s));
 $map=['щ'=>'shch','ш'=>'sh','ч'=>'ch','ж'=>'zh','ц'=>'ts','ю'=>'yu','я'=>'ya','ё'=>'yo','й'=>'y','ы'=>'y','э'=>'e','ъ'=>'','ь'=>'', 'а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','з'=>'z','и'=>'i','к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u','ф'=>'f','х'=>'h','і'=>'i','ї'=>'yi','є'=>'ye'];
 $s=strtr($s,$map);
 $s=preg_replace('/[^a-z0-9]+/u','',$s)??'';
 // Known cross-transliteration phonemes only; no semantic equivalence is asserted.
 $s=str_replace(['sch','tch','shch','shi','chi','tsu','dz','j'],['sh','ch','sh','shi','chi','tsu','z','zh'],$s);
 return $s;
}
function fj_name_similarity(string $a,string $b): float {
 $a=fj_normal_name($a);$b=fj_normal_name($b);if($a===''||$b==='')return 0.0;
 if($a===$b)return 1.0;
 $d=levenshtein($a,$b);$length=max(strlen($a),strlen($b));
 if($length<5)return 0.0;
 return $d<=max(1,(int)floor($length*.3))?1-$d/$length:0.0;
}
function fj_inspector_files(string $dir): array {return [
 'lully'=>$dir.'/library.json',
 'purcell'=>$dir.'/purcell/library.json',
 'lully_model'=>$dir.'/classifier-model.json',
 'purcell_feedback'=>$dir.'/purcell/feedback.json',
 'purcell_trajectory'=>$dir.'/purcell/trajectory-search.json',
 ];}
function fj_inspector_read(string $dir): array {
 $paths=fj_inspector_files($dir);$out=[];
 foreach(['lully','purcell'] as $type){$p=$paths[$type];$out[$type]=fj_storage_read_json($p,['examples'], $type==='lully'?['feedback']:[])??['examples'=>[]];}
 return $out;
}
function fj_inspector_names(array $store): array {
 $names=[];
 foreach($store as $origin=>$lib)foreach($lib['examples']??[] as $entry){
  $kind=(string)($entry['kind']??'movement');$style=(string)($entry['style']??'unspecified');
  $values=[['field'=>'label','type'=>$kind,'name'=>(string)($entry['label']??'')]];
  if(isset($entry['unit_name'])&&trim((string)$entry['unit_name'])!=='')$values[]=['field'=>'unit_name','type'=>'kata','name'=>(string)$entry['unit_name']];
  if(isset($entry['kata_name'])&&trim((string)$entry['kata_name'])!=='')$values[]=['field'=>'kata_name','type'=>'kata','name'=>(string)$entry['kata_name']];
  if(($entry['unit_type']??'')==='kata'&&$kind==='kata')$values[0]['type']='kata';
  foreach($values as $v){$name=trim($v['name']);if($name==='')continue;
   $key=$v['type'].'|'.$style.'|'.$name;
   if(!isset($names[$key]))$names[$key]=['type'=>$v['type'],'style'=>$style,'name'=>$name,'count'=>0,'stores'=>[]];
   $names[$key]['count']++;$names[$key]['stores'][$origin]=($names[$key]['stores'][$origin]??0)+1;
  }
 }
 return array_values($names);
}
function fj_inspector_proposals(array $libs): array {
 $names=fj_inspector_names($libs);$found=[];$n=count($names);
 for($i=0;$i<$n;$i++)for($j=$i+1;$j<$n;$j++){
  $a=$names[$i];$b=$names[$j];if($a['type']!==$b['type']||$a['style']!==$b['style']||$a['name']===$b['name'])continue;
  $score=fj_name_similarity($a['name'],$b['name']);if($score<.69)continue;
  $found[]=['id'=>hash('sha256',$a['type'].'|'.$a['style'].'|'.$a['name'].'|'.$b['name']),
    'kind'=>$a['type'],'style'=>$a['style'],'a'=>$a['name'],'b'=>$b['name'],'a_count'=>$a['count'],'b_count'=>$b['count'],'similarity'=>round($score,3),'automatic'=>false];
 }
 usort($found,static fn($a,$b)=>$b['similarity']<=>$a['similarity']);return array_slice($found,0,200);
}
function fj_inspector_digest(array $libs): string {return hash('sha256',json_encode([$libs['lully']['examples']??[],$libs['purcell']['examples']??[]],JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE));}
function fj_inspector_inspect(string $dir): array {
 $libs=fj_inspector_read($dir);return ['ok'=>true,'proposals'=>fj_inspector_proposals($libs),'revision'=>fj_inspector_digest($libs),
 'counts'=>['lully'=>count($libs['lully']['examples']??[]),'purcell'=>count($libs['purcell']['examples']??[])],
 'note'=>'Ничего не объединено автоматически. Предлагаются только похожие написания одного типа и стиля.'];
}
function fj_inspector_atomic(string $path,array $data): void {
 $str=json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
 if(!is_string($str))throw new RuntimeException('Cannot encode learning store');
 $tmp=$path.'.new.'.bin2hex(random_bytes(5));
 if(@file_put_contents($tmp,$str,LOCK_EX)===false||!@rename($tmp,$path)){@unlink($tmp);throw new RuntimeException('Atomic write failed: '.basename($path));}
 @chmod($path,0600);
}
function fj_inspector_merge(string $dir,array $body): array {
 $old=(string)($body['old_name']??'');$canonical=(string)($body['canonical_name']??'');$kind=(string)($body['kind']??'');$style=(string)($body['style']??'');
 if(strlen($old)>240||strlen($canonical)>240||$old===''||$canonical===''||$old===$canonical)throw new InvalidArgumentException('Choose two distinct names.');
 if(!in_array($kind,['kata','stance','hand_strike','kick','block','movement','sequence','transition','biomechanics'],true))throw new InvalidArgumentException('Invalid movement kind');
 $lockPath=$dir.'/library.lock';$lock=@fopen($lockPath,'c+');if(!$lock||!flock($lock,LOCK_EX))throw new RuntimeException('Lully library lock unavailable');
 $pdir=$dir.'/purcell';if(!is_dir($pdir))@mkdir($pdir,0700,true);
 $pl=@fopen($pdir.'/purcell.lock','c+');if(!$pl||!flock($pl,LOCK_EX)){flock($lock,LOCK_UN);throw new RuntimeException('Purcell library lock unavailable');}
 try {
  $paths=fj_inspector_files($dir);$libs=fj_inspector_read($dir);
  if(!hash_equals(fj_inspector_digest($libs),(string)($body['revision']??'')))throw new RuntimeException('Библиотека изменилась после инспекции. Повтори инспекцию.');
  $valid=false;foreach(fj_inspector_proposals($libs) as $p)if($p['kind']===$kind&&$p['style']===$style&&(($p['a']===$old&&$p['b']===$canonical)||($p['b']===$old&&$p['a']===$canonical)))$valid=true;
  if(!$valid)throw new InvalidArgumentException('Эта пара не подтверждена результатом инспекции.');
  $updated=['lully'=>0,'purcell'=>0];
  foreach(['lully','purcell'] as $target)foreach($libs[$target]['examples'] as &$entry){
   if((string)($entry['style']??'unspecified')!==$style)continue;
   $rowKind=(string)($entry['kind']??'movement');
   if($kind!=='kata'&&$rowKind===$kind&&($entry['label']??null)===$old){$entry['label']=$canonical;$updated[$target]++;}
   if($kind==='kata'){
    foreach(['unit_name','kata_name'] as $field)if(($entry[$field]??null)===$old){$entry[$field]=$canonical;$updated[$target]++;}
    if((($entry['unit_type']??'')==='kata'||$rowKind==='kata')&&$rowKind==='kata'&&($entry['label']??null)===$old){$entry['label']=$canonical;$updated[$target]++;}
   }
  }unset($entry);
  if(array_sum($updated)===0)throw new RuntimeException('No matched examples');
  $extras=[];
  if(is_file($paths['purcell_feedback'])){
    $feedbackStore=fj_storage_read_json($paths['purcell_feedback'],['feedback']);
    foreach($feedbackStore['feedback'] as &$row)if($kind==='kata'&&($row['unit_name']??null)===$old&&($row['style']??'unspecified')===$style)$row['unit_name']=$canonical;
    unset($row);$extras['purcell_feedback']=$feedbackStore;
  }
  if(is_file($paths['purcell_trajectory'])){
    $trajectoryStore=fj_storage_read_json($paths['purcell_trajectory'],['runs']);
    foreach($trajectoryStore['runs'] as &$row)if($kind==='kata'&&($row['unit_name']??null)===$old)$row['unit_name']=$canonical;
    unset($row);$extras['purcell_trajectory']=$trajectoryStore;
  }
  // Preserve comments verbatim; update structured training labels only.
  if($kind==='kata'&&isset($libs['lully']['feedback']))foreach($libs['lully']['feedback'] as &$row){
    if(($row['style']??'unspecified')===$style&&($row['unit_name']??null)===$old)$row['unit_name']=$canonical;
    foreach($row['patterns']??[] as &$pattern)if(($pattern['label']??null)===$old&&($row['style']??'unspecified')===$style)$pattern['label']=$canonical;
    unset($pattern);
  }unset($row);
  $priorModel=fj_model_read($dir);
  $priorTrained=(int)($priorModel['training_examples']??0);
  // Verified non-destructive snapshot before changing ANY live file.
  $backup=$dir.'/.merge-backups/'.gmdate('Ymd_His').'-'.bin2hex(random_bytes(5));
  if(!@mkdir($backup,0700,true))throw new RuntimeException('Cannot create backup; no files changed');
  $snap=[];foreach($paths as $key=>$path)if(is_file($path)){
    $filename=$key.'.json';if(!@copy($path,$backup.'/'.$filename)||hash_file('sha256',$path)!==hash_file('sha256',$backup.'/'.$filename))throw new RuntimeException('Backup failed; no data changed');$snap[$key]=$filename;
  }
  // Preserve untouched records verbatim; train classifier again from unchanged numeric features.
  try {
   if($updated['lully'])fj_inspector_atomic($paths['lully'],$libs['lully']);
   if($updated['purcell'])fj_inspector_atomic($paths['purcell'],$libs['purcell']);
   foreach($extras as $key=>$data)fj_inspector_atomic($paths[$key],$data);
   if($updated['lully']){
    $result=fj_model_rebuild($dir,$libs['lully']['examples']);
    fj_model_set_source_library_hash($dir,fj_model_source_library_hash_from_rows($libs['lully']['examples']));
    if((int)(fj_model_status($dir)['training_examples']??0)<$priorTrained)throw new RuntimeException('Classifier trained example count would decrease');
   }
  } catch(Throwable $e){
   foreach($snap as $key=>$fn){$target=$paths[$key];$source=$backup.'/'.$fn;if(!@copy($source,$target))throw new RuntimeException('ROLLBACK FAILED; restore from '.$backup.'; '. $e->getMessage());}
   throw new RuntimeException('Объединение отменено и файлы восстановлены: '.$e->getMessage());
  }
  return ['ok'=>true,'changed'=>$updated,'backup_created'=>true,'revision'=>fj_inspector_digest($libs),'model_rebuilt'=>$updated['lully']>0];
 } finally {flock($pl,LOCK_UN);fclose($pl);flock($lock,LOCK_UN);fclose($lock);}
}
