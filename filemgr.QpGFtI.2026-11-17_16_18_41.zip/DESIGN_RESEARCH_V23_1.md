# Design research — Falco Jugger 23.1.0

## GitHub references reviewed

- [AamirrH/FrutigerAero](https://github.com/AamirrH/FrutigerAero) — pure HTML/CSS/JS recreation of the Windows 7-era visual language: glass panels, glossy controls, rounded windows and readable interaction states.
- [Zakintaliban/frutiger-aero](https://github.com/Zakintaliban/frutiger-aero) — sky, clouds, grassy hills, waterline, light rays, bubbles, frosted panels and reduced-motion fallback.
- [biagio-scaglia/frutiger-js](https://github.com/biagio-scaglia/frutiger-js) — reference for specular highlights, acrylic material, glossy controls and design tokens; no framework or package was imported.
- [TheAgencyMGE/frutiger-aero-everywhere](https://github.com/TheAgencyMGE/frutiger-aero-everywhere) — practical palette and progressive enhancement: sky wash, aqua/turquoise accents, ocean ink, grass green, readable surfaces and limited glass.
- [Visnalize/makeaero](https://github.com/Visnalize/makeaero) — button/orb/window material references: convex gloss, reflection streak, rounded Aero controls and Segoe/ humanist sans typography.
- [PetoKrisa/frutiger-aero-css](https://github.com/PetoKrisa/frutiger-aero-css) — vanilla stylesheet reference for dimensional Web 2.0 controls.

## Design decisions for an analysis workstation

The references converge on optimistic daylight, nature/water imagery, transparent acrylic, specular highlights, rounded tactile controls and a humanist sans. Falco applies these to a dense technical interface rather than copying a nostalgic desktop shell. The studio hero carries the landscape; controls and settings use light acrylic; numerical results use a consistent sans and tabular numerals; video and skeletal overlays remain dark so the measured content is legible.

The project uses a locally authored SVG landscape and locally bundled Inter WOFF2. This avoids a network dependency on font/CDN services and ensures Russian Cyrillic renders consistently. The visual treatment is intentionally restrained around high-density data: no decorative floating text, no unanchored numbers, no perpetual bubbles over controls, and no blur on large scrollable/video surfaces.

## Performance decisions

The prior styling layer used broad glass/blur rules and left many new studio classes without actual layout definitions. v23.1 replaces it with explicit component-level rules, no infinite animations, a 12 px blur only on a few compact surfaces, static gradients, and responsive CSS grids. The browser's video / pose / depth processing pipeline is not modified by this visual update.
