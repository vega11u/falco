/** Falco 23.0.14: off-main-thread robust trajectory speed estimation. */
import {measureRelativeSpeeds,VELOCITY_VERSION} from './motion-velocity-core.mjs?v=23.0.14';
self.onmessage=({data})=>{
 const id=data?.id;
 if(data?.type!=='calculate')return;
 try{const results=measureRelativeSpeeds(data.frames||[],{heightCm:Number(data.heightCm)||175});self.postMessage({id,type:'result',results,schema:VELOCITY_VERSION});}
 catch(e){self.postMessage({id,type:'error',error:String(e?.message||e).slice(0,400)});}
};
