/* Falco Canonical Evidence V3.0: additive evidence metadata, not a replacement for the existing mesh.
 * The goal is to preserve the difference between observations, estimates and assumptions.
 */
export const CANONICAL_EVIDENCE_SCHEMA='falco-canonical-evidence-v3.0';
const valid=(x)=>typeof x==='number'&&Number.isFinite(x);
const bounded=(x)=>valid(x)?Math.max(0,Math.min(1,x)):null;
const countPresent=(points)=>Array.isArray(points)?points.filter(p=>p&&valid(p.x)&&valid(p.y)).length:0;
export function buildReconstructionEvidenceV3(frame={}){
 const s=frame.surface?.silhouette||null, d=frame.depth_ensemble||null;
 const mask=!!(s&&(s.b64||s.rle||s.mask||s.data)), pose=countPresent(frame.p||frame.landmarks||frame.poseLandmarks||[]);
 const depth=!!(frame.scene_depth_grid?.values?.length||frame.depth_landmark_values?.length);
 const quality=bounded(s?.boundary_confidence??s?.confidence);
 const isConsensus=frame.depth_mode==='consensus'||!!d?.enabled;
 const contributors=Array.isArray(d?.contributors)?d.contributors.length:0;
 const ensembleComplete=isConsensus?!!d?.complete&&contributors===4:null;
 const measured={pose_2d:pose>0,athlete_mask:mask,depth_relative:depth};
 const assumptions=['unobserved_body_surface','monocular_depth_scale'];
 if(!mask)assumptions.push('athlete_boundary_unverified');
 if(!depth)assumptions.push('depth_unobserved');
 if(isConsensus&&!ensembleComplete)assumptions.push('depth_consensus_incomplete');
 return {schema:CANONICAL_EVIDENCE_SCHEMA,t_s:valid(frame.t)?frame.t:null,category:!pose&&!mask?'uncertain':isConsensus&&!ensembleComplete?'uncertain':mask&&quality!==null&&quality<.5?'uncertain':'inferred',observed:measured,pose_points_2d:pose,athlete_mask_quality:quality,relative_depth_agreement:bounded(d?.model_agreement),depth_mode:frame.depth_mode||null,consensus_contributors:isConsensus?contributors:null,consensus_complete:ensembleComplete,geometry_status:'inferred_from_monocular_video',metric_calibration:false,assumptions};
}
export function summarizeReconstructionEvidenceV3(frames=[],options={}){
 const rows=frames.map(buildReconstructionEvidenceV3),len=rows.length;
 const count=key=>rows.reduce((s,r)=>s+(r.observed[key]?1:0),0);
 const consensusRows=rows.filter(r=>r.consensus_complete!==null);
 return {schema:CANONICAL_EVIDENCE_SCHEMA,frame_count:len,pose_observed_frames:count('pose_2d'),athlete_mask_frames:count('athlete_mask'),relative_depth_frames:count('depth_relative'),consensus_evaluated_frames:consensusRows.length,consensus_complete_frames:consensusRows.filter(r=>r.consensus_complete).length,uncertain_frames:rows.filter(r=>r.category==='uncertain').length,metric_calibration:options.calibrated===true,metric_depth_claim_allowed:false,model_mode:options.mode||null,units:'relative, not metres',identity_geometry:'fixed mesh with inferred unseen thickness',note:'V3 evidence metadata is additive. No claim of measured hidden 3D body surface or certified uncertainty.'};
}
