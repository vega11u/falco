import { analyzeMovementPhases, applyPhaseRetimingCandidate } from './trajectory-intelligence.mjs?v=23.0.0';
import {compareVivaldiMeshIdentity} from './vivaldi-athlete-lattice.mjs?v=26.2.0';
/**
 * Purcell — lightweight, explainable biomechanics layer.
 * It does not denoise, smooth, or rewrite measured trajectories.
 * Reviewed references and explicitly marked, bounded phase hypotheses are separate
 * from measurements. A hypothesis is never reported as a measured improvement.
 */
const LANDMARK_IDS = [11,12,13,14,15,16,23,24,25,26,27,28,29,30,31,32];
const PART_JOINTS = {
  arms: new Set([11,12,13,14,15,16]),
  trunk: new Set([11,12,23,24]),
  legs: new Set([23,24,25,26,27,28]),
  feet: new Set([27,28,29,30,31,32]),
  hands: new Set([15,16])
};
const VALID_KINDS = new Set(['stance','hand_strike','kick','block','movement','transition']);
const finite = Number.isFinite;
const clamp = (v,a,b)=>Math.max(a,Math.min(b,v));
const mean = values => values.length ? values.reduce((a,b)=>a+b,0)/values.length : null;

function frameDistance(a,b) {
  if (!(Array.isArray(a)||ArrayBuffer.isView(a)) || !(Array.isArray(b)||ArrayBuffer.isView(b)) || a.length !== 384 || b.length !== 384) return Infinity;
  let sum=0,weight=0;
  const jointWeights=[1.05,1.05,1.02,1.02,1.08,1.08,1.15,1.15,1.24,1.24,1.32,1.32,1.18,1.18,1.18,1.18];
  for(let t=0;t<8;t++) for(let j=0;j<16;j++) {
    const w=jointWeights[j];
    for(let k=0;k<3;k++) {
      const x=Number(a[t*48+j*3+k]), y=Number(b[t*48+j*3+k]);
      if(finite(x)&&finite(y)) { const d=x-y; sum+=w*d*d; weight+=w; }
    }
  }
  return weight ? Math.sqrt(sum/weight) : Infinity;
}
function labelKey(v) {
  return String(v||'').toLocaleLowerCase('ru').replace(/[ё]/g,'е').replace(/[^a-zа-я0-9]+/g,' ').trim();
}
function inferParts(kind) {
  if(kind==='hand_strike'||kind==='block') return ['arms','trunk'];
  if(kind==='kick') return ['legs','feet','trunk'];
  if(kind==='stance') return ['legs','feet','trunk'];
  return ['arms','legs','trunk'];
}
function actionableCue(cue) {
  if(!cue || !VALID_KINDS.has(cue.kind||'movement')) return false;
  if(Number(cue.priority||9)>2 || Number(cue.confidence||0)<.54) return false;
  const title=String(cue.title||'');
  if(/сохранить|личный референс|повторённый переход|использовать повторённый/i.test(title)) return false;
  const why=String(cue.why||'');
  return /(?:\d|≈|около|расхожд|дистанц|угол|задержк|скорост|пик|прямолин|обратн|находится|составляет)/i.test(why);
}

function findTechniqueKnowledge(cue,kind,knowledge={}) {
  const mappings=Array.isArray(knowledge.technique_mappings)?knowledge.technique_mappings:[];
  const text=labelKey([cue.pattern,cue.title,cue.action].filter(Boolean).join(' '));
  let best=null,bestScore=0;
  for(const item of mappings) {
    if(item.kind!==kind) continue;
    let score=0;
    for(const alias of item.aliases||[]) {
      const key=labelKey(alias);
      if(!key) continue;
      if(text===key) score=Math.max(score,12);
      else if(text.includes(key)) score=Math.max(score,9+Math.min(2,key.length/12));
      else if(key.includes(text)&&text.length>=5) score=Math.max(score,4+Math.min(2,text.length/12));
    }
    if(score>bestScore){best=item;bestScore=score;}
  }
  return bestScore>=4?best:null;
}

export function rankPurcellExamples(signature, examples=[], {kind='movement',style='unspecified',patternLabel='',signature_2d=null,signature_3d=null,meshIdentity=null}={}) {
  const hasSignature=v=>(Array.isArray(v)||ArrayBuffer.isView(v))&&v.length===384;
  if(!hasSignature(signature)&&!hasSignature(signature_2d)&&!hasSignature(signature_3d))return [];
  const wanted=labelKey(patternLabel);
  const rows=[];
  for(const example of examples||[]) {
    const features=example?.features,features2d=example?.features_2d,features3d=example?.features_3d;
    const hasLegacy=hasSignature(features)&&hasSignature(signature);
    const hasTwo=hasSignature(features2d)&&hasSignature(signature_2d);
    const hasThree=hasSignature(features3d)&&hasSignature(signature_3d);
    if(!hasLegacy&&!hasTwo&&!hasThree)continue;
    const sampleKind=String(example.kind||'movement');
    // Biomechanics exemplars are body-motion references, not learned kata labels.
    // They may inform any detected technique, but require stricter visual similarity.
    const genericBiomechanics=sampleKind==='biomechanics';
    if(!genericBiomechanics && kind!=='transition' && sampleKind!==kind && !(kind==='movement'&&sampleKind==='block')) continue;
    const sampleStyle=String(example.style||'unspecified');
    if(style!=='unspecified' && sampleStyle!=='unspecified' && sampleStyle!==style) continue;
    const oldDistance=hasLegacy?frameDistance(signature,features):Infinity;
    const twoDistance=hasTwo?frameDistance(signature_2d,features2d):Infinity;
    const threeDistance=hasThree?frameDistance(signature_3d,features3d):Infinity;
    const evidence=[oldDistance,twoDistance,threeDistance].filter(finite);if(!evidence.length)continue;
    const score=d=>finite(d)?100*Math.exp(-1.65*d):null;
    const baseScore=score(oldDistance),twoScore=score(twoDistance),threeScore=score(threeDistance);
    const primary=baseScore??twoScore??threeScore;
    const both=twoScore!=null&&threeScore!=null;
    // Optical and world evidence are evaluated independently. Strong disagreement
    // prevents an unjustified boost; legacy-only examples remain fully competitive.
    const fused=both&&Math.abs(twoScore-threeScore)<28?.45*twoScore+.55*threeScore:primary;
    let similarityBase=baseScore!=null&&both?.65*baseScore+.35*fused:fused;
    const meshSimilarity=hasThree?compareVivaldiMeshIdentity(meshIdentity,example.personalized_mesh_identity):null;
    if(meshSimilarity!==null)similarityBase=.92*similarityBase+.08*meshSimilarity;
    const distance=oldDistance===Infinity?(twoDistance===Infinity?threeDistance:twoDistance):oldDistance;
    let similarity=Math.round(similarityBase)-(genericBiomechanics?5:0);
    const sampleLabel=labelKey(example.label);
    if(wanted && sampleLabel===wanted) similarity=Math.min(100,similarity+5);
    else if(wanted && sampleLabel && (wanted.includes(sampleLabel)||sampleLabel.includes(wanted))) similarity=Math.min(100,similarity+2);
    if(style!=='unspecified'&&sampleStyle===style) similarity=Math.min(100,similarity+2);
    rows.push({...example, similarity, distance:Number(distance.toFixed(4)), rating:Number(example.rating||3),space_evidence:{legacy:baseScore==null?null:Math.round(baseScore),two_d:twoScore==null?null:Math.round(twoScore),three_d:threeScore==null?null:Math.round(threeScore),personalized_mesh:meshSimilarity,disagreement:both&&Math.abs(twoScore-threeScore)>=28}});
  }
  return rows.sort((a,b)=>b.similarity-a.similarity || b.rating-a.rating).slice(0,8);
}

function selectedJointIds(parts=[]) {
  const ids=new Set();
  for(const part of parts) for(const id of PART_JOINTS[part]||[]) ids.add(id);
  return ids;
}
function pointOk(p) {
  return Array.isArray(p)&&finite(p[0])&&finite(p[1])&&(p[3]??1)>=.18;
}
function pointMid(a,b) {
  return pointOk(a)&&pointOk(b)?[(a[0]+b[0])/2,(a[1]+b[1])/2]:null;
}
function referencePoint(features, sample, jointIndex) {
  const off=sample*48+jointIndex*3;
  const x=Number(features[off]),y=Number(features[off+1]);
  return finite(x)&&finite(y)?[x,y]:null;
}

/**
 * Blend a reviewed reference into a short local window. Only selected anatomical
 * regions are changed, and each landmark is capped at 7% of torso length.
 */
export function applyPurcellReferenceCorrection(frames, {
  referenceFeatures, targetTime, windowStart, windowEnd, parts=[], aspect=1, strength=.28,
  maxShiftTorso=.07
}={}) {
  if(!Array.isArray(frames)||!Array.isArray(referenceFeatures)||referenceFeatures.length!==384||
     !finite(targetTime)||!finite(windowStart)||!finite(windowEnd)||windowEnd<=windowStart) {
    return {frames, changedLandmarks:0, changedFrames:0};
  }
  const ids=selectedJointIds(parts);
  if(!ids.size) return {frames, changedLandmarks:0, changedFrames:0};
  const output=frames.slice();
  let changedLandmarks=0,changedFrames=0;
  const safeAspect=finite(aspect)&&aspect>0?aspect:1;
  for(let i=0;i<frames.length;i++) {
    const frame=frames[i],t=Number(frame?.t);
    if(!finite(t)||t<windowStart-.001||t>windowEnd+.001) continue;
    const im=frame.im;
    if(!Array.isArray(im)||im.length<33) continue;
    const hip=pointMid(im[23],im[24]),shoulder=pointMid(im[11],im[12]);
    if(!hip||!shoulder) continue;
    const torso=Math.hypot((shoulder[0]-hip[0])*safeAspect,shoulder[1]-hip[1]);
    if(!(torso>.025&&torso<1.5)) continue;
    const refHipA=referencePoint(referenceFeatures,0,6),refHipB=referencePoint(referenceFeatures,0,7);
    const refShoulderA=referencePoint(referenceFeatures,0,0),refShoulderB=referencePoint(referenceFeatures,0,1);
    if(!refHipA||!refHipB||!refShoulderA||!refShoulderB) continue;
    const refHip=[(refHipA[0]+refHipB[0])/2,(refHipA[1]+refHipB[1])/2];
    const refShoulder=[(refShoulderA[0]+refShoulderB[0])/2,(refShoulderA[1]+refShoulderB[1])/2];
    const refTorso=Math.hypot(refShoulder[0]-refHip[0],refShoulder[1]-refHip[1]);
    if(!(refTorso>.25)) continue;
    const refAngle=Math.atan2(refShoulder[1]-refHip[1],refShoulder[0]-refHip[0]);
    const screenAngle=Math.atan2((shoulder[1]-hip[1]),(shoulder[0]-hip[0])*safeAspect);
    const rotation=screenAngle-refAngle;
    const scale=torso/refTorso;
    const sample=clamp(Math.round((t-windowStart)/(windowEnd-windowStart)*7),0,7);
    const next=im.map(p=>Array.isArray(p)?p.slice():p);
    let frameChanged=0;
    for(let j=0;j<LANDMARK_IDS.length;j++) {
      const id=LANDMARK_IDS[j];
      if(!ids.has(id)) continue;
      const current=im[id];
      if(!pointOk(current)) continue;
      const target=referencePoint(referenceFeatures,sample,j);
      if(!target) continue;
      const dx=target[0]-refHip[0],dy=target[1]-refHip[1];
      const rx=dx*Math.cos(rotation)-dy*Math.sin(rotation);
      const ry=dx*Math.sin(rotation)+dy*Math.cos(rotation);
      const tx=hip[0]+(rx*scale)/safeAspect;
      const ty=hip[1]+ry*scale;
      let sx=(tx-current[0])*safeAspect,sy=ty-current[1];
      const distance=Math.hypot(sx,sy),cap=maxShiftTorso*torso;
      if(distance<.018*torso) continue;
      const blend=Math.min(strength,cap/Math.max(distance,1e-8));
      sx*=blend;sy*=blend;
      if(Math.hypot(sx,sy)>.0015*torso) {
        next[id]=[current[0]+sx/safeAspect,current[1]+sy,current[2]??0,current[3]??1];
        frameChanged++;changedLandmarks++;
      }
    }
    if(frameChanged) {
      output[i]={...frame,im:next};
      changedFrames++;
    }
  }
  return {frames:output,changedLandmarks,changedFrames};
}

/**
 * Purcell baseline: conservative evidence gates independent of Lully labels and
 * personal examples. This uses only *reliable projected* support estimates.
 * It deliberately does not infer ground reaction forces, injury risks, or true
 * 3-D centre of mass. A failed gate returns no recommendation, not a guess.
 */
export function buildPurcellBaselineFindings({frames=[],metrics=[],strikes=[],strikeFallback=false,knowledge={}}={}) {
  if(!Array.isArray(frames)||!Array.isArray(metrics)||frames.length<10||metrics.length<10) return [];
  const policy=knowledge?.baseline_rules?.projected_balance||{};
  const minConfidence=clamp(Number(policy.min_pose_confidence??.72),.60,.95);
  const limit=clamp(Number(policy.margin_below??-.12),-.35,-.07);
  const duration=clamp(Number(policy.min_duration_s??.38),.30,1.5);
  const minSamples=Math.max(9,Math.floor(Number(policy.min_samples??10)));
  const minValidFraction=clamp(Number(policy.min_reliable_fraction??.75),.6,1);
  const footprint=(frame,m)=>{
    const im=frame?.im||[],feet=[29,30,31,32].map(id=>im[id]);
    if(!feet.every(pointOk)||!finite(m?.com_x))return null;
    const xs=feet.map(v=>v[0]),left=Math.min(...xs),right=Math.max(...xs);
    const head=im[0],h=pointOk(head)?Math.abs(feet.reduce((a,v)=>a+v[1],0)/feet.length-head[1]):null;
    if(!(h>.24 && right-left>.035))return null;
    const distance=Math.max(0,left-m.com_x,m.com_x-right)/h;
    return {outside:distance,left,right,h};
  };
  const rows=metrics.map((m,i)=>({m,frame:frames[i],t:Number(m?.t??frames[i]?.t),foot:footprint(frames[i],m)}))
    .filter(x=>finite(x.t)).sort((a,b)=>a.t-b.t);
  if(rows.length<minSamples) return [];
  const quality=rows.filter(x=>x.m?.bos_reliable && finite(x.m?.bos_margin_body_heights)&&
    finite(x.m?.pose_confidence)&&x.m.pose_confidence>=minConfidence);
  // No evidence if most of the sequence is unsuitable for support projection.
  const balanceQualified=quality.length/rows.length>=minValidFraction;
  const issues=[];let run=[];
  function commit(){
    if(run.length>=minSamples && run.at(-1).t-run[0].t>=duration &&
      // Reject moving-foot phases; apparent COM excursion is not automatically an error during a step.
      run.every(x=>Math.max(Math.abs(x.foot.left-run[0].foot.left),Math.abs(x.foot.right-run[0].foot.right)) < .065*run[0].foot.h)) {
      const worst=Math.max(...run.map(x=>x.foot.outside)),middle=run[Math.floor(run.length/2)];
      const actual=Number((run.at(-1).t-run[0].t).toFixed(2));
      const percent=Math.round(worst*100);
      issues.push({
        source:'purcell_builtin',rule_id:'projected_balance',kind:'stance',priority:1,
        confidence:clamp(.68+Math.min(.20,(run.length-minSamples)*.006),.68,.88),
        time_s:middle.t,start_s:run[0].t,end_s:run.at(-1).t,
        title:'Проверить устойчивость опоры',
        why:`В течение ${actual.toFixed(2)} с центр тела на изображении находился заметно сбоку от опоры; горизонтальное отклонение достигало ${percent}% видимой высоты тела.`,
        action:'Проверьте постановку стоп и положение таза в этом моменте. При необходимости измените подготовительный шаг и распределение веса, сохраняя рисунок ката.',
        evidence:`COM/опорная стопа в проекции · ${run.length} кадров · уверенность позы ≥ ${(minConfidence*100).toFixed(0)}%`,
        baseline_note:'Это оценка в проекции камеры, а не прямое измерение баланса или силы реакции опоры. В повороте и при скрытой стопе вывод требуется проверять по видео.'
      });
    }
    run=[];
  }
  for(const row of balanceQualified?rows:[]) {
    const m=row.m, previous=run.at(-1);
    if(previous&&(row.t-previous.t>.16 || (row.frame?.camera_segment_id??0)!==(previous.frame?.camera_segment_id??0)))commit();
    if(m?.bos_reliable && finite(m.bos_margin_body_heights)&&
       m.bos_margin_body_heights<=limit && row.foot?.outside>=.11 && finite(m.pose_confidence)&&m.pose_confidence>=minConfidence) run.push(row);
    else commit();
  }
  commit();
  // Repeated low inter-segment synchronization is evaluated only in high-quality
  // automatically detected strike windows. A single odd peak is never diagnosed.
  if(!strikeFallback && Array.isArray(strikes) && strikes.length>=2 && rows.length>=22) {
    const periods=rows.slice(1).map((x,i)=>x.t-rows[i].t).filter(x=>x>0&&x<.1).sort((a,b)=>a-b);
    const samplingPeriod=periods.length?periods[Math.floor(periods.length/2)]:Infinity;
    if(samplingPeriod<=.043) {
      const valid=strikes.filter(w=>finite(w?.sequencing_index)&&w.sequencing_index>=0&&w.sequencing_index<=.12&&
        finite(w.start_time_s)&&finite(w.end_time_s)&&w.end_time_s-w.start_time_s>=.16 &&
        w.end_time_s-w.start_time_s<=1.0 && Number(w.pose_confidence_mean)>=.78 &&
        Number(w.world_landmark_fraction)>=.65 && w.segment_id!=null)
        .sort((a,b)=>a.start_time_s-b.start_time_s);
      for(let i=1;i<valid.length;i++) {
        const a=valid[i-1],b=valid[i];
        if(a.segment_id!==b.segment_id || b.start_time_s-a.end_time_s>6 || b.start_time_s<a.end_time_s) continue;
        if(!rows.some(r=>r.t>=a.start_time_s&&r.t<=a.end_time_s) || !rows.some(r=>r.t>=b.start_time_s&&r.t<=b.end_time_s))continue;
        const score=Math.max(a.sequencing_index,b.sequencing_index),p=Math.round(score*100);
        issues.push({source:'purcell_builtin',rule_id:'repeated_strike_timing',kind:'hand_strike',priority:1,confidence:.78,
          time_s:(a.start_time_s+a.end_time_s)/2,start_s:a.start_time_s,end_s:b.end_time_s,
          title:'Проверить согласование ударной цепи',
          why:`Две отдельные ударные фазы имеют очень низкую согласованность временных пиков сегментов (SI не выше ${p}/100).`,
          action:'Сопоставьте на повторе начало работы таза и корпуса с разгоном плеча, локтя и кисти. Проверьте, не стартует ли рука раньше подготовки опоры; сохраняйте принятую в этом ката технику.',
          evidence:`SI двух ударных окон · MediaPipe world ≥65% · уверенность позы ≥78%`,
          baseline_note:'SI оценивает порядок пиков скоростей, а не ударную силу. Некоторые техники намеренно нарушают простую последовательность; решение проверяют по контексту и ракурсу.'
        });
        break;
      }
    }
  }
  // At most three separated actionable observations, and no near-duplicates.
  return issues.sort((a,b)=>(a.time_s-b.time_s)).filter((x,i,a)=>i===0||x.start_s-a[i-1].end_s>.30).slice(0,3);
}

export function buildPurcellDecisionLayer({
  plan, examples=[], feedback=[], windows=[], style='unspecified', aspect=1, knowledge={}, frames=[], metrics=[],strikes=[],strikeFallback=false,meshIdentity=null
}={}) {
  const baseline=buildPurcellBaselineFindings({frames,metrics,strikes,strikeFallback,knowledge});
  const trajectoryProfiles=[...(plan?.trajectory_analysis?.profiles||[])];
  if(!trajectoryProfiles.length&&!strikeFallback)for(const strike of strikes.slice(0,120)){const profile=analyzeMovementPhases(frames,{start:Number(strike.start_time_s),end:Number(strike.end_time_s),kind:'movement',aspect,confirmed:false,knowledge});if(profile.available)trajectoryProfiles.push(profile);}
  const trajectoryFindings=trajectoryProfiles.flatMap(p=>p.findings||[]);
  baseline.push(...trajectoryFindings);
  if(!plan?.available && !baseline.length) return {available:false,reason:plan?.reason||'Недостаточно качественных кадров.',recommendations:[],diagnostics:[]};
  const recommendations=[],diagnostics=[];
  const votes=Array.isArray(feedback)?feedback:[];
  for(const cue of [...(plan?.recommendations||[]),...baseline]) {
    if(!['purcell_builtin','purcell_trajectory'].includes(cue.source) && !actionableCue(cue)) continue;
    const window=windows.find(w=>Math.abs(Number(w.time_s)-Number(cue.time_s))<.08 &&
      (!w.kind||w.kind===cue.kind||cue.kind==='transition'));
    if(!window?.signature && !['purcell_builtin','purcell_trajectory'].includes(cue.source)) { diagnostics.push({title:cue.title,reason:'Недостаточно пригодных кадров для сравнения с базой Purcell.'}); continue; }
    const referenceKind=cue.kind==='transition'?(window.nextKind||window.kind||'movement'):cue.kind;
    const technique=findTechniqueKnowledge(cue,referenceKind,knowledge);
    const ranked=window?.signature?rankPurcellExamples(window.signature,examples,{kind:referenceKind,style,patternLabel:cue.pattern||'',signature_2d:window.signature_2d,signature_3d:window.signature_3d,meshIdentity}):[];
    const positives=ranked.filter(x=>Number(x.rating)>=4);
    const negatives=ranked.filter(x=>Number(x.rating)<=2);
    const positive=positives[0]||null,negative=negatives[0]||null;
    const similarVotes=votes.filter(v=>(v.kind||'movement')===cue.kind&&labelKey(v.title)===labelKey(cue.title));
    const wrong=similarVotes.filter(v=>v.decision==='wrong').length;
    const good=similarVotes.filter(v=>v.decision==='good').length;
    const acceptable=similarVotes.filter(v=>v.decision==='acceptable').length;
    if(wrong>good+Math.max(1,acceptable)) { diagnostics.push({title:cue.title,reason:'Похожие рекомендации ранее чаще отмечались как ошибочные; Purcell не повторяет их автоматически.'}); continue; }
    const phaseCandidate=cue.source==='purcell_trajectory'&&cue.trajectory_candidate?.mode==='phase_retiming'&&cue.confidence>=.76;
    const correctionAvailable=phaseCandidate || (cue.source!=='purcell_builtin' && positive?.kind!=='biomechanics' && !!positive && positive.similarity>=70 &&
      (!negative || positive.similarity>=negative.similarity-5));
    const parts=(positive?.good_parts||[]).filter(x=>['arms','trunk','legs','feet','hands'].includes(x));
    const correctionParts=parts.length?parts:inferParts(referenceKind);
    const counterexampleParts=(negative?.problem_parts||[]).filter(x=>['arms','trunk','legs','feet','hands'].includes(x));
    const evidence=[];
    if(positive) evidence.push(`положительный пример «${positive.label||'без названия'}» — индекс сходства ${positive.similarity}/100`);
    if(negative) evidence.push(`антипример «${negative.label||'без названия'}» — индекс сходства ${negative.similarity}/100`);
    if(wrong) evidence.push(`ранее отклонено ${wrong} похожих рекомендаций`);
    if(acceptable) evidence.push(`${acceptable} похожих рекомендаций ранее оценено как приемлемое`);
    const muscleContext=(technique?.muscle_groups||[]).map(id=>({id,...(knowledge.muscle_groups?.[id]||{})})).filter(x=>x.name_ru);
    const functionalChain=technique?.functional_chain||knowledge.functional_chains?.[referenceKind]||[];
    const phaseContext=technique?.phases||[];
    const principleContext=(technique?.principles||[]).map(id=>(knowledge.principles||[]).find(p=>p.id===id)).filter(Boolean);
    const principlesText=principleContext.map(p=>`${p.name}: ${p.practice}`).join(' ');
    const anatomyText=technique
      ?`Для техники «${technique.name_ru}» типичная цепь: ${functionalChain.join(' → ')}. Обычно участвуют группы: ${muscleContext.map(x=>x.name_ru).join(', ')}. Это анатомическое объяснение, не измерение активации мышц.`
      :`Для этого типа движения функциональная цепь: ${functionalChain.join(' → ')}. Конкретные мышцы и их активацию по этому видео подтвердить нельзя.`;
    // A concise grounded conclusion: the measured anomaly first, then the
    // proposed technical check, plus only the relevant personal/theory context.
    // No generic text generation and no false claims about measured muscles.
    const explanation=['purcell_builtin','purcell_trajectory'].includes(cue.source)
      ? [cue.why,cue.action,cue.baseline_note].filter(Boolean).join(' ')
      : [
        cue.why||'',
        cue.action||'',
        technique?`Контекст «${technique.name_ru}»: ${functionalChain.slice(0,4).join(' → ')}.`:'',
        principleContext.length?`Принцип для проверки: ${principleContext[0].practice}`:'',
        positive?`Сходный обучающий пример: ${positive.label||'движение'} (индекс ${positive.similarity}/100). ${positive.kind==='biomechanics'?'Это наблюдение о работе тела, не образец правильного ката.':''}`:'',
        negative?`Сходный антипример: ${negative.label||'движение'} (индекс ${negative.similarity}/100).`:'',
        wrong?`Ранее отклонено: ${wrong}.`:'',
      ].filter(Boolean).join(' ');
    recommendations.push({
      ...cue,
      technique_name:technique?.name_ru||null,
      muscle_context:muscleContext,
      phase_context:phaseContext,
      functional_chain_context:functionalChain,
      principle_context:principleContext,
      purcell_id:`purcell-${String(cue.kind||'movement')}-${Math.round(Number(cue.time_s||0)*1000)}`,
      purcell_explanation:explanation,
      correctionAvailable,
      correction_mode:phaseCandidate?'phase_retiming_candidate':correctionAvailable?'reviewed_reference':null,
      short_explanation:[cue.why,cue.action].filter(Boolean).join(' '),
      reference_similarity:positive?.similarity??null,
      reference_label:positive?.label||null,
      reference_id:positive?.id||null,
      reference_rating:positive?.rating??null,
      reference_note:positive?.notes||'',counterexample_note:negative?.notes||'',user_vote_summary:{good,acceptable,wrong},
      reference_parts:correctionParts,counterexample_parts:counterexampleParts,
      negative_similarity:negative?.similarity??null,
      evidence_summary:evidence.join(' · '),
      correction_window_start:window?.start_s??cue.start_s??null,
      correction_window_end:window?.end_s??cue.end_s??null,
      correction_features:correctionAvailable&&!phaseCandidate?positive.features:null
    });
  }
  return {available:true,recommendations,diagnostics,trajectory_profiles:trajectoryProfiles,method:'quality-gated biomechanics + phase-aware trajectories + optional Lully context + reviewed references + explicit avatar hypotheses + feedback'};
}

export function applyPurcellRecommendations(frames, recommendations=[], {aspect=1}={}) {
  let current=frames;
  const corrections=[];
  for(const cue of recommendations||[]) {
    if(cue.correctionAvailable&&cue.correction_mode==='phase_retiming_candidate'){
      const result=applyPhaseRetimingCandidate(current,cue.trajectory_candidate,{aspect});
      current=result.frames;
      if(result.changedFrames)corrections.push({id:cue.purcell_id,title:cue.title,time_s:cue.time_s,changed_landmarks:result.changedLandmarks,changed_frames:result.changedFrames,changed_hand_landmarks:result.changedHandLandmarks||0,candidate_space:'image_projection',reference_label:null,reference_similarity:null,hypothesis:true,method:result.method});
      continue;
    }
    if(!cue.correctionAvailable||!Array.isArray(cue.correction_features)) continue;
    const result=applyPurcellReferenceCorrection(current,{
      referenceFeatures:cue.correction_features,
      targetTime:Number(cue.time_s),
      windowStart:Number(cue.correction_window_start),
      windowEnd:Number(cue.correction_window_end),
      parts:cue.reference_parts||[],
      aspect,
      strength:.28,
      maxShiftTorso:.07
    });
    current=result.frames;
    if(result.changedFrames)corrections.push({id:cue.purcell_id,title:cue.title,time_s:cue.time_s,changed_landmarks:result.changedLandmarks,changed_frames:result.changedFrames,reference_label:cue.reference_label,reference_similarity:cue.reference_similarity});
  }
  return {frames:current,corrections,changedLandmarks:corrections.reduce((n,x)=>n+x.changed_landmarks,0),changedFrames:current.reduce((n,f,i)=>n+(f!==frames[i]?1:0),0),changedHandLandmarks:corrections.reduce((n,x)=>n+(x.changed_hand_landmarks||0),0)};
}
