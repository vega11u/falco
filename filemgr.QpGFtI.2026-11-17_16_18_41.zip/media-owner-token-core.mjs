/** Stable per-browser owner token for resumable social-video imports. */
const STORAGE_KEY = 'falco-media-owner-token-v1';
const TOKEN_RE = /^[a-f0-9]{64}$/;

function bytesToHex(bytes) {
  return Array.from(bytes, value => value.toString(16).padStart(2, '0')).join('');
}

function createToken(cryptoObject) {
  if (!cryptoObject || typeof cryptoObject.getRandomValues !== 'function') return null;
  const bytes = new Uint8Array(32);
  cryptoObject.getRandomValues(bytes);
  return bytesToHex(bytes);
}

export function getMediaOwnerToken(options = {}) {
  const readGlobal = name => { try { return globalThis[name] || null; } catch (_) { return null; } };
  const localStorage = Object.prototype.hasOwnProperty.call(options, 'localStorage') ? options.localStorage : readGlobal('localStorage');
  const sessionStorage = Object.prototype.hasOwnProperty.call(options, 'sessionStorage') ? options.sessionStorage : readGlobal('sessionStorage');
  const crypto = Object.prototype.hasOwnProperty.call(options, 'crypto') ? options.crypto : readGlobal('crypto');
  // Prefer durable storage so a reload/browser restart can still cancel its server job.
  try {
    const current = localStorage?.getItem(STORAGE_KEY) || '';
    if (TOKEN_RE.test(current)) return current;
  } catch (_) { /* Private browsing may deny localStorage. */ }

  try {
    const current = sessionStorage?.getItem(STORAGE_KEY) || '';
    if (TOKEN_RE.test(current)) return current;
  } catch (_) { /* Fall back to the legacy PHP session owner. */ }

  const token = createToken(crypto);
  if (!token) return null;
  try {
    if (localStorage) {
      localStorage.setItem(STORAGE_KEY, token);
      return token;
    }
  } catch (_) { /* Try session-only storage. */ }
  try {
    if (sessionStorage) {
      sessionStorage.setItem(STORAGE_KEY, token);
      return token;
    }
  } catch (_) { /* Server falls back to the PHP session hash. */ }
  return null;
}

export const MEDIA_OWNER_TOKEN_STORAGE_KEY = STORAGE_KEY;
