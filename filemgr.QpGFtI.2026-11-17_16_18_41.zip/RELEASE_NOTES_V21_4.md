# Falco Jugger v21.4.0 — release notes

This release focuses on the analysis workspace and reviewed learning loop. The original PHP backend, browser-side MediaPipe inference, ESM biomechanics/recognition cores, and personal learning store remain in place.

- Pinned 2D and 3D players with synchronized seek, frame stepping, playback rate and still-image export.
- Quality-only timeline and separate pattern-review cards with a representative avatar still for every instance.
- Per-instance Yes/No decisions, whole-group rejection, rethink/re-detect pass and explicit kata-reviewed completion.
- Simplified current metrics, with speed, support/COM proxy and harmony visible by default.
- Red/green optimizer comparison, region-level measurements, speed retention and feedback-weighted repeat passes.
- Bow candidates, optional camera-cut heuristics and segmentation-mask surface diagnostics.
- Corrected null handling, zero foot velocity, cut-aware derivatives, support-foot contact handling and aspect-correct stance geometry.

See `README.md`, `CHANGELOG.md` and `QA_REPORT_V21_4.md` for details and limitations.
