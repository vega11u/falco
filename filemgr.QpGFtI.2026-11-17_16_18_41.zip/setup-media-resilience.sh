#!/usr/bin/env bash
# Set up the complete resilient media-ingestion toolchain.
set -Eeuo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
echo '=== 1/2 · server-side social media downloaders ==='
bash "$ROOT/setup-media-import.sh"
echo
echo '=== 2/2 · browser-side FFmpeg.wasm fallback ==='
bash "$ROOT/setup-ffmpeg-wasm.sh"
echo
echo 'Media resilience setup complete. Refresh the app with Ctrl+F5 and check the server status panel.'
