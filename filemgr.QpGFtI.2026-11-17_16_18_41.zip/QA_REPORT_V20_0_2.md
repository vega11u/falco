# QA report — Falco Jugger v20.0.2

## Fixed regression

The `footLift` variable was previously declared inside the per-frame candidate predicate and then referenced later while constructing the kick event. That reference was out of scope and caused a ReferenceError when a kick window was emitted. The event now recomputes peak-frame foot lift through an exported, tested helper.

## Foot stability

Added confidence-gated spike repair for ankle/heel/toe points. Only a low-confidence one-frame deviation bracketed by high-confidence neighboring samples is replaced by time-interpolated coordinates. High-confidence samples are never modified by this filter. This is an outlier guard, not a new foot pose model; it cannot create missing toe/heel landmarks or correct systematic detector bias.

## YouTube

Added separate yt-dlp client profiles: default, web_safari/HLS, android_vr, and web_embedded. The profiles use one yt-dlp executable and allow adaptive, combined or video-only formats. No real REG.RU-IP download was performed in this environment. YouTube PO-token/IP restrictions remain external dependencies.

## Tests

- PHP syntax and release smoke.
- JavaScript syntax and biomechanics core tests.
- Foot-lift baseline/peak regression.
- Low-confidence foot spike repair and high-confidence movement preservation.
- Social-import URL validation, profile fallback, job queue, cleanup, status and file transfer using a mocked yt-dlp process.
- CRON integration with `proc_open` disabled.

These tests validate the application logic, not the user's browser, the REG.RU network route to YouTube, or biomechanical accuracy on real kata recordings.

## Full syntax pass

All PHP files in the project were checked with `php -l`; all shell scripts were checked with `bash -n`. The complete `RUN_CRON_INTEGRATION=1 bash tests/verify.sh` suite passed after applying the final changes.
