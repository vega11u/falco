# Install Falco Jugger 23.0.23 over 23.0.19 (REG.RU Host-0)

This is one integrated overlay. It includes the 23.0.22 integrated functionality plus the personalized dense surface extension. Do not install 23.0.20/23.0.21 or 23.0.22 separately.

The target must already contain the `falco_jugger_patch_23.0.12_23.0.19_combined.zip` marker. Extract this package to a temporary folder and run:

```bash
bash install-host0-patch-23.0.23.sh /absolute/path/to/site-root
```

The installer overlays only the listed application files. It does not delete, reset, rename or copy trained data, private reports, user configuration, vendor assets, model weights, uploads or caches. It does not create an external backup directory.

After installation, hard-refresh the browser (Ctrl+F5). Run one analysis with the clothing/surface option either on or off; segmentation masks are now requested for the personalized profile regardless of that display option. Check the 2D overlay, 3D avatar, report archive, and one Purcell training save before batch training. The Purcell batch queue also captures per-video surface extras in memory while that video is active; its localStorage draft intentionally stores only the compact legacy 384D vector. If the page is refreshed before annotation/save, reprocess that queued clip to regenerate its dense surface payload.
