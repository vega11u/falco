# Falco Jugger 23.0.26 — Unified Aero / Individual Silhouette / Kime

## Deployment base

Single direct installation **over exactly Falco Jugger 23.0.25 GLOBAL_EVOLUTION**, as released in `falco_jugger_patch_23.0.25_GLOBAL_EVOLUTION_OVER_23.0.24_HOST0.zip`. The installer checks 23.0.25 core hashes and stops on customized/unknown source rather than risk breaking user code or trained data. Does not require the older 23.0.24 ZIP and does not reinstall earlier patches.

## UI

- One Frutiger Aero / Windows Vista-inspired component system, consistent across Analyzer, Purcell and Models/Memory pages. Limited 60 / 30 / 10 visual palette: mist 60%, ocean 30%, lime accent 10%; light and dark support.
- Harmonized headers, panels, field controls, buttons, grid, typography, margins, card layouts and mobile breakpoints. Overrides are loaded after earlier CSS and do not replace existing JavaScript controls.
- Purcell result view removes redundant large default optimizer player; trims and source selection remain possible before analysis. No duplicate animated player surface after report; same 2D/3D replay engine used for result cards.
- Kime cards each contain an autonomous in-card 2D replay canvas with play/pause, scrubber, timestamp and reviewed Yes/No/Uncertain controls writing to the existing Monteverdi feedback endpoint. These replays show 2D landmarks, not source video imagery.

## Analysis and tracking

- Visible model-stage timeline for video, pose/hands, depth/consensus, Bach, Vivaldi, Lully, Monteverdi, Purcell and report. Displays states, reported details and stage duration; source events are not upgraded to completion without events. Resets at new analysis and reset; detailed existing app journal retained, with errors preserved.
- Kime influences overall score when there are measurable fast movements, with a weight scaling up to 15% at five or more measurable events; score cap preserved. Summary states count/hits and explicit weighted contribution. An archived report is migrated in memory idempotently for display.

## Measured silhouette and 3D

- Segmentation mask from MediaPipe is converted to a connected component anchored at this athlete’s torso. Background and separated adjacent people are removed; bad/missing masks do not create fabricated wide 2D geometry.
- Drawn 2D mesh coordinates and raster output both constrained to the frame’s measured mask (128x128 packed pixel foreground), avoiding mesh overdraw beyond measured apparel boundaries.
- Compact per-frame masks are **losslessly** run-length compressed in newly created server archives with fallback for uncompressible bitplanes; previous archives without masks and earlier uncompressed masks still import.
- Shared Vivaldi 3D fine-mesh viewer replaces obsolete oversized cylinder/sphere overlays and point clouds, uses smaller body radii, taper and restrained face shading. As a single-camera geometric rendering, occluded 3D surfaces remain unmeasured; 3D must not be treated as metrically exact or a physical kimono scan.

## Compatibility

Preserves learned databases, Lully/Purcell settings, server reports, vendor models and older archive schemas. New files are additive; installer only replaces listed runtime files. Existing APIs and 33-joint training format remain untouched.

## Notes

The silhouette can only match what the segmentation network actually recognizes. Where its mask is unavailable or poor, the renderer deliberately displays the observed skeleton rather than extrapolating a broad body. Kime scoring relies on measured fast events. Browser visual/video validation remains for live site testing.
