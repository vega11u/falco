# Falco Jugger v19.6.0 — полная перестройка загрузчиков

## Социальные ссылки

- Один официальный standalone yt-dlp 2026.10.26 для YouTube и Instagram.
- Deno 2.x только как JavaScript runtime для YouTube EJS challenge solver; без `deno cache`, npm graph, YouTube.js worker, Composer или PHP scraper.
- Удалены nightly-дубликат, `youtubei.js`, `athlon1600/youtube-downloader`, aria2/gallery-dl cascades и их старые entrypoints.
- Встроенные повторные попытки yt-dlp, 20-минутный лимит задачи, watchdog 4 минуты без обновления лога, одна задача на аккаунт.
- Сессионная очередь, CRON, allowlist, проверка размера/сигнатуры файла и потоковая передача сохранены.

## Локальные файлы

- Mediabunny 1.65.0 и официальный `@mediabunny/prores` 1.65.0 / TurboRes с проверкой npm SHA-512.
- ProRes подключается через ESM entrypoint и import map, который фиксирует одну общую копию peer dependency Mediabunny.
- FFmpeg.wasm 0.12.15 + core 0.12.10; core/WASM проверяются и загружаются с same-origin URL.
- MediaRecorder удалён из конвейера конвертации входного файла. Отдельная функция экспорта guide video не затронута.

## Установка

```sh
bash setup-release.sh
```

Системные Python/pip/venv, Node.js service, Composer, npm CLI, root или системные пакеты не нужны. Существующие `data/`, `training-data/` и приватные `.kata-*` каталоги сохраняются.

## Проверка

Полная локальная проверка релиза выполнена командой:

```sh
RUN_CRON_INTEGRATION=1 bash tests/verify.sh
```

Все PHP/JS/shell smoke tests и CRON integration прошли. Это не live-проверка публичного YouTube/Instagram с IP REG.RU и не браузерный тест конкретного MOV: такие условия нельзя честно подтвердить из локального тестового окружения.
