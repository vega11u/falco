/** Relative point-cloud export; requires a real depth snapshot and explicit user request.
 * Pinhole with assumed FOV; not a metrically calibrated room mesh. */
export function relativeSceneCloud(snapshot,{maxPoints=3500,fovDegrees=60}={}){
 const w=Number(snapshot?.width),h=Number(snapshot?.height),values=snapshot?.values;
 if(!Number.isInteger(w)||!Number.isInteger(h)||w<4||h<4||!values||values.length<w*h)throw Error('Нет карты глубины для реконструкции сцены');
 const fov=Math.max(25,Math.min(95,Number(fovDegrees)||60))*Math.PI/180,fx=.5*w/Math.tan(fov/2),fy=fx;
 const step=Math.max(1,Math.ceil(Math.sqrt(w*h/Math.max(100,maxPoints))));
 const points=[];for(let y=0;y<h;y+=step)for(let x=0;x<w;x+=step){
  const v=Number(values[y*w+x]);if(!Number.isFinite(v)||v<0||v>255)continue;
  // Stronger values in normalized inverse depth => nearer, not known metres.
  const z=.6+2.4*(1-v/255),X=(x-(w-1)/2)/fx*z,Y=(y-(h-1)/2)/fy*z;
  points.push([Math.round(X*1000)/1000,Math.round(Y*1000)/1000,Math.round(z*1000)/1000]);
 }
 return {schema:'falco-relative-scene-cloud-v1',units:'arbitrary relative depth, NOT metres',assumed_fov_deg:fov*180/Math.PI,points,
  limitations:'Single camera, uncalibrated focal length, relative model depth; a point cloud is a hypothesis, not measured room geometry.'};
}
