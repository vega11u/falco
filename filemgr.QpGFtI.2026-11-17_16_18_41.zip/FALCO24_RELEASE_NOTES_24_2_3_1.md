# Falco 24.2.3.1 — Workspace stylesheet hotfix

The 24.2.3 installer was rolled back because the legacy `falco24-workspace-mode.css`
stylesheet was still linked from `index.php`. This contradicted the clean UI migration
and triggered the production workspace integration smoke test.

Changes:
- Removed the remaining `falco24-workspace-mode.css?v=24.2.0` stylesheet link from the
  main analyzer. The clean 24.2.3 stylesheet remains the sole UI stylesheet linked here.
- Kept `lully.php` and `purcell-lab.php` standalone; no iframe or app embedding change.
- No API, DOM IDs, algorithms, training storage, or model data changed.
- Updated installer release labels to 24.2.3.1.

The installer continues to run the target site's workspace and Learning Centers smoke
tests, plus the patch's clean UI contract smoke. Any failed mandatory test triggers rollback.
