<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    exit('Research installer is CLI-only.');
}
/** PHP-only research-source installer. CLI; public HTTPS allowlist, quotas and atomic writes. */
$root=dirname(__DIR__);$store=$root.'/data/trained/research-sources';$report=$root.'/data/trained/research-acquisition.json';
$options=['only'=>'all','max-total-mb'=>400,'max-file-mb'=>80,'max-files-per-source'=>80,'dry-run'=>false];
foreach(array_slice($argv,1) as $arg){if($arg==='--dry-run'){$options['dry-run']=true;continue;}if(preg_match('/^--([a-z-]+)=(.+)$/',$arg,$m)&&array_key_exists($m[1],$options))$options[$m[1]]=in_array($m[1],['only'],true)?$m[2]:(int)$m[2];else {fwrite(STDERR,"Unknown argument $arg\n");exit(2);}}
foreach(['max-total-mb','max-file-mb','max-files-per-source'] as $field)if($options[$field]<1||$options[$field]>1500){fwrite(STDERR,"Invalid $field\n");exit(2);}
$allow=['api.github.com','raw.githubusercontent.com','api.figshare.com','ndownloader.figshare.com','huggingface.co','cdn-lfs.huggingface.co','cas-bridge.xethub.hf.co'];
function fj_install_fetch(string $url,int $limit,array $allow):string{
  if(!str_starts_with($url,'https://'))throw new RuntimeException('HTTPS required');
  $host=strtolower((string)parse_url($url,PHP_URL_HOST));
  if(!in_array($host,$allow,true))throw new RuntimeException('Untrusted download host: '.$host);
  if(function_exists('curl_init')){
    $ch=curl_init($url);$data='';
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>false,CURLOPT_CONNECTTIMEOUT=>12,CURLOPT_TIMEOUT=>90,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_USERAGENT=>'FalcoJugger-PHP-Research/23.0.7',CURLOPT_HTTPHEADER=>['Accept: application/json, */*'],CURLOPT_WRITEFUNCTION=>static function($h,$chunk)use(&$data,$limit){if(strlen($data)+strlen($chunk)>$limit)return 0;$data.=$chunk;return strlen($chunk);}]);
    $ok=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
    if(!$ok||$http<200||$http>=300)throw new RuntimeException('HTTP '.$http.' '.substr($err,0,160));
    return $data;
  }
  if(!filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))throw new RuntimeException('Requires PHP curl or allow_url_fopen');
  $ctx=stream_context_create(['http'=>['timeout'=>50,'follow_location'=>0,'header'=>"User-Agent: FalcoJugger-PHP-Research/23.0.7\r\n"]]);
  $stream=@fopen($url,'rb',false,$ctx);if(!$stream)throw new RuntimeException('Unable to fetch remote source');
  $data=stream_get_contents($stream,$limit+1);fclose($stream);
  if(!is_string($data)||strlen($data)>$limit)throw new RuntimeException('Source exceeds size limit');
  return $data;
}
function fj_install_json(string $url,array $allow):array{
 $data=json_decode(fj_install_fetch($url,4*1024*1024,$allow),true);if(!is_array($data))throw new RuntimeException('Source returned invalid JSON');return $data;
}
function fj_install_file(string $url,string $destination,int $max, array &$budget,array $allow):array{
 if(is_file($destination)&&filesize($destination)>0)return ['file'=>$destination,'bytes'=>filesize($destination),'sha256'=>hash_file('sha256',$destination),'cached'=>true];
 $bytes=fj_install_fetch($url,min($max,$budget['left']),$allow);
 if(strlen($bytes)<12)throw new RuntimeException('Download empty or incomplete');
 $ext=strtolower(pathinfo($destination,PATHINFO_EXTENSION));
 if(in_array($ext,['xml','osim'],true)&&function_exists('simplexml_load_string')){libxml_use_internal_errors(true);$xml=@simplexml_load_string($bytes,'SimpleXMLElement',LIBXML_NONET);libxml_clear_errors();if($xml===false)throw new RuntimeException('Invalid XML');}
 if($ext==='csv'&& !str_contains(substr($bytes,0,8192),',')&&!str_contains(substr($bytes,0,8192),';'))throw new RuntimeException('Invalid CSV');
 $dir=dirname($destination);if(!is_dir($dir)&&!mkdir($dir,0700,true))throw new RuntimeException('Cannot create destination');
 $tmp=tempnam($dir,'.incoming-');if(!$tmp||file_put_contents($tmp,$bytes,LOCK_EX)===false||!rename($tmp,$destination)){if($tmp&&is_file($tmp))unlink($tmp);throw new RuntimeException('Cannot save source file');}
 $budget['left']-=strlen($bytes);return ['file'=>$destination,'bytes'=>strlen($bytes),'sha256'=>hash('sha256',$bytes),'cached'=>false];
}
function fj_install_safe_path(string $base,string $path):string{
 $path=str_replace('\\','/',$path);if(str_starts_with($path,'/')||str_contains($path,'..')||!preg_match('~^[a-zA-Z0-9_./ +()-]+$~',$path))throw new RuntimeException('Invalid upstream path');
 return $base.'/'.implode('/',array_filter(explode('/',$path),static fn($x)=>$x!==''&&$x!=='.'));
}
$repos=[
 'shotokan_source'=>['fatibennacer','e-Sport-and-Smart-Coaching-System-using-a-Multiview-Dataset'],
 'opensim_anatomy'=>['opensim-org','opensim-models'],
 'myosuite_musculoskeletal'=>['MyoHub','myo_sim'],
 'opensim_3d_kinematics'=>['opensim-org','opensim-models']
];
$names=[...array_keys($repos),'opensim_moco_3d_walking','pavani_biomechanics','generic_3d_motion'];
if($options['only']!=='all'){
 if(!in_array($options['only'],$names,true)){fwrite(STDERR,"Unknown source\n");exit(2);}$names=[$options['only']];
}
if($options['dry-run']){echo json_encode(['sources'=>$names,'mode'=>'dry-run','runtime'=>'PHP only'],JSON_PRETTY_PRINT)."\n";exit(0);}
if(!is_dir($store)&&!mkdir($store,0700,true)){fwrite(STDERR,"Storage unavailable\n");exit(1);}
file_put_contents($store.'/.htaccess',"Require all denied\n");file_put_contents($store.'/index.html','');
$old=is_file($report)?json_decode((string)file_get_contents($report),true):null;
$status=is_array($old)?$old:['schema'=>'kata-research-acquisition-v1','sources'=>[]];
$budget=['left'=>$options['max-total-mb']*1048576];$perfile=$options['max-file-mb']*1048576;$maxfiles=$options['max-files-per-source'];
foreach($names as $name){
 echo "Source $name\n";$saved=[];$error=null;
 try{
   $base=$store.'/'.$name;
   if(isset($repos[$name])){
     [$owner,$repo]=$repos[$name];$info=fj_install_json("https://api.github.com/repos/$owner/$repo",$allow);$branch=(string)($info['default_branch']??'main');
     $tree=fj_install_json("https://api.github.com/repos/$owner/$repo/git/trees/".rawurlencode($branch).'?recursive=1',$allow);
     if($tree['truncated']??false)throw new RuntimeException('Incomplete GitHub tree');
     foreach(($tree['tree']??[]) as $entry){
       $path=(string)($entry['path']??'');$size=(int)($entry['size']??0);
       if(($entry['type']??'')!=='blob'||$size>$perfile)continue;
       if($name==='shotokan_source'&&!str_ends_with(strtolower($path),'.csv'))continue;
       if($name==='opensim_anatomy'&&!(str_starts_with($path,'Models/Rajagopal/')&&(str_ends_with($path,'.osim')||str_ends_with($path,'README.txt'))))continue;
       if($name==='myosuite_musculoskeletal'&&!(str_starts_with($path,'myo_sim/models/')&&str_ends_with($path,'.xml')))continue;
       if($name==='opensim_3d_kinematics'&&!(str_starts_with($path,'Models/')&&preg_match('/\.(osim|trc|mot|sto)$/i',$path)))continue;
       try{$dest=fj_install_safe_path($base,$path);$url="https://raw.githubusercontent.com/$owner/$repo/".rawurlencode($branch).'/'.implode('/',array_map('rawurlencode',explode('/',$path)));
         $saved[]=fj_install_file($url,$dest,$perfile,$budget,$allow)+['source'=>$url];}
       catch(Throwable $e){$saved[]=['file'=>$path,'error'=>$e->getMessage()];}
       if(count($saved)>=$maxfiles)break;
     }
   }elseif($name==='opensim_moco_3d_walking'){
      // Explicit, bounded OpenSim Moco 3D walking reference: no Python or OpenSim runtime.
      $upstream='https://api.github.com/repos/opensim-org/opensim-core/contents/OpenSim/Examples/Moco/example3DWalking?ref=main';
      $entries=fj_install_json($upstream,$allow);
      foreach($entries as $entry){$path=(string)($entry['name']??'');
       if(($entry['type']??'')!=='file'||!preg_match('/\.(?:osim|trc|mot|sto|xml|txt)$/i',$path)||((int)($entry['size']??0))>$perfile)continue;
       $url=(string)($entry['download_url']??'');if(!str_starts_with($url,'https://raw.githubusercontent.com/'))continue;
       try{$saved[]=fj_install_file($url,fj_install_safe_path($base,$path),$perfile,$budget,$allow)+['source'=>$url];}
       catch(Throwable $e){$saved[]=['file'=>$path,'error'=>$e->getMessage()];}
       if(count($saved)>=$maxfiles)break;
      }
   }elseif($name==='pavani_biomechanics'){
      $info=fj_install_json('https://api.figshare.com/v2/articles/32288943',$allow);
      if(!is_dir($base))mkdir($base,0700,true);
      file_put_contents($base.'/article-metadata.json',json_encode(['title'=>$info['title']??null,'doi'=>$info['doi']??null,'published_date'=>$info['published_date']??null],JSON_UNESCAPED_UNICODE));
      foreach(array_slice($info['files']??[],0,$maxfiles) as $entry){$namepart=basename((string)($entry['name']??''));$url=(string)($entry['download_url']??'');if($namepart===''||!str_starts_with($url,'https://'))continue;
       try{$saved[]=fj_install_file($url,fj_install_safe_path($base,$namepart),$perfile,$budget,$allow)+['source'=>$url];}catch(Throwable $e){$saved[]=['file'=>$namepart,'error'=>$e->getMessage()];}
      }
   }else{
      $info=fj_install_json('https://huggingface.co/api/datasets/exptech/g1-moves/tree/main?recursive=true&expand=false',$allow);
      foreach($info as $entry){$path=(string)($entry['path']??'');if(($entry['type']??'')!=='file'||!preg_match('~(^|/)karate/.+/capture/.+\.(bvh|mp4)$~i',$path))continue;
       $url='https://huggingface.co/datasets/exptech/g1-moves/resolve/main/'.implode('/',array_map('rawurlencode',explode('/',$path)));
       try{$saved[]=fj_install_file($url,fj_install_safe_path($base,$path),$perfile,$budget,$allow)+['source'=>$url];}catch(Throwable $e){$saved[]=['file'=>$path,'error'=>$e->getMessage()];}
       if(count($saved)>=$maxfiles)break;
      }
   }
 }catch(Throwable $e){$error=$e->getMessage();}
 $completed=count(array_filter($saved,static fn($x)=>isset($x['sha256'])));
 $status['sources'][$name]=['status'=>$completed?'downloaded':($error?'error':'unavailable'),'file_count'=>$completed,'items'=>$saved,'trained'=>false];
 if($error)$status['sources'][$name]['message']=$error;
 $status['updated_at']=gmdate('c');
 $tmp=$report.'.tmp';file_put_contents($tmp,json_encode($status,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_INVALID_UTF8_SUBSTITUTE));rename($tmp,$report);
 echo "Verified files: $completed".($error?"; $error":'')."\n";
}
$status['updated_at']=gmdate('c');echo "Research download status stored at $report\n";
