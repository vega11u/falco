<?php
declare(strict_types=1);
/** PHP-only offline research index builder, CLI or protected API inclusion. */
function fj_build_evidence_index(string $root): array {
    $target=$root.'/data/trained/purcell-evidence-index.json';
    $sourceDir=$root.'/data/trained/research-sources';
    $items=[];$seen=[];$limit=14000;
    $add=static function(string $source,string $file,string $kind,string $title,string $content,string $level='source_text',array $tags=[]) use (&$items,&$seen,$limit): void {
        if(count($items)>=$limit)return;
        $title=trim(substr($title,0,170));
        $content=trim((string)preg_replace('/\s+/u',' ',$content));
        if(strlen($content)<18)return;
        $content=substr($content,0,1100);
        $id=substr(hash('sha256',$source.'|'.$file.'|'.$kind.'|'.$title.'|'.$content),0,20);
        if(isset($seen[$id]))return;$seen[$id]=true;
        $items[]=['id'=>$id,'source'=>$source,'file'=>$file,'kind'=>$kind,'title'=>$title,'text'=>$content,'evidence_level'=>$level,'tags'=>array_slice($tags,0,10)];
    };
    $knowledge=json_decode((string)@file_get_contents($root.'/data/purcell-knowledge.json'),true);
    if(is_array($knowledge))foreach($knowledge as $key=>$values){
        if(in_array($key,['principles','technique_mappings','reading'],true)&&is_array($values))foreach($values as $row){
            if(!is_array($row))continue;
            $txt=[];foreach($row as $k=>$v)if($k!=='id'&&$k!=='url'&&is_scalar($v))$txt[]=$k.': '.$v;
            $add('purcell_builtin','data/purcell-knowledge.json',$key,(string)($row['name_ru']??$row['label']??$row['title']??$row['id']??$key),implode('; ',$txt),'theoretical_rule');
        }elseif(in_array($key,['muscle_roles','functional_chains','body_parts','muscle_groups'],true)&&is_array($values))foreach($values as $name=>$v){
            $txt=is_scalar($v)?(string)$v:json_encode($v,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
            $add('purcell_builtin','data/purcell-knowledge.json',$key,is_array($v)?(string)($v['label']??$v['id']??$name):(string)$name,(string)$txt,'theoretical_rule',[(string)$name]);
        }
    }
    if(is_dir($sourceDir)){
        $iterator=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($sourceDir,FilesystemIterator::SKIP_DOTS));
        foreach($iterator as $f){
            if(count($items)>=$limit)break;
            if(!$f->isFile()||$f->isLink()||$f->getSize()>12*1024*1024)continue;
            $path=$f->getPathname();$rel='data/trained/research-sources/'.str_replace('\\','/',substr($path,strlen($sourceDir)+1));
            $parts=explode('/',substr($rel,strlen('data/trained/research-sources/')));$group=$parts[0]??'research';
            $ext=strtolower(pathinfo($path,PATHINFO_EXTENSION));$name=pathinfo($path,PATHINFO_FILENAME);
            if(in_array($ext,['txt','md'],true)){
                $raw=substr((string)@file_get_contents($path),0,30000);
                foreach(array_slice(preg_split('/\R\s*\R/u',$raw)?:[],0,100) as $i=>$chunk)$add($group,$rel,'documentation',$name.' §'.($i+1),$chunk);
            }elseif($ext==='csv'){
                $handle=@fopen($path,'rb');if(!$handle)continue;
                $head=fgetcsv($handle);if(is_array($head)){
                    $add($group,$rel,'dataset_schema',$name.' — колонки',implode(', ',$head),'dataset_metadata');
                    for($i=0;$i<300&&($row=fgetcsv($handle))!==false;$i++){
                        $fields=[];foreach($row as $j=>$value)if(isset($head[$j])&&is_string($value)&&!preg_match('/^[-\d.,eE ]+$/',$value))$fields[]=$head[$j].': '.substr($value,0,80);
                        $add($group,$rel,'dataset_observation',$name.' строка '.($i+2),implode('; ',$fields),'dataset_observation');
                    }
                }fclose($handle);
            }elseif(in_array($ext,['xml','osim'],true)){
                $old=false;$xml=null;
                if(function_exists('simplexml_load_file')){$old=libxml_use_internal_errors(true);$xml=@simplexml_load_file($path,'SimpleXMLElement',LIBXML_NONET|LIBXML_NOCDATA);libxml_clear_errors();libxml_use_internal_errors($old);}
                // On lean shared PHP hosting ext-simplexml is often absent. An XML
                // tag-name catalogue is still useful, but is metadata only.
                if($xml){
                    $add($group,$rel,'anatomy_model',$name,'Структурная биомеханическая модель '.$f->getFilename().', корень '.$xml->getName().'. Мышечная активация не измерена.','structural_metadata');
                    $n=0;foreach($xml->xpath('//*[@name]')?:[] as $node){$type=strtolower($node->getName());if(!preg_match('/body|joint|muscle|coordinate|ligament|force|pathpoint/',$type))continue;
                        $label=(string)$node['name'];$add($group,$rel,'anatomy_structure',$label,"Структура $type: $label; модель ".$f->getFilename().'. Не измерение человека.','structural_metadata',[$type,$label]);if(++$n>=250)break;}
                }else{
                    $raw=(string)@file_get_contents($path);$count=preg_match_all('/<([A-Za-z][A-Za-z0-9_-]*)(?:\s+[^<>]{0,800}?)?\s+name=["\']([^"\']{1,120})["\'][^<>]*>/i',$raw,$matches,PREG_SET_ORDER);
                    if($count){$add($group,$rel,'anatomy_model',$name,'XML модель '.$f->getFilename().' (объекты без XML расширения PHP).','structural_metadata');
                        $n=0;foreach($matches as $m){$type=strtolower($m[1]);if(!preg_match('/body|joint|muscle|coordinate|ligament|force|pathpoint/',$type))continue;
                            $label=html_entity_decode($m[2],ENT_QUOTES|ENT_XML1,'UTF-8');$add($group,$rel,'anatomy_structure',$label,"Структура $type: $label; файл ".$f->getFilename().'. Только метаданные.','structural_metadata',[$type,$label]);if(++$n>=250)break;}
                    }
                }
            }elseif(in_array($ext,['trc','mot','sto'],true)){
                $handle=@fopen($path,'rb');if(!$handle)continue;
                $head='';for($line=0;$line<20&&!feof($handle);$line++)$head.=(string)fgets($handle);
                fclose($handle);
                $columns=[];foreach(preg_split('/\R/',$head)?:[] as $line){
                    if(str_contains($line,"\t")&&preg_match('/time|frame|marker|ground|pelvis|hip|knee|ankle|moment|force/i',$line)){
                        $columns=array_slice(array_filter(preg_split('/\t+/',trim($line))?:[]),0,70);break;
                    }
                }
                $add($group,$rel,'kinematic_3d_metadata',$name,strtoupper($ext).' OpenSim 3D time-series header; columns: '.implode(', ',$columns).'. These are model/reference signals, not an athlete\'s kata or measured forces.', 'motion_metadata',$columns);
            }elseif($ext==='bvh'){
                $handle=@fopen($path,'rb');if(!$handle)continue;$raw='';for($i=0;$i<150&&!feof($handle);$i++)$raw.=fgets($handle);fclose($handle);
                preg_match_all('/\b(?:ROOT|JOINT)\s+([^\r\n{]+)/',$raw,$matches);
                $joints=array_slice(array_map('trim',$matches[1]??[]),0,35);
                $add($group,$rel,'motion_reference',$name,'BVH; суставы: '.implode(', ',$joints).'. Для оценки ката требуется согласование кинематики и масштаба.','motion_metadata',array_slice($joints,0,8));
            }elseif($ext==='json'&&str_ends_with($f->getFilename(),'metadata.json')){
                $meta=json_decode((string)@file_get_contents($path),true);
                if(is_array($meta))$add($group,$rel,'publication_metadata',(string)($meta['title']??$name),'Исследование. DOI: '.($meta['doi']??'не указан').'; дата: '.($meta['published_date']??'неизвестна'),'publication_metadata');
            }
        }
    }
    $counts=[];foreach($items as $row)$counts[$row['source']]=($counts[$row['source']]??0)+1;
    $revision=substr(hash('sha256',json_encode($items,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE)),0,20);
    $payload=['schema'=>'purcell-evidence-index-v1','index_revision'=>$revision,'count'=>count($items),'counts_by_source'=>$counts,'units'=>'source passages; not trained model weights','items'=>$items];
    if(!is_dir(dirname($target)))mkdir(dirname($target),0700,true);
    $tmp=tempnam(dirname($target),'.purcell-index-');
    if(!$tmp)throw new RuntimeException('Не удаётся создать временный индекс');
    try{if(file_put_contents($tmp,json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE|JSON_UNESCAPED_SLASHES))===false)throw new RuntimeException('Ошибка записи индекса');if(!rename($tmp,$target))throw new RuntimeException('Ошибка атомарного сохранения индекса');}finally{if(is_file($tmp))unlink($tmp);}
    return ['ok'=>true,'index'=>$target,'count'=>count($items),'revision'=>$revision,'sources'=>$counts];
}
if(PHP_SAPI==='cli'&&realpath($_SERVER['SCRIPT_FILENAME']??'')===__FILE__){
    try{$result=fj_build_evidence_index(dirname(__DIR__));echo json_encode($result,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)."\n";}catch(Throwable $e){fwrite(STDERR,$e->getMessage()."\n");exit(1);}
}
