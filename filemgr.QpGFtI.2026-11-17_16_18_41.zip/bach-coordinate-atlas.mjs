/** Bach Coordinate Atlas v1: one image coordinate convention, not metric camera calibration. */
export const BACH_ATLAS_VERSION='bach-atlas-v1';
const valid=(p,d)=>Array.isArray(p)&&p.length>=d&&p.slice(0,d).every(Number.isFinite)&&(p[3]??1)>=.12;
const mid=(a,b)=>a.map((x,i)=>(x+b[i])*.5);
const dist=(a,b,d)=>Math.hypot(...Array.from({length:d},(_,i)=>a[i]-b[i]));
export function bachAtlasFrame(frame,{aspect=1}={}){
 const p=frame?.render_im||frame?.im||[],w=frame?.render_w||frame?.w||[],shoulders=valid(p[11],2)&&valid(p[12],2)?mid(p[11].slice(0,2),p[12].slice(0,2)):null;
 const hips=valid(p[23],2)&&valid(p[24],2)?mid(p[23].slice(0,2),p[24].slice(0,2)):null;
 const size=valid(p[11],2)&&valid(p[12],2)?dist(p[11],p[12],2):null;
 const origin=hips||shoulders;
 return {schema:BACH_ATLAS_VERSION,space:'image-normalized',aspect,origin,scale:size,visible_joints:p.filter(x=>valid(x,2)).length,world_visible_joints:w.filter(x=>valid(x,3)).length,scene_transform_calibrated:false,notes:'All inference modules use image-normalized x,y and source timestamps. World coordinates are body-relative unless externally calibrated.'};
}
/** Similarity-normalized motion descriptors: physical size and weight are NOT classifier labels. */
export function normalizedTechniqueVector(frame){const p=frame?.render_im||frame?.im||[];const root=valid(p[23],2)&&valid(p[24],2)?mid(p[23],p[24]):null;const shoulder=valid(p[11],2)&&valid(p[12],2)?dist(p[11],p[12],2):null;if(!root||!(shoulder>.015))return null;
 return [11,12,13,14,15,16,23,24,25,26,27,28].flatMap(i=>valid(p[i],2)?[(p[i][0]-root[0])/shoulder,(p[i][1]-root[1])/shoulder]:[null,null]);}
