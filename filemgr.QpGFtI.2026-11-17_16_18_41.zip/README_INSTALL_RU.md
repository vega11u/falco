# Falco Jugger 27.2.1-C.D2 — Research C / Vista Precision Lab D2 hotfix

Исправление ошибки dry-run установщика 27.2.0 на Host-0.

## Что исправлено
- `body-reconstruction-worker.js` и `pose-worker.js` проверяются как ES-модули: установщик временно копирует их в файлы `.mjs` и вызывает `node --check` для `.mjs`. Они больше не передаются Node как CommonJS `.js`.
- Обычный `falco-jugger-ui.js` проверяется отдельно как классический скрипт.
- Если Node на хостинге не поддерживает ESM и современный синтаксис, Node-проверки пропускаются с явным предупреждением; PHP-проверки целостности и интеграции остаются обязательными.
- Исправлен cache-busting URL Worker: `v=27.2.1`, чтобы браузер не продолжал использовать Worker с ключом `27.1.0`.
- Усилены release smoke / integrity checks: они проверяют и ключ кеша, и `type:'module'`.

## Проверка установки

Архив `Falco_Jugger_Research_C_D2_27_2_1.zip` положить в `$HOME/www/falcojugger.art`.

Сначала dry-run:

```bash
cd "$HOME/www/falcojugger.art" && ( T="$(mktemp -d)" && trap 'rm -rf "$T"' EXIT && unzip -q Falco_Jugger_Research_C_D2_27_2_1.zip -d "$T" && bash "$T/install-host0-c-d2-27.2.1.sh" "$PWD" --dry-run )
```

После успешного dry-run — установка:

```bash
cd "$HOME/www/falcojugger.art" && ( T="$(mktemp -d)" && trap 'rm -rf "$T"' EXIT && unzip -q Falco_Jugger_Research_C_D2_27_2_1.zip -d "$T" && bash "$T/install-host0-c-d2-27.2.1.sh" "$PWD" --install )
```

## Безопасность
- Требуется PHP 8.1+.
- Базовая версия сайта должна оставаться `23.0.27`.
- Изменяемые файлы резервируются в `$HOME/.falco-backups/`.
- Обученные данные, отчёты, конфигурации, медиа и кэш моделей не входят в список изменяемых файлов.
- GC сохраняет прежнюю allowlist/quarantine модель и не удаляет непроверенные файлы.
