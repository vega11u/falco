# Аудит конвейера импорта Falco Jugger v19.6.0

## Цель перестройки

Удалить параллельные экстракторы и несовместимые резервные интеграции, а не добавлять всё новые попытки поверх предыдущих. Сохраняются PHP + браузерный JavaScript, URL-import YouTube/Instagram, очередь, CRON режим, приватное хранение временных задач, проверка URL/файла, передача в сессию и лимит одновременной загрузки.

## Социальные URL

- Один официальный standalone yt-dlp 2026.10.26 для YouTube и Instagram; бинарник и SHA-256 manifest берутся из upstream GitHub Releases.
- Deno 2.x — только JS-runtime для EJS challenge solver YouTube. yt-dlp standalone содержит собственные EJS-компоненты; installer не строит npm dependency graph и не вызывает `deno cache`.
- Удалены youtubei.js worker/npm cache, nightly-вариант бинарника, aria2 cascade, gallery-dl/Python path, Composer-based `athlon1600/youtube-downloader` и PHP fallback с несовместимыми сигнатурами.
- Повторы запросов, фрагментов, extractor и файловых операций принадлежат самому yt-dlp; в PHP создаётся один supervised worker. Лимиты: 20 минут на job/attempt и watchdog 4 минуты без роста лога; один активный job на хостинг-аккаунт.
- Сессионная очередь, cron fallback для хостингов с отключённым `proc_open`, allowlist доменов, signature/size validation, временный приватный каталог и post-transfer cleanup сохранены.

## Локальные файлы

- Mediabunny 1.65.0 — контейнерный demuxer и `VideoSampleSink` для покадрового чтения.
- `@mediabunny/prores` 1.65.0 / TurboRes — официальный ProRes decoder. Установщик получает реальный ESM entrypoint `mediabunny-prores.mjs`, проверяет npm SHA-512 integrity и устанавливает его рядом с Mediabunny.
- Import map закрепляет peer dependency `mediabunny` на одном и том же локальном ESM bundle, чтобы не создать две независимые копии реестра декодеров.
- FFmpeg.wasm 0.12.x загружается как same-origin module/core/WASM. Перед инициализацией проверяются HTTP-ответы, core/WASM передаются URL напрямую, без Blob URL.
- Удалён MediaRecorder из входной конвертации: запись воспроизводимого потока в реальном времени не является надёжным декодером/транскодером исходного файла. Экспорт оптимизированного guide video остаётся отдельной возможностью.
- Нативный предпросмотр не считается достаточным доказательством покадровой декодируемости: анализ разрешается только при доступном декодере и читаемых samples.

## Установка и совместимость

`setup-release.sh` разворачивает все assets. `setup-media-import.sh` также запускает `setup-video-runtime.sh`, чтобы частичное обновление загрузчиков не оставляло без демультиплексора. Нет системных Python/pip/venv, Node.js service, Composer, root, `npm install` или `deno cache`.

## Проверки

`tests/verify.sh` проверяет PHP/JS/shell syntax, release/installer contracts, integrity validation logic, frame-analysis interfaces, mock social importer, transfer/cleanup, CRON serialization and one-worker lock. Эти тесты подтверждают локальную корректность оркестрации, но не заменяют live YouTube/Instagram access from REG.RU и тестовую ProRes/MOV выборку в целевом браузере.
