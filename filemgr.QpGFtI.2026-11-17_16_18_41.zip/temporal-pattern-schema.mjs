/** Versioned detailed pattern memory. Legacy rows remain readable and untouched. */
export const TEMPORAL_PATTERN_SCHEMA='kata-pattern-v2';
export function makeTemporalPattern({kind,label,frames,fps=null,athlete=null,source='user-labelled',notes=''}){
 if(!Array.isArray(frames)||frames.length<2)throw new Error('Pattern requires at least two frames');
 const t=frames.map((f,i)=>Number.isFinite(f.t)?f.t:i/(fps||30));
 if(t.some((v,i)=>i&&v<=t[i-1]))throw new Error('Pattern timestamps must be strictly increasing');
 const duration=t.at(-1)-t[0];if(!(duration>0&&duration<=8))throw new Error('Pattern duration outside supported 0–8s window');
 const pick=(f)=>({t:f.t,im:f.im||[],w:f.w||[],surface2d:f.surface2d||null,surface3d:f.surface3d||null,confidence:f.confidence??null,phase:f.phase??null});
 return {schema:TEMPORAL_PATTERN_SCHEMA,legacy_compatible:true,kind:String(kind||'movement'),label:String(label||''),duration_s:+duration.toFixed(4),sample_count:frames.length,athlete_profile:athlete?{height_m:athlete.height_m??null,segment_ratios:athlete.segment_ratios??null,body_shape:athlete.body_shape??null}:null,temporal_track:frames.map(pick),phase_boundaries:frames.filter(f=>f.phase).map(f=>({t:f.t,phase:f.phase})),source,notes:String(notes).slice(0,2000),created_at:new Date().toISOString()};
}
export function readTemporalPattern(row){if(row?.schema===TEMPORAL_PATTERN_SCHEMA)return row;if(Array.isArray(row?.frames))return {...row,schema:'kata-pattern-v1',legacy_compatible:true,temporal_track:row.frames};return {...row,schema:'legacy-opaque',legacy_compatible:true};}
