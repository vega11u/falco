# Architecture note — v22.4.0

## Scope

This release is a presentation and release-packaging update. The PHP APIs, private storage model, classifier, biomechanics engines, video decoder, report transport, and import workers are not rewritten.

## Presentation layers

- `baroque-editorial-v22-4.css` is the sole presentation layer for the shared analyzer, Purcell and archive markup; the old studio skin has been retired. It resets the previous gradients, dark card surfaces, round corners, Bebas Neue headings and decorative seals.
- `index.php` retains all existing control IDs and browser module contracts. Its hero now contains only the page title.
- `uppurcell.php` continues to use the shared analyzer engine with `FALCO_PURCELL_MODE`; the video trimmer and analysis controls retain their IDs.
- `Memories.php` retains the same report-list API and actions; its fabricated FJ badge and MEM/XXII seal have been removed.

## Typography and brand

`Falco Jugger` is the only brand mark. IM Fell English SC (17th-century Fell type revival) is used only for the Latin project name. All UI labels, buttons, headings, forms and explanatory text use Times New Roman. If Google Fonts is unavailable, the wordmark falls back to Times New Roman/serif; no runtime functionality depends on the external font.

## Compatibility guarantees

- No database schema or private storage path changes.
- No migration or overwrite of Lully, Purcell or report data.
- No change to API route names or payload schemas.
- No change to MediaPipe, Mediabunny, Depth Anything, Lux or yt-dlp worker behavior.
- Existing DOM IDs and event hooks are retained; only static header/hero markup was simplified.

## Hosting

REG.RU Host-0 remains PHP + browser JavaScript. The new stylesheet is static CSS and requires no build process, Node service or Python runtime.
