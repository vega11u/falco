# Deployment — Falco Jugger v19.5.0

1. Back up the current site files and private data directory.
2. Upload/extract this release over the existing project.
3. Preserve `data/`, `training-data/`, `vendor/`, and the private `.kata-*` storage directories. Do not delete or replace user-generated data.
4. Run `bash setup-media-import.sh` from the project root if the local Mediabunny runtime or YouTube.js cache is not installed.
5. Hard-refresh the browser (Ctrl+Shift+R / clear mobile site cache).
6. Open `index.php?api=health`. Check `local_video_pipeline` and `media_import` values.
7. Test with a short H.264 MP4 first, then a public YouTube video.

The local video is intentionally processed in the browser and is not uploaded to the server. The YouTube smoke test uses a mocked Deno executable; live YouTube availability is not guaranteed and must be verified from the hosting account's network.

Release validation: `RUN_CRON_INTEGRATION=1 bash tests/verify.sh`.
