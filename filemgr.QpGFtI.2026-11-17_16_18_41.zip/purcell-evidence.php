<?php
declare(strict_types=1);
/** Retrieval of research evidence per movement pattern; imported by index.php API dispatcher. */
function fj_evidence_tokens(string $text): array {
    $text = function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtr(strtolower($text),
        array_combine(preg_split('//u','АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ',-1,PREG_SPLIT_NO_EMPTY),
                      preg_split('//u','абвгдеёжзийклмнопрстуфхцчшщъыьэюя',-1,PREG_SPLIT_NO_EMPTY)));
    preg_match_all('/[\p{L}\p{N}]{3,}/u', $text, $matches);
    $words = array_unique(array_slice($matches[0] ?? [], 0, 100));
    return array_fill_keys($words, true);
}
function fj_evidence_query(string $kind, string $label, string $observations): string {
    $aliases = [
      'stance' => 'стойка опора стопы пятка колено таз баланс stance ground support foot hip knee ankle stabilizer',
      'kick' => 'удар ногой разгибание колено таз опорная нога kick leg hip quadriceps hamstring',
      'hand_strike' => 'удар рукой плечо локоть кисть вращение корпуса strike punch shoulder wrist elbow',
      'strike' => 'удар рукой плечо локоть кисть вращение корпуса strike punch shoulder wrist elbow',
      'hand' => 'рука кисть локоть плечо лопатка hand arm wrist elbow shoulder scapula',
      'block' => 'блок защита плечо предплечье локоть block arm elbow shoulder',
      'transition' => 'переход перемещение смена опоры таз координация transition shift balance pelvis',
      'balance' => 'равновесие центр масс опора стопа balance support body mass foot',
    ];
    return substr($kind.' '.$label.' '.$observations.' '.($aliases[$kind] ?? ''), 0, 1200);
}
function fj_evidence_search(array $input, string $indexPath): array {
    $raw = @file_get_contents($indexPath);
    $index = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($index) || !is_array($index['items'] ?? null))return ['ok'=>false,'error'=>'Индекс исследований не создан. Запустите php research/build_evidence_index.php.','results'=>[]];
    // User votes steer relevance only. They never change source content or
    // assert physiological truth. Preferences are bounded per request.
    $preferences=[];
    foreach(array_slice((array)($input['preferences']??[]),0,1000,true) as $id=>$vote){
        if(is_string($id)&&preg_match('/^[0-9a-f]{20}$/',$id)&&is_numeric($vote))$preferences[$id]=max(-3,min(3,(int)$vote));
    }
    $patterns=$input['patterns']??[];
    if (!is_array($patterns))$patterns=[];
    $patterns=array_slice($patterns,0,80);
    $results=[];
    foreach($patterns as $p){
        if(!is_array($p))continue;
        $id=substr((string)($p['id']??''),0,100);
        $kind=substr((string)($p['kind']??'movement'),0,50);
        $label=substr(trim((string)($p['label']??'')),0,120);
        $observations=substr((string)($p['observations']??''),0,500);
        $query=fj_evidence_tokens(fj_evidence_query($kind,$label,$observations));
        $rank=[];
        foreach($index['items'] as $item){
            if(!is_array($item))continue;
            $tokens=fj_evidence_tokens((string)($item['title']??'').' '.(string)($item['text']??'').' '.implode(' ',(array)($item['tags']??[])));
            $overlap=count(array_intersect_key($query,$tokens));
            if($overlap<2)continue;
            $score=$overlap / sqrt(max(1,count($tokens))) + ($item['source']==='purcell_builtin' ? .08:0) + .075*($preferences[$item['id']]??0);
            $rank[]=['score'=>$score,'item'=>$item];
        }
        usort($rank,static fn($a,$b)=>$b['score']<=>$a['score']);
        $picked=[];$bySource=[];
        foreach($rank as $hit){
            $item=$hit['item'];$src=(string)($item['source']??'unknown');
            if(($bySource[$src]??0)>=2)continue;
            $bySource[$src]=($bySource[$src]??0)+1;
            $picked[]=['id'=>$item['id'],'source'=>$src,'file'=>$item['file'],'title'=>$item['title'],'text'=>substr($item['text'],0,650),'evidence_level'=>$item['evidence_level'],'score'=>round($hit['score'],3)];
            if(count($picked)>=8)break;
        }
        $results[]=['id'=>$id,'kind'=>$kind,'label'=>$label,'time_s'=>is_numeric($p['time_s']??null)?(float)$p['time_s']:null,'matches'=>$picked,'status'=>$picked?'retrieved':'no_evidence'];
    }
    return ['ok'=>true,'index_revision'=>$index['index_revision']??null,'indexed_passages'=>(int)($index['count']??0),'source_counts'=>$index['counts_by_source']??[],'results'=>$results,'warning'=>'Найденные документы — контекст, не доказательство правильности исполнения или мышечной активации.'];
}
