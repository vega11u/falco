# Falco Jugger 23.0.7 — full consolidated code distribution

This bundle contains the original site plus patches 23.0.1 through 23.0.7.
It is a CODE OVERLAY, not a data migration. Do not delete server folders, do not run rsync --delete.

## Safe deployment
1. Back up **all** site files and database/learning stores before replacing anything.
2. Deploy to a staging copy of your current site; first run regression checks.
3. Upload bundle to site root, **overwrite matching code files only**, preserving files absent from this archive.
4. In particular, preserve: training-data/, data/trained/ (including installed sources, indices, user manifests), private Purcell/Lully directories, report libraries, uploads, user configs, database or SQLite files and server-only secrets.
5. This ZIP deliberately does not include training-data records or data/trained runtime JSON. Do not extract to an empty folder and then move/delete your existing storage.
6. No Python is required. The research index can be refreshed with `php research/build_evidence_index.php` where PHP CLI exists; if absent, process offline and upload ONLY the generated index. Running that command is optional and does not train models.
7. Clear browser's stale HTML/JS cache after upload, verify Lully/Purcell counts and saved reports on Models, then run one short test analysis.

## Critical
This is an all-in-one consolidation of previously completed patches up to 23.0.7.
The recently requested expanded *dynamic muscle-chain scoring of all 21 proposed trajectories* is NOT implemented in prior patches and is NOT represented as completed here. The existing muscle-visualization proxy is preserved, without new scoring claims.

## Backup without deleting source
Use `bash backup-learning.sh /absolute/path/OUTSIDE/public_html` from the site root if shell access is available. This creates a backup tar.gz containing supported known data paths. Always also back up any custom storage locations configured on your server. The script does not alter originals.
