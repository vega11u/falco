# Third-party notices — v21.4.0

## MediaPipe Tasks Vision

- Package: `@mediapipe/tasks-vision` 1.1.1.
- Licence: Apache-2.0.
- Upstream: https://github.com/google-ai-edge/mediapipe and https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker/web_js
- Models are fetched from the official Google Storage model URLs by `setup-assets.sh`. Retain the model/runtime notices supplied by upstream.

## Mediabunny

- Package: `mediabunny` 1.65.0.
- Licence: MPL-2.0.
- Upstream: https://github.com/Vanilagy/mediabunny
- npm: https://www.npmjs.com/package/mediabunny
- Used in the browser for container inspection and timestamp-ordered sample demux/decode. The installer verifies the package against npm registry SHA-512 integrity metadata.

## @mediabunny/prores / TurboRes

- Package: `@mediabunny/prores` 1.65.0.
- Licence: MPL-2.0.
- Upstream: https://github.com/Vanilagy/mediabunny/tree/v1.65.0/packages/prores
- npm: https://www.npmjs.com/package/@mediabunny/prores
- The extension uses TurboRes WASM to decode Apple ProRes in the browser, then registers its decoder with Mediabunny. The package peer-depends on Mediabunny. The installer downloads the npm tarball and verifies its SHA-512 integrity before installation.

## yt-dlp

- Upstream: https://github.com/yt-dlp/yt-dlp
- Releases/checksums: https://github.com/yt-dlp/yt-dlp/releases
- Licence: The Unlicense; standalone release bundles include third-party components with their own licence notices. Retain upstream `THIRD_PARTY_LICENSES.txt` and the notices supplied with the executable.
- The project downloads an official standalone Linux binary and validates it against the official SHA-256 release manifest. The executable is built from the upstream Python project and contains its runtime; the application does not install system Python, pip or a venv.

## QuickJS-NG

- Package/runtime: QuickJS-NG 0.18.0.
- Upstream: https://github.com/quickjs-ng/quickjs
- Licence: MIT.
- Used only as yt-dlp's JavaScript runtime for YouTube EJS challenge solving. The installer verifies the upstream release SHA-256 and runs a JavaScript expression before marking the runtime ready. It does not execute the web application or install Node.js/Deno.
- The installer prefers the official Cosmopolitan APE release (portable across supported operating systems/architectures) and falls back to the matching native Linux binary when needed.

## FFmpeg.wasm

- `@ffmpeg/ffmpeg` 0.12.15 — MIT: https://github.com/ffmpegwasm/ffmpeg.wasm
- `@ffmpeg/core` 0.12.10 — GPL-2.0-or-later: https://github.com/ffmpegwasm/ffmpeg.wasm
- The browser worker and WASM core are installed same-origin through `setup-ffmpeg-wasm.sh`; npm registry SHA-512 integrity is checked before extraction.
- Review GPL obligations before redistributing the installed FFmpeg core. Personal deployment does not remove upstream licence conditions.

The source archive includes installer scripts, not all downloaded binary/runtime assets. The one-command setup obtains them from upstream and retains the package license files when available.


## Typography — v22.5.0

- **IM Fell English SC** by Igino Marini is loaded from Google Fonts and is not redistributed in this archive. It revives the Fell types bequeathed to the University of Oxford in 1686. License: SIL Open Font License 1.1. Source: https://fonts.google.com/specimen/IM+Fell+English+SC and https://ctan.org/pkg/imfellenglish.
- **EB Garamond SC fallback** (file `assets/EBGaramondSC08-Regular.otf`) is bundled as a local fallback for environments where Google Fonts is unavailable. Copyright 2010–2012 Georg Duffner. License: SIL Open Font License 1.1; full license text is included in `assets/EB_Garamond_FONT_LICENSE.txt`.
