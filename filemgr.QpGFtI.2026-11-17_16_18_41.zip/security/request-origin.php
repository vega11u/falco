<?php
declare(strict_types=1);

/**
 * Reject browser requests coming from another origin (including a different
 * scheme or port). This is a defense in depth for cookie-backed API writes;
 * it does not replace authentication or per-user authorization.
 *
 * On legacy clients without Origin, the Fetch Metadata header still applies.
 * Command-line/integration clients without browser headers remain compatible.
 */
function fj_api_same_origin(array $server): bool {
    $fetchSite = strtolower(trim((string)($server['HTTP_SEC_FETCH_SITE'] ?? '')));
    if ($fetchSite === 'cross-site' || $fetchSite === 'same-site') return false;

    $origin = trim((string)($server['HTTP_ORIGIN'] ?? ''));
    if ($origin === '') {
        $referer = trim((string)($server['HTTP_REFERER'] ?? ''));
        if ($referer === '') return true;
        $origin = $referer;
    }
    if (strlen($origin) > 2048) return false;

    $source = parse_url($origin);
    $hostHeader = trim((string)($server['HTTP_HOST'] ?? ''));
    if (!is_array($source) || $hostHeader === '') return false;
    $host = parse_url('http://' . $hostHeader);
    if (!is_array($host)) return false;

    $sourceScheme = strtolower((string)($source['scheme'] ?? ''));
    $sourceHost = strtolower((string)($source['host'] ?? ''));
    $targetHost = strtolower((string)($host['host'] ?? ''));
    if (!in_array($sourceScheme, ['http', 'https'], true) ||
        $sourceHost === '' || $targetHost === '' ||
        $sourceHost !== $targetHost ||
        isset($source['user']) || isset($source['pass'])) return false;

    $https = (string)($server['HTTPS'] ?? '');
    $forwardedProto = strtolower(trim((string)($server['HTTP_X_FORWARDED_PROTO'] ?? '')));
    // The deployment already trusts X-Forwarded-Proto for TLS termination.
    // If a proxy is used, it must strip untrusted incoming forwarding headers.
    $targetScheme = (($https !== '' && strtolower($https) !== 'off') || $forwardedProto === 'https')
        ? 'https' : 'http';
    $sourcePort = (int)($source['port'] ?? ($sourceScheme === 'https' ? 443 : 80));
    $targetPort = (int)($host['port'] ?? ($targetScheme === 'https' ? 443 : 80));
    return $sourceScheme === $targetScheme && $sourcePort === $targetPort;
}
