/* Falco Jugger canonical articulated skeleton v1.
 * One edge list and one confidence policy for player, replays, Purcell and training.
 * Legacy 33-landmark arrays remain unchanged; this is an additive view contract.
 */
export const SKELETON_SCHEMA='falco-canonical-skeleton-v1';
export const SKELETON_EDGES=Object.freeze([
 [0,1],[1,2],[2,3],[3,7],[0,4],[4,5],[5,6],[6,8],
 [9,10],[11,12],[11,13],[13,15],[15,17],[15,19],[15,21],
 [12,14],[14,16],[16,18],[16,20],[16,22],[11,23],[12,24],[23,24],
 [23,25],[25,27],[27,29],[29,31],[27,31],[24,26],[26,28],[28,30],[30,32]
]);
export const SKELETON_JOINTS=Object.freeze(Array.from({length:33},(_,i)=>i));
const finite=Number.isFinite;
export function skeletonPoints(frame,{space='image',minConfidence=.12}={}){
 const source=space==='world'?(frame?.render_w||frame?.w):(frame?.render_im||frame?.im);
 return Array.isArray(source)?source.map(p=>Array.isArray(p)&&p.slice(0,space==='world'?3:2).every(finite)&&(p[3]??1)>=minConfidence?p:null):[];
}
export function canonicalSkeleton(frame,options={}){return {schema:SKELETON_SCHEMA,space:options.space||'image',edges:SKELETON_EDGES,points:skeletonPoints(frame,options),source:'reconstructed-or-observed-landmarks'};}
