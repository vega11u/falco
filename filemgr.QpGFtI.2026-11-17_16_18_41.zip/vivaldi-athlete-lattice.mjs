/** Vivaldi Athlete Lattice: multi-frame anchors and fixed proportion priors.
 * Generates a consistent articulated surface proposal; not a metrically verified human scan.
 */
import {bachAtlasFrame,normalizedTechniqueVector} from './bach-coordinate-atlas.mjs';
export const VIVALDI_LATTICE_VERSION='vivaldi-lattice-v1';
const BONES=[[11,13],[13,15],[12,14],[14,16],[11,23],[12,24],[23,25],[25,27],[24,26],[26,28],[11,12],[23,24]];
const finite=Number.isFinite;
const good=(p,d=2)=>Array.isArray(p)&&p.length>=d&&p.slice(0,d).every(finite)&&(p[3]??1)>=.35;
const median=a=>{const x=a.filter(finite).sort((a,b)=>a-b);return x.length?x[Math.floor(x.length/2)]:null;};
const length=(p,q,d)=>Math.hypot(...Array.from({length:d},(_,k)=>p[k]-q[k]));
function frameQuality(f){const p=f.im||[],w=f.w||[];const core=[11,12,13,14,15,16,23,24,25,26,27,28];const visible=core.filter(i=>good(p[i])).length,world=core.filter(i=>good(w[i],3)).length;
 const conf=core.reduce((s,i)=>s+Math.max(0,Math.min(1,p[i]?.[3]||0)),0)/core.length;
 const silhouette=Math.max(0,Math.min(1,Number(f.surface?.confidence??f.surface?.quality??0)));
 return .54*(visible/12)+.24*(world/12)+.17*conf+.05*silhouette;}
/** Select diverse, high-visibility frames, optionally yielding <10 when footage is inadequate. */
export function selectVivaldiAnchors(frames,{max=30,minIntervalSeconds=.13}={}){
 if(!Array.isArray(frames)||!frames.length)return [];
 const step=Math.max(1,Math.floor(frames.length/2200));
 const pool=[];
 for(let i=0;i<frames.length;i+=step){const q=frameQuality(frames[i]),vec=normalizedTechniqueVector(frames[i]);if(q>.43&&vec)pool.push({index:i,time:Number(frames[i].t)||0,quality:q,vector:vec});}
 pool.sort((a,b)=>b.quality-a.quality);const chosen=[];
 for(const item of pool){if(chosen.some(x=>Math.abs(x.time-item.time)<minIntervalSeconds))continue;
  const diversity=chosen.length?Math.min(...chosen.map(x=>{let s=0,n=0;for(let j=0;j<item.vector.length;j++){const a=item.vector[j],b=x.vector[j];if(finite(a)&&finite(b)){s+=(a-b)**2;n++;}}return n?Math.sqrt(s/n):0;})):1;
  if(chosen.length>=6&&diversity<.025&&chosen.length>=Math.min(max,10))continue;
  chosen.push({...item,diversity});if(chosen.length>=max)break;
 }
 return chosen.sort((a,b)=>a.index-b.index).map(({index,time,quality,diversity})=>({index,time,quality:+quality.toFixed(3),diversity:+diversity.toFixed(3)}));
}
export function fitVivaldiIdentity(frames,{anchors=selectVivaldiAnchors(frames),profile=null}={}){
 const observedSh=anchors.map(anchor=>{const p=frames[anchor.index]?.im||[],a=p[11],b=p[12];return good(a)&&good(b)?length(a,b,2):null;}).filter(v=>finite(v)&&v>.025);
 const referenceImageShoulderSpan=median(observedSh);
 const lengths={},observations={};for(const [a,b] of BONES){const key=a+'-'+b;const samples=[];
  for(const anchor of anchors){const f=frames[anchor.index],p=f?.w||[];if(good(p[a],3)&&good(p[b],3)){const d=length(p[a],p[b],3);if(d>.018&&d<2.2)samples.push(d);}}
  const m=median(samples),deviation=median(samples.map(x=>m==null?null:Math.abs(x-m)));
  if(m!=null){lengths[key]=+m.toFixed(5);observations[key]={samples:samples.length,mad:deviation};}
 }
 return {schema:VIVALDI_LATTICE_VERSION,anchors,anchor_count:anchors.length,reference_image_shoulder_span:referenceImageShoulderSpan,segment_lengths: lengths,segment_evidence:observations,
  body_surface_profile:profile?{schema:profile.schema,profile_confidence:profile.profile_confidence,width_profile:profile.width_profile}:null,
  technique_space:'athlete-normalized',body_dimensions_are_not_technique_labels:true,
  coordinates:{image:'[0,1] normalized image',world:'body-relative estimates, not metres'},
  confidence:Math.min(1,anchors.length/15)*Math.min(1,Object.keys(lengths).length/BONES.length),
  limitations:['Fixed dimensions are estimated from visible frames, not direct biometric measurements.','Loose uniform and occlusion cause uncertainty; hidden geometry remains approximate.']};
}
/** Gentle bone constraint on rendering points only. Observed canonical landmarks are untouched.
 * Low-confidence points move much more than high-confidence points. */
export function stabilizeVivaldiFrames(frames,identity,{maxCorrection=.025}={}){
 if(!Array.isArray(frames))return {frames:[],corrected:0};let corrected=0;
 const out=frames.map(f=>({...f,render_w:(f.render_w||f.w||[]).map(p=>Array.isArray(p)?p.slice():p),render_im:(f.render_im||f.im||[]).map(p=>Array.isArray(p)?p.slice():p)}));
 for(const f of out){for(const [a,b] of BONES){const target=identity?.segment_lengths?.[a+'-'+b],p=f.render_w?.[a],q=f.render_w?.[b];if(!(target>.018)||!good(p,3)||!good(q,3))continue;
 const d=length(p,q,3);if(d<.008)continue;
 const delta=d-target;if(Math.abs(delta)<Math.max(.012,target*.06))continue;
 const ca=Math.min(1,Math.max(0,p[3]??0)),cb=Math.min(1,Math.max(0,q[3]??0));
 const elasticity=Math.max(.01,1-Math.min(ca,cb));const move=Math.sign(delta)*Math.min(maxCorrection,Math.abs(delta)*.45*elasticity);
 // Modify only lower-confidence endpoint. Prevents moving confidently observed joints.
 const point=ca>cb?q:p,other=ca>cb?p:q,sign=ca>cb?1:1;
 const vec=Array.from({length:3},(_,i)=>(point[i]-other[i])/d);
 for(let k=0;k<3;k++)point[k]-=sign*move*vec[k];corrected++;
 }}
 return {frames:out,corrected};
}
export function vivaldiQualityOverview(frames,identity){const qualities=(frames||[]).filter(f=>f.im).map(frameQuality);return {schema:VIVALDI_LATTICE_VERSION,anchor_count:identity?.anchor_count||0,frame_count:frames?.length||0,quality_mean:qualities.length?qualities.reduce((a,b)=>a+b,0)/qualities.length:null,coverage:identity?.confidence||0,atlas:frames?.length?bachAtlasFrame(frames[0]):null};}


/** Stable body-local frame used by the fixed-topology surface mesh. */
export const VIVALDI_MESH_BASIS_VERSION='vivaldi-body-frame-basis-v1';
export const VIVALDI_MESH_IDENTITY_SCHEMA='falco-athlete-mesh-identity-v2';
export const VIVALDI_FIXED_MESH_TOPOLOGY='falco-vivaldi-fixed-2048-v2';
export const VIVALDI_FIXED_MESH_VERTICES=2048;
const MESH_BONE_ORDER=['11-13','13-15','12-14','14-16','11-23','12-24','23-25','25-27','24-26','26-28','11-12','23-24'];
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const vdot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
const vsub=(a,b)=>a.map((x,i)=>x-b[i]);
const vnorm=a=>Math.hypot(...a);
const vunit=a=>{const n=vnorm(a);return n>1e-8?a.map(x=>x/n):null;};
const vcross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
function meshCenter(points,a,b){
 const p=points?.[a],q=points?.[b];
 if(!good(p,3)||!good(q,3))return null;
 return {p:[0,1,2].map(k=>(p[k]+q[k])*.5),confidence:Math.min(p[3]??1,q[3]??1)};
}
/**
 * Attach a deterministic anatomical coordinate frame to every reconstructed frame.
 * The axes are derived from the paired shoulder/hip lines; missing short spans inherit
 * the last valid basis only inside the same camera segment. No landmark is rewritten.
 */
export function stabilizeVivaldiMeshBasisSequence(frames,{maxGapSeconds=.28}={}){
 if(!Array.isArray(frames))return {frames:[],diagnostics:{frames:0,valid:0,inherited:0,missing:0}};
 const out=frames.map(f=>({...f}));
 let previous=null,validCount=0,inherited=0,missing=0;
 for(let i=0;i<out.length;i++){
  const f=out[i],p=f.render_w||f.w||[],sh=meshCenter(p,11,12),hip=meshCenter(p,23,24);
  let basis=null;
  if(sh&&hip){
   const shoulderRight=vsub(p[12].slice(0,3),p[11].slice(0,3));
   const hipRight=good(p[23],3)&&good(p[24],3)?vsub(p[24].slice(0,3),p[23].slice(0,3)):shoulderRight;
   let right=vunit(shoulderRight.map((x,k)=>x*.68+hipRight[k]*.32));
   const trunk=vsub(sh.p,hip.p);
   if(right){
    const up=vunit(trunk.map((x,k)=>x-right[k]*vdot(trunk,right)));
    const forward=up?vunit(vcross(up,right)):null;
    if(up&&forward){
     basis={schema:VIVALDI_MESH_BASIS_VERSION,right,up,forward,confidence:Math.min(sh.confidence,hip.confidence)};
     validCount++;
    }
   }
  }
  if(!basis&&previous&&
     (f.camera_segment_id??0)===previous.camera&&
     Number(f.t)-previous.t>=0&&Number(f.t)-previous.t<=maxGapSeconds){
   const decay=Math.max(.35,1-(Number(f.t)-previous.t)/Math.max(.001,maxGapSeconds));
   basis={...previous.basis,confidence:(previous.basis.confidence||.3)*decay,inherited:true};inherited++;
  }
  if(basis){
   f.mesh_basis=basis;
   previous={basis,camera:f.camera_segment_id??0,t:Number(f.t)||0};
  }else{f.mesh_basis=null;missing++;previous=null;}
 }
 return {frames:out,diagnostics:{schema:VIVALDI_MESH_BASIS_VERSION,frames:out.length,valid:validCount,inherited,missing,coverage:out.length?Number(((validCount+inherited)/out.length).toFixed(4)):0}};
}

/** Compact, subject-specific parameters that identify the canonical fixed mesh. */
export function buildVivaldiMeshIdentity(frames,profile,identity,basisDiagnostics=null){
 const referenceWorld=Number(identity?.segment_lengths?.['11-12']);
 const referenceImage=Number(identity?.reference_image_shoulder_span);
 const ratios=MESH_BONE_ORDER.map(key=>{
  const length=Number(identity?.segment_lengths?.[key]);
  return referenceWorld>.025&&finite(length)&&length>0?Number((length/referenceWorld).toFixed(5)):null;
 });
 const validRatios=ratios.filter(finite).length;
 const profileConfidence=clamp(Number(profile?.profile_confidence)||0,0,1);
 const identityConfidence=clamp(Number(identity?.confidence)||0,0,1);
 if(!(referenceWorld>.025&&validRatios>=6&&profileConfidence>=.08&&identityConfidence>=.10))return null;
 const confidence=Number((Math.min(profileConfidence,identityConfidence)*Math.min(1,validRatios/9)).toFixed(4));
 return {
  schema:VIVALDI_MESH_IDENTITY_SCHEMA,
  topology:VIVALDI_FIXED_MESH_TOPOLOGY,
  vertex_count:VIVALDI_FIXED_MESH_VERTICES,
  basis_schema:VIVALDI_MESH_BASIS_VERSION,
  reference_image_shoulder_span:finite(referenceImage)?Number(referenceImage.toFixed(5)):null,
  reference_world_shoulder_span:referenceWorld>.025?Number(referenceWorld.toFixed(5)):null,
  bone_order:MESH_BONE_ORDER.slice(),
  bone_length_ratios:ratios,
  profile_confidence:profileConfidence,
  identity_confidence:identityConfidence,
  confidence,
  evidence_frames:Array.isArray(frames)?frames.length:0,
  anchor_count:Number(identity?.anchor_count)||0,
  basis_coverage:Number(basisDiagnostics?.coverage)||0,
  limitations:[
   'Individual width profile is measured from multi-frame person-segmentation masks and normalized by shoulder span.',
   'The mesh topology and vertex correspondence are fixed across all frames and devices.',
   'Hidden-side depth, internal anatomy and absolute metric scale remain priors because a single monocular camera cannot observe them.'
  ]
 };
}
export function validateVivaldiMeshIdentity(value){
 return !!value&&value.schema===VIVALDI_MESH_IDENTITY_SCHEMA&&value.topology===VIVALDI_FIXED_MESH_TOPOLOGY&&
  value.vertex_count===VIVALDI_FIXED_MESH_VERTICES&&Array.isArray(value.bone_length_ratios)&&value.bone_length_ratios.length===MESH_BONE_ORDER.length&&
  value.bone_length_ratios.every(x=>x===null||finite(x)&&x>0&&x<8)&&
  finite(value.confidence)&&value.confidence>=0&&value.confidence<=1;
}
/** A small, bounded identity cue; never overrides pose/trajectory evidence. */
export function compareVivaldiMeshIdentity(a,b){
 if(!validateVivaldiMeshIdentity(a)||!validateVivaldiMeshIdentity(b)||a.confidence<.2||b.confidence<.2)return null;
 const errors=[];
 for(let i=0;i<MESH_BONE_ORDER.length;i++){
  const x=a.bone_length_ratios[i],y=b.bone_length_ratios[i];
  if(!finite(x)||!finite(y)||x<.025||y<.025)continue;
  errors.push(Math.abs(Math.log(x/y)));
 }
 if(errors.length<6)return null;
 errors.sort((x,y)=>x-y);
 const med=errors[Math.floor(errors.length/2)];
 const quality=Math.exp(-med/.22)*100;
 return Number(clamp(quality,0,100).toFixed(1));
}
