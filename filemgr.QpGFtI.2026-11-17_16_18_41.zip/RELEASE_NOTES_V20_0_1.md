# Falco Jugger v20.0.1

## Исправления по сообщениям об ошибках

### YouTube: Requested format is not available

Вместо одной жёсткой комбинации форматов добавлены ограниченные профили одного и того же yt-dlp-экстрактора. Если сборка адаптивного video+audio недоступна/не подходит, загрузчик пробует обычный muxed stream, а затем video-only. Для биомеханического анализа звук не нужен. При отсутствии FFmpeg используется только `best` → `bestvideo*`.

### `estimatePose3DNormalization is not defined`

Функция реализована и экспортирована в `biomechanics-core.mjs`, импортирована в браузерный модуль с cache-busting query `?v=20.0.1`, проверена на world landmarks, image-only fallback, пустых и частичных данных.

### Отставание аватара от видео

Overlay синхронизируется по `requestVideoFrameCallback` → `metadata.mediaTime` (PTS кадра, отправленного композитору). 3D-аватар больше не throttled до 30 Hz. Следующий callback регистрируется до рендеринга текущего кадра, чтобы занятая отрисовка не добавляла ещё один цикл задержки. Отчёт содержит счётчики вызовов, пропущенных presented frames и длительности рендера.

## Установка

Для существующего сайта распакуйте `OVERLAY-UPDATE` поверх корня и выполните `bash setup-media-import.sh`. Пользовательские data/training-data/vendor/private `.kata-*` каталоги в overlay не входят.
