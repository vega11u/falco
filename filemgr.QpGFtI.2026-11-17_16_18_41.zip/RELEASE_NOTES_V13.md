# Release 13.0 — locally trained karate corpus and anatomy references

- Adds a one-command local acquisition/training pipeline for SKMD, G1 Moves, Pavani stance data, OpenSim Rajagopal and MyoSuite arm/leg/torso anatomical modules; optional source failures are logged without discarding successful model outputs.
- Adds a 16-frame Shotokan temporal matcher using constrained DTW, visibility-aware landmark distance and left/right mirrored matching. UI labels output as similarity, never probability.
- Keeps per-frame Shotokan ExtraTrees model restricted to the four actual public CSV labels and fixes `Gidan/Gedan-barai` block naming.
- Adds Pavani CSV base aliases and style-specific base terminology; removes unsupported Wado-ryu assumption.
- Adds a modular MyoSuite anatomical index for arm, legs and torso; keeps its modules distinct and does not claim a completed personalized full-body dynamics solver.
- Adds 23 Goju-ryu MS-KARD class names as taxonomy-only adapter metadata; no unavailable raw clips are fabricated.
- Excludes Kyokushin/Oyama corpora. Generic G1 motion clips remain style-unverified.
- Adds source/training documentation and expanded synthetic pipeline tests.

See `docs/TRAINING_CORPUS_AND_MODELS.md` for exact data scope and limitations.

- Optional G1 MP4 pose extraction uses MediaPipe Pose Landmarker Lite to build generic 2D temporal templates; BVH continues to provide generic 3D reference templates.
- Pavani summary processing now avoids overlapping aggregates and keeps static references separate from dynamic trials; style-specific distributions require explicit per-row style metadata.
