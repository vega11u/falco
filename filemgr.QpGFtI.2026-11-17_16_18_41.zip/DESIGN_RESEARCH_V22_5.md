# Design research — Falco Jugger 22.5.0

## References inspected

1. **pinecreativelabs/Baroquest-Framework** (MIT): https://github.com/pinecreativelabs/Baroquest-Framework
   - Reviewed its ornamental system, frame examples, typography utilities and layout examples.
   - Applied the separation of layout, type and ornament; restrained frame and engraved-divider details.
   - Did not import its full framework, animation library, CSS masks, seals, or decorative branding. Falco is a working analysis tool, not a themed landing page.
2. **cyanharlow/purecss-lace**: https://github.com/cyanharlow/purecss-lace
   - Reviewed its Flemish Baroque engraving approach and hand-constructed scroll/leaf motifs.
   - Used the principle of line-based foliage as marginal ornament only; no portrait, logo or copied art composition is included.
3. **garymeyerca/design-styles-demo** — Baroque example: https://github.com/garymeyerca/design-styles-demo/blob/main/styles/baroque.html
   - Reviewed the use of chiaroscuro, crimson/gilt contrast, theatrical focal hierarchy and ornament.
   - Deliberately rejected its radial/linear gradients, glow, glassy surfaces, large shadows and faux brand medallions because they read as a generic luxury dashboard and conflict with the requested restraint.
4. **IM Fell English SC**: https://fonts.google.com/specimen/IM+Fell+English+SC
   - Chosen as the project wordmark face because it revives the Fell types associated with the Oxford collection bequeathed in 1686. The digital revival by Igino Marini is OFL 1.1.
   - Loaded from Google Fonts. If unavailable, the bundled EB Garamond small-caps file is the local visual fallback; its OFL text is shipped in `assets/EB_Garamond_FONT_LICENSE.txt`.

## Visual direction

The new interface is a **Baroque folio / analytical workbench**:

- a warm printed sheet set inside a dark walnut/ink surround;
- double rules and restrained engraved corner foliage rather than rounded dashboard cards;
- an asymmetric source layout, typographic frontispiece, numbered contents line, and a separate dark viewing chamber for the 2D/3D player;
- continuous score columns and catalogue rows instead of floating metric tiles;
- oxblood controls and brass rules are functional states, not decorative gradients;
- the only brand mark is the literal project name `Falco Jugger`; no monogram, crest, seal, initials badge or invented logo is shipped;
- IM Fell English SC is reserved for the project name. Interface text, controls, labels, and page headings use Times New Roman.

The new `assets/folio-corners.svg` and `assets/title-cartouche.svg` are original ornamental frames, not brand symbols. The existing acanthus engraving and paper-fiber texture are used only as marginal page decoration.

## Performance and accessibility

- No JS framework, CSS framework, animation runtime, image masks or additional server dependency is added.
- No gradients, backdrop filters, glass effects or heavy shadows are used.
- Controls retain visible focus, disabled and status states; reduced-motion preferences are respected.
- Layout is tested at desktop and mobile widths. Decorative corner art is reduced on narrow screens and never overlays the video controls.
