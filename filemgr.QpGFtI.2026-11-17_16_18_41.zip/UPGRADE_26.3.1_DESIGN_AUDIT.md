# Falco Jugger 26.3.1 — interface refinement

- Reworked the active visual layer: spacing, surfaces, cards, controls, panels, typography, focus states and responsive actions now use one coherent component system.
- Fixed mobile navigation jitter by making the drawer a composited `100svh` viewport layer with `translate3d`, containment and isolated overscroll behavior.
- Added sticky mobile context bar and safer mobile action stacking.
- Hardened long text rendering so labels, statuses, journal entries and explanatory blocks wrap without hanging outside their cards.
- Preserved existing HTML, JS handlers, API contracts, report formats and the 26.3.0 canonical skeleton contract.
