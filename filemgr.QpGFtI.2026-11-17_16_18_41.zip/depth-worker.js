/* Selected depth modes are preflighted before the first frame. Small preflights Base for disputed frames; CONSENSUS preflights and evaluates Base + Small + GLPN + DPT. */
import { normalizeDepthMap as normalizeMap, downsampleDepthMap as downsample } from './depth-map-core.mjs?v=23.0.4';
import { athleteRegion, fuseConsensusMaps, consensusBudget } from './depth-consensus-core.mjs?v=23.0.10';
import {stabilizeConsensusMap,guardConsensus} from './depth-stability-core.mjs?v=23.0.11';

const TRANSFORMERS_URL = 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@4.3.2';
const SMALL_ID = 'onnx-community/depth-anything-v2-small-ONNX';
const BASE_ID = 'onnx-community/depth-anything-v2-base';
const ALT_MODELS={dpt:{id:'Xenova/dpt-hybrid-midas',label:'DPT Hybrid MiDaS'},glpn:{id:'Xenova/glpn-nyu',label:'GLPN NYU (indoor)'}};
let estimator = null;
let pipelineFactory = null;
let runtimeEnv = null;
let activeRuntime = null;
let activeMode = null;
let initialized = false;
let busy = false;
let inferenceCanvas = null;
let inferenceContext = null;
let runtimePolicy = null;
let verifier = null;
let verifierRuntime = null;
let verifierUnavailable = null;
let verifierPromise = null;
let previousDepthCompact = null;
let consensusCounter=0, consensusAssistant=null, consensusAssistantRuntime=null;
let consensusResidentModels=null;
let consensusErrors=[];
let previousConsensus=null,previousConsensusLandmarks=null,previousConsensusAt=0;
const consensusStageMs={small:0,glpn:0,dpt:0};

function status(message, extra = {}) { self.postMessage({ type: 'status', message, ...extra }); }
function errorText(error) { return `${error?.name ? `${error.name}: ` : ''}${error?.message || String(error)}`.slice(0, 900); }
function normalizeMode(value) { return ['small','base','consensus','dpt','glpn'].includes(value) ? value : 'small'; }
function modelIdFor(mode) { return ALT_MODELS[mode]?.id || (mode === 'small' ? SMALL_ID : BASE_ID); }
function modelLabel(mode) { return mode==='consensus'?'Depth consensus · Base + Small + DPT + GLPN':ALT_MODELS[mode]?.label || (mode === 'small' ? 'Depth Anything V2 Small' : 'Depth Anything V2 Base'); }
function dtypeFor(mode, backend) { return backend === 'webgpu' ? (ALT_MODELS[mode]?'fp32':'fp16') : ((mode === 'base'||mode==='consensus') ? 'q4' : 'q8'); }

async function createPipeline(pipeline, env, modelId, mode, device, dtype, silent=false) {
  if(!silent)status(`Загрузка ${modelLabel(mode)} · ${device === 'webgpu' ? 'WebGPU' : 'WASM'} · ${dtype}`);
  return pipeline('depth-estimation', modelId, {
    device, dtype,
    progress_callback: event => {
      if (silent || !event || typeof event !== 'object') return;
      const name = event.file || event.name || 'модель глубины';
      const progress = Number(event.progress);
      if (event.status === 'progress' && Number.isFinite(progress)) status(`Загрузка ${name}: ${Math.round(progress)}%`, { progress, file: name });
      else if (event.status === 'done') status(`Файл модели загружен: ${name}`);
    }
  });
}

async function init(requestedMode = 'small') {
  const mode = normalizeMode(requestedMode);
  if (initialized && estimator && activeMode === mode) return runtimeInfo();
  if (initialized && activeMode !== mode) {
    try { await estimator?.dispose?.(); } catch (_) {}
    estimator = null; activeRuntime = null; initialized = false;
    try { await verifier?.dispose?.(); } catch (_) {}
    verifier=null;verifierRuntime=null;verifierUnavailable=null;verifierPromise=null;previousDepthCompact=null;
    try{await consensusAssistant?.dispose?.();}catch(_){}consensusAssistant=null;consensusAssistantRuntime=null;if(consensusResidentModels){for(const model of Object.values(consensusResidentModels)){try{await model?.dispose?.();}catch(_){}}}consensusResidentModels=null;consensusCounter=0;consensusErrors=[];previousConsensus=null;previousConsensusLandmarks=null;previousConsensusAt=0;
  }

  const modelId = modelIdFor(mode);
  status(`Подготовка ${modelLabel(mode)} · ${mode === 'small' ? 'проверка спорных кадров на Base' : mode === 'base' ? 'Base без смены модели' : mode === 'consensus' ? 'последовательные модели с ограничением памяти' : 'альтернативная модель без проверки Base'}`);
  const library = await import(TRANSFORMERS_URL);
  const { pipeline, env } = library;
  pipelineFactory = pipeline; runtimeEnv = env;
  env.allowRemoteModels = true; env.allowLocalModels = false; env.useBrowserCache = true; env.useWasmCache = true;
  status('Кеш моделей: браузерное Cache Storage включено; повторная загрузка весов не требуется, пока браузер не удалит кеш.');

  const cores = Math.max(1, Number(self.navigator?.hardwareConcurrency) || 2);
  const wasmThreads = self.crossOriginIsolated ? Math.min(2, Math.max(1, Math.floor(cores / 2))) : 1;
  if (env.backends?.onnx?.wasm) env.backends.onnx.wasm.numThreads = wasmThreads;
  const reportedMemory = Number(self.navigator?.deviceMemory) || null;
  runtimePolicy = { wasm_threads: wasmThreads, reported_memory_gib: reportedMemory, requested_mode: mode, model: modelId };

  if ((mode === 'base'||mode==='consensus') && reportedMemory && reportedMemory <= 4) {
    throw new Error('Режим Base/консенсус недоступен: браузер сообщает не более 4 ГБ RAM. Для обычного анализа доступен Small; Purcell требует Base или консенсус.');
  }

  let hasAdapter = false;
  try { if (self.navigator?.gpu?.requestAdapter) hasAdapter = !!(await self.navigator.gpu.requestAdapter()); } catch (_) { hasAdapter = false; }
  const preferredDevice = hasAdapter ? 'webgpu' : 'wasm';
  const preferredDtype = dtypeFor(mode, preferredDevice);
  try {
    estimator = await createPipeline(pipeline, env, modelId, mode, preferredDevice, preferredDtype);
    activeRuntime = { backend: preferredDevice, dtype: preferredDtype, model: modelId };
  } catch (firstError) {
    if (!hasAdapter) throw firstError;
    const fallbackDtype = dtypeFor(mode, 'wasm');
    status(`${modelLabel(mode)} не запустилась на WebGPU; повторяю ту же модель на WASM ${fallbackDtype}. ${errorText(firstError)}`);
    estimator = await createPipeline(pipeline, env, modelId, mode, 'wasm', fallbackDtype);
    activeRuntime = { backend: 'wasm', dtype: fallbackDtype, model: modelId, fallback_reason: errorText(firstError) };
  }

  activeMode = mode;
  initialized = false;
  try{if(mode==='small')await preflightSmallVerifier();await preflightConsensusModels();}
  catch(error){try{await estimator?.dispose?.();}catch(_){}estimator=null;activeRuntime=null;initialized=false;activeMode=null;throw error;}
  initialized = true;
  status(`${modelLabel(mode)} готова · ${activeRuntime.backend.toUpperCase()} · без автоматической замены модели`);
  return runtimeInfo();
}




async function preflightSmallVerifier(){
  if(activeMode!=='small')return;verifierUnavailable=null;verifierRuntime=null;verifierPromise=null;
  let model=null,last=null;
  for(const device of (activeRuntime?.backend==='webgpu'?['webgpu','wasm']:['wasm'])){
    try{model=await createPipeline(pipelineFactory,runtimeEnv,BASE_ID,'base',device,dtypeFor('base',device));verifierRuntime={backend:device,dtype:dtypeFor('base',device),model:BASE_ID};break;}catch(error){last=error;}
  }
  if(!model){verifierUnavailable=`Base preflight недоступен: ${errorText(last||'unknown error')}`;throw new Error(verifierUnavailable);}
  // Keep Base resident only on devices with enough reported memory; otherwise weights
  // are cached by Transformers.js and the verifier is re-created from local cache on demand.
  if((Number(runtimePolicy?.reported_memory_gib)||0)>=8)verifier=model;else{try{await model.dispose?.();}catch(_){}}
  status('Base для спорных кадров предварительно загружена; покадровое скачивание не потребуется.');
}
async function preflightConsensusModels(){
  if(activeMode!=='consensus')return {checked:[],failed:[]};
  const checked=[],failed=[],memoryGiB=Number(runtimePolicy?.reported_memory_gib)||null;
  const keepResident=memoryGiB!==null&&memoryGiB>=8;
  const resident={};
  for(const mode of ['small','glpn','dpt']){
    let model=null,last=null;
    for(const device of (activeRuntime?.backend==='webgpu'?['webgpu','wasm']:['wasm'])){
      try{model=await createPipeline(pipelineFactory,runtimeEnv,modelIdFor(mode),mode,device,dtypeFor(mode,device));checked.push({mode,device});if(keepResident)resident[mode]=model;break;}
      catch(error){last=error;}
    }
    if(model&&!keepResident){try{await model.dispose?.();}catch(_){}}
    else if(!model)failed.push(`${mode}: ${errorText(last||'model unavailable')}`);
  }
  if(failed.length){for(const model of Object.values(resident)){try{await model?.dispose?.();}catch(_){}}throw new Error('CONSENSUS не готов: предварительная загрузка обязательных моделей не завершена. '+failed.join(' | '));}
  consensusResidentModels=keepResident?resident:null;
  status(`Предзагрузка CONSENSUS завершена: Base + Small + GLPN + DPT. ${keepResident?'Все четыре конвейера оставлены в памяти устройства.':'Веса прогреты и сохранены в браузерном кеше; вспомогательные конвейеры будут запускаться последовательно.'}`,{preflight:checked,models_ready:true,resident:keepResident});
  return {checked,failed,resident:keepResident};
}

function runtimeInfo() {
  return {
    mode: activeMode || 'small',
    backend: activeRuntime?.backend || 'unknown',
    dtype: activeRuntime?.dtype || null,
    model: activeRuntime?.model || modelIdFor(activeMode || 'small'),
    library: 'Transformers.js 4.3.2',
    ensemble: { enabled: activeMode==='consensus', primary: activeRuntime, secondary: null, fusion: activeMode==='consensus'?'Base anchored + small + sparse scene/athlete cross-model agreement, sequential budget':'Single model' },
    ensemble_enabled: activeMode==='consensus',
    consensus_budget:activeMode==='consensus'?consensusBudget({memoryGiB:runtimePolicy?.reported_memory_gib,cores:self.navigator?.hardwareConcurrency||2,backend:activeRuntime?.backend}):null,
    base_disabled_reason: verifierUnavailable,
    verification: { strategy: activeMode === 'consensus' ? 'sequential evidence and median-robust fusion' : activeMode === 'small' ? 'suspicion-triggered Base' : 'single selected model, no ensemble', base_ready: !!verifier, base_error: verifierUnavailable },
    webgpu_fallback_reason: activeRuntime?.fallback_reason || null,
    runtime_policy: runtimePolicy,
    preflight: activeMode==='consensus'?{complete:true,models:['base','small','glpn','dpt']}:null
  };
}

function extractTensor(output) {
  const tensor = output?.predicted_depth;
  if (tensor?.data && Array.isArray(tensor.dims) && tensor.dims.length >= 2) {
    const height = Number(tensor.dims.at(-2)), width = Number(tensor.dims.at(-1));
    if (width > 1 && height > 1 && tensor.data.length >= width * height) return { data: tensor.data, width, height };
  }
  const image = output?.depth;
  if (image?.data && Number(image.width) > 1 && Number(image.height) > 1) {
    const channels = Math.max(1, Math.floor(image.data.length / (image.width * image.height)));
    const values = new Float32Array(image.width * image.height);
    for (let i = 0; i < values.length; i++) {
      const j = i * channels;
      values[i] = channels >= 3 ? (0.299 * image.data[j] + 0.587 * image.data[j + 1] + 0.114 * image.data[j + 2]) : image.data[j];
    }
    return { data: values, width: image.width, height: image.height };
  }
  throw new Error('Модель не вернула карту predicted_depth с ожидаемыми размерами.');
}

async function evaluateMap(model, canvas) {
  let output = null;
  try {
    output = await model(canvas);
    return normalizeMap(extractTensor(output));
  } finally {
    try { await output?.predicted_depth?.dispose?.(); } catch (_) {}
  }
}

async function inferOne(canvas) {
  try { return await evaluateMap(estimator, canvas); }
  catch (error) {
    if (activeRuntime?.backend !== 'webgpu') throw error;
    const mode = activeMode || 'small';
    const modelId = modelIdFor(mode);
    const dtype = dtypeFor(mode, 'wasm');
    status(`${modelLabel(mode)}: ошибка WebGPU inference; пересоздаю ту же модель на WASM ${dtype}. ${errorText(error)}`);
    try { await estimator?.dispose?.(); } catch (_) {}
    estimator = await createPipeline(pipelineFactory, runtimeEnv, modelId, mode, 'wasm', dtype);
    activeRuntime = { ...activeRuntime, backend: 'wasm', dtype, fallback_reason: errorText(error) };
    return evaluateMap(estimator, canvas);
  }
}

async function ensureVerifier() {
  if(activeMode==='base')return {model:estimator, runtime:activeRuntime};
  if(verifier)return {model:verifier,runtime:verifierRuntime};
  if(verifierUnavailable)throw new Error(verifierUnavailable);
  if(verifierPromise)return verifierPromise;
  verifierPromise=(async()=>{
    status('Сомнительный кадр: впервые загружаю Base для перепроверки (однократно, с кешированием весов).');
    let adapter=false;
    try{adapter=!!(await self.navigator?.gpu?.requestAdapter?.());}catch(_){}
    let first=null;
    for(const device of (adapter?['webgpu','wasm']:['wasm'])){
      const dtype=dtypeFor('base',device);
      try{
        const model=await createPipeline(pipelineFactory,runtimeEnv,BASE_ID,'base',device,dtype);
        verifier=model;verifierRuntime={backend:device,dtype,model:BASE_ID};
        status(`Base для спорных кадров готова · ${device} · ${dtype}`);
        return {model,runtime:verifierRuntime};
      }catch(error){first=error;status(`Base recheck ${device} недоступна: ${errorText(error)}`);}
    }
    verifierUnavailable=`Не удалось загрузить Base для перепроверки: ${errorText(first)}`;
    throw new Error(verifierUnavailable);
  })();
  try{return await verifierPromise;}finally{verifierPromise=null;}
}
function depthAgreement(a,b){
  // Depth Anything returns monocular relative depth. Compare normalized maps, not absolute units.
  if(!a?.values||!b?.values||a.width!==b.width||a.height!==b.height)return null;
  let sum=0,n=0;
  for(let i=0;i<a.values.length;i+=Math.max(1,Math.floor(a.values.length/700))){
    const x=a.values[i],y=b.values[i];if(Number.isFinite(x)&&Number.isFinite(y)){sum+=Math.abs(x-y);n++;}
  }
  return n?Math.max(0,1-sum/n):null;
}
async function ensureSmallConsensus(){
 if(consensusAssistant)return consensusAssistant;
 const budget=consensusBudget({memoryGiB:runtimePolicy?.reported_memory_gib,backend:activeRuntime?.backend});
 if(budget.max_loaded<2)return null;
 try {
  let last=null;
  for(const device of (activeRuntime?.backend==='webgpu'?['webgpu','wasm']:['wasm'])){
   try{const dtype=dtypeFor('small',device);consensusAssistant=await createPipeline(pipelineFactory,runtimeEnv,SMALL_ID,'small',device,dtype);consensusAssistantRuntime={backend:device,dtype,model:SMALL_ID};return consensusAssistant;}catch(e){last=e;}
  }
  throw last;
 }catch(error){consensusErrors.push('Small: '+errorText(error));status('Консенсус: Small недоступна, сохраняю Base без выдуманного согласования.');return null;}
}
async function transientConsensusModel(mode,canvas){
 let model=null,lastError=null;
 for(const device of (activeRuntime?.backend==='webgpu'?['webgpu','wasm']:['wasm'])){
  try{model=await createPipeline(pipelineFactory,runtimeEnv,modelIdFor(mode),mode,device,dtypeFor(mode,device),true);break;}catch(e){lastError=e;}
 }
 if(!model)throw lastError||new Error('Auxiliary model unavailable');
 try{return downsample(await evaluateMap(model,canvas),80);}finally{try{await model.dispose?.();}catch(_){}}
}
function athleteCanvasFrom(whole,roi){
 const width=Math.max(80,Math.round(whole.width*roi.w)),height=Math.max(80,Math.round(whole.height*roi.h));
 const crop=new OffscreenCanvas(width,height),ctx=crop.getContext('2d',{alpha:false});if(!ctx)throw Error('No crop 2D context');
 ctx.drawImage(whole,roi.x*whole.width,roi.y*whole.height,roi.w*whole.width,roi.h*whole.height,0,0,width,height);return crop;
}
async function consensusInference(canvas,base,landmarks){
 const budget=consensusBudget({memoryGiB:runtimePolicy?.reported_memory_gib,backend:activeRuntime?.backend});
 const evidence=[];const models={base:activeRuntime};const failed=[];
 // Every source frame receives the full multi-level evidence pass. Auxiliary models
 // are executed serially (never concurrently) so memory use stays bounded.
 consensusCounter++;
 const roi=athleteRegion(landmarks);
 try{const started=performance.now();const map=consensusResidentModels?.small?downsample(await evaluateMap(consensusResidentModels.small,canvas),80):await transientConsensusModel('small',canvas);evidence.push({map,name:'small',scope:'full',weight:.25});consensusStageMs.small+=performance.now()-started;models.small={model:SMALL_ID,backend:consensusResidentModels?'resident':'serial_per_frame'};}catch(error){failed.push('Small: '+errorText(error));}
 try{const started=performance.now();const map=consensusResidentModels?.glpn?downsample(await evaluateMap(consensusResidentModels.glpn,canvas),80):await transientConsensusModel('glpn',canvas);evidence.push({map,name:'glpn_room',scope:'room',weight:.18});consensusStageMs.glpn+=performance.now()-started;models.glpn={model:ALT_MODELS.glpn.id,backend:consensusResidentModels?'resident':'serial_per_frame'};}catch(error){failed.push('GLPN: '+errorText(error));}
 if(roi){try{const started=performance.now();const map=consensusResidentModels?.dpt?downsample(await evaluateMap(consensusResidentModels.dpt,athleteCanvasFrom(canvas,roi)),80):await transientConsensusModel('dpt',athleteCanvasFrom(canvas,roi));evidence.push({map:{...map,region:roi},region:roi,name:'dpt_athlete',scope:'athlete',weight:.18});consensusStageMs.dpt+=performance.now()-started;models.dpt={model:ALT_MODELS.dpt.id,backend:consensusResidentModels?'resident':'serial_per_frame'};}catch(error){failed.push('DPT crop: '+errorText(error));}}else failed.push('DPT athlete crop: недостаточно ориентиров спортсмена');
 if(failed.length)throw new Error('CONSENSUS frame incomplete: '+failed.join(' | '));
 if(consensusCounter===1||consensusCounter%20===0)status(`CONSENSUS · ${consensusCounter} опорных кадров. BASE — сцена; SMALL — детали; GLPN — комната; DPT — спортсмен. Время SMALL ${Math.round(consensusStageMs.small/1000)}с, GLPN ${Math.round(consensusStageMs.glpn/1000)}с, DPT ${Math.round(consensusStageMs.dpt/1000)}с.`,{summary:true,count:consensusCounter});
 const fused=guardConsensus(base,fuseConsensusMaps(base,evidence,{athlete:roi}));
 if((fused.contributors||[]).length!==4)throw new Error(`CONSENSUS frame has only ${(fused.contributors||[]).length}/4 aligned model maps; frame rejected instead of silently downgraded.`);
 return {...fused,models,failures:[...new Set([...consensusErrors,...failed])].slice(-5),ensemble_complete:fused.contributors.length===4&&failed.length===0,
  method:'relative-depth affine alignment + robust weighted consensus',budget};
}
async function infer(frame, review = null, landmarks = null) {
  if (!frame) throw new Error('Пустой VideoFrame передан в depth worker.');
  if (!initialized) throw new Error('Depth worker не прошёл предварительную инициализацию выбранного режима. Покадровый анализ заблокирован; автоматического перехода на Small нет.');
  if (busy) throw new Error('Depth worker получил второй кадр до завершения первого.');
  busy = true;
  const started = performance.now();
  try {
    const sourceWidth = Number(frame.displayWidth || frame.codedWidth || frame.width || 0);
    const sourceHeight = Number(frame.displayHeight || frame.codedHeight || frame.height || 0);
    if (sourceWidth < 2 || sourceHeight < 2) throw new Error('Некорректный размер исходного VideoFrame.');
    const budget=activeMode==='consensus'?consensusBudget({memoryGiB:runtimePolicy?.reported_memory_gib,backend:activeRuntime?.backend}):null;
    const scale = Math.min(1, (budget?.max_frame_edge||518) / Math.max(sourceWidth, sourceHeight));
    const width = Math.max(2, Math.round(sourceWidth * scale));
    const height = Math.max(2, Math.round(sourceHeight * scale));
    if (!inferenceCanvas || inferenceCanvas.width !== width || inferenceCanvas.height !== height) {
      inferenceCanvas = new OffscreenCanvas(width, height);
      inferenceContext = inferenceCanvas.getContext('2d', { alpha: false, desynchronized: true });
    }
    if (!inferenceContext) throw new Error('OffscreenCanvas 2D недоступен для карты глубины.');
    inferenceContext.drawImage(frame, 0, 0, width, height);
    const map = await inferOne(inferenceCanvas);
    const compact = downsample(map, 80);
    let consensus=null;
    if(activeMode==='consensus'){
      const fresh=await consensusInference(inferenceCanvas,compact,landmarks);
      const now=performance.now();
      const stable=stabilizeConsensusMap(fresh,previousConsensus,{landmarks,previousLandmarks:previousConsensusLandmarks,elapsed:(now-previousConsensusAt)/1000,agreement:fresh.agreement_values});
      consensus={...fresh,...stable,stabilization:stable.diagnostics};
      previousConsensus={width:stable.width,height:stable.height,values:stable.values};
      previousConsensusLandmarks=Array.isArray(landmarks)?landmarks.map(p=>Array.isArray(p)?[...p]:p):null;
      previousConsensusAt=now;
    }
    let verified=null,reviewError=null,agreement=null;
    const reviewReasons=Array.isArray(review?.reasons)?[...new Set(review.reasons)]:[];
    if(activeMode==='small' && previousDepthCompact && previousDepthCompact.values.length===compact.values.length){
      let delta=0,n=0;
      const step=Math.max(1,Math.floor(compact.values.length/500));
      for(let i=0;i<compact.values.length;i+=step){delta+=Math.abs(compact.values[i]-previousDepthCompact.values[i]);n++;}
      if(n&&delta/n>.32&&!reviewReasons.includes('depth_discontinuity'))reviewReasons.push('depth_discontinuity');
    }
    previousDepthCompact=compact;
    if(activeMode==='small'&&reviewReasons.length){
      try{
        const {model,runtime}=await ensureVerifier();
        const second=downsample(await evaluateMap(model,inferenceCanvas),80);
        agreement=depthAgreement(compact,second);
        if(agreement!==null&&agreement<.55)reviewReasons.push('model_disagreement');
        verified={values:second.values,backend:runtime.backend,model:runtime.model};
      }catch(error){reviewError=errorText(error);status(`Спорный кадр: Base не выполнена. ${reviewError}`);}
    }
    return {
      values: consensus?.values||compact.values, width: compact.width, height: compact.height,
      agreement_values:consensus?.agreement_values||null,
      consensus_failures:consensus?.failures||[],consensus_contributors:consensus?.contributors||null,
      consensus_complete:consensus?.ensemble_complete||false,consensus_budget:consensus?.budget||null,consensus_stabilization:consensus?.stabilization||null,
      inference_ms: Number((performance.now() - started).toFixed(1)),
      backend: activeRuntime.backend, dtype: activeRuntime.dtype,
      model: activeRuntime.model, mode: activeMode,
      models: consensus?.models||{ [activeMode]: activeRuntime }, ensemble_enabled:!!consensus,
      model_agreement: consensus?.agreement??agreement, base_disabled_reason: reviewError,
      verification: reviewReasons.length ? {reasons:reviewReasons,checked:!!verified,error:reviewError,base_backend:verified?.backend||null,agreement} : null,
      verified_values: verified?.values || null
    };
  } finally {
    try { frame.close?.(); } catch (_) {}
    busy = false;
  }
}

self.onmessage = async event => {
  const message = event.data || {}, { id, type } = message;
  try {
    if (type === 'init') { const result = await init(message.mode || 'small'); self.postMessage({ id, type: 'result', result }); return; }
    if (type === 'frame') { const result = await infer(message.frame,message.review,message.landmarks); const transfer=[result.values.buffer];if(result.verified_values)transfer.push(result.verified_values.buffer);if(result.agreement_values)transfer.push(result.agreement_values.buffer); self.postMessage({ id, type: 'result', result }, transfer); return; }
    if (type === 'dispose') {
      try { await estimator?.dispose?.(); } catch (_) {}
      try { await verifier?.dispose?.(); } catch (_) {}
      verifier=null;verifierRuntime=null;verifierUnavailable=null;verifierPromise=null;previousDepthCompact=null;
      try{await consensusAssistant?.dispose?.();}catch(_){}consensusAssistant=null;consensusAssistantRuntime=null;if(consensusResidentModels){for(const model of Object.values(consensusResidentModels)){try{await model?.dispose?.();}catch(_){}}}consensusResidentModels=null;consensusErrors=[];consensusCounter=0;
      estimator = null; initialized = false; activeRuntime = null; activeMode = null;
      pipelineFactory = null; runtimeEnv = null; inferenceCanvas = null; inferenceContext = null; runtimePolicy = null;
      self.postMessage({ id, type: 'result', result: { disposed: true } }); return;
    }
    throw new Error(`Неизвестная команда depth worker: ${type}`);
  } catch (error) {
    try { message.frame?.close?.(); } catch (_) {}
    self.postMessage({ id, type: 'error', error: errorText(error) });
  }
};
