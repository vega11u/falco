# Falco Jugger 21.8.0 — release notes

## User-visible changes

- **Optimization score UI:** results are organized into eight criteria: global trajectory-noise reduction, arms/hands, legs/feet, trunk, speed retention, support/balance proxy, next-phase continuity, and 3D segment-length consistency. Detailed diagnostics remain available below.
- **Optimized player:** play/pause, frame step, playback rate, seek bar, 2D comparison, and a separate 3D canvas. 3D refresh during optimized playback is opt-in.
- **Lower browser load:** normal source-video playback no longer triggers the 3D renderer on every frame by default; seeking still renders a current still frame.
- **Heel contact:** a missing/occluded heel can be inferred only when the toe and ankle are visible, motion is stable, and plantar orientation supports contact. A visible elevated heel is preserved. The inferred point is used only by the display renderer.
- **Pattern transparency:** each group reports the closest-matching regions separately: shoulders, elbows/hands, pelvis, thighs/knees, shins/ankles, and heels/toes. Values describe normalized geometric deviation, not sports technique quality; the UI also reports how many snapshots had sufficient MediaPipe world landmarks.
- **3D-aware matching:** knee, ankle, heel and toe positions receive more weight, and lower-chain angles are part of posture distance. The renderer also restores camera-relative horizontal pelvis travel per camera segment; relative depth remains a separate estimate. This addresses pelvis-centred MediaPipe world coordinates that otherwise made the avatar appear stationary.

## Training-data compatibility

The persisted feature dimensions do **not** change: 16 joints × 3 coordinates = 48 values per frame, eight temporal snapshots = 384 values per confirmed example. Only distance weighting and angular terms change. Existing archive files are not deleted, migrated, rewritten or replaced by the app update. Personal learning data remains in the private `.kata-biomechanics-*` directory outside the website document root; social-import temporary data remains in `.kata-media-import-*`. The installer operates on application files and does not mirror-delete unrelated directories.

## Important limitations

- A display-only inferred heel is a conservative visual fallback, not a new observation. If both heel and toe are occluded or the toe/ankle posture is ambiguous, no inference is made.
- 3D coordinates remain monocular model estimates, not calibrated motion capture. The new similarity breakdown explains which measured regions contributed; it is not a technique-quality score.
- Browser performance varies by device. Default-off 3D playback reduces workload, but a manual 3D seek still performs a single render.

### Training-safe repack
- The deploy ZIP excludes mutable `data/trained/training-manifest.json`; only the `.template` is shipped.
- Release smoke test now fails if a runtime training manifest is accidentally added to the archive.
- Personal library remains external to DOCUMENT_ROOT and is preserved by overlay deployment.
