#!/usr/bin/env bash
# Falco Jugger 27.2.2-C.D2 — safe UI cleanup/consolidation patch for Reg.ru Host-0.
set -Eeuo pipefail
umask 077

SRC="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
TARGET="${1:-$PWD}"
MODE="${2:---dry-run}"
[[ "$MODE" == --dry-run || "$MODE" == --install ]] || {
  echo "Usage: install-host0-c-d2-cleanup-27.2.2.sh TARGET [--dry-run|--install]" >&2
  exit 2
}
[[ -d "$TARGET" ]] || { echo "Target directory missing: $TARGET" >&2; exit 2; }
TARGET="$(cd -- "$TARGET" && pwd -P)"
[[ "$TARGET" != / && "$TARGET" != "$SRC" ]] || { echo "Unsafe target path" >&2; exit 2; }

[[ -f "$TARGET/index.php" && -f "$TARGET/VERSION" && -f "$TARGET/FALCO_RELEASE_VERSION.txt" ]] || {
  echo "Target is not a Falco Jugger 27.2.x site root" >&2; exit 2;
}
command -v php >/dev/null || { echo "PHP CLI is required" >&2; exit 2; }
php -r 'if(PHP_VERSION_ID<80100){fwrite(STDERR,"PHP 8.1+ required\n");exit(1);}'
BASE="$(tr -d '\r\n ' < "$TARGET/VERSION")"
[[ "$BASE" == "23.0.27" ]] || { echo "Unsupported core baseline: $BASE (expected 23.0.27)" >&2; exit 2; }
TARGET_RELEASE="$(head -n 1 "$TARGET/FALCO_RELEASE_VERSION.txt" | tr -d '\r\n ')"
case "$TARGET_RELEASE" in
  27.2.1-C.D2|27.2.2-C.D2) ;;
  *) echo "Unsupported parent release: $TARGET_RELEASE (expected 27.2.1-C.D2 or 27.2.2-C.D2)" >&2; exit 2 ;;
esac

# Files changed by this patch. No training, report, cache, media or private-data paths.
FILES=(
  index.php models.php Memories.php lully.php purcell-lab.php
  falco-jugger-ui.css FALCO_RELEASE_VERSION.txt FALCO_UI_CLEANUP_RELEASE.json
  tools/falco-gc.sh tools/audit-css-references.php tools/falco-ui-cleanup-audit.php
  tests/ui-cleanup-27.2.2.php README_CLEANUP_27.2.2_RU.md QA_REPORT_27.2.2.md
  install-host0-c-d2-cleanup-27.2.2.sh
)

# Verify exact package allowlist and SHA-256 values before touching the target.
php -r '
$root=$argv[1];
$m=json_decode((string)file_get_contents($root."/FALCO_UI_CLEANUP_RELEASE.json"),true,512,JSON_THROW_ON_ERROR);
$allowed=[
"index.php","models.php","Memories.php","lully.php","purcell-lab.php",
"falco-jugger-ui.css","FALCO_RELEASE_VERSION.txt",
"tools/falco-gc.sh","tools/audit-css-references.php","tools/falco-ui-cleanup-audit.php",
"tests/ui-cleanup-27.2.2.php","README_CLEANUP_27.2.2_RU.md","QA_REPORT_27.2.2.md",
"install-host0-c-d2-cleanup-27.2.2.sh"
];
if(($m["release"]??"")!=="27.2.2-C.D2"||($m["parentRelease"]??"")!=="27.2.1-C.D2"||($m["baseCore"]??"")!=="23.0.27")exit(2);
$got=[];
foreach(($m["files"]??[]) as $f){
 $p=$f["path"]??"";
 if(!in_array($p,$allowed,true)||isset($got[$p])||str_contains($p,"..")||str_starts_with($p,"/")||is_link($root."/".$p)||!is_file($root."/".$p)||!hash_equals((string)$f["sha256"],hash_file("sha256",$root."/".$p))){
  fwrite(STDERR,"Package manifest validation failed: ".$p."\n");exit(3);
 }
 $got[$p]=true;
}
sort($allowed);$keys=array_keys($got);sort($keys);
if($keys!==$allowed){fwrite(STDERR,"Package file allowlist mismatch\n");exit(4);}
' "$SRC"

for f in "${FILES[@]}"; do
  [[ ! -L "$TARGET/$f" ]] || { echo "Refusing target symlink: $f" >&2; exit 2; }
done

for f in index.php models.php Memories.php lully.php purcell-lab.php tools/audit-css-references.php tools/falco-ui-cleanup-audit.php tests/ui-cleanup-27.2.2.php; do
  php -l "$SRC/$f" >/dev/null
done
bash -n "$SRC/tools/falco-gc.sh"
php "$SRC/tests/ui-cleanup-27.2.2.php" "$SRC"
php "$SRC/tools/falco-ui-cleanup-audit.php" "$SRC"

printf '\nFalco Jugger 27.2.2-C.D2 | target=%s | mode=%s\n' "$TARGET" "$MODE"
printf 'Changed files: %s\n' "${#FILES[@]}"
printf 'Parent release: %s\n' "$TARGET_RELEASE"
if [[ "$MODE" == --dry-run ]]; then
  echo "Dry run PASS. No target files changed."
  exit 0
fi

LOCK="$TARGET/.falco-ui-cleanup-27.2.2-install.lock"
( set -C; : > "$LOCK" ) 2>/dev/null || { echo "Install lock exists; inspect before retry." >&2; exit 3; }
trap 'rm -f -- "$LOCK"' EXIT

: "${HOME:?HOME must be set}"
BACKUP_ROOT="$HOME/.falco-backups"
mkdir -p "$BACKUP_ROOT"
chmod 700 "$BACKUP_ROOT"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)-$$"
BACKUP="$BACKUP_ROOT/falco-ui-cleanup-27.2.2-$STAMP"
mkdir -p "$BACKUP/original" "$BACKUP/missing"
chmod 700 "$BACKUP"

COMMITTED=0
rollback(){
  local rc=$?
  if [[ "$COMMITTED" -eq 0 ]]; then
    echo "Install failed; restoring the pre-install code snapshot." >&2
    for f in "${FILES[@]}"; do
      if [[ -f "$BACKUP/missing/$f" ]]; then
        rm -f -- "$TARGET/$f"
      elif [[ -f "$BACKUP/original/$f" ]]; then
        mkdir -p "$TARGET/$(dirname "$f")"
        cp -p "$BACKUP/original/$f" "$TARGET/$f"
      fi
    done
  fi
  rm -f -- "$LOCK"
  exit "$rc"
}
trap rollback ERR

for f in "${FILES[@]}"; do
  if [[ -e "$TARGET/$f" ]]; then
    mkdir -p "$BACKUP/original/$(dirname "$f")"
    cp -p "$TARGET/$f" "$BACKUP/original/$f"
  else
    mkdir -p "$BACKUP/missing/$(dirname "$f")"
    : > "$BACKUP/missing/$f"
  fi
done

for f in "${FILES[@]}"; do
  mkdir -p "$TARGET/$(dirname "$f")"
  tmp="$TARGET/$(dirname "$f")/.fj2722-$(basename "$f").$$.tmp"
  cp -p "$SRC/$f" "$tmp"
  mv -f -- "$tmp" "$TARGET/$f"
done

for f in index.php models.php Memories.php lully.php purcell-lab.php tools/audit-css-references.php tools/falco-ui-cleanup-audit.php tests/ui-cleanup-27.2.2.php; do
  php -l "$TARGET/$f" >/dev/null
done
php "$TARGET/tests/ui-cleanup-27.2.2.php" "$TARGET"
php "$TARGET/tools/falco-ui-cleanup-audit.php" "$TARGET" > "$BACKUP/ui-cleanup-audit.txt"

COMMITTED=1
trap 'rm -f -- "$LOCK"' EXIT

# GC only quarantines unreferenced, explicitly allowlisted files. It never deletes source fragments.
if ! bash "$TARGET/tools/falco-gc.sh" "$TARGET" --apply > "$BACKUP/gc-output.txt" 2>&1; then
  echo "WARNING: GC audit failed; no non-allowlisted source files were touched."
fi

printf 'Installed successfully.\n'
printf 'External backup: %s\n' "$BACKUP"
printf 'UI audit: %s/ui-cleanup-audit.txt\n' "$BACKUP"
printf 'GC output: %s/gc-output.txt\n' "$BACKUP"
echo "Static inline styles migrated; live progress/timeline geometry styles retained."
echo "No analysis modules, handlers, trained data, reports, model cache, source media or private configuration were deleted."
