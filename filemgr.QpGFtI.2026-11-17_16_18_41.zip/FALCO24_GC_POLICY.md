# Falco 24.3.0 — aggressive garbage-collector policy

The installer runs in aggressive mode only when `--aggressive-cleanup` is supplied.

## Allow-listed legacy files

| File | Reason |
|---|---|
| `install-full.sh` | Legacy Falco 23.0.10 bootstrap installer; no runtime PHP/JS/MJS/CSS/shell references in the current release. It may download optional models/research and is not the current overlay installer. |
| `baroque-workbench-v22-5.css` | Historical stylesheet; no runtime-code references in the current release. |
| `aero-workbench-v23.css` | Historical stylesheet; no runtime-code references in the current release. |

The installer checks each basename against runtime source files on the target. If a reference is found, the candidate is preserved. Files are deleted only after a backup archive has been created outside the website root.

## Never-clean policy

The garbage collector does not target:
- training databases, learned examples, feedback, prototypes or private model artifacts;
- uploaded videos, media caches, user reports or report libraries;
- `KATA_LEARNING_DIR`, `KATA_REPORTS_DIR`, `.kata-biomechanics-*`, `.kata-reports-*`;
- model weights, `vendor/`, `data/`, `training-data/`, CRON scripts, setup scripts or test suites;
- any file not named in the explicit allowlist.

## Rollback

The installer backs up every existing file it will overwrite or delete. If PHP lint, workspace/UI/Learning Centers smoke tests, or available Node.js syntax checks fail, it removes newly created patch files and restores the backup. The backup is retained outside the public website directory.

The cleanup is intentionally conservative about dependencies: only the three reviewed allow-listed files can be permanently removed. A missing or unrecognized candidate is simply skipped.
