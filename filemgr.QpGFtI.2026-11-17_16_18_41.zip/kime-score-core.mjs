/* Backwards-compatible, evidence-weighted kime contribution to final proxy score. */
export const KIME_SCORE_SCHEMA='falco-kime-score-integration-v1';
const cap=(n,a,b)=>Math.max(a,Math.min(b,n));
export function applyKimeToReport(report,{maximumWeight=.15,minimumEvents=1,fullWeightEvents=5}={}){
 if(!report||!report.final_score||report.final_score.kime_integration?.schema===KIME_SCORE_SCHEMA)return report;
 const k=report.analysis?.kime,measured=Number(k?.measured),hit=Number(k?.within_window);
 const base=Number(report.final_score.value),uncapped=report.final_score.uncapped==null?NaN:Number(report.final_score.uncapped),scoreCap=report.final_score.cap==null?NaN:Number(report.final_score.cap);
 if(!Number.isFinite(base)||!Number.isFinite(measured)||measured<minimumEvents||!Number.isFinite(hit)||!Number.isFinite(k?.overall_percent)||hit<0||hit>measured)return report;
 const pct=cap(Number(k.overall_percent),0,100);
 const weight=cap(maximumWeight,0,.3)*Math.min(1,measured/Math.max(1,fullWeightEvents));
 const origin=Number.isFinite(uncapped)?uncapped:base;
 const mixed=(1-weight)*origin+weight*pct;
 const limit=Number.isFinite(scoreCap)?cap(scoreCap,0,100):100;
 const value=cap(Number(mixed.toFixed(2)),0,limit);
 const original=report.final_score;
 original.kime_integration={schema:KIME_SCORE_SCHEMA,measured,within_window:hit,percentage:pct,weight:Number(weight.toFixed(4)),original_value:base,original_uncapped:origin,method:'Кимэ добавляется только при измеримых быстрых движениях; вес растёт с числом проверяемых событий до 15% и сохраняет исходный cap'};
 original.value=value;original.uncapped=Number(mixed.toFixed(2));
 original.note=(original.note||'')+' Кимэ: '+Math.round(weight*1000)/10+'% веса (число событий '+measured+').';
 const breakdown=Array.isArray(original.breakdown)?original.breakdown:[];
 for(const row of breakdown){if(Number.isFinite(row.weight)){row.weight=Number((row.weight*(1-weight)).toFixed(5));if(Number.isFinite(row.score))row.contribution=Number((row.weight*row.score).toFixed(3));}}
 breakdown.push({key:'kime',label:'Кимэ · синхронность конечной точки',weight:Number(weight.toFixed(5)),score:pct,contribution:Number((weight*pct).toFixed(3)),source:`${hit} из ${measured} быстрых событий; порог ${Number(k.threshold_ms??180)} мс`});
 original.breakdown=breakdown;
 report.summary=report.summary||{};report.summary.kime_score_weight=weight;report.summary.kime_score_included=true;
 return report;
}
