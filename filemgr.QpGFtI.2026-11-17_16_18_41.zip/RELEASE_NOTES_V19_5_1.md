# Falco Jugger v19.5.1 — media import and local video hotfix

## Fixes
- Deno `deno cache` for YouTube.js is skipped by default on shared hosting. Set `KATA_ENABLE_YOUTUBE_JS=1` only on a host with enough RAM. The yt-dlp standalone extractor and its Deno EJS runtime remain the default route.
- Optional Composer PHP fallback now runs with `COMPOSER_ROOT_VERSION=1.0.0`, checks that the downloader class can be instantiated, and patches the exact incompatible `setUserAgent(string $agent): void` child signature to the parent's untyped parameter when that source signature is present. If it still fails, the fallback is disabled rather than advertised as ready.
- Defined the PHP fallback's 750 MiB maximum transfer size (previously referenced but not initialized).
- When Mediabunny/WebCodecs reports an undecodable source codec, the browser now verifies actual native playback with `canplay` and a decoded frame before deciding to transcode. This can accept MOV/QuickTime formats supported by the browser without conversion.
- FFmpeg WASM assets are fetched from the same-origin URLs, checked for HTTP success, and handed to the worker as blob URLs. Missing or inaccessible assets now report the actual HTTP status rather than a generic `failed to import ffmpeg-core.js`.

## Deployment
1. Back up the current site and extract the overlay patch over the project root.
2. Preserve `data`, `training-data`, `vendor/mediabunny`, `.kata-*` and other private runtime data.
3. Run `bash setup-media-import.sh` and `bash setup-ffmpeg-wasm.sh` from the project root.
4. Hard-refresh the browser and test a short H.264 MP4, then the original MOV, then a public YouTube URL.

## Verification boundary
Automated PHP/JS/shell and mocked queue tests validate the code paths. They do not establish that REG.RU permits a real YouTube extraction, that its Deno memory quota is sufficient, or that the specific MOV codec is supported by the user's browser. Those require a live test on the hosting account and the target browser.
