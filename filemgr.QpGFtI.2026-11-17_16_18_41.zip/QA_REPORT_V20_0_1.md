# Falco Jugger v20.0.1 — QA report

Date: 2026-11-03
Base: v20.0.0 REG.RU source archive

## Fixed defects reported by deployment

### YouTube `Requested format is not available`

The importer previously made a single explicit format request. It now uses a bounded sequence in the same official yt-dlp executable:

- With FFmpeg: `bv*+ba/best` (adaptive video/audio with merge), then `best` (single combined stream), then `bestvideo*` (video-only).
- Without FFmpeg: `best`, then `bestvideo*`.

The video-only option is valid for Falco's purpose because the downstream pose pipeline consumes the video track; audio is not required for pose inference. Each profile writes into its own isolated attempt directory. Existing job ownership, URL allowlist, file size checks, account-wide lock, status polling, private transfer, cleanup, and CRON dispatch remain in place.

### `estimatePose3DNormalization is not defined`

The missing symbol is now an exported pure function in `biomechanics-core.mjs` and is explicitly imported by the main browser module. The module import uses a version query to avoid retaining the prior browser cache entry. Unit tests cover world-space input, image-space fallback, empty frames and invalid world landmarks.

### Avatar lag

The offline analysis still decodes samples sequentially through Mediabunny and infers pose for each decoded source sample. Playback rendering now uses `requestVideoFrameCallback`'s `metadata.mediaTime` as the display timestamp for 2D and 3D overlays. The prior 32 ms/30 Hz 3D render throttle was removed. The next frame callback is registered before the current draw, preventing a slow draw from adding another scheduling cycle of latency. Runtime diagnostics record callback count, compositor-frame gaps and render duration in `source.overlay_runtime`.

## Automated validation

Command executed:

```sh
RUN_CRON_INTEGRATION=1 bash tests/verify.sh
```

Results:

- Karate intelligence data: 102 WKF entries, 35 research references, 6 datasets, 24 anatomy groups — PASS.
- Release smoke v20.0.1 — PASS.
- Local video pipeline smoke — PASS.
- PHP and JavaScript syntax — PASS.
- Learning API and complete 3,005-example / 1,002-feedback archive checks — PASS.
- Biomechanics core tests — PASS; synthetic trajectory acceleration RMS reduced by 3.93% while constraints held.
- Kata temporal recognition tests — PASS; short-gap recovery, long-gap rejection, mirror handling and movement direction.
- Media import smoke — PASS; fake downloader deliberately returns `Requested format is not available` on its first call, then succeeds on the video-only profile; YouTube/Instagram route, transfer and cleanup are checked.
- CRON integration — PASS with web `proc_open` disabled, two sessions, account-level serialization and private transfer.

## What this does not prove

- The media-import smoke test uses a fake yt-dlp executable. It does not prove that every public YouTube/Instagram URL is accessible from the user's REG.RU IP, that a video is not region/age/PO-Token/authentication restricted, or that an account is not rate-limited.
- The overlay test checks code contracts and the timestamp/PTS routing structurally. No real browser playback session with the user's source video was available here. `source.overlay_runtime` is included to identify whether the browser misses compositor frames or spends longer than a frame budget drawing the avatar.
- Synthetic biomechanics tests are correctness/regression checks, not external validation of anatomical accuracy. Metric validity still depends on camera calibration, camera angle, occlusion, frame quality and whether world landmarks are reliable.

## Data preservation

The patch does not modify `data/`, `training-data/`, `vendor/`, or private `.kata-*` storage. The overlay archive deliberately excludes those directories. Back up the private learning and media-import folders before deployment as an operational safeguard.
