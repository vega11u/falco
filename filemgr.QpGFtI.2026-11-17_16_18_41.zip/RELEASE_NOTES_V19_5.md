# Falco Jugger v19.5.0 — release patch

## Critical fixes
- Added the missing `prepareCanvas()` helper used by muscle maps, pose overlay and 3D canvases. It sizes canvases for device-pixel ratio while preserving CSS-pixel drawing coordinates.
- Added a native browser video metadata/decode probe when local Mediabunny is unavailable. Common browser-supported MP4/MOV/WebM files can proceed through the existing HTMLVideoElement + MediaPipe frame-analysis pipeline instead of being blocked solely because the optional demuxer could not load. Actual playback is verified by `canplay`; unsupported files continue to conversion/error handling.
- Kept local source files in the browser; no server upload of local files was introduced.

## YouTube import redesign
- Reduced the repetitive extractor cascade to a bounded sequence: yt-dlp nightly, independent YouTube.js InnerTube WEB extractor, yt-dlp stable, curl transport retry, then optional PHP progressive fallback.
- Removed repeated TV/Safari/embedded/Android profile attempts that reused the same server IP and often repeated the same failure while consuming many minutes.
- Set hard per-attempt limit to 180 seconds, no-output watchdog to 120 seconds, and total job deadline to 900 seconds. Limits are enforced by the generated shell runner and do not depend on GNU `timeout`.
- Updated health diagnostics and regression tests to match the actual limits and attempt chain.

## Validation
- `bash tests/verify.sh` passes all PHP, JavaScript, importer, local-video, learning, optimizer, security and mocked YouTube.js checks.
- The mocked YouTube.js test does not prove live YouTube availability. Live platform behavior remains dependent on YouTube policy, PO Token/attestation requirements, and the hosting provider's outbound network/IP reputation.
- Release remains PHP + JavaScript in the application. Deno is used only as the JS runtime for upstream yt-dlp EJS and YouTube.js; no system Python, pip, virtualenv or Node.js service is required.
