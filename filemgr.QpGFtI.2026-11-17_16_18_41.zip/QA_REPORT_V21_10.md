# QA / audit report — Falco Jugger v21.10.0

## Scope

Audited the supplied v21.9.0 ZIP and performed an additive update of the browser application, biomechanics knowledge resource, tests and setup metadata. The existing application architecture and persisted learning formats were retained.

## Findings addressed

- `#optimizerSummary` used a three-column grid while receiving three top-level block children, producing an incorrect multi-column layout. The container is now a vertical block and the numeric cards have their own responsive grid.
- Optimizer recommendations had no paired contextual snapshots. Cards now show an actual frame from the source video and an estimated side projection from the frame's display-only world/depth track. Insufficient depth is explicitly disclosed.
- Timecode navigation was split across bespoke handlers. A document-level capture handler now routes supported metric/pattern time links through the synchronized `seekToPlayers()` path and scrolls the page to the player dock.
- Pattern reconsideration did not reliably carry draft label/type edits across detection reruns. Drafts and yes/no/hint feedback are now upserted by source kind/time interval and reconciled against overlapping/signature-similar new candidates.
- No zoom/pan capability existed in the main synchronized player. A dependency-free zoom core and pointer interaction wrapper were added to the common video/overlay surface.
- The anatomy resource held muscle groups/fascial continuity context but the sequence planner used mostly built-in rules. Its resource is now validated/cached and passed to the planner, with recommendation-level knowledge/evidence labels.
- The biomechanical planning pass now runs before trajectory refinement. Measured pelvis/thorax/wrist/hip/knee/foot phase peaks, relevant transition timings and recommendation moments are passed as additional event anchors to the optimizer. This protects observed timing; it does not create hypothetical target poses or a synthetic ideal trajectory.

## Preservation checks

- `VERSION` is 21.10.0.
- Learning feature widths are unchanged (384D pattern; 1152D kata). Existing classifier and PHP API are not migrated.
- Anatomy schema remains `karate-functional-anatomy-v1`; 24 muscle groups remain. Seven concept records and seven optimizer decision rules were added as optional JSON fields.
- The release smoke test still rejects shipping a runtime `data/trained/training-manifest.json`, to prevent an overlay from replacing user corpus state.
- Setup checks the new browser module and continues to describe installation as non-destructive. It does not delete private `.kata-*` directories or the user's training corpus.

## Automated checks

- `bash tests/verify.sh` — passed. The suite includes intelligence data (102 WKF entries; 35 research references; 6 datasets; 24 anatomy groups), PHP/API/release checks, local-video and media-import tests, device profile, biomechanics, planner, zoom math, scene perspective, avatar, depth reconstruction, recognition, report rendering, learning API, and optimizer UI/constraints.
- PHP syntax checks for application, API and smoke tests.
- release, intelligence-data, local-video, learning API and optimizer smoke tests.
- JavaScript syntax checks and Node 22 runtime tests, including the new player zoom geometry test and planner tests that load the additive anatomy catalog.
- media import / transfer / hash smoke tests.

## Limits / manual acceptance

- Browser-specific pointer/touch behaviour and real still-frame decoding need a visual test on desktop and a touch device; the automated suite validates zoom math and source wiring, not actual hardware gesture feel. The source-frame decoder is smoke-tested through code paths, but no physical browser session was available in this run.
- A second viewpoint cannot be reconstructed exactly from a single RGB camera. The side image remains an estimated projection from model world landmarks/depth and can be unavailable when those observations are poor.
- The optimizer remains a constrained kinematic trajectory stabilizer, not a validated inverse-dynamics or performance-maximization engine. The knowledge layer provides transparent, phase-aware hypotheses and preserves observed phase timing; it does not infer force, EMG, fascial tension or mechanical efficiency from the video.
- The optional detached CRON queue integration test was not run; it remains opt-in (`RUN_CRON_INTEGRATION=1 bash tests/verify.sh`) because it launches detached processes.
