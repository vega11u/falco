/**
 * Falco personalized silhouette-lifted body surface v23.0.23.
 * Width evidence is measured from MediaPipe person-segmentation masks in image space.
 * 3D depth thickness is an explicitly low-confidence prior: a monocular front silhouette
 * cannot measure hidden-side depth. No age, sex, ethnicity or health inference is performed.
 */
export const PERSONALIZED_BODY_SURFACE_VERSION = 'falco-personalized-silhouette-surface-v1';
export const BODY_SURFACE_SEGMENTS = [
  {key:'torso',zone:'torso',segment:0,a: 'shoulderCenter',b:'hipCenter',kind:'torso'},
  {key:'left_arm_upper',zone:'left_sleeve',segment:0,a:11,b:13,kind:'arm'},
  {key:'left_arm_lower',zone:'left_sleeve',segment:1,a:13,b:15,kind:'arm'},
  {key:'right_arm_upper',zone:'right_sleeve',segment:0,a:12,b:14,kind:'arm'},
  {key:'right_arm_lower',zone:'right_sleeve',segment:1,a:14,b:16,kind:'arm'},
  {key:'left_leg_upper',zone:'left_trouser',segment:0,a:23,b:25,kind:'leg'},
  {key:'left_leg_lower',zone:'left_trouser',segment:1,a:25,b:27,kind:'leg'},
  {key:'right_leg_upper',zone:'right_trouser',segment:0,a:24,b:26,kind:'leg'},
  {key:'right_leg_lower',zone:'right_trouser',segment:1,a:26,b:28,kind:'leg'}
];
const STATIONS=[.30,.47,.64,.80];
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const finite=Number.isFinite;
const valid=(p,d=2,c=.10)=>Array.isArray(p)&&p.length>=d&&p.slice(0,d).every(finite)&&(p[3]??1)>=c;
const median=a=>{const s=a.filter(finite).sort((x,y)=>x-y);return s.length?s[Math.floor(s.length/2)]:null;};
const norm=v=>Math.hypot(...v);
const unit=v=>{const n=norm(v)||1;return v.map(x=>x/n);};
const sub=(a,b)=>a.map((x,i)=>x-b[i]);
const add=(a,b,k=1)=>a.map((x,i)=>x+b[i]*k);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
function encodeQ16(values){const bytes=new Uint8Array(values.length*2),view=new DataView(bytes.buffer);for(let i=0;i<values.length;i++){const v=clamp(Number(values[i])||0,-8,8);view.setUint16(i*2,Math.round(((v+8)/16)*65535),true);}let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,Math.min(bytes.length,i+0x8000)));return btoa(binary);}
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
function centerPoint(points,a,b,dim=2){const A=points?.[a],B=points?.[b];return valid(A,dim,.12)&&valid(B,dim,.12)?(dim===2?[(A[0]+B[0])/2,(A[1]+B[1])/2,0,Math.min(A[3]??1,B[3]??1)]:[(A[0]+B[0])/2,(A[1]+B[1])/2,(A[2]+B[2])/2,Math.min(A[3]??1,B[3]??1)]):null;}
function segmentEndpoints(frame,space,seg){const p=space==='3d'?(frame.render_w||frame.w):(frame.render_im||frame.im),dim=space==='3d'?3:2;if(seg.a==='shoulderCenter'){const a=centerPoint(p,11,12,dim),b=centerPoint(p,23,24,dim);return [a,b];}return [p?.[seg.a],p?.[seg.b]];}
function readMeasuredProfile(frame,seg,profile,{allowFrameLocal=false}={}){
 // Geometry is fitted once from the whole clip. Per-frame mask widths remain
 // evidence for the fit, but must never replace the fixed identity profile at render time.
 const local=allowFrameLocal?frame?.surface?.zone_width_profile?.[seg.zone]?.[seg.segment]:null;
 const fallback=profile?.width_profile?.[seg.key];
 return STATIONS.map((_,i)=>{
  const v=Array.isArray(local?.[i])?local[i]:null,useLocal=finite(v?.[0])&&finite(v?.[1])&&v[0]>.015&&v[1]>=.08;
  const r=useLocal?v[0]:fallback?.[i]?.[0];
  const c=useLocal?v[1]:fallback?.[i]?.[1]??0;
  return {ratio:finite(r)?clamp(r,.015,1.4):null,confidence:clamp(Number(c)||0,0,1)};
 });
}
export function buildPersonalizedShapeProfile(frames,{minObservations=8}={}){
 const rows=Array.isArray(frames)?frames:[];
 const width_profile={},segmentCoverage={};let eligible=0;
 for(const seg of BODY_SURFACE_SEGMENTS){
  const stationRows=STATIONS.map(()=>[]);
  for(const f of rows){const arr=f?.surface?.zone_width_profile?.[seg.zone]?.[seg.segment];if(!Array.isArray(arr))continue;
   let validCount=0;
   for(let i=0;i<STATIONS.length;i++){const v=arr[i];if(Array.isArray(v)&&finite(v[0])&&finite(v[1])&&v[1]>=.20&&v[0]>.015&&v[0]<1.4){stationRows[i].push(v[0]);validCount++;}}
   if(validCount>=2)eligible++;
  }
  const samples=stationRows.map(x=>x.length),values=stationRows.map(x=>median(x));
  const conf=stationRows.map(x=>clamp(x.length/Math.max(minObservations,1),0,1));
  width_profile[seg.key]=values.map((v,i)=>[v??0,conf[i]]);
  segmentCoverage[seg.key]={station_samples:samples,median_width_ratio:values,confidence:conf};
 }
 const all=Object.values(segmentCoverage).flatMap(x=>x.station_samples),measured=all.filter(x=>x>=minObservations).length;
 const confidence=all.length?measured/all.length:0;
 const imageSpans=[],worldSpans=[];
 for(const f of rows){const im=f?.render_im||f?.im,w=f?.render_w||f?.w;if(valid(im?.[11])&&valid(im?.[12]))imageSpans.push(Math.hypot(im[11][0]-im[12][0],im[11][1]-im[12][1]));if(valid(w?.[11],3)&&valid(w?.[12],3))worldSpans.push(norm(sub(w[11].slice(0,3),w[12].slice(0,3))));}
 const referenceImage=median(imageSpans),referenceWorld=median(worldSpans);
 return {schema:PERSONALIZED_BODY_SURFACE_VERSION,method:'multi-frame person-mask silhouette widths normalized by shoulder span; median profile per anatomical segment',frames:rows.length,profile_confidence:Number(confidence.toFixed(3)),profile_observations:eligible,width_profile,coverage:segmentCoverage,fixed_geometry:{reference_image_shoulder_span:referenceImage,world_shoulder_span:referenceWorld,geometry_fit:'clip-wide median shoulder spans'},limitations:['2D widths are mask-derived and clothing-inclusive','3D depth thickness is a conservative prior, not directly observed','camera calibration and multiple views are required for metric body volume']};
}
function getScale(frame,profile=null){
 const im=frame.render_im||frame.im,w=frame.render_w||frame.w;
 if(!valid(im?.[11])||!valid(im?.[12])||!valid(w?.[11],3)||!valid(w?.[12],3))return null;
 const image=Math.hypot(im[11][0]-im[12][0],im[11][1]-im[12][1]);
 const observed=norm(sub(w[11].slice(0,3),w[12].slice(0,3)));
 const fixed=Number(profile?.fixed_geometry?.world_shoulder_span||profile?.mesh_identity?.reference_world_shoulder_span);
 const world=fixed>.025&&fixed<2.5?fixed:observed;
 return image>.005&&world>.025?{image,world,observed_world:observed,ratio:world/image}:null;
}
function frameSegmentWidth(frame,profile,seg,station,scale){const q=readMeasuredProfile(frame,seg,profile)[station];if(!finite(q.ratio)||q.confidence<.08)return null;return {radius:q.ratio*scale.world*.5,confidence:q.confidence,ratio:q.ratio};}
function bodyRight(world){if(valid(world?.[23],3)&&valid(world?.[24],3))return unit(sub(world[24].slice(0,3),world[23].slice(0,3)));if(valid(world?.[11],3)&&valid(world?.[12],3))return unit(sub(world[12].slice(0,3),world[11].slice(0,3)));return [1,0,0];}
/** Returns a compact per-frame 2D contour cloud and a 3D silhouette-lifted point cloud. */
export function buildPersonalizedBodyCloud(frame,profile=null,{sides=8}={}){
 const im=frame?.render_im||frame?.im,w=frame?.render_w||frame?.w,scale=getScale(frame,profile);
 const nSides=clamp(Math.round(sides),4,12),points2d=[],points3d=[],usedSegments=[];
 const empty=()=>{for(let k=0;k<nSides;k++){points2d.push([0,0,0,0]);points3d.push([0,0,0,0]);}};
 if(!Array.isArray(im)||!Array.isArray(w)||!scale){for(let i=0;i<BODY_SURFACE_SEGMENTS.length*STATIONS.length;i++)empty();return {available:false,reason:'Нет согласованных 2D/3D ориентиров плеч',points2d,points3d,point_count_2d:points2d.length,point_count_3d:points3d.length};}
 const shoulderPx=scale.image,shoulderWorld=scale.world,right=bodyRight(w);
 for(const seg of BODY_SURFACE_SEGMENTS){
  const [A2,B2]=segmentEndpoints(frame,'2d',seg),[A3,B3]=segmentEndpoints(frame,'3d',seg);
  if(!valid(A2)||!valid(B2)||!valid(A3,3)||!valid(B3,3)){for(let s=0;s<STATIONS.length;s++)empty();continue;}
  const axis2=unit([B2[0]-A2[0],B2[1]-A2[1]]),axis3=unit(sub(B3.slice(0,3),A3.slice(0,3)));if(!axis2||!axis3){for(let s=0;s<STATIONS.length;s++)empty();continue;}const normal2=[-axis2[1],axis2[0]];
  const bodyRightAxis=frame.mesh_basis?.right||right,bodyForwardAxis=frame.mesh_basis?.forward||null;
  let side3=sub(bodyRightAxis,axis3.map(x=>x*dot(bodyRightAxis,axis3)));
  if(norm(side3)<.08){const seed=frame.mesh_basis?.up|| (Math.abs(axis3[1])<.85?[0,1,0]:[0,0,1]);side3=sub(seed,axis3.map(x=>x*dot(seed,axis3)));}
  side3=unit(side3)||unit(cross(axis3,[0,0,1]))||[1,0,0];let depth3=unit(cross(axis3,side3))||unit(cross(axis3,[0,1,0]))||[0,0,1];
  if(depth3&&bodyForwardAxis&&dot(depth3,bodyForwardAxis)<0){side3=side3.map(x=>-x);depth3=depth3.map(x=>-x);}
  const samples=readMeasuredProfile(frame,seg,profile);let segmentUsed=0;
  for(let s=0;s<STATIONS.length;s++){
   const q=samples[s];if(!finite(q.ratio)||q.confidence<.08){empty();continue;}
   const t=STATIONS[s],center2=[A2[0]+(B2[0]-A2[0])*t,A2[1]+(B2[1]-A2[1])*t],center3=A3.slice(0,3).map((v,k)=>v+(B3[k]-v)*t),radiusPx=q.ratio*shoulderPx*.5,anatomicalWidthLimit=seg.kind==='torso'?1.05:(seg.kind==='arm'?.72:.86),radius3=Math.min(q.ratio,anatomicalWidthLimit)*shoulderWorld*.5,depthRadius=radius3*.38;
   for(let k=0;k<nSides;k++){
    const u=-1+2*k/(nSides-1),x=center2[0]+normal2[0]*radiusPx*u,y=center2[1]+normal2[1]*radiusPx*u;
    points2d.push([clamp(x,0,1),clamp(y,0,1),0,clamp(Math.min(A2[3]??1,B2[3]??1)*q.confidence,0,1)]);
    const angle=2*Math.PI*k/nSides,pt=center3.map((v,d)=>v+side3[d]*Math.cos(angle)*radius3+depth3[d]*Math.sin(angle)*depthRadius),conf=clamp(Math.min(A3[3]??1,B3[3]??1)*q.confidence*.48,0,.48);
    points3d.push([...pt,conf]);
   }
   segmentUsed++;
  }
  if(segmentUsed)usedSegments.push(seg.key);
 }
 const measured2=points2d.filter(p=>p[3]>.08).length,measured3=points3d.filter(p=>p[3]>.08).length;
 return {available:measured2>=64&&measured3>=64,version:PERSONALIZED_BODY_SURFACE_VERSION,points2d,points3d,point_count_2d:measured2,point_count_3d:measured3,segments:usedSegments,scale:{image_shoulder_span:shoulderPx,world_shoulder_span:shoulderWorld},depth_model:'conservative elliptical cross-section prior; depth semi-axis 0.38× bounded width; clothing can exceed anatomical shell; confidence capped at 0.48',measured_evidence:'person segmentation mask widths + tracked 2D/3D skeleton'};
}

export function buildPersonalizedSurfaceClip(frames,profile,space='3d',{samples=8,sides=4}={}){
 if(!Array.isArray(frames)||!frames.length)return null;
 const out=[],metadata=[],nSides=clamp(Math.round(sides),4,12),pointsPerFrame=BODY_SURFACE_SEGMENTS.length*STATIONS.length*nSides,expectedValues=samples*pointsPerFrame*4;
 let goodFrames=0,measuredPointCount=0;
 for(let i=0;i<samples;i++){
  const f=frames[Math.round(i*(frames.length-1)/Math.max(1,samples-1))],cloud=buildPersonalizedBodyCloud(f,profile,{sides:nSides}),points=space==='2d'?cloud.points2d:cloud.points3d;
  const src=space==='2d'?(f.render_im||f.im):(f.render_w||f.w),dim=space==='2d'?2:3,hipA=src?.[23],hipB=src?.[24],shA=src?.[11],shB=src?.[12];
  if(!cloud.available||!Array.isArray(points)||!valid(hipA,dim)||!valid(hipB,dim)||!valid(shA,dim)||!valid(shB,dim)){
   out.push(...Array(pointsPerFrame*4).fill(0));metadata.push({sample:i,available:false});continue;
  }
  const center=Array.from({length:dim},(_,k)=>(hipA[k]+hipB[k])*.5),shoulder=Array.from({length:dim},(_,k)=>(shA[k]+shB[k])*.5),scale=Math.max(.03,norm(sub(shoulder,center)));
  for(let j=0;j<pointsPerFrame;j++){const p=points[j]||[0,0,0,0];if((p[3]??0)<=0){out.push(0,0,0,0);continue;}out.push(clamp((p[0]-center[0])/scale,-5,5),clamp((p[1]-center[1])/scale,-5,5),space==='3d'?clamp((p[2]-center[2])/scale,-5,5):0,clamp(p[3]??0,0,1));measuredPointCount++;}
  metadata.push({sample:i,available:true,points:cloud.point_count_3d});goodFrames++;
 }
 return goodFrames>=Math.ceil(samples*.65)&&out.length===expectedValues?{schema:PERSONALIZED_BODY_SURFACE_VERSION,space,samples,frames_used:goodFrames,points_per_frame:pointsPerFrame,point_count:samples*pointsPerFrame,measured_point_count:measuredPointCount,encoding:'normalized-xyzc-q16-base64',values_q16:encodeQ16(out),values_count:out.length,metadata,depth_uncertainty:space==='3d'?'Depth thickness is an anthropometric prior; not a measured posterior surface.':null}:null;
}


/** Checks whether a candidate preserves the athlete's measured width-to-segment proportions. */
export function evaluatePersonalizedSurfaceFit(originalFrames,candidateFrames,profile=null,{maxRelativeDrift=.22,space='3d'}={}){
 if(!Array.isArray(originalFrames)||!Array.isArray(candidateFrames)||originalFrames.length!==candidateFrames.length||!originalFrames.length)return {available:false,passed:true,score:null,reason:'No paired frame sequence'};
 const dim=space==='2d'?2:3,errors=[],used=new Set(),stride=Math.max(1,Math.floor(originalFrames.length/12));
 for(let i=0;i<originalFrames.length;i+=stride){const o=originalFrames[i],c=candidateFrames[i],po=space==='2d'?(o.im||o.render_im):(o.w||o.render_w),pc=space==='2d'?(c.im||c.render_im):(c.w||c.render_w);
  const spanA=space==='2d'&&valid(po?.[11])&&valid(po?.[12])?Math.hypot(po[11][0]-po[12][0],po[11][1]-po[12][1]):space==='3d'&&valid(po?.[11],3)&&valid(po?.[12],3)?norm(sub(po[11].slice(0,3),po[12].slice(0,3))):null;
  const spanB=space==='2d'&&valid(pc?.[11])&&valid(pc?.[12])?Math.hypot(pc[11][0]-pc[12][0],pc[11][1]-pc[12][1]):space==='3d'&&valid(pc?.[11],3)&&valid(pc?.[12],3)?norm(sub(pc[11].slice(0,3),pc[12].slice(0,3))):null;
  if(!(spanA>.005&&spanB>.005))continue;
  const ends=(points,seg)=>seg.a==='shoulderCenter'?[centerPoint(points,11,12,dim),centerPoint(points,23,24,dim)]:[points?.[seg.a],points?.[seg.b]];
  for(const seg of BODY_SURFACE_SEGMENTS){const [oa,ob]=ends(po,seg),[ca,cb]=ends(pc,seg);if(!valid(oa,dim)||!valid(ob,dim)||!valid(ca,dim)||!valid(cb,dim))continue;
   const widths=readMeasuredProfile(o,seg,profile).filter(x=>finite(x.ratio)&&x.confidence>=.25);if(!widths.length)continue;
   const measured=median(widths.map(x=>x.ratio));if(!finite(measured)||measured<=0)continue;
   const oldLength=norm(sub(oa.slice(0,dim),ob.slice(0,dim))),newLength=norm(sub(ca.slice(0,dim),cb.slice(0,dim)));if(oldLength<.008||newLength<.008)continue;
   const oldRatio=measured*spanA/oldLength,newRatio=measured*spanB/newLength;if(oldRatio>1.8||newRatio>2.2)continue;
   const drift=Math.abs(Math.log(Math.max(.001,newRatio)/Math.max(.001,oldRatio)));errors.push(drift);used.add(seg.key);
  }
 }
 if(errors.length<4)return {available:false,passed:true,score:null,reason:'Insufficient measured silhouette profile coverage',segments:[...used],space};
 const sorted=[...errors].sort((a,b)=>a-b),mean=errors.reduce((a,b)=>a+b,0)/errors.length,p90=sorted[Math.min(sorted.length-1,Math.floor(sorted.length*.9))];
 return {available:true,passed:p90<=maxRelativeDrift,score:clamp(100-mean*180-p90*70,0,100),mean_log_drift:mean,p90_log_drift:p90,observations:errors.length,segments:[...used],threshold:maxRelativeDrift,space,evidence:'Measured person-mask silhouette widths mapped through shoulder span; relative segment-shape consistency, not a biomechanical ground truth'};
}
