<?php
declare(strict_types=1);
$root = dirname(__DIR__);
$required = [
  'lully.php', 'purcell-lab.php', 'falco-jugger-ui.css',
  'falco-jugger-ui.js', 'falco24-learning-centers.js', 'index.php'
];
foreach ($required as $file) {
  if (!is_file($root . DIRECTORY_SEPARATOR . $file)) {
    fwrite(STDERR, "Missing learning-center asset: {$file}\n");
    exit(1);
  }
}
$lully = file_get_contents($root . '/lully.php');
$purcell = file_get_contents($root . '/purcell-lab.php');
$index = file_get_contents($root . '/index.php');
$js = file_get_contents($root . '/falco24-learning-centers.js');
$checks = [
  'Lully page uses existing library API' => str_contains($js, "api('library')"),
  'Purcell page uses existing library API' => str_contains($js, "api('purcell-library')"),
  'Purcell status uses existing status API' => str_contains($js, "api('purcell-status')"),
  'Lully page links back to current-video pattern review' => str_contains($lully, 'index.php#patternsSection'),
  'Purcell page links back to current-video weakness analysis' => str_contains($purcell, 'index.php#purcellWeaknessSection'),
  'Lully page uses the single shared stylesheet' => str_contains($lully, 'falco-jugger-ui.css?v=26.0.0') && !str_contains($lully, 'falco24-learning-centers.css'),
  'Purcell page uses the single shared stylesheet' => str_contains($purcell, 'falco-jugger-ui.css?v=26.0.0') && !str_contains($purcell, 'falco24-learning-centers.css'),
  'Lully page has no embedded application iframe' => !str_contains($lully, '<iframe'),
  'Purcell page has no embedded application iframe' => !str_contains($purcell, '<iframe'),
  'Lully cards do not render an empty replay placeholder' => !str_contains($js, 'replay-visual') && str_contains($js, 'index.php#patternsSection'),
  'Purcell cards route to existing analyzer anchors' => str_contains($js, 'index.php#purcellWeaknessSection'),
  'Hub rendering escapes server-provided text' => str_contains($js, 'const esc ='),
  'No new training-write API is introduced' => !preg_match('/api\\([\'"](?:learn|purcell-save|model-sync)[\'"]\\)/', $js),
];
$failed = 0;
foreach ($checks as $name => $ok) {
  echo ($ok ? "PASS " : "FAIL ") . $name . PHP_EOL;
  if (!$ok) $failed++;
}
exit($failed ? 1 : 0);
