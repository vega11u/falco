import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {packAthleteSilhouette,compactAthleteSilhouette,expandAthleteSilhouette,pointInAthleteSilhouette} from '../athlete-silhouette-core.mjs';
import {auditReconstructedTrack,qualityOfRange} from '../motion-reconstruction-quality.mjs';
import {mapWKFCriteria} from '../wkf-kata-criteria-2026.mjs';
const src=readFileSync(new URL('../index.php',import.meta.url),'utf8');
const p={};for(const id of [11,12,13,14,15,16,23,24,25,26,27,28,29,30,31,32]){
  p[id]=[{11:.38,12:.62,13:.32,14:.68,15:.26,16:.74,23:.4,24:.6,25:.42,26:.58,27:.43,28:.57,29:.43,30:.57,31:.42,32:.58}[id],{11:.35,12:.35,13:.42,14:.42,15:.5,16:.5,23:.55,24:.55,25:.71,26:.71,27:.86,28:.86,29:.88,30:.88,31:.87,32:.87}[id],0,.99];
}
const maskW=128,maskH=128,data=new Float32Array(maskW*maskH).fill(0);
for(let y=12;y<121;y++)for(let x=17;x<113;x++)data[y*maskW+x]=1;
const landmarks=Array.from({length:33},(_,i)=>({x:p[i]?.[0]??.5,y:p[i]?.[1]??.5,visibility:.99}));
const mask=packAthleteSilhouette({width:maskW,height:maskH,getAsFloat32Array:()=>data},landmarks);
assert(mask?.b64);
const highRes=packAthleteSilhouette({width:maskW,height:maskH,getAsFloat32Array:()=>data},landmarks,{width:192,height:192});
assert.equal(highRes.w,192);assert.equal(highRes.h,192);
const compressed=compactAthleteSilhouette(highRes),unpacked=expandAthleteSilhouette(compressed,{w:192,h:192});
assert.equal(unpacked?.w,192);assert.equal(unpacked?.h,192);
assert.equal(pointInAthleteSilhouette(unpacked,.5,.5),true);
assert.equal(pointInAthleteSilhouette(unpacked,.02,.02),false);

function frames(N=15,bad=0){return Array.from({length:N},(_,i)=>({t:i/30,camera_segment_id:0,im:Array.from({length:33},(_,j)=>p[j]?.slice()||null),w:Array.from({length:33},(_,j)=>p[j]?[p[j][0],p[j][1],p[j][2]+.12,p[j][3]]:null),surface: i<bad?{}:{silhouette:mask}}));}
const good=frames();const report=auditReconstructedTrack(good);
assert.equal(report.available,true);assert.equal(report.trainable,true);assert.equal(report.usable,15);assert.equal(qualityOfRange(good,.04,.36).allowed,true);
const poor=frames(15,12);const audit=auditReconstructedTrack(poor);assert.equal(audit.trainable,false);assert.equal(qualityOfRange(poor,0,.45).allowed,false);
const wkf=mapWKFCriteria({summary:{sequencing_index:.7,average_fast_velocity_m_s:2.5,average_pose_confidence:.9,median_com_margin_body_heights:.03},analysis:{kime:{measured:4,within_window:3},ground_contact:{}},orientation_segments:[{start_time_s:0,end_time_s:.2}]},{reconstruction:report});
assert.equal(wkf.criteria.length,10);assert.equal(wkf.official_wkf_score,null);
for(const key of ['breathing','strength','kihon'])assert.equal(wkf.criteria.find(x=>x.id===key).status,'expert_required');
for(const needle of ['const spatialRanked={overall:[]}','result.shortlist||[]','falco-jugger-ui.css?v=26.0.0','motion-reconstruction-quality.mjs','wkf-kata-criteria-2026.mjs','renderMotionEvidence(r)','renderWKFCriteria(r)','qualityOfRange(state.frames','const presented3d=','motionHeightBasis','motionCameraStability','reconstruction_quality_per_frame'])assert(src.includes(needle),`Missing integrated behavior ${needle}`);
assert(!src.includes('for(const [a,b] of spatialBones){const pa=projected[a]'), 'Purcell 3D fallback skeleton must not appear');
const access=readFileSync(new URL('../.htaccess',import.meta.url),'utf8');assert(access.includes('zip|7z'));
console.log('PASS 23.0.27: personal QA range gate, WKF criteria, archive transport, frontend integration and disclosure');
