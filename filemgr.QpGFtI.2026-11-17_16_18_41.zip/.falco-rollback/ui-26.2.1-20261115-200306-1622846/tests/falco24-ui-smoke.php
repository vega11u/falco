<?php
declare(strict_types=1);
/* Release 26 static-layout contract. Uses PHP CLI, no Node requirement. */
$root=dirname(__DIR__);
$_GET=[];$_SERVER['DOCUMENT_ROOT']=$root;
ob_start();require $root.'/index.php';$html=(string)ob_get_clean();
$source=(string)file_get_contents($root.'/index.php');
$css=(string)file_get_contents($root.'/falco-jugger-ui.css');
$js=(string)file_get_contents($root.'/falco-jugger-ui.js');
$ok=static function(bool $pass,string $why):void{if(!$pass)throw new RuntimeException($why);};
foreach(['fjWorkbench','fjCenter','fjPlayerColumn','analysisDock','fjVideoMount','fjThreeMount','playerMetricsScroll','playerPlay','playerSeek','player3dPlayback','playerZoom','dropZone','video','overlay','progressLabel','resultsSection','optimizerPanel','purcellTrainingPanel','currentPanel','appJournalPanel','fjJournalDrawer','fjJournalMount','fjJournalOpen','fjJournalClose','highlightsSection','patternsSection','monteverdiKimePanel','metricCards'] as $id){
 $ok(substr_count($html,'id="'.$id.'"')===1,"Absent or duplicate player/workspace DOM id: $id");
}
$ok(str_contains($html,'id="fjPlayerColumn"')&&str_contains($html,'id="analysisDock"'),'Static player is not in the initial HTML response');
$ok(preg_match('~<aside class="fj-player-column"[^>]*>\s*<section id="analysisDock"~s',$html)===1,'Dock is not inside the right column');
$ok(preg_match('~<div class="fj-center"[^>]*>.*?<section id="resultsSection"~s',$html)===1,'Results are not in the center workstream');
$ok(substr_count($html,'falco-jugger-ui.css?v=26.0.0')===1,'Analyzer must have exactly one 26.0.0 stylesheet link');
$ok(substr_count($source,'falco-jugger-ui.js?v=26.0.1')===1,'Analyzer must have exactly one 26.0.0 controller link');
$ok(!str_contains($html,'<style')&&!str_contains($html,'f24-topbar'),'Legacy inline CSS or header survived');
$ok(!str_contains($js,'layout.replaceWith(workspace)')&&!str_contains($js,'mountWorkspace()'),'Runtime DOM rebuilding survived');
$ok(str_contains($js,'videoMount.replaceChildren(stage)')&&str_contains($js,'journalMount.append(journal)'),'Static mounts must attach existing DOM nodes');
$ok(!str_contains($css,'@import')&&!str_contains($css,'@layer compatibility')&&!str_contains($css,'.f24-workspace-grid'),'Legacy cascading stylesheet rules survived');
foreach(['.fj-workbench{display:grid','grid-template-columns:minmax(0,1fr) clamp(380px',' .fj-player-column{position:sticky',' .fj-journal-drawer{position:fixed','body.fj-player-expanded .analysis-dock{display:block','--fj-accent:','prefers-reduced-motion'] as $needle){
 $ok(str_contains($css,trim($needle)),"Missing Flight Deck design contract: $needle");
}
$ok(!str_contains($source,"stage.insertAdjacentElement('afterend',workspace)"),'Trimming editor must stay in the scrolling center');
$ok(str_contains($source,'data-optimizer-feedback="overall"')&&!preg_match('/data-optimizer-feedback="(?:speed|arms|legs|balance|feet)"/',$source),'Purcell optimizer split into directions');
$ok(str_contains($source,'function installAnalysisDock()')&&str_contains($source,'if(!dock||!stage||!three'),'Synchronized player initializer lost');
foreach(['lully.php','purcell-lab.php','models.php','Memories.php'] as $page){$text=(string)file_get_contents($root.'/'.$page);$ok(str_contains($text,'falco-jugger-ui.css?v=26.0.0'),"Page $page not migrated to new CSS");$ok(str_contains($text,'id="fjSideRail"'),"Page $page lacks navigation rail");}
$rootCss=glob($root.'/*.css')?:[];$ok(count($rootCss)===1&&basename($rootCss[0])==='falco-jugger-ui.css','Legacy CSS remained in root');
$ok(str_contains((string)file_get_contents($root.'/uppurcell.php'),"require __DIR__ . '/index.php'"),'Purcell route must reuse analyzer');
echo "PASS Falco 26 — static dock, center, drawer, one stylesheet, persistent core IDs, Purcell general optimizer\n";
