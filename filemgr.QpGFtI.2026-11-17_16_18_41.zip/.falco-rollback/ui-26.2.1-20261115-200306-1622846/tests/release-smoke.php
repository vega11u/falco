<?php
declare(strict_types=1);
/**
 * Falco24 current compatibility/release smoke.
 *
 * Previous release-smoke was hard-coded to v23.0.7 rendering and a 2-mode depth
 * policy. Its original is preserved at tests/archived/release-smoke-v23-historical.txt
 * for archaeology, not executed against the v23.0.27 engine.
 */
$root=dirname(__DIR__);
$check=static function(bool $ok,string $description):void {
    if(!$ok){fwrite(STDERR,"FAIL: $description\n");exit(1);}
};
$version=trim((string)file_get_contents($root.'/VERSION'));
$check($version==='23.0.27','Core version is not the validated 23.0.27 baseline');
$manifest=json_decode((string)file_get_contents($root.'/data/trained/training-manifest.json.template'),true);
$check(is_array($manifest) && is_array($manifest['models']??null),'Training template is missing or invalid');
foreach($manifest['models'] as $name=>$model) {
    $check(($model['ready']??false)===false,"Research model $name marked ready without installed weights");
}
$installed=$root.'/data/trained/training-manifest.json';
if(is_file($installed)) {
    $data=json_decode((string)file_get_contents($installed),true);
    $check(is_array($data)&&is_array($data['models']??null),'Research snapshot manifest invalid');
}
$corpus=json_decode((string)file_get_contents($root.'/data/real-training-corpus-manifest.json'),true);
$check(is_array($corpus)&&($corpus['training_pipeline']['actual_training_on_install']??true)===false,'Unverified training claim');
$index=(string)file_get_contents($root.'/index.php');
foreach(['media-import-start','media-import-status','reports-upload-begin','reports-upload-chunk','reports-upload-commit',
          'reports-save','reports-list','reports-get','reports-delete','purcell-library',
          'purcell-save','purcell-feedback','pattern-reviews','model-sync'] as $endpoint) {
    $check(str_contains($index,"'".$endpoint."'"),"Missing API contract: $endpoint");
}
foreach(['reconstruction-memory.php','kata-recognition-core.mjs','biomechanics-core.mjs',
         'purcell-core.mjs','personalized-body-surface-core.mjs','vivaldi-fine-mesh.mjs',
         'pose-worker.js','depth-worker.js','falco-jugger-ui.css',
         'falco-jugger-ui.js','FALCO26_INSTALL.md','FALCO26_RELEASE_VERSION.txt'] as $file) {
    $check(is_file($root.'/'.$file),"Missing runtime: $file");
}
$check(str_contains($index,'constrained-dtw-posture-motion-v6-foot-aware'),'Missing persisted 48D matching method');
$check(str_contains($index,'avatarPlaybackEnabled:false'),'3D playback must start disabled');
$check(str_contains($index,'data-biomech-replay'),'Purcell replay cards missing');
$check(str_contains($index,'id="analysisDock"'),'Static synchronized player missing');
$check(str_contains($index,"!fj_api_same_origin("),'Cross-origin POST guard not connected');
$_GET=[];
$_SERVER['DOCUMENT_ROOT']=$root;
ob_start();require $root.'/index.php';$html=(string)ob_get_clean();
foreach(['dropZone','videoFile','video','overlay','resultsSection','optimizerPanel',
         'purcellTrainingPanel','generate3dBtn','player3dPlayback',
         'f24SessionStatus','f24SourceStatus','f24AnalysisStatus'] as $id) {
    $check(substr_count($html,'id="'.$id.'"')===1, "Rendered ID missing or duplicated: $id");
}
$check(str_contains($html,'YouTube')&&str_contains($html,'Instagram'),'Supported imports not visible');
$check(str_contains($html,'FALCO JUGGER') && str_contains($html,'KATA BIOMECHANICS LAB'),'Falco Jugger brand missing');
$check(str_contains($html,'data-f24-nav="upload"') && str_contains($html,'data-f24-nav="metrics"'),'Accessible main navigation missing');
$check(str_contains($html,'falco-jugger-ui.css?v=26.0.0') && !str_contains($html,'f24-topbar'),'Neo Aero Flight Deck stylesheet/rail missing');
$check(str_contains($html,'Кинематический'),'Biomechanical methodology missing');
$jsonCount=0;
foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS)) as $file) {
    if(!$file->isFile()||strtolower($file->getExtension())!=='json')continue;
    try{json_decode((string)file_get_contents($file->getPathname()),true,512,JSON_THROW_ON_ERROR);}
    catch(JsonException $error){$check(false,'Invalid JSON '.$file->getPathname().' '.$error->getMessage());}
    $jsonCount++;
}
printf("Falco26 release smoke: core %s, reports, Purcell, player, research status, UX, %d JSON assets: PASS\n",$version,$jsonCount);
