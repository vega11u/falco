<?php
declare(strict_types=1);
$root=dirname(__DIR__);$src=file_get_contents($root.'/index.php');$css=file_get_contents($root.'/falco-jugger-ui.css');$js=file_get_contents($root.'/falco-jugger-ui.js');
$checks=[
 'one root CSS file'=>count(glob($root.'/*.css')?:[])===1,
 'one versioned stylesheet'=>substr_count($src,'falco-jugger-ui.css?v=26.0.0')===1,
 'one versioned controller'=>substr_count($src,'falco-jugger-ui.js?v=26.0.1')===1,
 'no inline stylesheet'=>!str_contains($src,'<style'),
 'no legacy cascade layer'=>!str_contains($css,'@layer compatibility'),
 'no legacy 24 workspace grid'=>!str_contains($css,'.f24-workspace-grid'),
 'player in server HTML'=>str_contains($src,'<aside class="fj-player-column"')&&str_contains($src,'id="analysisDock"'),
 'desktop player sticky'=>str_contains($css,'.fj-player-column{position:sticky'),
 'tablet and mobile player'=>str_contains($css,'.fj-mobile-player-open{position:fixed')&&str_contains($css,'body.fj-player-expanded .analysis-dock{display:block'),
 'bounded journal drawer'=>str_contains($css,'.fj-journal-drawer{position:fixed')&&str_contains($src,'id="fjJournalDrawer"'),
 'journal rendering cap'=>str_contains($src,".slice(-150).reverse()"),
 'no workspace DOM rebuild'=>!str_contains($js,'layout.replaceWith(')&&!str_contains($js,'mountWorkspace('),
 'existing trim preserved'=>str_contains($src,'id="clipWorkspace"')&&str_contains($src,'id="rangeControls"')&&str_contains($src,'installStudioWorkspace()'),
 'single Purcell feedback'=>str_contains($src,'data-optimizer-feedback="overall"'),
];
$failed=0;foreach($checks as $key=>$pass){echo ($pass?'PASS ':'FAIL ').$key."\n";if(!$pass)$failed++;}exit($failed?1:0);
