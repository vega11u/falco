/* Falco Jugger 26.1.0 | Fixed-mesh / accessible Flight Deck controller.
 * All analysis, learning, player event handlers and API contracts remain in index.php.
 * This controller moves existing media nodes once; it never clones IDs or creates players.
 */
(()=>{
'use strict';
const d=document,$=id=>d.getElementById(id),body=d.body,root=d.documentElement;
const ready=fn=>d.readyState==='loading'?d.addEventListener('DOMContentLoaded',fn,{once:true}):fn();
const focusable=el=>el?[...el.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')].filter(x=>!x.hidden&&x.getAttribute('aria-hidden')!=='true'&&x.getClientRects().length):[];
function trapTab(event,container){
 if(event.key!=='Tab')return;
 const items=focusable(container);if(!items.length){event.preventDefault();return;}
 const first=items[0],last=items.at(-1),active=d.activeElement;
 if(event.shiftKey&&active===first){event.preventDefault();last.focus({preventScroll:true});}
 else if(!event.shiftKey&&active===last){event.preventDefault();first.focus({preventScroll:true});}
}
function setup(){
 const rail=$('fjSideRail'),scrim=$('fjNavScrim'),menu=$('fjNavToggle');
 let navReturnFocus=null;
 if(menu)menu.setAttribute('aria-controls','fjSideRail');
 const closeNav=()=>{
  const wasOpen=body.classList.contains('fj-nav-open');
  body.classList.remove('fj-nav-open');if(menu)menu.setAttribute('aria-expanded','false');if(scrim)scrim.hidden=true;
  if(wasOpen&&navReturnFocus?.isConnected)navReturnFocus.focus({preventScroll:true});navReturnFocus=null;
 };
 const openNav=()=>{
  if(!rail)return;navReturnFocus=d.activeElement;body.classList.add('fj-nav-open');
  if(menu)menu.setAttribute('aria-expanded','true');if(scrim)scrim.hidden=false;
  (focusable(rail)[0]||rail).focus?.({preventScroll:true});
 };
 menu?.addEventListener('click',()=>body.classList.contains('fj-nav-open')?closeNav():openNav());
 scrim?.addEventListener('click',closeNav);
 rail?.querySelectorAll('a').forEach(link=>link.addEventListener('click',closeNav));
 window.addEventListener('resize',()=>{if(window.innerWidth>=1180)closeNav();},{passive:true});

 // Theme follows the user's explicit choice; otherwise it follows the OS preference.
 const themeButton=$('themeToggle');
 function setTheme(theme,persist=true){
  const next=theme==='light'?'light':'dark';root.dataset.theme=next;
  if(themeButton){themeButton.textContent=next==='light'?'☾ Тёмная тема':'☼ Светлая тема';themeButton.setAttribute('aria-pressed',String(next==='dark'));}
  const meta=d.querySelector('meta[name="color-scheme"]');if(meta)meta.content=next;
  if(persist)try{localStorage.setItem('falco-jugger-theme-v1',next);localStorage.setItem('fj-theme',next);}catch(_){}
 }
 let previous=null;try{previous=localStorage.getItem('falco-jugger-theme-v1')||localStorage.getItem('fj-theme');}catch(_){}
 const systemDark=!!window.matchMedia?.('(prefers-color-scheme: dark)').matches;
 setTheme(previous==='dark'?'dark':previous==='light'?'light':systemDark?'dark':'light',false);
 if(!previous&&window.matchMedia){
  const media=window.matchMedia('(prefers-color-scheme: dark)');
  media.addEventListener?.('change',e=>{let explicit=null;try{explicit=localStorage.getItem('falco-jugger-theme-v1')||localStorage.getItem('fj-theme');}catch(_){}if(!explicit)setTheme(e.matches?'dark':'light',false);});
 }
 // The analyzer module owns its theme button; two click handlers would toggle twice.
 if(!body.matches('[data-mode="analyzer"],[data-mode="purcell"]')&&themeButton?.dataset.fjThemeBound!=='1')themeButton?.addEventListener('click',()=>setTheme(root.dataset.theme==='dark'?'light':'dark'));

 // Static grid is server-rendered: move only existing DOM nodes, never recreate them.
 const stage=$('videoStage'),video=$('video'),three=$('pose3dCanvas')?.closest('section.panel'),metrics=$('currentPanel');
 const videoMount=$('fjVideoMount'),threeMount=$('fjThreeMount'),metricMount=$('playerMetricsScroll');
 if(stage&&videoMount){if(stage.parentElement!==videoMount)videoMount.replaceChildren(stage);stage.classList.add('docked-video-stage');}
 if(three&&threeMount){if(three.parentElement!==threeMount)threeMount.replaceChildren(three);three.classList.add('docked-three-panel');}
 if(metrics&&metricMount&&metrics.parentElement!==metricMount)metricMount.append(metrics);
 if(videoMount&&stage)videoMount.classList.add('fj-video-ready');

 // Local anchor navigation; the document scrolls while the desktop player stays pinned.
 const anchorLinks=[...d.querySelectorAll('.fj-session-nav a[href^="#"]')];
 const active=link=>anchorLinks.forEach(a=>{const selected=a===link;a.classList.toggle('is-active',selected);if(selected)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');});
 anchorLinks.forEach(link=>link.addEventListener('click',e=>{
  const target=d.getElementById(link.hash.slice(1));
  if(!target||target.closest('[hidden], .hidden')||target.hidden){e.preventDefault();$('dropZone')?.scrollIntoView({behavior:'smooth',block:'start'});return;}
  active(link);
 }));
 if('IntersectionObserver'in window){
  const els=anchorLinks.map(link=>({link,target:d.getElementById(link.hash.slice(1))})).filter(x=>x.target);
  const observer=new IntersectionObserver(entries=>{const hit=entries.filter(x=>x.isIntersecting).sort((a,b)=>b.intersectionRatio-a.intersectionRatio)[0];const row=els.find(x=>x.target===hit?.target);if(row)active(row.link);},{rootMargin:'-8% 0px -70% 0px',threshold:[0,.05,.2]});
  els.forEach(x=>observer.observe(x.target));
 }
 const page=location.pathname.split('/').pop()||'index.php';
 const pages={'uppurcell.php':'purcell-training','lully.php':'lully','purcell-lab.php':'purcell-library','models.php':'models','Memories.php':'reports'};
 rail?.querySelectorAll('[data-fj-page]').forEach(a=>{const selected=a.dataset.fjPage===pages[page];a.classList.toggle('is-page-active',selected);if(selected)a.setAttribute('aria-current','page');});

 // Journal is a modal drawer; preserve focus and keep keyboard navigation inside it.
 const drawer=$('fjJournalDrawer'),journalMount=$('fjJournalMount'),journal=$('appJournalPanel'),journalOpen=$('fjJournalOpen'),journalClose=$('fjJournalClose'),journalScrim=$('fjJournalScrim');
 if(journalMount&&journal){journalMount.append(journal);journal.hidden=false;}
 let journalReturnFocus=null;
 if(journalOpen)journalOpen.setAttribute('aria-controls','fjJournalDrawer');
 const closeJournal=()=>{
  const wasOpen=!!drawer&&!drawer.hidden;if(drawer)drawer.hidden=true;if(journalScrim)journalScrim.hidden=true;body.classList.remove('fj-journal-open');
  journalOpen?.setAttribute('aria-expanded','false');drawer?.setAttribute('aria-modal','false');
  if(wasOpen&&journalReturnFocus?.isConnected)journalReturnFocus.focus({preventScroll:true});journalReturnFocus=null;
 };
 const openJournal=()=>{
  if(!drawer)return;journalReturnFocus=d.activeElement;if(journalScrim)journalScrim.hidden=false;drawer.hidden=false;body.classList.add('fj-journal-open');
  journalOpen?.setAttribute('aria-expanded','true');drawer.setAttribute('role','dialog');drawer.setAttribute('aria-modal','true');
  (journalClose||focusable(drawer)[0]||drawer).focus?.({preventScroll:true});
 };
 journalOpen?.addEventListener('click',openJournal);journalClose?.addEventListener('click',closeJournal);journalScrim?.addEventListener('click',closeJournal);

 // 3D is one general player mode; the underlying analyzer controls the renderer.
 const toggle3d=$('aeroToggle3d'),original3d=$('player3dPlayback'),open3d=$('player3dOpen'),pane3=d.querySelector('#analysisDock .player-pane-3d');
 function sync3d(){
  const enabled=!!original3d?.checked&&!original3d?.disabled,available=!original3d?.disabled||!open3d?.disabled;
  if(toggle3d){toggle3d.disabled=!available;toggle3d.textContent=enabled?'3D включён':'3D по запросу';toggle3d.setAttribute('aria-pressed',String(enabled));}
  pane3?.classList.toggle('is-open',enabled);$('analysisDock')?.classList.toggle('fj-3d-active',enabled);
 }
 toggle3d?.addEventListener('click',()=>{if(original3d?.checked){original3d.checked=false;original3d.dispatchEvent(new Event('change',{bubbles:true}));}else if(open3d&&!open3d.disabled)open3d.click();requestAnimationFrame(sync3d);});
 original3d?.addEventListener('change',sync3d);open3d?.addEventListener('click',()=>requestAnimationFrame(sync3d));
 if(original3d)new MutationObserver(sync3d).observe(original3d,{attributes:true,attributeFilter:['disabled','checked']});
 if(open3d)new MutationObserver(sync3d).observe(open3d,{attributes:true,attributeFilter:['disabled']});
 sync3d();

 const dock=$('analysisDock'),expand=$('fjMobilePlayerOpen'),time=$('fjMiniTime');
 if(expand)expand.setAttribute('aria-controls','analysisDock');
 function setPlayerExpanded(open){
  const next=!!open&&window.innerWidth<1180;body.classList.toggle('fj-player-expanded',next);
  expand?.setAttribute('aria-expanded',String(next));if(dock)dock.setAttribute('aria-label',next?'Развёрнутый видеоплеер':'Видеосессия');
 }
 expand?.addEventListener('click',()=>setPlayerExpanded(!body.classList.contains('fj-player-expanded')));
 window.addEventListener('resize',()=>{if(window.innerWidth>=1180)setPlayerExpanded(false);},{passive:true});
 video?.addEventListener('timeupdate',()=>{if(time){const sec=Number(video.currentTime)||0;time.textContent=`${String(Math.floor(sec/60)).padStart(2,'0')}:${String(Math.floor(sec%60)).padStart(2,'0')}`;}});

 d.addEventListener('keydown',e=>{
  if(e.key==='Escape'){
   if(body.classList.contains('fj-journal-open'))closeJournal();
   else if(body.classList.contains('fj-nav-open'))closeNav();
   else if(body.classList.contains('fj-player-expanded'))setPlayerExpanded(false);
   return;
  }
  if(body.classList.contains('fj-journal-open'))trapTab(e,drawer);
  else if(body.classList.contains('fj-nav-open')&&window.innerWidth<900)trapTab(e,rail);
 });
}
ready(setup);
})();
