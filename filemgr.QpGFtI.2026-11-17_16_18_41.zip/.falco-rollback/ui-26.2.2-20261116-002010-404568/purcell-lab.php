<?php
declare(strict_types=1);
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: private, no-store, max-age=0');
?><!doctype html>
<html lang="ru"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#061522"><script>try{const saved=localStorage.getItem("falco-jugger-theme-v1")||localStorage.getItem("fj-theme");document.documentElement.dataset.theme=(saved==="dark"||saved!=="light"&&window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches)?"dark":"light";}catch(_){}</script><title>Purcell · FALCO KATA LAB</title>
<link rel="stylesheet" href="falco-jugger-ui.css?v=26.2.1">
</head>
<body class="f24-hub falco24-secondary" data-center="purcell">
<aside class="fj-side-rail fj-secondary-rail" id="fjSideRail" aria-label="Навигация Falco Jugger">
  <a class="fj-rail-brand" href="index.php" aria-label="Falco Jugger — анализ ката"><img src="assets/falco-avatar-sanchin.svg" width="46" height="46" alt=""><span><strong>FALCO JUGGER</strong><small>KATA BIOMECHANICS LAB</small></span></a>
  <div class="fj-rail-section-label">РАБОЧИЕ ОБЛАСТИ</div>
  <nav class="f24-rail-group fj-library-nav" aria-label="Рабочие области">
    <a class="f24-rail-link fj-secondary-link" href="index.php" data-fj-page="analyzer"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M8 4v16"/></svg></span><span>Анализ ката</span></a>
    <a class="f24-rail-link fj-secondary-link" href="uppurcell.php" data-fj-page="purcell-training"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M7 17 17 7M8 7h9v9"/></svg></span><span>Обучение Purcell</span></a>
    <a class="f24-rail-link fj-secondary-link" href="lully.php" data-fj-page="lully"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="12" cy="18" r="2"/><path d="M8 6h8M7.5 7.5l3.2 8.7m5.8-8.7-3.2 8.7"/></svg></span><span>Lully · паттерны</span></a>
    <a class="f24-rail-link fj-secondary-link" href="purcell-lab.php" data-fj-page="purcell-library"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="m12 3 8 5v8l-8 5-8-5V8z"/><path d="m4 8 8 5 8-5m-8 5v8"/></svg></span><span>Purcell · библиотека</span></a>
    <a class="f24-rail-link fj-secondary-link" href="models.php" data-fj-page="models"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><rect x="13" y="13" width="7" height="7" rx="1"/></svg></span><span>Модели</span></a>
    <a class="f24-rail-link fj-secondary-link" href="Memories.php" data-fj-page="reports"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 8h16v12H4zM3 4h18v4H3zM9 12h6"/></svg></span><span>Отчёты</span></a>
  </nav>
  <div class="fj-rail-footer">
    <button class="btn small theme-toggle" id="themeToggle" type="button" aria-pressed="false" title="Переключить светлую / тёмную тему">◐ Тема</button>
    <button class="btn small hard-update-btn" id="hardUpdateBtn" type="button" aria-haspopup="dialog" title="Очистить Cache Storage и загрузить актуальную версию">HARD UPDATE</button>
  </div>
</aside>
<div class="fj-nav-scrim" id="fjNavScrim" hidden></div>
<div class="hub-shell">
<div class="fj-mobile-bar"><button class="fj-menu-toggle" id="fjNavToggle" type="button" aria-controls="fjSideRail" aria-expanded="false" aria-label="Открыть навигацию">☰</button><span class="fj-mobile-brand">FALCO JUGGER</span><span class="fj-mobile-page">PURCELL · БИБЛИОТЕКА</span></div>
<section class="hub-hero">
  <div class="eyebrow">PURCELL</div><h1>Biomechanics Library</h1>
  <p>Эталоны, нейтральные примеры и антипримеры</p>
  <div class="hero-actions"><a class="hub-btn" href="index.php#purcellWeaknessSection">К анализу слабых мест ↗</a><button class="hub-btn primary" id="refreshPurcell" type="button">Обновить</button></div>
</section>
<section class="stats">
  <div class="stat"><strong id="purcellTotal">—</strong><small>Примеров</small></div>
  <div class="stat"><strong id="purcellPositive">—</strong><small>Эталонов</small></div>
  <div class="stat"><strong id="purcellNegative">—</strong><small>Антипримеров</small></div>
  <div class="stat"><strong id="purcellFeedback">—</strong><small>Оценок</small></div>
</section>
<section class="hub-panel">
  <div class="panel-head"><div><h2>Распределение библиотеки</h2></div><span class="status-pill" id="purcellStatus">Подключение…</span></div>
  <div class="progress-block">
    <div class="distribution-line" role="img" aria-label="Распределение эталонов, нейтральных примеров и антипримеров"><span id="purcellPositiveBar" class="distribution-positive" style="width:0"></span><span id="purcellNeutralBar" class="distribution-neutral" style="width:0"></span><span id="purcellNegativeBar" class="distribution-negative" style="width:0"></span></div>
    <div class="distribution-legend"><span><i class="distribution-dot positive"></i><b id="purcellPositiveLabel">0</b> эталонов</span><span><i class="distribution-dot neutral"></i><b id="purcellNeutralLabel">0</b> нейтральных</span><span><i class="distribution-dot negative"></i><b id="purcellNegativeLabel">0</b> антипримеров</span></div>
    <small class="muted" id="purcellLibraryNote">Распределение оценок</small><small class="muted" id="purcellUpdated"></small>
  </div>
</section>
<section class="hub-panel">
  <div class="panel-head"><div><h2>Биомеханические примеры</h2></div></div>
  <div class="filters">
    <input id="searchPurcell" type="search" placeholder="Поиск по примеру…" aria-label="Поиск примеров Purcell">
    <select id="filterRating"><option value="">Все оценки</option><option value="good">4–5 · Эталоны</option><option value="neutral">3 · Нейтральные</option><option value="bad">1–2 · Антипримеры</option></select>
    <select id="sortPurcell"><option value="recent">Сначала новые</option><option value="rating">По оценке</option></select>
  </div>
  <div id="purcellCards" class="card-grid"><div class="loading">Загрузка…</div></div>
</section>
<footer class="hub-footer">FALCO KATA LAB · CREATED BY MAKS POLUCHOWICZ</footer>
</div>
<script src="falco24-learning-centers.js?v=24.2.2" defer></script>
<script defer src="falco-jugger-ui.js?v=26.2.1"></script>
<script type="module" src="hard-update-v23.0.19.js?v=23.0.19"></script>
</body></html>