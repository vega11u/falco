<?php
declare(strict_types=1);
/* FJ 26.0.1: static regression guard for the fatal missing pageModeLabel and lost handlers.
 * Runtime browser integration is separately tested by functional_smoke.py in QA.
 */
$root=dirname(__DIR__);
$php=(string)file_get_contents($root.'/index.php');
$js=(string)file_get_contents($root.'/falco-jugger-ui.js');
$css=glob($root.'/*.css') ?: [];
$ok=function(bool $pass,string $message):void {if(!$pass)throw new RuntimeException($message);};
$ok(substr_count($php,'id="pageModeLabel"')===1,'Critical initialization target pageModeLabel absent / duplicated');
$ok(str_contains($php,"if(\$('pageModeLabel'))\$('pageModeLabel').textContent='PURCELL';"),'Purcell mode boot must guard mode target');
$ok(str_contains($php,"if(\$('pageModeLabel'))\$('pageModeLabel').textContent='ANALYZER';"),'Analyzer mode boot must guard mode target');
$ok(str_contains($php,'installAnalysisDock();installStudioWorkspace();installTaskFirstLayout();installOptimizerPlayer();'),'Main boot sequence altered');
foreach(['chooseVideo','loadVideoUrl','analyzeBtn','stopBtn','resetAllBtn','playerPlay','playerContinue','playerRestart','playerBack','playerForward','playerRate','playerSeek','openClipEditor','quickTrimApply','saveReportBtn','downloadReportBtn','appJournalPanel'] as $id){
 $ok(substr_count($php,'id="'.$id.'"')===1,"Missing/duplicate essential ID: $id");
}
$ok(str_contains($php,'falco-jugger-ui.js?v=26.2.1'),'Versioned handler controller missing');
$ok(str_contains($php,'falco-jugger-ui.css?v=26.2.1'),'Approved CSS replacement changed unexpectedly');
$ok(str_contains($js,"if(!body.matches('[data-mode=\"analyzer\"],[data-mode=\"purcell\"]'))"),'Double theme toggle may return');
$ok(str_contains($js,'aeroCloseClipEditor')&&str_contains($js,'aeroPlayerFullscreen')&&str_contains($js,'setRangePaint'),'Trim and player controls not recovered');
$ok(str_contains($js,'#analysisDock')&&str_contains($js,'event.key')&&str_contains($js,'fjAuxiliaryPanels'),'Keyboard or auxiliary panel controls missing');
$ok(!str_contains($js,'layout.replaceWith(')&&!str_contains($js,'mountWorkspace('),'Old DOM reconstruction was restored');
$ok(count($css)===1&&basename($css[0])==='falco-jugger-ui.css','Expected one active root stylesheet');
foreach(['lully.php','purcell-lab.php','models.php','Memories.php'] as $page){
 $src=(string)file_get_contents($root.'/'.$page);
 $ok(str_contains($src,'falco-jugger-ui.js?v=26.2.1'),"Stale UI JS cache-busting in $page");
}
$ok(str_contains($php,'data-optimizer-feedback="overall"'),'Purcell single overall optimization contract lost');
echo "PASS Falco 26.0.1: fatal boot target, critical handlers, single theme owner, trim, player, journal, libraries, one CSS\n";
