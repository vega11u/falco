/** CPU-only body reconstruction, run after frame capture in a dedicated worker.
 * Single in-flight sequence, no GPU use and no writes to learning libraries. */
import {reconstructBodySequence} from './body-reconstruction-core.mjs?v=23.0.13';
self.onmessage=event=>{
  const {frames,aspect,maxGap}=event.data||{};
  try{
    if(!Array.isArray(frames)||frames.length>120000)throw new Error('Недопустимый размер последовательности реконструкции.');
    const result=reconstructBodySequence(frames,{aspect,maxGap});
    self.postMessage({ok:true,...result});
  }catch(error){self.postMessage({ok:false,error:String(error?.message||error).slice(0,800)});}
};
