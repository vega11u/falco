/** Personal 3D model archive v2. Geometry is derived from the available observed
 * 3D joint track and measured silhouette profile. A keyframe is a REAL rendered
 * mesh snapshot, not a 33-point skeleton or an unvalidated neural scan.
 * Depth of hidden surfaces is a geometric prior.
 */
import {buildVivaldiFineMesh,paintVivaldiMesh3D,VIVALDI_FINE_MESH_VERSION} from './vivaldi-fine-mesh.mjs';
export const PERSONAL_3D_ARCHIVE_VERSION='falco-personalized-vivaldi-mesh-keyframes-v2';
const finite=Number.isFinite;
const bound=(v,min,max)=>Math.max(min,Math.min(max,v));
const p3=p=>Array.isArray(p)&&p.length>=3&&p.slice(0,3).every(finite)&&(p[3]??1)>=.12;
const bytes64=bytes=>{let result='';for(let i=0;i<bytes.length;i+=8192)result+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(result);};
const from64=text=>{const source=atob(text),out=new Uint8Array(source.length);for(let i=0;i<source.length;i++)out[i]=source.charCodeAt(i);return out;};
const ownProfile=profile=>!!profile&&finite(profile.profile_confidence)&&profile.profile_confidence>=.12&&profile.width_profile&&Object.values(profile.width_profile).some(rows=>Array.isArray(rows)&&rows.some(v=>Array.isArray(v)&&finite(v[0])&&v[0]>.015&&v[1]>=.18));
export function hasMeasuredPersonal3D(frame,profile){return ownProfile(profile)&&(frame?.render_w||frame?.w||[]).filter(p3).length>=12;}
/** Fixed world-coordinate quantization ±2.5 m-equivalent MediaPipe units, 3 x Int16 + Uint8 confidence. */
export function encodeVivaldiMeshSnapshot(frame,profile){
 if(!hasMeasuredPersonal3D(frame,profile))return null;
 const mesh=buildVivaldiFineMesh(frame,profile,{resolution:'compact',space:'3d'});
 if(mesh.vertex_count!==512||mesh.visible_vertices<256||mesh.quality==='insufficient_evidence')return null;
 const bytes=new Uint8Array(512*7),v=new DataView(bytes.buffer);
 for(let i=0;i<512;i++){
  for(let axis=0;axis<3;axis++){const x=mesh.positions[i*4+axis];if(!finite(x))return null;v.setInt16(i*7+axis*2,Math.round(bound(x,-2.5,2.5)*32767/2.5),true);}
  bytes[i*7+6]=Math.round(bound(mesh.positions[i*4+3],0,1)*255);
 }
 return {t:Number(frame.t)||0,sample_index:Number.isInteger(frame.sample_index)?frame.sample_index:null,encoding:'512x-xyz-i16-conf-u8-le',vertices:512,bytes_base64:bytes64(bytes)};
}
export function decodeVivaldiMeshSnapshot(item){
 if(!item||item.encoding!=='512x-xyz-i16-conf-u8-le'||item.vertices!==512||typeof item.bytes_base64!=='string')return null;
 let bytes;try{bytes=from64(item.bytes_base64);}catch{return null;}
 if(bytes.length!==3584)return null;
 const view=new DataView(bytes.buffer),positions=new Float32Array(2048);let good=0;
 for(let i=0;i<512;i++){
  for(let k=0;k<3;k++)positions[i*4+k]=view.getInt16(i*7+k*2,true)*2.5/32767;
  positions[i*4+3]=bytes[i*7+6]/255;if(positions[i*4+3]>=.12)good++;
 }
 return {positions,vertex_count:512,visible_vertices:good};
}
/** Samples all regions of the timeline; no unnecessary 8192-vertex arrays stored in JS/PHP. */
export function buildPersonalized3DArchive(frames,profile,{maxKeyframes=200}={}){
 if(!Array.isArray(frames)||!frames.length||!ownProfile(profile))return null;
 const count=frames.length,limit=bound(Math.trunc(maxKeyframes),1,400),step=Math.max(1,Math.ceil(count/limit));
 const sampled=[],bad=0;
 for(let i=0;i<count;i+=step){const point=encodeVivaldiMeshSnapshot(frames[i],profile);if(point)sampled.push(point);}
 if((count-1)%step!==0){const tail=encodeVivaldiMeshSnapshot(frames.at(-1),profile);if(tail)sampled.push(tail);}
 if(!sampled.length)return null;
 return {schema:PERSONAL_3D_ARCHIVE_VERSION,mesh_generator:VIVALDI_FINE_MESH_VERSION,topology:'512 compact vertices, same segments as standard 2048/fine 8192',coordinate_space:'MediaPipe-relative body-centred 3D; not calibrated metric',shape_source:'multi-frame measured 2D person segmentation widths, 3D estimated geometry',frame_count:count,sample_step:step,has_full_3d_track:true,has_frame_surface_profile:true,keyframe_count:sampled.length,keyframes:sampled,profile_confidence:profile.profile_confidence};
}
export function validatePersonalized3DArchive(archive,frameCount){
 if(!archive||archive.schema!==PERSONAL_3D_ARCHIVE_VERSION||!Array.isArray(archive.keyframes)||!archive.keyframes.length||archive.keyframes.length>401||archive.frame_count!==frameCount)return false;
 return !!decodeVivaldiMeshSnapshot(archive.keyframes[0]);
}
/** Draw the actual quantized keyframe from the report, using its saved vertices.
 * Stable topology means the same triangle strips can be rebuilt without a skeleton.
 */
export function paintSavedPersonal3D(ctx,item,{width=640,height=480,yaw=-.42,pitch=.23,color='#7ed9eb'}={}){
 const mesh=decodeVivaldiMeshSnapshot(item);if(!mesh||mesh.visible_vertices<256||!ctx)return false;
 const points=mesh.positions,visible=[];
 for(let i=0;i<512;i++)if(points[i*4+3]>=.12)visible.push([points[i*4],points[i*4+1],points[i*4+2]]);
 if(!visible.length)return false;
 const range=axis=>{const a=visible.map(p=>p[axis]);return [Math.min(...a),Math.max(...a)]};
 const [minX,maxX]=range(0),[minY,maxY]=range(1),[minZ,maxZ]=range(2);
 const cx=(minX+maxX)*.5,cy=(minY+maxY)*.5,cz=(minZ+maxZ)*.5;
 const zoom=bound(height*1.85/Math.max(.25,maxY-minY),height*.65,height*3.1);
 const ca=Math.cos(yaw),sa=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);
 const projected=Array.from({length:512},(_,i)=>{
  const x=points[i*4]-cx,y=points[i*4+1]-cy,z=points[i*4+2]-cz;
  const X=x*ca+z*sa,Z=z*ca-x*sa,Y=y*cp-Z*sp,D=Math.max(1.2,2.4+Z*cp+y*sp);
  return {x:width*.5+X/D*zoom,y:height*.54+Y/D*zoom,z:Z,c:points[i*4+3]};
 });
 const faces=[];
 for(let seg=0;seg<9;seg++)for(let r=0;r<3;r++)for(let k=0;k<14;k++){
  const a=seg*56+r*14+k,b=seg*56+r*14+(k+1)%14,c=a+14,d=b+14;
  for(const ids of [[a,b,c],[b,d,c]]){
   const q=ids.map(i=>projected[i]);if(Math.min(...q.map(p=>p.c))<.15)continue;
   const area=Math.abs((q[1].x-q[0].x)*(q[2].y-q[0].y)-(q[1].y-q[0].y)*(q[2].x-q[0].x));
   if(area<.025||area>width*height*.25)continue;
   faces.push({q,depth:q.reduce((a,p)=>a+p.z,0)/3});
  }
 }
 faces.sort((a,b)=>b.depth-a.depth);ctx.save();ctx.fillStyle=color;ctx.globalAlpha=.94;
 for(const f of faces){ctx.beginPath();ctx.moveTo(f.q[0].x,f.q[0].y);ctx.lineTo(f.q[1].x,f.q[1].y);ctx.lineTo(f.q[2].x,f.q[2].y);ctx.closePath();ctx.fill();}
 ctx.restore();return faces.length>=60;
}
/** Personalized surfaces only; don't silently replace a missing mesh with a stick figure. */
export function renderArchivedPersonal3D(ctx,frame,profile,archive,{width=640,height=480,yaw=-.42,pitch=.23}={}){
 if(!ctx)return false;
 ctx.clearRect(0,0,width,height);
 const gradient=ctx.createLinearGradient(0,0,0,height);gradient.addColorStop(0,'#112b44');gradient.addColorStop(1,'#07101d');ctx.fillStyle=gradient;ctx.fillRect(0,0,width,height);
 let painted=false;
 if(archive?.keyframes?.length){const timestamp=Number(frame?.t)||0;const snapshot=archive.keyframes.find(item=>Math.abs(Number(item?.t)-timestamp)<.005);if(snapshot)painted=paintSavedPersonal3D(ctx,snapshot,{width,height,yaw,pitch});}
 if(!painted&&hasMeasuredPersonal3D(frame,profile)){
  const points=(frame.render_w||frame.w).filter(p3),y=points.map(p=>p[1]),height3D=Math.max(.25,Math.max(...y)-Math.min(...y));
  const zoom=bound(height*1.85/height3D,height*.65,height*3.1);
  painted=paintVivaldiMesh3D(ctx,frame,profile,{resolution:'compact',yaw,pitch,centerX:width*.5,centerY:height*.55,size:zoom,color:'#7ed9eb',alpha:.94});
 }
 // An old archive may have a valid saved dense mesh keyframe but no 3D track.
 if(!painted&&archive?.keyframes?.length){
  const time=Number(frame?.t)||0,nearest=archive.keyframes.reduce((a,b)=>Math.abs(b.t-time)<Math.abs(a.t-time)?b:a);
  const mesh=decodeVivaldiMeshSnapshot(nearest);
  // Do not render an arbitrary stale pose for current playback time.
  if(mesh&&Math.abs(nearest.t-time)<.12){
   ctx.fillStyle='#9acadd';ctx.font=`${Math.max(14,Math.floor(height*.026))}px system-ui`;ctx.textAlign='center';
   ctx.fillText('3D-сетка сохранена; нужен исходный трек для точного реплея',width/2,height*.5);
  }
 }
 if(!painted){ctx.fillStyle='#b8d0e0';ctx.textAlign='center';ctx.font=`${Math.max(14,Math.floor(height*.028))}px system-ui`;ctx.fillText('Персональная 3D-сетка недоступна',width*.5,height*.47);ctx.font=`${Math.max(11,Math.floor(height*.020))}px system-ui`;ctx.fillText('Старый архив: нужен повторный анализ видео',width*.5,height*.52);}
 return painted;
}
