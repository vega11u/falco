<?php
declare(strict_types=1);
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: private, no-store, max-age=0');
?><!doctype html>
<html lang="ru"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#061522"><title>Lully · FALCO KATA LAB</title>
<link rel="stylesheet" href="falco-jugger-ui.css?v=26.0.0">
</head>
<body class="f24-hub falco24-secondary" data-center="lully">
<aside class="fj-side-rail fj-secondary-rail" id="fjSideRail" aria-label="Навигация Falco Jugger">
  <a class="fj-rail-brand" href="index.php" aria-label="Falco Jugger — анализ ката"><img src="assets/falco-avatar-sanchin.svg" width="46" height="46" alt=""><span><strong>FALCO JUGGER</strong><small>KATA BIOMECHANICS LAB</small></span></a>
  <div class="fj-rail-section-label">РАБОЧИЕ ОБЛАСТИ</div>
  <nav class="f24-rail-group fj-library-nav" aria-label="Рабочие области">
    <a class="f24-rail-link fj-secondary-link" href="index.php" data-fj-page="analyzer"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M8 4v16"/></svg></span><span>Анализ ката</span></a>
    <a class="f24-rail-link fj-secondary-link" href="uppurcell.php" data-fj-page="purcell-training"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M7 17 17 7M8 7h9v9"/></svg></span><span>Обучение Purcell</span></a>
    <a class="f24-rail-link fj-secondary-link" href="lully.php" data-fj-page="lully"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="12" cy="18" r="2"/><path d="M8 6h8M7.5 7.5l3.2 8.7m5.8-8.7-3.2 8.7"/></svg></span><span>Lully · паттерны</span></a>
    <a class="f24-rail-link fj-secondary-link" href="purcell-lab.php" data-fj-page="purcell-library"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="m12 3 8 5v8l-8 5-8-5V8z"/><path d="m4 8 8 5 8-5m-8 5v8"/></svg></span><span>Purcell · библиотека</span></a>
    <a class="f24-rail-link fj-secondary-link" href="models.php" data-fj-page="models"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><rect x="13" y="13" width="7" height="7" rx="1"/></svg></span><span>Модели</span></a>
    <a class="f24-rail-link fj-secondary-link" href="Memories.php" data-fj-page="reports"><span class="f24-rail-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 8h16v12H4zM3 4h18v4H3zM9 12h6"/></svg></span><span>Отчёты</span></a>
  </nav>
  <div class="fj-rail-footer">
    <button class="btn small theme-toggle" id="themeToggle" type="button" aria-pressed="false" title="Переключить светлую / тёмную тему">◐ Тема</button>
    <button class="btn small hard-update-btn" id="hardUpdateBtn" type="button" aria-haspopup="dialog" title="Очистить Cache Storage и загрузить актуальную версию">HARD UPDATE</button>
  </div>
</aside>
<div class="fj-nav-scrim" id="fjNavScrim" hidden></div>
<div class="hub-shell">
<div class="fj-mobile-bar"><button class="fj-menu-toggle" id="fjNavToggle" type="button" aria-controls="fjSideRail" aria-expanded="false" aria-label="Открыть навигацию">☰</button><span class="fj-mobile-brand">FALCO JUGGER</span><span class="fj-mobile-page">LULLY · ПАТТЕРНЫ</span></div>
<section class="hub-hero">
  <div class="eyebrow">LULLY</div><h1>Pattern Library</h1>
  <p>Подтверждённые паттерны ката</p>
  <div class="hero-actions"><a class="hub-btn" href="index.php#patternsSection">К разбору паттернов ↗</a><button class="hub-btn primary" id="refreshLully" type="button">Обновить</button></div>
</section>
<section class="stats" aria-label="Статистика Lully">
  <div class="stat"><strong id="totalExamples">—</strong><small>Примеров</small></div>
  <div class="stat"><strong id="labelCount">—</strong><small>Размечено</small></div>
  <div class="stat"><strong id="feedbackCount">—</strong><small>Оценок</small></div>
  <div class="stat"><strong id="modelExamples">—</strong><small>В модели</small></div>
</section>
<section class="hub-panel">
  <div class="panel-head"><div><h2>Библиотека паттернов</h2></div><span class="status-pill" id="lullyStatus">Подключение…</span></div>
  <div class="filters">
    <input id="searchLully" type="search" placeholder="Поиск паттерна…" aria-label="Поиск паттернов">
    <select id="filterStyle" aria-label="Фильтр по стилю"><option value="">Все стили</option><option value="shotokan">Сётокан</option><option value="shitoryu">Сито-рю</option><option value="gojuryu">Годзю-рю</option><option value="ryueiryu">Рюэй-рю</option><option value="unspecified">Стиль не указан</option></select>
    <select id="sortLully" aria-label="Сортировка"><option value="recent">Сначала новые</option><option value="label">По названию</option></select>
  </div>
  <div id="lullyCards" class="card-grid"><div class="loading">Загрузка…</div></div>
</section>
<footer class="hub-footer">FALCO KATA LAB · CREATED BY MAKS POLUCHOWICZ</footer>
</div>
<script src="falco24-learning-centers.js?v=24.2.2" defer></script>
<script defer src="falco-jugger-ui.js?v=26.0.1"></script>
<script type="module" src="hard-update-v23.0.19.js?v=23.0.19"></script>
</body></html>