/** Vivaldi Athlete Lattice: multi-frame anchors and fixed proportion priors.
 * Generates a consistent articulated surface proposal; not a metrically verified human scan.
 */
import {bachAtlasFrame,normalizedTechniqueVector} from './bach-coordinate-atlas.mjs';
export const VIVALDI_LATTICE_VERSION='vivaldi-lattice-v1';
const BONES=[[11,13],[13,15],[12,14],[14,16],[11,23],[12,24],[23,25],[25,27],[24,26],[26,28],[11,12],[23,24]];
const finite=Number.isFinite;
const good=(p,d=2)=>Array.isArray(p)&&p.length>=d&&p.slice(0,d).every(finite)&&(p[3]??1)>=.35;
const median=a=>{const x=a.filter(finite).sort((a,b)=>a-b);return x.length?x[Math.floor(x.length/2)]:null;};
const length=(p,q,d)=>Math.hypot(...Array.from({length:d},(_,k)=>p[k]-q[k]));
function frameQuality(f){const p=f.im||[],w=f.w||[];const core=[11,12,13,14,15,16,23,24,25,26,27,28];const visible=core.filter(i=>good(p[i])).length,world=core.filter(i=>good(w[i],3)).length;
 const conf=core.reduce((s,i)=>s+Math.max(0,Math.min(1,p[i]?.[3]||0)),0)/core.length;
 const silhouette=Math.max(0,Math.min(1,Number(f.surface?.confidence??f.surface?.quality??0)));
 return .54*(visible/12)+.24*(world/12)+.17*conf+.05*silhouette;}
/** Select diverse, high-visibility frames, optionally yielding <10 when footage is inadequate. */
export function selectVivaldiAnchors(frames,{max=30,minIntervalSeconds=.13}={}){
 if(!Array.isArray(frames)||!frames.length)return [];
 const step=Math.max(1,Math.floor(frames.length/2200));
 const pool=[];
 for(let i=0;i<frames.length;i+=step){const q=frameQuality(frames[i]),vec=normalizedTechniqueVector(frames[i]);if(q>.43&&vec)pool.push({index:i,time:Number(frames[i].t)||0,quality:q,vector:vec});}
 pool.sort((a,b)=>b.quality-a.quality);const chosen=[];
 for(const item of pool){if(chosen.some(x=>Math.abs(x.time-item.time)<minIntervalSeconds))continue;
  const diversity=chosen.length?Math.min(...chosen.map(x=>{let s=0,n=0;for(let j=0;j<item.vector.length;j++){const a=item.vector[j],b=x.vector[j];if(finite(a)&&finite(b)){s+=(a-b)**2;n++;}}return n?Math.sqrt(s/n):0;})):1;
  if(chosen.length>=6&&diversity<.025&&chosen.length>=Math.min(max,10))continue;
  chosen.push({...item,diversity});if(chosen.length>=max)break;
 }
 return chosen.sort((a,b)=>a.index-b.index).map(({index,time,quality,diversity})=>({index,time,quality:+quality.toFixed(3),diversity:+diversity.toFixed(3)}));
}
export function fitVivaldiIdentity(frames,{anchors=selectVivaldiAnchors(frames),profile=null}={}){
 const observedSh=anchors.map(anchor=>{const p=frames[anchor.index]?.im||[],a=p[11],b=p[12];return good(a)&&good(b)?length(a,b,2):null;}).filter(v=>finite(v)&&v>.025);
 const referenceImageShoulderSpan=median(observedSh);
 const lengths={},observations={};for(const [a,b] of BONES){const key=a+'-'+b;const samples=[];
  for(const anchor of anchors){const f=frames[anchor.index],p=f?.w||[];if(good(p[a],3)&&good(p[b],3)){const d=length(p[a],p[b],3);if(d>.018&&d<2.2)samples.push(d);}}
  const m=median(samples),deviation=median(samples.map(x=>m==null?null:Math.abs(x-m)));
  if(m!=null){lengths[key]=+m.toFixed(5);observations[key]={samples:samples.length,mad:deviation};}
 }
 return {schema:VIVALDI_LATTICE_VERSION,anchors,anchor_count:anchors.length,reference_image_shoulder_span:referenceImageShoulderSpan,segment_lengths: lengths,segment_evidence:observations,
  body_surface_profile:profile?{schema:profile.schema,profile_confidence:profile.profile_confidence,width_profile:profile.width_profile}:null,
  technique_space:'athlete-normalized',body_dimensions_are_not_technique_labels:true,
  coordinates:{image:'[0,1] normalized image',world:'body-relative estimates, not metres'},
  confidence:Math.min(1,anchors.length/15)*Math.min(1,Object.keys(lengths).length/BONES.length),
  limitations:['Fixed dimensions are estimated from visible frames, not direct biometric measurements.','Loose uniform and occlusion cause uncertainty; hidden geometry remains approximate.']};
}
/** Gentle bone constraint on rendering points only. Observed canonical landmarks are untouched.
 * Low-confidence points move much more than high-confidence points. */
export function stabilizeVivaldiFrames(frames,identity,{maxCorrection=.025}={}){
 if(!Array.isArray(frames))return {frames:[],corrected:0};let corrected=0;
 const out=frames.map(f=>({...f,render_w:(f.render_w||f.w||[]).map(p=>Array.isArray(p)?p.slice():p),render_im:(f.render_im||f.im||[]).map(p=>Array.isArray(p)?p.slice():p)}));
 for(const f of out){for(const [a,b] of BONES){const target=identity?.segment_lengths?.[a+'-'+b],p=f.render_w?.[a],q=f.render_w?.[b];if(!(target>.018)||!good(p,3)||!good(q,3))continue;
 const d=length(p,q,3);if(d<.008)continue;
 const delta=d-target;if(Math.abs(delta)<Math.max(.012,target*.06))continue;
 const ca=Math.min(1,Math.max(0,p[3]??0)),cb=Math.min(1,Math.max(0,q[3]??0));
 const elasticity=Math.max(.01,1-Math.min(ca,cb));const move=Math.sign(delta)*Math.min(maxCorrection,Math.abs(delta)*.45*elasticity);
 // Modify only lower-confidence endpoint. Prevents moving confidently observed joints.
 const point=ca>cb?q:p,other=ca>cb?p:q,sign=ca>cb?1:1;
 const vec=Array.from({length:3},(_,i)=>(point[i]-other[i])/d);
 for(let k=0;k<3;k++)point[k]-=sign*move*vec[k];corrected++;
 }}
 return {frames:out,corrected};
}
export function vivaldiQualityOverview(frames,identity){const qualities=(frames||[]).filter(f=>f.im).map(frameQuality);return {schema:VIVALDI_LATTICE_VERSION,anchor_count:identity?.anchor_count||0,frame_count:frames?.length||0,quality_mean:qualities.length?qualities.reduce((a,b)=>a+b,0)/qualities.length:null,coverage:identity?.confidence||0,atlas:frames?.length?bachAtlasFrame(frames[0]):null};}
