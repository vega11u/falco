/** Motion Studio reconstruction evidence gate v1 (no implicit 3D metric calibration).
 * Observations are not invented. The score measures suitability for training, not form accuracy.
 * Pure JS, usable in browsers and Node tests, linear time in decoded frames.
 */
import {pointInAthleteSilhouette} from './athlete-silhouette-core.mjs';
export const MOTION_RECONSTRUCTION_QA_VERSION='falco-reconstruction-evidence-v1';
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
const finite=Number.isFinite;
const joint=(p,d=2)=>Array.isArray(p)&&p.length>=d&&p.slice(0,d).every(finite)&&(p[3]??1)>.18;
const median=arr=>{const v=arr.filter(finite).sort((a,b)=>a-b);return v.length?v[Math.floor(v.length/2)]:null;};
const CORE=[11,12,13,14,15,16,23,24,25,26,27,28],TORSO=[11,12,23,24],FEET=[27,28,29,30,31,32];
function checkMask(frame){
 const mask=frame?.surface?.silhouette;if(!mask?.b64||!(mask.w>=32&&mask.h>=32))return {available:false,fit:null,coverage:null};
 const pose=frame.render_im||frame.im||[];
 // Core torso and endpoints must project onto observed athlete; visible shoes at the boundary
 // are sometimes just outside a low-resolution mask and are therefore reported separately.
 let valid=0,inside=0,feetValid=0,feetInside=0;
 for(const id of CORE){const p=pose[id];if(!joint(p))continue;valid++;if(pointInAthleteSilhouette(mask,p[0],p[1]))inside++;}
 for(const id of FEET){const p=pose[id];if(!joint(p))continue;feetValid++;if(pointInAthleteSilhouette(mask,p[0],p[1]))feetInside++;}
 return {available:true,fit:valid>=5?inside/valid:null,foot_fit:feetValid>=2?feetInside/feetValid:null,coverage:mask.coverage??null,resolution:[mask.w,mask.h]};
}
function frameAudit(f,previous){
 const im=f?.render_im||f?.im||[],world=f?.render_w||f?.w||[],mask=checkMask(f);
 const core=CORE.filter(i=>joint(im[i])).length/CORE.length;
 const torso=TORSO.filter(i=>joint(im[i])).length/TORSO.length;
 const depth=CORE.filter(i=>joint(world[i],3)).length/CORE.length;
 const feet=FEET.filter(i=>joint(im[i])).length/FEET.length;
 const sourceConfidence=CORE.reduce((sum,i)=>sum+clamp(im[i]?.[3]??0),0)/CORE.length;
 let velocity=null;
 if(previous&&Number(f.t)>Number(previous.t)&&Number(f.t)-Number(previous.t)<.55&&f.camera_segment_id===previous.camera_segment_id){
  const p=im[23],q=previous.render_im?.[23]||previous.im?.[23];
  if(joint(p)&&joint(q))velocity=Math.hypot(p[0]-q[0],p[1]-q[1])/(f.t-previous.t);
 }
 const motionValid=velocity==null||velocity<9;
 const overlap=mask.fit===null?0:clamp(mask.fit);
 // No mask = max 0.56; no 3D = max 0.65. A good pose alone is NOT a 3D scan.
 const evidence=clamp(.22*core+.14*torso+.19*depth+.12*feet+.15*sourceConfidence+.18*overlap);
 const score=motionValid?evidence:evidence*.55;
 const reasons=[];
 if(!mask.available)reasons.push('missing_person_mask');
 if(mask.available&&mask.fit!==null&&mask.fit<.58)reasons.push('pose_mask_mismatch');
 if(depth<.65)reasons.push('insufficient_world_track');
 if(feet<.5)reasons.push('uncertain_feet');
 if(!motionValid)reasons.push('implausible_root_jump');
 if(!joint(im[23])||!joint(im[24]))reasons.push('missing_hip_anchor');
 const status=!mask.available||score<.47||torso<.5||depth<.45||!motionValid?'reject':score<.72||overlap<.7?'review':'usable';
 return {score:Number(score.toFixed(3)),status,mask_available:mask.available,pose_mask_agreement:mask.fit,foot_mask_agreement:mask.foot_fit,source_confidence:Number(sourceConfidence.toFixed(3)),depth_coverage:Number(depth.toFixed(3)),foot_coverage:Number(feet.toFixed(3)),reasons};
}
export function auditReconstructedTrack(frames,{minUsableFraction=.70}={}){
 if(!Array.isArray(frames)||!frames.length)return {schema:MOTION_RECONSTRUCTION_QA_VERSION,available:false,reason:'no_frames',trainable:false,frames:0};
 let usable=0,review=0,rejected=0,hasMasks=0,world=0;const scores=[],reasons={};
 for(let i=0;i<frames.length;i++){
  const f=frames[i],qa=frameAudit(f,frames[i-1]);f.reconstruction_quality=qa;
  scores.push(qa.score);if(qa.status==='usable')usable++;else if(qa.status==='review')review++;else rejected++;
  if(qa.mask_available)hasMasks++;if(qa.depth_coverage>=.65)world++;
  for(const reason of qa.reasons)reasons[reason]=(reasons[reason]||0)+1;
 }
 const count=frames.length,usableFraction=usable/count,maskFraction=hasMasks/count,worldFraction=world/count;
 const trainable=usableFraction>=minUsableFraction&&maskFraction>=.8&&worldFraction>=.75;
 return {schema:MOTION_RECONSTRUCTION_QA_VERSION,available:true,frames:count,usable,review,rejected,usable_fraction:Number(usableFraction.toFixed(4)),mask_fraction:Number(maskFraction.toFixed(4)),world_fraction:Number(worldFraction.toFixed(4)),median_evidence_score:median(scores),trainable,training_policy:'only usable, observed 3D plus mask evidence; reject and review never silently promoted',metric_accuracy_verified:false,issues:Object.entries(reasons).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([code,count])=>({code,count})),limitations:['A compatible mask is not proof of surface accuracy','Depth from one RGB camera is relative and ambiguously scaled','This gate cannot certify unseen geometry']};
}
export function qualityOfRange(frames,start,end,{minFraction=.72,minFrames=5}={}){
 const relevant=(frames||[]).filter(f=>f.t>=start&&f.t<=end);
 if(relevant.length<minFrames)return {allowed:false,reason:'Недостаточно проверенных кадров',total:relevant.length};
 const missing=relevant.some(f=>!f.reconstruction_quality),ok=relevant.filter(f=>f.reconstruction_quality?.status==='usable').length;
 const fraction=ok/relevant.length;
 return {allowed:!missing&&fraction>=minFraction,usable:ok,total:relevant.length,fraction,reason:missing?'Отсутствует проверка геометрии':fraction<minFraction?'Недостаточная надёжность маски и 3D в выбранном фрагменте':null};
}
