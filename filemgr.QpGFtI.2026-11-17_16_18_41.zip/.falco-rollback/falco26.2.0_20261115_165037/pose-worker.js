import {packAthleteSilhouette} from './athlete-silhouette-core.mjs?v=23.0.27';
/*
 * Pose/hand inference worker for Kata Biomechanics Analyzer.
 * Runs MediaPipe synchronously off the UI thread. Every decoded source sample gets an
 * timestamped VIDEO-mode inference preserves temporal tracking while every decoded sample remains
 * represented in the output, including samples with partial or missing landmarks.
 */
let FilesetResolver = null;
let PoseLandmarker = null;
let HandLandmarker = null;
let poseTask = null;
let handTask = null;
let delegateName = 'unknown';
let assetSource = 'unknown';
let handError = null;
let segmentationEnabled = false;
let busy = false;
let lastPoseTimestamp = -1;
let lastHandTimestamp = -1;
let surfaceCanvas = null, surfaceContext = null;

function errText(error) {
  if (!error) return 'Unknown worker error';
  return `${error.name ? `${error.name}: ` : ''}${error.message || String(error)}`.slice(0, 500);
}
function uaIsIOSWebKit() {
  const ua = self.navigator?.userAgent || '';
  const mobileApple = /iPad|iPhone|iPod/i.test(ua) || (self.navigator?.platform === 'MacIntel' && Number(self.navigator?.maxTouchPoints || 0) > 1);
  return mobileApple && /AppleWebKit/i.test(ua);
}

async function init(config) {
  if (poseTask) return readyInfo();
  const importCandidates = [];
  if (config.remoteFirst) { importCandidates.push({ url: config.cdnBundleUrl, source: 'CDN jsDelivr' }, { url: config.unpkgBundleUrl, source: 'CDN unpkg' }); if (config.localAssets?.bundle) importCandidates.push({ url: config.localBundleUrl, source: 'локальный резерв' }); }
  else { if (config.localAssets?.bundle) importCandidates.push({ url: config.localBundleUrl, source: 'локальная библиотека' }); importCandidates.push({ url: config.cdnBundleUrl, source: 'CDN jsDelivr' }, { url: config.unpkgBundleUrl, source: 'CDN unpkg' }); }
  const failures = [];
  let api = null;
  for (const candidate of importCandidates) {
    try {
      api = await import(candidate.url);
      if (!api?.FilesetResolver || !api?.PoseLandmarker) throw new Error('PoseLandmarker/FilesetResolver отсутствует в модуле');
      FilesetResolver = api.FilesetResolver;
      PoseLandmarker = api.PoseLandmarker;
      HandLandmarker = api.HandLandmarker || null;
      assetSource = candidate.source;
      break;
    } catch (error) {
      failures.push(`${candidate.source}: ${errText(error)}`);
    }
  }
  if (!FilesetResolver || !PoseLandmarker) throw new Error(`Worker не загрузил MediaPipe. ${failures.slice(-2).join(' | ')}`);

  const wasmCandidates = [];
  if (config.remoteFirst) { wasmCandidates.push({ url: config.cdnWasmUrl, source: 'WASM jsDelivr' }, { url: config.unpkgWasmUrl, source: 'WASM unpkg' }); if (config.localAssets?.wasm) wasmCandidates.push({ url: config.localWasmUrl, source: 'локальный резерв WASM' }); }
  else { if (config.localAssets?.wasm) wasmCandidates.push({ url: config.localWasmUrl, source: 'локальный WASM' }); wasmCandidates.push({ url: config.cdnWasmUrl, source: 'WASM jsDelivr' }, { url: config.unpkgWasmUrl, source: 'WASM unpkg' }); }
  let vision = null;
  const wasmFailures = [];
  for (const candidate of wasmCandidates) {
    try {
      // The ESM package ships a module factory alongside the legacy UMD loader.
      // Select the module variant so module Workers do not fail with “ModuleFactory not set”.
      vision = await FilesetResolver.forVisionTasks(candidate.url, true);
      assetSource = `${assetSource} + ${candidate.source}`;
      break;
    } catch (error) { wasmFailures.push(`${candidate.source}: ${errText(error)}`); }
  }
  if (!vision) throw new Error(`Worker не смог загрузить WebAssembly. ${wasmFailures.slice(-2).join(' | ')}`);

  const preferCpu = config.preferCpu === true || uaIsIOSWebKit();
  const poseModels = [];
  // Prefer Full on desktop and Lite on iOS/WebKit. Within each model tier, use
  // network first by default and installed local assets only as a failure fallback.
  if (!preferCpu) {
    if (config.remoteFirst) { poseModels.push({ url: config.remoteFullModelUrl, source: 'Google Storage Pose Full' }); if (config.localAssets?.poseFullModel) poseModels.push({ url: config.localFullModelUrl, source: 'локальная Pose Full' }); poseModels.push({ url: config.remoteModelUrl, source: 'Google Storage Pose Lite' }); if (config.localAssets?.poseModel) poseModels.push({ url: config.localModelUrl, source: 'локальная Pose Lite' }); }
    else { if (config.localAssets?.poseFullModel) poseModels.push({ url: config.localFullModelUrl, source: 'локальная Pose Full' }); poseModels.push({ url: config.remoteFullModelUrl, source: 'Google Storage Pose Full' }); if (config.localAssets?.poseModel) poseModels.push({ url: config.localModelUrl, source: 'локальная Pose Lite' }); poseModels.push({ url: config.remoteModelUrl, source: 'Google Storage Pose Lite' }); }
  } else {
    if (config.remoteFirst) { poseModels.push({ url: config.remoteModelUrl, source: 'Google Storage Pose Lite' }); if (config.localAssets?.poseModel) poseModels.push({ url: config.localModelUrl, source: 'локальная Pose Lite' }); poseModels.push({ url: config.remoteFullModelUrl, source: 'Google Storage Pose Full' }); if (config.localAssets?.poseFullModel) poseModels.push({ url: config.localFullModelUrl, source: 'локальная Pose Full' }); }
    else { if (config.localAssets?.poseModel) poseModels.push({ url: config.localModelUrl, source: 'локальная Pose Lite' }); poseModels.push({ url: config.remoteModelUrl, source: 'Google Storage Pose Lite' }); if (config.localAssets?.poseFullModel) poseModels.push({ url: config.localFullModelUrl, source: 'локальная Pose Full' }); poseModels.push({ url: config.remoteFullModelUrl, source: 'Google Storage Pose Full' }); }
  }
  const poseErrors = [];
  let poseReady = false;
  for (const model of poseModels) {
    for (const delegate of (preferCpu ? ['CPU'] : ['GPU', 'CPU'])) {
      try {
        const baseOptions = { modelAssetPath: model.url };
        if (delegate === 'GPU') baseOptions.delegate = 'GPU';
        poseTask = await PoseLandmarker.createFromOptions(vision, {
          baseOptions,
          runningMode: 'VIDEO',
          numPoses: 1,
          minPoseDetectionConfidence: 0.20,
          minPosePresenceConfidence: 0.20,
          minTrackingConfidence: 0.20,
          outputSegmentationMasks: config.outputSegmentationMasks === true
        });
        delegateName = delegate;
        assetSource = `${assetSource} + ${model.source}`;
        poseReady = true;
        break;
      } catch (error) {
        poseErrors.push(`${model.source}/${delegate}: ${errText(error)}`);
      }
    }
    if (poseReady) break;
  }
  if (!poseReady) throw new Error(`Не удалось создать Pose Landmarker в worker. ${poseErrors.slice(-3).join(' | ')}`);

  // Hand model is an enhancement, not a prerequisite for pose analysis.
  handError = null;
  if (config.enableHands !== false && HandLandmarker) {
    const handModels = config.remoteFirst
      ? [{ url: config.remoteHandModelUrl, source: 'Google Storage hand-модель' }, ...(config.localAssets?.handModel ? [{ url: config.localHandModelUrl, source: 'локальный резерв hand-модели' }] : [])]
      : [...(config.localAssets?.handModel ? [{ url: config.localHandModelUrl, source: 'локальная hand-модель' }] : []), { url: config.remoteHandModelUrl, source: 'Google Storage hand-модель' }];
    const handErrors = [];
    for (const model of handModels) {
      let created = false;
      for (const delegate of (preferCpu ? ['CPU'] : ['GPU', 'CPU'])) {
        try {
          const baseOptions = { modelAssetPath: model.url };
          if (delegate === 'GPU') baseOptions.delegate = 'GPU';
          handTask = await HandLandmarker.createFromOptions(vision, {
            baseOptions,
            runningMode: 'VIDEO',
            numHands: 2,
            minHandDetectionConfidence: 0.25,
            minHandPresenceConfidence: 0.25,
            minTrackingConfidence: 0.25
          });
          assetSource = `${assetSource} + ${model.source}`;
          created = true;
          break;
        } catch (error) { handErrors.push(`${model.source}/${delegate}: ${errText(error)}`); }
      }
      if (created) break;
    }
    if (!handTask) handError = handErrors.slice(-2).join(' | ') || 'Hand Landmarker недоступен';
  } else {
    handError = 'Hand Landmarker отсутствует в библиотеке; 21-точечная детализация пальцев отключена, но landmarks кисти/запястья из Pose Landmarker остаются доступны.';
  }
  segmentationEnabled = config.outputSegmentationMasks === true;
  return readyInfo();
}
function readyInfo() {
  return { delegate: delegateName, assetSource, handAvailable: !!handTask, handError, segmentationAvailable: segmentationEnabled };
}
function classifyHand(lm) {
  const xy = i => lm[i] && Number.isFinite(lm[i][0]) && Number.isFinite(lm[i][1]) ? { x: lm[i][0], y: lm[i][1] } : null;
  const distance = (a, b) => a && b ? Math.hypot(a.x - b.x, a.y - b.y) : 0;
  const wrist = xy(0);
  if (!wrist) return { shape: 'unknown', shape_ru: 'не определено', confidence: 0.2, extended_fingers: 0 };
  const fingers = [{ tip: 8, pip: 6, mcp: 5 }, { tip: 12, pip: 10, mcp: 9 }, { tip: 16, pip: 14, mcp: 13 }, { tip: 20, pip: 18, mcp: 17 }];
  const checks = fingers.map(f => {
    const tip = xy(f.tip), pip = xy(f.pip), mcp = xy(f.mcp);
    if (!tip || !pip || !mcp) return null;
    return distance(tip, wrist) > distance(pip, wrist) * 1.06 && distance(tip, wrist) > distance(mcp, wrist) * 1.38;
  });
  const known = checks.filter(v => v !== null), extended = checks.filter(v => v === true).length;
  if (known.length < 3) return { shape: 'unknown', shape_ru: 'не определено', confidence: 0.25, extended_fingers: extended };
  const thumb = xy(4), index = xy(5), pinky = xy(17);
  const palmWidth = distance(index, pinky) || 0.001, thumbGap = distance(thumb, index);
  const thumbOpen = thumbGap > palmWidth * 0.48;
  let shape = 'partially_closed', shape_ru = 'частично сжата', confidence = 0.55;
  if (extended >= 3) { shape = 'open_palm'; shape_ru = 'открытая ладонь'; confidence = 0.72 + 0.07 * (extended - 3) + (thumbOpen ? 0.05 : 0); }
  else if (extended <= 1) { shape = 'fist'; shape_ru = 'кулак'; confidence = 0.70 + 0.08 * (1 - extended); }
  else if (extended === 2 && thumbOpen) { shape = 'partially_open'; shape_ru = 'частично открыта'; confidence = 0.60; }
  return { shape, shape_ru, confidence: Math.max(0, Math.min(0.95, confidence)), extended_fingers: extended, thumb_open: thumbOpen };
}
function handPayload(result, poseLandmarks) {
  const out = [];
  for (let i = 0; i < (result?.landmarks || []).length; i++) {
    const lm = result.landmarks[i].map(p => [p.x, p.y, p.z ?? 0, 1]);
    const wrist = lm[0], pwL = poseLandmarks?.[15], pwR = poseLandmarks?.[16];
    const dL = pwL ? Math.hypot(wrist[0] - pwL.x, wrist[1] - pwL.y) : Infinity;
    const dR = pwR ? Math.hypot(wrist[0] - pwR.x, wrist[1] - pwR.y) : Infinity;
    const near = Math.min(dL, dR), pose_side = near <= 0.32 && Math.abs(dL - dR) >= 0.012 ? (dL <= dR ? 'left' : 'right') : null;
    const cat = result?.handedness?.[i]?.[0] || result?.handednesses?.[i]?.[0] || {};
    const handedness_label = cat.displayName || cat.categoryName || cat.label || 'unknown';
    const world = (result?.worldLandmarks?.[i] || []).map(p => [p.x, p.y, p.z ?? 0, 1]);
    out.push({ pose_side, handedness_label, landmarks: lm, world_landmarks: world, ...classifyHand(lm) });
  }
  return out;
}

function summarizeSurfaceFromMask(bitmap, mask, landmarks) {
  if (!segmentationEnabled || !mask || !landmarks || typeof OffscreenCanvas === 'undefined') return null;
  try {
    const mw = Number(mask.width), mh = Number(mask.height), data = mask.getAsFloat32Array?.();
    if (!(mw > 0 && mh > 0) || !data?.length) return null;
    const W = 96, H = Math.max(48, Math.min(108, Math.round(W * Number(bitmap.displayHeight || bitmap.height || 1) / Math.max(1, Number(bitmap.displayWidth || bitmap.width || 1)))));
    if (!surfaceCanvas || surfaceCanvas.width !== W || surfaceCanvas.height !== H) { surfaceCanvas = new OffscreenCanvas(W, H); surfaceContext = surfaceCanvas.getContext('2d', { willReadFrequently: true, alpha: false }); }
    const ctx = surfaceContext;
    if (!ctx) return null;
    ctx.drawImage(bitmap, 0, 0, W, H);
    const pixels = ctx.getImageData(0, 0, W, H).data;
    const zones = {
      torso: [[11,12],[23,24]], left_sleeve: [[11,13],[13,15]], right_sleeve: [[12,14],[14,16]],
      left_trouser: [[23,25],[25,27]], right_trouser: [[24,26],[26,28]]
    };
    const zoneCoverage = {}, colours = [], zoneRgb = {};
    for (const [name, segments] of Object.entries(zones)) {
      let hit = 0, total = 0, r = 0, g = 0, b = 0;
      for (const [a, z] of segments) {
        const A = landmarks[a], B = landmarks[z];
        if (!A || !B || !Number.isFinite(A.x) || !Number.isFinite(A.y) || !Number.isFinite(B.x) || !Number.isFinite(B.y)) continue;
        for (const u of [.25,.5,.75]) {
          const x = Math.max(0,Math.min(W-1,Math.round((A.x+(B.x-A.x)*u)*W)));
          const y = Math.max(0,Math.min(H-1,Math.round((A.y+(B.y-A.y)*u)*H)));
          for (let dy=-1;dy<=1;dy++) for (let dx=-1;dx<=1;dx++) {
            const xx=Math.max(0,Math.min(W-1,x+dx)), yy=Math.max(0,Math.min(H-1,y+dy));
            const mi=Math.min(mh-1,Math.floor(yy/H*mh))*mw+Math.min(mw-1,Math.floor(xx/W*mw));
            total++; if (Number(data[mi]??0)<.55) continue;
            const pi=(yy*W+xx)*4; r+=pixels[pi]; g+=pixels[pi+1]; b+=pixels[pi+2]; hit++;
          }
        }
      }
      zoneCoverage[name]=total?hit/total:0;
      if(hit){const meanColour=[r/hit,g/hit,b/hit];colours.push(meanColour);zoneRgb[name]=meanColour.map(x=>Number(x.toFixed(1)));}
    }
    if (!colours.length) return null;
    const coverage=Object.values(zoneCoverage).reduce((a,b)=>a+b,0)/Object.keys(zoneCoverage).length;
    const avg=colours.reduce((a,c)=>a.map((v,i)=>v+c[i]/colours.length),[0,0,0]);
    const dispersion=colours.reduce((a,c)=>a+Math.hypot(c[0]-avg[0],c[1]-avg[1],c[2]-avg[2])/colours.length,0);
    const brightness=(avg[0]+avg[1]+avg[2])/3, uniformity=Math.max(0,Math.min(1,1-dispersion/220));
    const clothingZones=['torso','left_sleeve','right_sleeve'].filter(k=>Number.isFinite(zoneCoverage[k]));
    const clothingCoverage=clothingZones.length?clothingZones.reduce((sum,k)=>sum+zoneCoverage[k],0)/clothingZones.length:0;
    const textileColours=clothingZones.map(k=>zoneRgb[k]).filter(Boolean);
    const textileCenter=textileColours.length?textileColours.reduce((a,c)=>a.map((v,i)=>v+c[i]/textileColours.length),[0,0,0]):null;
    const textileDispersion=textileCenter&&textileColours.length>1?textileColours.reduce((sum,c)=>sum+Math.hypot(c[0]-textileCenter[0],c[1]-textileCenter[1],c[2]-textileCenter[2]),0)/textileColours.length:220;
    const clothingSurfaceConfidence=textileColours.length>=2?Math.max(0,Math.min(1,clothingCoverage*.55+(1-textileDispersion/220)*.45)):null;
    // Measure segmentation-mask thickness around the anatomical centerlines. This is a
    // garment-envelope cue (loose sleeves/trousers), not a classifier of garment identity.
    const midpoint=(a,b)=>landmarks[a]&&landmarks[b]?{x:(landmarks[a].x+landmarks[b].x)/2,y:(landmarks[a].y+landmarks[b].y)/2}:null;
    const widthPaths={
      torso:[[midpoint(11,12),midpoint(23,24)]],
      left_sleeve:[[landmarks[11],landmarks[13]],[landmarks[13],landmarks[15]]],right_sleeve:[[landmarks[12],landmarks[14]],[landmarks[14],landmarks[16]]],
      left_trouser:[[landmarks[23],landmarks[25]],[landmarks[25],landmarks[27]]],right_trouser:[[landmarks[24],landmarks[26]],[landmarks[26],landmarks[28]]]
    };
    const shoulderWidth=landmarks[11]&&landmarks[12]?Math.hypot((landmarks[12].x-landmarks[11].x)*W,(landmarks[12].y-landmarks[11].y)*H):0;
    const zoneWidthRatio={},zoneWidthConfidence={},zoneWidthProfile={};
    const profileStations=[.30,.47,.64,.80];
    for(const [name,segments] of Object.entries(widthPaths)){
      const widths=[],confidences=[],segmentProfiles=[];
      for(const [A,B] of segments){
        const stationProfile=[];
        if(!A||!B||![A.x,A.y,B.x,B.y].every(Number.isFinite)){segmentProfiles.push(profileStations.map(()=>[0,0]));continue;}
        const ax=A.x*W,ay=A.y*H,bx=B.x*W,by=B.y*H,dx=bx-ax,dy=by-ay,len=Math.hypot(dx,dy);
        if(len<4){segmentProfiles.push(profileStations.map(()=>[0,0]));continue;}
        const nx=-dy/len,ny=dx/len;
        for(const u of profileStations){
          const cx=ax+dx*u,cy=ay+dy*u;let lo=Infinity,hi=-Infinity,hits=0,centerHit=false;
          const reach=Math.min(25,Math.max(6,Math.round(shoulderWidth*(name==='torso'?.62:.25))));
          for(let off=-reach;off<=reach;off++){
            const x=Math.round(cx+nx*off),y=Math.round(cy+ny*off);if(x<0||y<0||x>=W||y>=H)continue;
            const mi=Math.min(mh-1,Math.floor(y/H*mh))*mw+Math.min(mw-1,Math.floor(x/W*mw));
            if(Number(data[mi]??0)>=.55){lo=Math.min(lo,off);hi=Math.max(hi,off);hits++;if(Math.abs(off)<=1)centerHit=true;}
          }
          if(hits>=2&&Number.isFinite(lo)&&Number.isFinite(hi)&&shoulderWidth>2){
            const width=hi-lo+1,ratio=width/shoulderWidth,confidence=Math.min(1,hits/(reach*.9))*(centerHit?1:.55);
            widths.push(width);confidences.push(confidence);stationProfile.push([Number(ratio.toFixed(4)),Number(confidence.toFixed(3))]);
          }else stationProfile.push([0,0]);
        }
        segmentProfiles.push(stationProfile);
      }
      zoneWidthProfile[name]=segmentProfiles;
      if(widths.length>=2&&shoulderWidth>2){zoneWidthRatio[name]=Number((widths.reduce((a,b)=>a+b,0)/widths.length/shoulderWidth).toFixed(3));zoneWidthConfidence[name]=Number((confidences.reduce((a,b)=>a+b,0)/confidences.length*Math.min(1,widths.length/3)).toFixed(3));}
    }
    const surfaceHint=coverage>.28&&uniformity>.72?(brightness>165?'light_uniform_surface':brightness<85?'dark_uniform_surface':'uniform_surface'):'mixed_or_uncertain_surface';
    return {mask_available:true,mask_coverage:Number(coverage.toFixed(3)),uniformity:Number(uniformity.toFixed(3)),tone:brightness>165?'light':brightness<85?'dark':'mixed',surface_hint:surfaceHint,clothing_surface_confidence:Number.isFinite(clothingSurfaceConfidence)?Number(clothingSurfaceConfidence.toFixed(3)):null,uniform_clothing_candidate:Number.isFinite(clothingSurfaceConfidence)?clothingSurfaceConfidence>=.58:null,zone_rgb:zoneRgb,zone_coverage:Object.fromEntries(Object.entries(zoneCoverage).map(([k,v])=>[k,Number(v.toFixed(3))])),zone_width_ratio:zoneWidthRatio,zone_width_confidence:zoneWidthConfidence,zone_width_profile:zoneWidthProfile,body_surface_profile_version:'falco-personalized-silhouette-surface-v1',garment_geometry_hint:'segmentation-mask centerline thickness relative to shoulder width; not a kimono classifier'};
  } catch (_) { return null; }
}

function packLandmarks(points) {
  return points?.map(p => [p.x, p.y, p.z ?? 0, p.visibility ?? p.presence ?? 1]) || null;
}
async function processFrame(bitmap, timestamp) {
  if (!poseTask) throw new Error('Pose worker не инициализирован');
  if (busy) throw new Error('Нарушен порядок очереди кадров в pose worker');
  busy = true;
  try {
    // VIDEO mode uses the source-timestamp sequence for temporal tracking. The caller decodes
    // every source sample in presentation order and supplies monotonically increasing ms stamps.
    const sourceTs = Number.isFinite(Number(timestamp)) ? Number(timestamp) : 0;
    const poseTs = Math.max(sourceTs, lastPoseTimestamp + 1);
    lastPoseTimestamp = poseTs;
    const result = poseTask.detectForVideo(bitmap, poseTs);
    const landmarks = result.landmarks?.[0] || null;
    const world = result.worldLandmarks?.[0] || null;
    const segmentationMask = result.segmentationMasks?.[0];
    const surface = summarizeSurfaceFromMask(bitmap, segmentationMask, landmarks);
    if(surface&&segmentationMask)surface.silhouette=packAthleteSilhouette(segmentationMask,landmarks,{width:192,height:192});
    try { segmentationMask?.close?.(); } catch (_) {}
    let hands = [];
    if (handTask) {
      try { const handTs = Math.max(sourceTs, lastHandTimestamp + 1); lastHandTimestamp = handTs; hands = handPayload(handTask.detectForVideo(bitmap, handTs), landmarks); }
      catch (error) {
        handError = errText(error);
        try { handTask.close(); } catch (_) {}
        handTask = null;
        self.postMessage({ type: 'status', message: `Дополнительное распознавание кистей отключено: ${handError}` });
      }
    }
    return { im: packLandmarks(landmarks) || Array.from({ length: 33 }, () => [NaN, NaN, NaN, 0]), w: packLandmarks(world), hands, surface };
  } finally {
    busy = false;
    try { bitmap.close(); } catch (_) {}
  }
}

self.onmessage = async event => {
  const message = event.data || {};
  const { id, type } = message;
  try {
    if (type === 'init') {
      const info = await init(message.config || {});
      self.postMessage({ id, type: 'result', result: info });
    } else if (type === 'frame') {
      const result = await processFrame(message.bitmap, message.timestamp);
      self.postMessage({ id, type: 'result', result });
    } else if (type === 'close') {
      try { poseTask?.close(); } catch (_) {}
      try { handTask?.close(); } catch (_) {}
      poseTask = null; handTask = null; lastPoseTimestamp = -1; lastHandTimestamp = -1; surfaceCanvas = null; surfaceContext = null;
      self.postMessage({ id, type: 'result', result: true });
    } else {
      throw new Error(`Неизвестная команда worker: ${String(type)}`);
    }
  } catch (error) {
    try { message.bitmap?.close(); } catch (_) {}
    self.postMessage({ id, type: 'error', error: errText(error) });
  }
};
