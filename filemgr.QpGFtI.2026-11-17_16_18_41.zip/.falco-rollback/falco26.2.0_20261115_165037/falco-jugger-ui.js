/* Falco Jugger 26.0.1 | Flight Deck Handler Recovery. One UI controller, no runtime workspace reconstruction.
 * All analysis, learning, player event handlers and API contracts remain in index.php.
 * This controller moves the EXISTING media nodes once; does not clone IDs or create players.
 */
(()=>{
'use strict';
const d=document,$=id=>d.getElementById(id),body=d.body,root=d.documentElement;
const ready=fn=>d.readyState==='loading'?d.addEventListener('DOMContentLoaded',fn,{once:true}):fn();
function setup(){
  const rail=$('fjSideRail'),scrim=$('fjNavScrim'),menu=$('fjNavToggle');
  const closeNav=()=>{body.classList.remove('fj-nav-open');if(menu)menu.setAttribute('aria-expanded','false');if(scrim)scrim.hidden=true;};
  const openNav=()=>{body.classList.add('fj-nav-open');if(menu)menu.setAttribute('aria-expanded','true');if(scrim)scrim.hidden=false;rail?.querySelector('a')?.focus({preventScroll:true});};
  menu?.addEventListener('click',()=>body.classList.contains('fj-nav-open')?closeNav():openNav());
  scrim?.addEventListener('click',closeNav);
  rail?.querySelectorAll('a').forEach(link=>link.addEventListener('click',closeNav));
  window.addEventListener('resize',()=>{if(window.innerWidth>=1180)closeNav();},{passive:true});
  // One theme source of truth: attribute, CSS variables and persistent explicit preference.
  const themeButton=$('themeToggle');
  function setTheme(theme){
    const next=theme==='light'?'light':'dark';root.dataset.theme=next;
    if(themeButton){themeButton.textContent=next==='light'?'☾ Тёмная тема':'☼ Светлая тема';themeButton.setAttribute('aria-pressed',String(next==='light'));}
    const meta=d.querySelector('meta[name="color-scheme"]');if(meta)meta.content=next;
    try{localStorage.setItem('falco-jugger-theme-v1',next);}catch(_){ }
  }
  let previous;try{previous=localStorage.getItem('falco-jugger-theme-v1');}catch(_){ }
  setTheme(previous==='dark'?'dark':'light');
  // The analyzer module owns its theme button: two listeners would toggle back to the old state.
  if(!body.matches('[data-mode="analyzer"],[data-mode="purcell"]')) themeButton?.addEventListener('click',()=>setTheme(root.dataset.theme==='dark'?'light':'dark'));

  // Static grid is server-rendered: hydrate only existing DOM nodes, no generated wrappers.
  const stage=$('videoStage'),video=$('video'),three=$('pose3dCanvas')?.closest('section.panel'),metrics=$('currentPanel');
  const videoMount=$('fjVideoMount'),threeMount=$('fjThreeMount'),metricMount=$('playerMetricsScroll');
  if(stage&&videoMount){if(stage.parentElement!==videoMount)videoMount.replaceChildren(stage);stage.classList.add('docked-video-stage');}
  if(three&&threeMount){if(three.parentElement!==threeMount)threeMount.replaceChildren(three);three.classList.add('docked-three-panel');}
  if(metrics&&metricMount&&metrics.parentElement!==metricMount)metricMount.append(metrics);
  if(videoMount&&stage)videoMount.classList.add('fj-video-ready');

  // Keep navigation strictly local. The document scrolls; the player is sticky.
  const anchorLinks=[...d.querySelectorAll('.fj-session-nav a[href^="#"]')];
  const active=link=>anchorLinks.forEach(a=>{const selected=a===link;a.classList.toggle('is-active',selected);if(selected)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');});
  anchorLinks.forEach(link=>link.addEventListener('click',e=>{
    const target=d.getElementById(link.hash.slice(1));
    if(!target||target.closest('[hidden], .hidden')||target.hidden){e.preventDefault();const start=$('dropZone');start?.scrollIntoView({behavior:'smooth',block:'start'});return;}
    active(link);
  }));
  if('IntersectionObserver' in window){
    const els=anchorLinks.map(link=>({link,target:d.getElementById(link.hash.slice(1))})).filter(x=>x.target);
    const observer=new IntersectionObserver(entries=>{
      const hit=entries.filter(x=>x.isIntersecting).sort((a,b)=>b.intersectionRatio-a.intersectionRatio)[0];
      const row=els.find(x=>x.target===hit?.target);if(row)active(row.link);
    },{rootMargin:'-8% 0px -70% 0px',threshold:[0,.05,.2]});
    els.forEach(x=>observer.observe(x.target));
  }
  const page=location.pathname.split('/').pop()||'index.php';
  const pages={'uppurcell.php':'purcell-training','lully.php':'lully','purcell-lab.php':'purcell-library','models.php':'models','Memories.php':'reports'};
  rail?.querySelectorAll('[data-fj-page]').forEach(a=>{const selected=a.dataset.fjPage===pages[page];a.classList.toggle('is-page-active',selected);if(selected)a.setAttribute('aria-current','page');});

  // No journal in main flow. All errors remain in underlying IndexedDB / state; draw recent only.
  const drawer=$('fjJournalDrawer'),journalMount=$('fjJournalMount'),journal=$('appJournalPanel'),journalOpen=$('fjJournalOpen'),journalClose=$('fjJournalClose'),journalScrim=$('fjJournalScrim');
  if(journalMount&&journal){journalMount.append(journal);journal.hidden=false;}
  let journalReturnFocus=null;
  const closeJournal=()=>{if(drawer)drawer.hidden=true;if(journalScrim)journalScrim.hidden=true;body.classList.remove('fj-journal-open');journalOpen?.setAttribute('aria-expanded','false');journalReturnFocus?.focus({preventScroll:true});};
  const openJournal=()=>{if(!drawer)return;journalReturnFocus=d.activeElement;if(journalScrim)journalScrim.hidden=false;drawer.hidden=false;body.classList.add('fj-journal-open');journalOpen?.setAttribute('aria-expanded','true');journalClose?.focus({preventScroll:true});};
  journalOpen?.addEventListener('click',openJournal);journalClose?.addEventListener('click',closeJournal);journalScrim?.addEventListener('click',closeJournal);
  d.addEventListener('keydown',e=>{if(e.key==='Escape'){if(body.classList.contains('fj-journal-open'))closeJournal();else if(body.classList.contains('fj-nav-open'))closeNav();else if(body.classList.contains('fj-player-expanded'))setPlayerExpanded(false);}});

  // 3D is one general player mode; underlying analyzer controls actual renderer.
  const toggle3d=$('aeroToggle3d'),original3d=$('player3dPlayback'),open3d=$('player3dOpen'),pane3=d.querySelector('#analysisDock .player-pane-3d');
  function sync3d(){
    const enabled=!!original3d?.checked&&!original3d?.disabled;
    const available=!original3d?.disabled||!open3d?.disabled;
    if(toggle3d){toggle3d.disabled=!available;toggle3d.textContent=enabled?'3D включён':'3D по запросу';toggle3d.setAttribute('aria-pressed',String(enabled));}
    pane3?.classList.toggle('is-open',enabled);
    $('analysisDock')?.classList.toggle('fj-3d-active',enabled);
  }
  toggle3d?.addEventListener('click',()=>{
    if(original3d?.checked){original3d.checked=false;original3d.dispatchEvent(new Event('change',{bubbles:true}));}
    else if(open3d&&!open3d.disabled)open3d.click();
    requestAnimationFrame(sync3d);
  });
  original3d?.addEventListener('change',sync3d);open3d?.addEventListener('click',()=>requestAnimationFrame(sync3d));
  if(original3d)new MutationObserver(sync3d).observe(original3d,{attributes:true,attributeFilter:['disabled','checked']});
  if(open3d)new MutationObserver(sync3d).observe(open3d,{attributes:true,attributeFilter:['disabled']});
  sync3d();

  const dock=$('analysisDock'),expand=$('fjMobilePlayerOpen'),time=$('fjMiniTime');
  function setPlayerExpanded(open){
    const next=!!open&&window.innerWidth<1180;
    body.classList.toggle('fj-player-expanded',next);
    expand?.setAttribute('aria-expanded',String(next));
    if(dock)dock.setAttribute('aria-label',next?'Развёрнутый видеоплеер':'Видеосессия');
  }
  expand?.addEventListener('click',()=>setPlayerExpanded(!body.classList.contains('fj-player-expanded')));
  window.addEventListener('resize',()=>{if(window.innerWidth>=1180)setPlayerExpanded(false);},{passive:true});
  video?.addEventListener('timeupdate',()=>{if(time){let sec=Number(video.currentTime)||0;time.textContent=`${String(Math.floor(sec/60)).padStart(2,'0')}:${String(Math.floor(sec%60)).padStart(2,'0')}`;}});
  // Preserve the native video component and native range editor. Do not re-create either.
  const clipOpen=$('openClipEditor'),clip=$('rangeControls');
  clipOpen?.addEventListener('click',()=>{if(clip){clip.classList.remove('hidden');clip.hidden=false;}},{passive:true});
  // Recovery 26.0.1: restore the non-destructive interaction helpers removed with the 24.3 controller.
  // The analysis module continues to own all processing/video/learning state and actual button handlers.
  const fmt=sec=>{const ms=Math.max(0,Math.round((Number(sec)||0)*1000));return `${String(Math.floor(ms/60000)).padStart(2,'0')}:${String(Math.floor(ms/1000)%60).padStart(2,'0')}.${String(ms%1000).padStart(3,'0')}`;};
  const setRangePaint=el=>{if(!el)return;const min=Number(el.min)||0,max=Number(el.max)||0,v=Number(el.value)||0,pct=max>min?Math.max(0,Math.min(100,(v-min)/(max-min)*100)):0;el.style.setProperty('--aero-progress',pct.toFixed(2)+'%');};
  function syncTrimPresentation(){
    for(const id of ['trimSeek','playerSeek','playerZoom','rangeStartSlider','rangeEndSlider'])setRangePaint($(id));
    const duration=Number(video?.duration)||0,begin=Number($('rangeStartSlider')?.value)||0,finish=Number($('rangeEndSlider')?.value)||duration;
    const durationLabel=$('aeroTrimDuration');if(durationLabel)durationLabel.textContent=duration>0?`${fmt(Math.max(0,finish-begin))} / ${fmt(duration)}`:'—';
    const overview=$('rangeOverview'),width=overview?.clientWidth||0;
    if(overview&&duration>0&&width)overview.classList.toggle('aero-tight-range',Math.abs(finish-begin)/duration*width<43);
  }
  const editor=$('rangeControls');
  if(editor&&!editor.dataset.fjRecovered){
    editor.dataset.fjRecovered='1';
    const fields=editor.querySelector('.range-editor-fields'),inner=editor.querySelector('.range-editor');
    if(fields&&inner&&!$('aeroCloseClipEditor')){
      const dismiss=d.createElement('button');dismiss.id='aeroCloseClipEditor';dismiss.type='button';dismiss.className='btn small aero-close-clip';dismiss.textContent='Готово · закрыть обрезку';
      dismiss.addEventListener('click',()=>{editor.classList.add('hidden');editor.hidden=false;$('openClipEditor')?.focus({preventScroll:true});});
      fields.insertAdjacentElement('beforebegin',dismiss);
    }
    const label=editor.querySelector('.range-overview-label');
    if(label&&!$('aeroTrimDuration')){const output=d.createElement('output');output.id='aeroTrimDuration';output.className='aero-trim-runtime';label.append(output);}
    for(const id of ['rangeStartSlider','rangeEndSlider','rangeStart','rangeEnd','trimSeek']){
      $(id)?.addEventListener('input',syncTrimPresentation,{passive:true});$(id)?.addEventListener('change',syncTrimPresentation,{passive:true});
    }
    editor.querySelectorAll('button').forEach(button=>button.addEventListener('click',()=>requestAnimationFrame(syncTrimPresentation),{passive:true}));
  }
  for(const id of ['playerSeek','playerZoom'])$(id)?.addEventListener('input',syncTrimPresentation,{passive:true});
  video?.addEventListener('loadedmetadata',syncTrimPresentation,{passive:true});
  video?.addEventListener('timeupdate',syncTrimPresentation,{passive:true});
  syncTrimPresentation();
  if(stage&&!$('aeroPlayerFullscreen')){
    const tools=$('analysisDock')?.querySelector('.player-tools-grid')||$('analysisDock')?.querySelector('.player-transport-controls');
    if(tools){const full=d.createElement('button');full.id='aeroPlayerFullscreen';full.type='button';full.className='btn small aero-fullscreen-button';full.textContent='⛶ Во весь экран';full.setAttribute('aria-label','Развернуть видео на весь экран');
      full.addEventListener('click',async()=>{try{if(d.fullscreenElement)await d.exitFullscreen();else if(stage.requestFullscreen)await stage.requestFullscreen();else if(video?.webkitEnterFullscreen)video.webkitEnterFullscreen();}catch(e){full.title='Полноэкранный режим недоступен: '+(e?.message||'');}});
      tools.append(full);
    }
  }
  d.addEventListener('keydown',event=>{
    if(event.defaultPrevented||event.altKey||event.ctrlKey||event.metaKey||event.isComposing)return;
    const target=event.target;
    if(!target?.closest?.('#analysisDock')||target.closest('input,textarea,select,button,[contenteditable="true"],[role="slider"],summary'))return;
    if(!video?.currentSrc||$('stopBtn')?.disabled===false)return;
    const key=event.key,button=key===' '||key.toLowerCase()==='k'?'playerPlay':key==='ArrowLeft'?'playerBack':key==='ArrowRight'?'playerForward':key==='Home'?'playerRestart':null;
    if(button&&!$(button)?.disabled){event.preventDefault();$(button).click();}
  });
  // The old right-side stack contained working history controls. It must not disappear with display:none.
  const side=d.querySelector('.fj-center .side-stack'),extraHost=$('advancedPanelHost');
  if(side&&extraHost&&!$('fjAuxiliaryPanels')){
    const remainder=[...side.children].filter(node=>node.tagName==='SECTION'&&!node.querySelector('#pose3dCanvas'));
    if(remainder.length){const details=d.createElement('details');details.id='fjAuxiliaryPanels';details.className='fj-auxiliary-panels panel';const summary=d.createElement('summary');summary.textContent='Дополнительные инструменты и история';details.append(summary);remainder.forEach(node=>details.append(node));extraHost.append(details);}
  }
  const hard=$('hardUpdateBtn');hard?.setAttribute('title','Обновление интерфейса 26.0.1 с очисткой браузерного кэша');
}
ready(setup);
})();
