import {pointInAthleteSilhouette,projectInsideAthleteSilhouette,silhouetteImageData} from './athlete-silhouette-core.mjs?v=23.0.26';
/** Vivaldi Fine Mesh v1: deterministic articulated, identity-locked surface.
 * This is a geometric proxy, NOT a neural SMPL fit and NOT a 3-D scan.
 * True surface observations come only from available person masks; unseen thickness is prior.
 * Shared by all compatible players. Dense arrays are generated on demand, never per-frame cached.
 */
export const VIVALDI_FINE_MESH_VERSION='vivaldi-fine-mesh-v1';
export const VIVALDI_MESH_RESOLUTIONS=Object.freeze({compact:512,standard:2048,fine:8192});
const specs={compact:{rings:4,sides:14,head:8},standard:{rings:8,sides:28,head:32},fine:{rings:32,sides:28,head:128}};
const segments=[['torso',11,12,23,24],['left_arm_upper',11,13],['left_arm_lower',13,15],['right_arm_upper',12,14],['right_arm_lower',14,16],['left_leg_upper',23,25],['left_leg_lower',25,27],['right_leg_upper',24,26],['right_leg_lower',26,28]];
const finite=Number.isFinite;
const good=(p,d)=>Array.isArray(p)&&p.length>=d&&p.slice(0,d).every(finite)&&(p[3]??1)>=.12;
const clip=(n,min,max)=>Math.max(min,Math.min(max,n));
const v3=(p,d)=>[p[0],p[1],d===3?p[2]:0];
const minus=(a,b)=>a.map((x,i)=>x-b[i]);
const plus=(a,b,m=1)=>a.map((x,i)=>x+b[i]*m);
const mult=(v,m)=>v.map(x=>x*m);
const dot=(a,b)=>a.reduce((r,x,i)=>r+x*b[i],0);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const unit=v=>{const d=Math.hypot(...v);return d>.00001?mult(v,1/d):[1,0,0];};
function segmentEnds(pts,s,d){
 if(s.length===5){const [a,b,c,e]=s.slice(1),u=pts[a],v=pts[b],x=pts[c],y=pts[e];if(![u,v,x,y].every(q=>good(q,d)))return null;
 return [mult(plus(v3(u,d),v3(v,d)),.5),mult(plus(v3(x,d),v3(y,d)),.5),Math.min(u[3]??1,v[3]??1,x[3]??1,y[3]??1)];}
 const a=pts[s[1]],b=pts[s[2]];return good(a,d)&&good(b,d)?[v3(a,d),v3(b,d),Math.min(a[3]??1,b[3]??1)]:null;
}
function median(vals){const a=vals.filter(finite).sort((x,y)=>x-y);return a.length?a[Math.floor(a.length/2)]:null;}
function widths(profile,key,kind){const a=profile?.width_profile?.[key]||profile?.body_surface_profile?.width_profile?.[key]||[];
 const values=a.filter(q=>Array.isArray(q)&&q[1]>=.18&&q[0]>.015).map(q=>q[0]);
 const fallback=kind==='torso'?.68:kind==='arm'?.20:.30;
 const hi=kind==='torso'?.90:kind==='arm'?.34:.46;
 return clip(median(values)??fallback,.07,hi);
}
/**
 * The fixed topology is 9 articulated cylinders plus one head patch.
 * 512/2048/8192 vertices exactly; each vertex has stable segment/ring/side correspondence.
 * `im` is normalized image geometry. `w` is relative world geometry, not calibrated metres.
 */
export function buildVivaldiFineMesh(frame,profile=null,{resolution='standard',space='2d'}={}){
 const spec=specs[resolution]||specs.standard,dim=space==='3d'?3:2;
 const pts=space==='3d'?(frame?.render_w||frame?.w):(frame?.render_im||frame?.im);
 const confidence=new Float32Array((VIVALDI_MESH_RESOLUTIONS[resolution]||2048)),indices=[],areas=[];
 // positions have x,y,z,visible packed; null segments are encoded with zero confidence.
 const out=new Float32Array((VIVALDI_MESH_RESOLUTIONS[resolution]||2048)*4);
 if(!Array.isArray(pts))return {schema:VIVALDI_FINE_MESH_VERSION,resolution,space,positions:out,confidence,triangles:new Uint32Array(0),segments:[],visible_vertices:0,vertex_count:out.length/4,quality:'insufficient_evidence'};
 const shoulder=good(pts[11],dim)&&good(pts[12],dim)?Math.hypot(...minus(v3(pts[12],dim),v3(pts[11],dim))):.2;
 const identity=profile?.fixed_geometry||{};
 const reference=dim===3?Number(identity.world_shoulder_span):Number(identity.reference_image_shoulder_span);
 // Preserve personal dimensions while allowing scene-consistent apparent scale changes.
 const perspective=dim===2?clip(Number(frame?.scene_depth?.scale)||1,.88,1.12):1;
 const shoulderSpan=dim===2?clip(shoulder,.04,1.5):(reference>.04?clip(reference,.04,1.5):clip(shoulder,.04,1.5));
 let cursor=0,visible=0;const silhouette=dim===2?frame?.surface?.silhouette:null;
 for(const s of segments){const name=s[0],kind=name==='torso'?'torso':name.includes('arm')?'arm':'leg',seg=segmentEnds(pts,s,dim),base=cursor;
  const radius=widths(profile,name,kind)*shoulderSpan*.5;
  const A=seg?.[0]||[0,0,0],B=seg?.[1]||[0,0,0],axis=unit(minus(B,A));
  const seed=Math.abs(axis[1])<.82?[0,1,0]:[1,0,0];
  let side=dim===2?unit([-axis[1],axis[0],0]):unit(cross(axis,seed));if(Math.hypot(...side)<.001)side=[1,0,0];
  const across=dim===2?[0,0,1]:unit(cross(side,axis));
  // Corelli · bind garment silhouette stations to the same anatomical mesh rings.
  // Four stable stations are fitted from multi-frame silhouette observations.
  // Interpolate between them; do not recalculate each ring independently per video frame.
  const stations=profile?.width_profile?.[name]||profile?.body_surface_profile?.width_profile?.[name]||[];
  const localStations=frame?.surface?.zone_width_profile?.[kind==='torso'?'torso':name.includes('left_arm')?'left_sleeve':name.includes('right_arm')?'right_sleeve':name.includes('left_leg')?'left_trouser':'right_trouser']?.[kind==='torso'?0:name.includes('upper')?0:1]||[];
  const reliable=Array.from({length:4},(_,i)=>{
   const sample=localStations[i]?.[1]>=.30?localStations[i]:stations[i];return Array.isArray(sample)&&Number.isFinite(sample[0])&&sample[0]>.015&&sample[1]>=.18?
      clip(sample[0],.06,kind==='torso'?.9:kind==='arm'?.34:.46):null;
  });
  // Missing stations borrow the nearest measured station; all-missing uses profile median.
  const stable=Array.from({length:4},(_,i)=>reliable[i]??reliable.reduce((best,x,j)=>x!=null&&(!best||Math.abs(i-j)<best.dist)?{dist:Math.abs(i-j),v:x}:best,null)?.v??radius*2/shoulderSpan);
  for(let r=0;r<spec.rings;r++)for(let k=0;k<spec.sides;k++){
   const t=r/(spec.rings-1),angle=2*Math.PI*k/spec.sides;
   const stationPos=t*3,lo=Math.min(2,Math.floor(stationPos)),blend=stationPos-lo;
   const localRatio=stable[lo]*(1-blend)+stable[lo+1]*blend;
   const anatomicalTaper=kind==='torso'?(1-.18*t):kind==='arm'?(1-.26*t):(1-.28*t);
   const localRadius=clip(localRatio*shoulderSpan*.5*anatomicalTaper,radius*.40,radius*(dim===3?1.03:1.18));
   const center=plus(A,minus(B,A),t);
   let p=plus(plus(center,side,Math.cos(angle)*localRadius),across,Math.sin(angle)*localRadius*(dim===3?.32:.10));
   let visiblePoint=!!seg;
   if(dim===2&&silhouette){const constrained=projectInsideAthleteSilhouette(silhouette,center,p);if(constrained)p=constrained;else visiblePoint=false;}
   const offset=cursor*4;out[offset]=p[0];out[offset+1]=p[1];out[offset+2]=p[2];out[offset+3]=visiblePoint?clip(seg[2],0,1):0;
   confidence[cursor]=out[offset+3];if(out[offset+3]>=.12)visible++;cursor++;
  }
  if(seg)for(let r=0;r<spec.rings-1;r++)for(let k=0;k<spec.sides;k++){
   const a=base+r*spec.sides+k,b=base+r*spec.sides+(k+1)%spec.sides,c=a+spec.sides,d=b+spec.sides;
   indices.push(a,b,c,b,d,c);
  }
  areas.push({name,first:base,count:spec.rings*spec.sides,visible:!!seg,width_shoulder_ratio:radius*2/shoulderSpan});
 }
 // Head proxy, fixed index count. It never implies an individually measured head shape.
 const head=good(pts[0],dim)?v3(pts[0],dim):null,headRadius=shoulderSpan*.205;
 for(let k=0;k<spec.head;k++){
  const t=(k+.5)/spec.head,theta=k*2.3999632297,rad=headRadius*Math.sqrt(Math.max(0,1-(2*t-1)**2));
  const i=cursor*4;let hp=[(head?.[0]||0)+rad*Math.cos(theta),(head?.[1]||0)+headRadius*(2*t-1),(head?.[2]||0)+rad*Math.sin(theta)*.30];
  const headValid=!!head&&(!silhouette||pointInAthleteSilhouette(silhouette,hp[0],hp[1]));
  out[i]=hp[0];out[i+1]=hp[1];out[i+2]=hp[2];out[i+3]=headValid?clip(pts[0][3]??1,0,1):0;
  confidence[cursor]=out[i+3];if(headValid&&out[i+3]>=.12)visible++;cursor++;
 }
 return {schema:VIVALDI_FINE_MESH_VERSION,resolution,space,positions:out,confidence,triangles:new Uint32Array(indices),segments:areas,visible_vertices:visible,vertex_count:out.length/4,quality:visible>=Math.floor(out.length/4*.55)?'geometric_proxy':'insufficient_evidence', limitations:['Widths are garment-inclusive silhouette observations or conservative priors','Occluded 3D surfaces cannot be uniquely reconstructed from monocular video','Increasing mesh resolution does not add independent measurements']};
}
/** Explicit measured-silhouette clipping: no painted avatar pixel is allowed outside
 * the worker's tracked-athlete foreground component. Older reports fall back to 2D skeleton.
 */
let silhouetteScratch=null,silhouetteMaskCanvas=null,silhouetteLastRef=null,silhouetteLastSize='';
function createCanvas(w,h){if(typeof OffscreenCanvas!=='undefined')return new OffscreenCanvas(w,h);if(typeof document!=='undefined'){const c=document.createElement('canvas');c.width=w;c.height=h;return c;}return null;}
function maskCanvas(mask){if(!mask)return null;if(silhouetteLastRef===mask&&silhouetteMaskCanvas&&silhouetteMaskCanvas.width===mask.w&&silhouetteMaskCanvas.height===mask.h)return silhouetteMaskCanvas;
 const canvas=createCanvas(mask.w,mask.h),c=canvas?.getContext('2d');if(!c)return null;
 const rgba=silhouetteImageData(mask),image=c.createImageData(mask.w,mask.h);image.data.set(rgba);c.putImageData(image,0,0);
 silhouetteMaskCanvas=canvas;silhouetteLastRef=mask;return canvas;
}
export function paintVivaldiMesh2D(context,frame,profile,{resolution='standard',width=1,height=1,color='#77dccc',alpha=.63,requireSilhouette=true}={}){
 const silhouette=frame?.surface?.silhouette;
 if(requireSilhouette&&!silhouette)return false;
 const mesh=buildVivaldiFineMesh(frame,profile,{resolution,space:'2d'});
 if(mesh.visible_vertices<128)return false;
 const mw=Math.round(width),mh=Math.round(height),mask=maskCanvas(silhouette);
 if(silhouette&&!mask)return false;
 let ctx=context;
 if(mask){if(!silhouetteScratch||silhouetteScratch.width!==mw||silhouetteScratch.height!==mh)silhouetteScratch=createCanvas(mw,mh);
  ctx=silhouetteScratch?.getContext('2d');if(!ctx)return false;ctx.clearRect(0,0,mw,mh);}
 const {positions:p}=mesh;ctx.save();ctx.fillStyle=color;ctx.strokeStyle=color;ctx.globalAlpha=alpha;ctx.lineWidth=Math.max(.7,width*.0012);
 const spec0=specs[resolution]||specs.standard,n=spec0.sides;
 for(const area of mesh.segments){if(!area.visible)continue;const first=area.first,a=first,b=first+Math.floor(n*.5);
  const goodRing=r=>p[(a+r*n)*4+3]>=.12&&p[(b+r*n)*4+3]>=.12;
  // Only a continuous run of actual foreground can produce a filled segment.
  let r=0;while(r<spec0.rings){while(r<spec0.rings&&!goodRing(r))r++;const start=r;while(r<spec0.rings&&goodRing(r))r++;const end=r-1;if(end<=start)continue;
   const point=idx=>[p[idx*4]*width,p[idx*4+1]*height];ctx.beginPath();ctx.moveTo(...point(a+start*n));
   for(let j=start+1;j<=end;j++)ctx.lineTo(...point(a+j*n));
   for(let j=end;j>=start;j--)ctx.lineTo(...point(b+j*n));ctx.closePath();ctx.fill();ctx.stroke();}
 }
 ctx.restore();
 if(mask){ctx.save();ctx.globalCompositeOperation='destination-in';ctx.imageSmoothingEnabled=false;ctx.drawImage(mask,0,0,mw,mh);ctx.restore();context.drawImage(silhouetteScratch,0,0,width,height);}
 return true;
}
/** Shared 3D projected body surface. Camera transform agrees with spatialReplayPoints.
 * The surface is a visual geometric proxy; only observed input landmarks are measured.
 */
export function paintVivaldiMesh3D(ctx,frame,profile,{resolution='compact',yaw=-.45,pitch=.26,centerX=0,centerY=0,size=300,color='#84efc8',alpha=.67}={}){
 const mesh=buildVivaldiFineMesh(frame,profile,{resolution,space:'3d'});
 if(mesh.visible_vertices<Math.ceil(mesh.vertex_count*.5))return false;
 const p=mesh.positions,w=frame?.render_w||frame?.w||[],l=w[23],r=w[24];
 const mid=good(l,3)&&good(r,3)?l.slice(0,3).map((v,i)=>(v+r[i])*.5):[0,0,0];
 const ca=Math.cos(yaw),sa=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch),projected=[];
 for(let i=0;i<mesh.vertex_count;i++){
  const x=p[i*4]-mid[0],y=p[i*4+1]-mid[1],z=p[i*4+2]-mid[2],X=x*ca+z*sa,Z=z*ca-x*sa,Y=y*cp-Z*sp,D=Math.max(1.2,2.4+Z*cp+y*sp);
  projected.push({x:centerX+X/D*size,y:centerY+Y/D*size,z:Z,c:p[i*4+3]});
 }
 // Draw a bounded number of faces on demand, in camera depth order.
 const faces=[],indices=mesh.triangles;
 for(let i=0;i<indices.length;i+=3){const a=projected[indices[i]],b=projected[indices[i+1]],c=projected[indices[i+2]];
  if(!a||!b||!c||Math.min(a.c,b.c,c.c)<.15)continue;
  const area=Math.abs((b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x));
  if(!Number.isFinite(area)||area<.025||area>size*size*.25)continue;
  // View-space Lambert shading makes the single geometric surface readable
  // without stacking unmeasured anatomical spheres on top of the avatar.
  const pa=indices[i]*4,pb=indices[i+1]*4,pc=indices[i+2]*4;
  const ux=p[pb]-p[pa],uy=p[pb+1]-p[pa+1],uz=p[pb+2]-p[pa+2];
  const vx=p[pc]-p[pa],vy=p[pc+1]-p[pa+1],vz=p[pc+2]-p[pa+2];
  const nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx,mag=Math.hypot(nx,ny,nz)||1;
  const shade=clip(.38+.62*Math.abs((nx*.38-ny*.50+nz*.78)/mag),.35,1);
  faces.push({a,b,c,depth:(a.z+b.z+c.z)/3,shade});
 }
 faces.sort((a,b)=>b.depth-a.depth);
 const rgb=/^#([0-9a-f]{6})$/i.exec(color);const channels=rgb?[parseInt(rgb[1].slice(0,2),16),parseInt(rgb[1].slice(2,4),16),parseInt(rgb[1].slice(4,6),16)]:[152,217,222];
 ctx.save();ctx.globalAlpha=alpha;
 for(const f of faces){ctx.beginPath();ctx.moveTo(f.a.x,f.a.y);ctx.lineTo(f.b.x,f.b.y);ctx.lineTo(f.c.x,f.c.y);ctx.closePath();ctx.fillStyle=`rgb(${channels.map(n=>Math.round(n*f.shade)).join(',')})`;ctx.fill();}
 ctx.restore();return faces.length>60;
}
/** Fine is a display detail level, not an evidence-confidence grade.
 * Prefer fine on capable devices when paused; never sacrifice smooth motion for vertex count.
 */
export function chooseVivaldiLOD(frame,{memoryGiB=0,cores=0,renderFps=0,paused=false,profileConfidence=0}={}){
 const p=frame?.render_im||frame?.im||[];
 const visible=p.filter(q=>good(q,2)).length;
 if(visible<13)return 'compact';
 if(visible>=24&&profileConfidence>=.28&&memoryGiB>=8&&cores>=6&&paused)return 'fine';
 if(visible>=27&&profileConfidence>=.52&&memoryGiB>=12&&cores>=10&&renderFps>=57)return 'fine';
 if(memoryGiB&&memoryGiB<=2)return 'compact';
 return 'standard';
}
