/* Falco 23.0.26 — per-frame measured silhouette, shared by main thread & Pose Worker.
 * The mask is evidence, not generated geometry. Bit packing costs 2 KiB at 128x128.
 */
export const ATHLETE_SILHOUETTE_VERSION='falco-athlete-mask-v3';
const bitCache=new WeakMap();
function base64Encode(bytes){if(typeof btoa==='function'){let out='';for(let i=0;i<bytes.length;i++)out+=String.fromCharCode(bytes[i]);return btoa(out);}return Buffer.from(bytes).toString('base64');}
function base64Decode(mask){if(mask?.bits)return mask.bits;if(bitCache.has(mask))return bitCache.get(mask);if(typeof mask?.b64!=='string')return null;const raw=typeof atob==='function'?atob(mask.b64):Buffer.from(mask.b64,'base64').toString('latin1');const bytes=Uint8Array.from(raw,ch=>ch.charCodeAt(0));bitCache.set(mask,bytes);return bytes;}
const finite=Number.isFinite;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export function packAthleteSilhouette(mask,landmarks,{width=128,height=128,threshold=.59}={}){
 const mw=Number(mask?.width),mh=Number(mask?.height),pixels=mask?.getAsFloat32Array?.();
 if(!(mw>0&&mh>0)||!pixels?.length||!Array.isArray(landmarks)||!landmarks[11]||!landmarks[12]||!landmarks[23]||!landmarks[24])return null;
 const w=clamp(Math.round(width),32,256),h=clamp(Math.round(height),32,256),raw=new Uint8Array(w*h);
 for(let y=0;y<h;y++){const srcY=Math.min(mh-1,Math.floor((y+.5)*mh/h));for(let x=0;x<w;x++){
  const srcX=Math.min(mw-1,Math.floor((x+.5)*mw/w));raw[y*w+x]=Number(pixels[srcY*mw+srcX])>=threshold?1:0;
 }}
 const hips=[landmarks[23],landmarks[24]],shoulders=[landmarks[11],landmarks[12]];
 const cx=clamp(Math.round(((hips[0].x+hips[1].x+shoulders[0].x+shoulders[1].x)/4)*w),0,w-1);
 const cy=clamp(Math.round(((hips[0].y+hips[1].y+shoulders[0].y+shoulders[1].y)/4)*h),0,h-1);
 if(![cx,cy].every(finite))return null;
 let seed=-1;
 for(let r=0;r<=Math.max(4,Math.ceil(w*.065))&&seed<0;r++){
  for(let dy=-r;dy<=r&&seed<0;dy++)for(let dx=-r;dx<=r;dx++){
   const x=cx+dx,y=cy+dy;if(x>=0&&y>=0&&x<w&&y<h&&raw[y*w+x]){seed=y*w+x;break;}
  }
 }
 if(seed<0)return null;
 // Follow the one connected foreground component containing the tracked athlete's torso.
 // Eight connectivity prevents small segmentation gaps at diagonal sleeves or hems.
 const found=new Uint8Array(w*h),queue=new Int32Array(w*h);let head=0,tail=1;queue[0]=seed;found[seed]=1;
 while(head<tail){const p=queue[head++],x=p%w,y=(p/w)|0;
  for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){if(!dx&&!dy)continue;const xx=x+dx,yy=y+dy;if(xx<0||yy<0||xx>=w||yy>=h)continue;const q=yy*w+xx;if(raw[q]&&!found[q]){found[q]=1;queue[tail++]=q;}}
 }
 if(tail<Math.max(38,Math.round(w*h*.008))||tail>w*h*.91)return null;
 const bits=new Uint8Array(Math.ceil(w*h/8));for(let i=0;i<found.length;i++)if(found[i])bits[i>>3]|=1<<(i&7);
 return {schema:ATHLETE_SILHOUETTE_VERSION,w,h,b64:base64Encode(bits),coverage:Number((tail/(w*h)).toFixed(4)),confidence:'segmentation-observation',source:'pose-landmarker-mask'};
}
export function pointInAthleteSilhouette(mask,x,y){
 if(!(mask?.bits||mask?.b64)||!(mask.w>0&&mask.h>0)||!finite(x)||!finite(y)||x<0||x>1||y<0||y>1)return false;
 const px=Math.min(mask.w-1,Math.floor(x*mask.w)),py=Math.min(mask.h-1,Math.floor(y*mask.h)),i=py*mask.w+px;
 const bits=base64Decode(mask);return !!((bits?.[i>>3]||0)&(1<<(i&7)));
}
export function projectInsideAthleteSilhouette(mask,center,vertex){
 if(!mask)return vertex;
 if(!Array.isArray(center)||!Array.isArray(vertex)||![...center,...vertex].every(finite))return null;
 if(!pointInAthleteSilhouette(mask,center[0],center[1]))return null;
 if(pointInAthleteSilhouette(mask,vertex[0],vertex[1]))return vertex;
 // Step inward. The first valid pixel guarantees that silhouette geometry cannot protrude.
 for(let i=1;i<=32;i++){const t=1-i/32;
  const x=center[0]+(vertex[0]-center[0])*t,y=center[1]+(vertex[1]-center[1])*t;
  if(pointInAthleteSilhouette(mask,x,y))return [x,y,vertex[2]??0];
 }
 return center;
}
export function silhouetteImageData(mask){
 if(!(mask?.bits||mask?.b64)||!(mask.w>0&&mask.h>0))return null;
 const bits=base64Decode(mask);if(!bits)return null;
 const out=new Uint8ClampedArray(mask.w*mask.h*4);
 for(let y=0;y<mask.h;y++)for(let x=0;x<mask.w;x++){const i=y*mask.w+x,k=i*4;out[k]=255;out[k+1]=255;out[k+2]=255;out[k+3]=(bits[i>>3]&(1<<(i&7)))?255:0;}
 return out;
}

/** Reversible run-length archive transport. Shape masks usually become 3–8 times
 * smaller than raw bitplanes; if a noisy foreground resists RLE, retain raw bits.
 * Prefix 'r' (runs) or 'b' (original bitplane) makes corruption detectable.
 */
export function compactAthleteSilhouette(mask){
 if(!mask?.b64||!(mask.w>0&&mask.h>0))return null;
 const pixels=mask.w*mask.h,bits=base64Decode(mask);if(!bits||bits.length!==Math.ceil(pixels/8))return null;
 const packed=[(bits[0]&1)?1:0];let prev=packed[0],run=0;
 const emit=n=>{do{let b=n&127;n=Math.floor(n/128);if(n)b|=128;packed.push(b);}while(n);};
 for(let i=0;i<pixels;i++){const bit=(bits[i>>3]>>(i&7))&1;
  if(bit!==prev){emit(run);prev=bit;run=0;}run++;
 }
 emit(run);const encoded=base64Encode(Uint8Array.from(packed));
 return encoded.length+1<mask.b64.length?'r'+encoded:'b'+mask.b64;
}
export function expandAthleteSilhouette(serialized,{w=128,h=128}={}){
 if(typeof serialized!=='string'||serialized.length<2||serialized.length>6000)return null;
 const scheme=serialized[0],payload=serialized.slice(1),pixels=w*h;
 if(scheme==='b'){const bits=base64Decode({b64:payload});return bits?.length===Math.ceil(pixels/8)?{schema:ATHLETE_SILHOUETTE_VERSION,w,h,b64:payload,source:'pose-landmarker-mask',confidence:'segmentation-observation'}:null;}
 if(scheme!=='r')return null;
 const data=base64Decode({b64:payload});if(!data?.length)return null;
 const bits=new Uint8Array(Math.ceil(pixels/8));let next=Number(data[0]);if(next!==0&&next!==1)return null;
 let cursor=1,pos=0;
 while(cursor<data.length){let run=0,shift=0,terminated=false;
  while(cursor<data.length){const b=data[cursor++];run+=(b&127)*2**shift;shift+=7;if(shift>28)return null;if(!(b&128)){terminated=true;break;}}
  if(!terminated||!Number.isSafeInteger(run)||pos+run>pixels)return null;
  if(next)for(let i=pos;i<pos+run;i++)bits[i>>3]|=1<<(i&7);
  pos+=run;next^=1;
 }
 if(pos!==pixels)return null;
 return {schema:ATHLETE_SILHOUETTE_VERSION,w,h,b64:base64Encode(bits),source:'pose-landmarker-mask',confidence:'segmentation-observation'};
}
