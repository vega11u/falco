<?php
declare(strict_types=1);
// Server-side report library UI. Report ownership is enforced by index.php's
// independent HttpOnly kata_report_owner cookie, not by this page.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
?><!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light dark">
<meta name="theme-color" content="#2799c8">
<title>Falco Jugger — Библиотека отчётов</title>
<script>try{if(localStorage.getItem("falco-jugger-theme-v1")==="dark")document.documentElement.dataset.theme="dark";}catch(_){}</script>

<link rel="stylesheet" href="frutiger-aero-v23.css?v=23.0.2">
<link rel="stylesheet" href="aero-y2k-studio-v23.0.15.css?v=23.0.15">
<link rel="stylesheet" href="vista-aero-v23.0.16.css?v=23.0.16">
<link rel="stylesheet" href="vista-aero-v23.0.17.css?v=23.0.17">
<link rel="stylesheet" href="vista-aero-v23.0.18.css?v=23.0.18">
<link rel="stylesheet" href="hard-update-v23.0.19.css?v=23.0.19"><link rel="stylesheet" href="aero-unified-v23.0.26.css?v=23.0.26">
</head>
<body class="aero-archive">
<main class="shell">
  <header class="top">
    <div class="brand"><img class="aero-avatar-brand" src="assets/falco-avatar-sanchin.svg" width="48" height="48" alt="2D-аватар Falco в стойке Санчин"><div><div class="brand-title">Falco Jugger <span class="build-version">23.0.26.1</span></div><span class="aero-brand-caption">Лаборатория движения</span></div></div>
    <nav class="top-actions">
      <button class="btn theme-toggle" id="themeToggle" type="button" aria-pressed="false">◐ Тема</button>
      <button class="btn hard-update-btn" id="hardUpdateBtn" type="button" aria-haspopup="dialog" title="Очистить Cache Storage и перезагрузить актуальную версию сайта">HARD UPDATE</button>
      <a class="top-link" href="index.php">← Анализатор ката</a>
      <a class="top-link btn primary" href="uppurcell.php">Upgrade Purcell</a>
    </nav>
    <div class="server-status" id="serverStatus"><span class="server-dot" id="serverDot"></span><span id="serverStatusText">Проверка соединения…</span></div>
  </header>
  <section class="archive-hero"><div class="archive-hero-copy"><div class="aero-eyebrow">Ваши наблюдения</div><h2>Библиотека отчётов</h2><p>Возвращайтесь к разобранным движениям, сравнивайте технику и продолжайте обучение моделей.</p><div class="aero-hero-badges"><span>Отчёты · разметка · эталоны</span></div></div><img class="aero-hero-art" src="assets/aero-motion.svg" width="360" height="280" alt="" aria-hidden="true"></section>
  
  <div class="toolbar"><div><strong>Архив</strong> <span class="count" id="count">Загрузка…</span></div><button class="btn" id="refresh" type="button">Обновить список</button></div>
  <div id="loading" class="loading" aria-hidden="true"></div>
  <section class="list" id="list" aria-live="polite"><div class="empty">Загружаю серверную библиотеку…</div></section>
  <details class="hint"><summary>О хранении</summary>Отчёты хранятся на сервере вне публичной папки сайта. Доступ к вашей подборке ограничен отдельным HttpOnly cookie владельца. Если удалить cookies или открыть другой браузер/устройство, этот браузерный ключ не перенесётся и доступ к прежней подборке может быть потерян. Это не локальное хранение файлов.</details>
</main>
<script>
const $=id=>document.getElementById(id);
function applyWorkspaceTheme(theme){const next=theme==='dark'?'dark':'light';document.documentElement.dataset.theme=next;const button=$('themeToggle');if(button){button.setAttribute('aria-pressed',String(next==='dark'));button.textContent=next==='dark'?'☼ Светлая тема':'◐ Тёмная тема';}const meta=document.querySelector('meta[name="color-scheme"]');if(meta)meta.content=next==='dark'?'dark':'light';try{localStorage.setItem('falco-jugger-theme-v1',next);}catch(_){}}
let initialTheme='light';try{initialTheme=localStorage.getItem('falco-jugger-theme-v1')==='dark'?'dark':'light';}catch(_){}applyWorkspaceTheme(initialTheme);
$('themeToggle').addEventListener('click',()=>applyWorkspaceTheme(document.documentElement.dataset.theme==='dark'?'light':'dark'));
const fmtTime=s=>{const n=Math.max(0,Number(s)||0),m=Math.floor(n/60),sec=n-m*60;return `${String(m).padStart(2,'0')}:${sec.toFixed(1).padStart(4,'0')}`;};
const dateLabel=s=>{const d=new Date(s);return Number.isNaN(d.getTime())?'Дата не указана':new Intl.DateTimeFormat('ru-RU',{dateStyle:'medium',timeStyle:'short'}).format(d);};
const sizeLabel=n=>{const b=Number(n)||0;return b>1048576?(b/1048576).toFixed(2)+' МБ':(b/1024).toFixed(0)+' КБ';};
async function api(url,options={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...options,headers:{'Accept':'application/json',...(options.headers||{})}});let d;try{d=await r.json();}catch(_){throw new Error('Сервер вернул не JSON. Проверьте PHP API.');}if(!r.ok||d.ok===false)throw new Error(d.error||`HTTP ${r.status}`);return d;}
function action(label,href,kind=''){const a=document.createElement('a');a.className='btn '+kind;a.textContent=label;a.href=href;if(kind!=='danger'){a.target='_blank';a.rel='noopener';}return a;}
function render(items){const root=$('list');root.replaceChildren();$('count').textContent=`${items.length} отчётов`;
 if(!items.length){const empty=document.createElement('div');empty.className='empty';empty.textContent='Пока нет серверных отчётов в этой библиотеке. Файлы хранятся на сервере, а доступ к подборке ограничен HttpOnly cookie владельца и точным origin сайта. После отправки приложение проверяет, что новый отчёт появился в списке.';root.append(empty);return;}
 for(const x of items){const card=document.createElement('article');card.className='item';const main=document.createElement('div');main.className='item-main';const title=document.createElement('div');title.className='item-title';title.textContent=x.file_name||'Ката без названия';main.append(title);const meta=document.createElement('div');meta.className='meta';const m=(text,cls='')=>{const s=document.createElement('span');s.textContent=text;if(cls)s.className=cls;return s;};meta.append(m(dateLabel(x.created_at)),m(x.legacy_metadata_missing?'Старый архив · откройте для просмотра':`${fmtTime(x.duration_s)} · ${Number(x.frame_count)||0} кадров`),m(sizeLabel(x.bytes)));if(!x.legacy_metadata_missing)meta.append(m(`Оценка ${Math.round(Number(x.final_score)||0)}/100`,'score'));
 meta.append(m(x.personalized_mesh_schema==='falco-personalized-vivaldi-mesh-keyframes-v2'&&Number(x.personalized_mesh_keyframes)>0?`Персональная 3D-сетка · ${x.personalized_mesh_keyframes} сохранённых ключевых кадров`:'Архив прежнего формата · персональная 3D-сетка не сохранена','mesh-state'));main.append(meta);
 const buttons=document.createElement('div');buttons.className='actions';buttons.append(action('Открыть отчёт',`index.php?report=${encodeURIComponent(x.id)}`));buttons.append(action('Открыть для обучения',`index.php?report=${encodeURIComponent(x.id)}&training=1`,'primary'));buttons.append(action('В эталоны Purcell',`uppurcell.php?report=${encodeURIComponent(x.id)}&training=1`));
 const del=document.createElement('button');del.className='btn danger';del.type='button';del.textContent='Удалить';del.addEventListener('click',()=>deleteReport(x.id,card,del));buttons.append(del);card.append(main,buttons);root.append(card);}
}
async function load(){ $('loading').hidden=false;$('count').textContent='Обновление…';$('refresh').disabled=true;try{const d=await api('index.php?api=reports-list');render(d.items||[]);$('serverDot').style.background='#a8c99b';$('serverStatusText').textContent='Сервер онлайн';$('serverStatus').title='Последняя проверка: '+new Date().toLocaleTimeString('ru-RU');$('count').textContent=`${d.count??(d.items||[]).length} отчётов · библиотека ${d.owner_scope||'—'} · ${d.storage_ready?'хранилище доступно':'папка создаётся при первой записи'}`;}catch(e){$('serverDot').style.background='#e98d83';$('serverStatusText').textContent='Нет соединения';$('count').textContent='Ошибка';$('list').replaceChildren();const box=document.createElement('div');box.className='error';box.textContent='Не удалось загрузить библиотеку: '+e.message;const retry=document.createElement('button');retry.className='btn';retry.textContent='Повторить';retry.addEventListener('click',load);box.append(document.createElement('br'),retry);$('list').append(box);}finally{$('loading').hidden=true;$('refresh').disabled=false;}}
async function deleteReport(id,card,button){if(!confirm('Удалить этот отчёт с сервера? Подтверждённые обучающие примеры и веса моделей останутся без изменений.'))return;button.disabled=true;button.textContent='Удаление…';try{await api('index.php?api=reports-delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})});card.remove();const remaining=$('list').querySelectorAll('.item').length;$('count').textContent=`${remaining} отчётов`;if(!remaining){const e=document.createElement('div');e.className='empty';e.textContent='Библиотека отчётов пуста.';$('list').append(e);}}catch(e){button.disabled=false;button.textContent='Удалить';alert('Не удалось удалить отчёт: '+e.message);}}
$('refresh').addEventListener('click',load);load();
</script>
<script type="module" src="hard-update-v23.0.19.js?v=23.0.19"></script>
</body>
</html>
