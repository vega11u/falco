import assert from 'node:assert/strict';
import {trainingConfig,initialGenome,mutateGenome,applyGenome,validateHypothesis,assessEvolutionCandidate,trainHypothesis} from '../purcell-evolution-core.mjs';
const xy={0:[.5,.14],11:[.43,.29],12:[.57,.29],13:[.39,.40],14:[.61,.40],15:[.34,.54],16:[.66,.54],23:[.45,.52],24:[.55,.52],25:[.44,.68],26:[.56,.68],27:[.44,.83],28:[.56,.83],29:[.43,.86],30:[.57,.86],31:[.43,.88],32:[.57,.88]};
const source=Array.from({length:60},(_,i)=>{const t=i/30,im=Array.from({length:33},(_,j)=>[.5+(j%5)*.01,.5,0,1]);for(const [id,p] of Object.entries(xy))im[+id]=[...p,0,1];for(const j of [15,16])im[j][0]+=.037*Math.sin(t*11);const w=im.map(p=>[(p[0]-.5)*2,(p[1]-.5)*2,0,1]);return {t,im,w,camera_segment_id:0};});
const snap=JSON.stringify(source);
assert.throws(()=>trainingConfig({copies:25}),/1 до 24/);assert.equal(trainingConfig({copies:1}).coherence_goal,100);
const g=initialGenome(4201),rng=()=>.41,mut=mutateGenome(g,rng);assert.deepEqual(g.map(x=>x.chain),mut.map(x=>x.chain));
const generated=applyGenome(source,g),geometry=validateHypothesis(source,generated);assert.ok('passed' in geometry);
const baseline=assessEvolutionCandidate(source,source);assert.ok('coherence' in baseline,'Baseline must report the same measured objective, even when evidence insufficient');
const feedback=[];const result=await trainHypothesis({frames:source,copies:4,steps:12,seed:12014,onProgress:p=>feedback.push(p)});
assert.equal(result.results.length,4);assert.equal(feedback.length,4);
assert.equal(result.config.coherence_goal,100);assert.equal(result.config.min_overall,60);
assert.equal(result.quorum&&result.successes<2,false,'one successful copy must not certify four-copy consensus');
for(const row of result.results){assert.ok(row.attempted>=0&&row.attempted<=12);assert.ok(row.accepted<=row.attempted);assert.ok(row.overall===null||Number.isFinite(row.overall));assert.ok(row.coherence===null||Number.isFinite(row.coherence));}
assert.equal(JSON.stringify(source),snap,'Source reconstructed pose must be immutable');
if(result.consolidated){assert.ok(result.quorum&&result.consolidated.score.adequate_evidence&&result.consolidated.score.coherence===100&&result.consolidated.score.overall>=60);}
const cancelled=()=>true;await assert.rejects(()=>trainHypothesis({frames:source,copies:2,steps:12,shouldStop:cancelled}),/прервана/);
console.log('PASS independent replicas, bounded mutations, anatomy gates, honest 100 threshold, no source mutation, cancellation');
