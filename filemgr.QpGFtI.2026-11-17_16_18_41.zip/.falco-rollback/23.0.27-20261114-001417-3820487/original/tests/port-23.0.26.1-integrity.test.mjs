import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const file=new URL('../index.php',import.meta.url);
const src=readFileSync(file,'utf8');
for(const required of [
  "'./athlete-silhouette-core.mjs?v=23.0.26'",
  "'./kime-score-core.mjs?v=23.0.26'",
  'aero-unified-v23.0.26.css',
  'aero-monteverdi-v23.0.26.1.css',
  'data-kime-canvas="${i}"',
  'data-kime-play="${i}"',
  'data-kime-seek="${i}"',
  'monteverdiRefineFastCandidates(frames,kimeEvents)',
  'fitMonteverdiMotionClassifier(labelled)',
  'buildPersonalized3DArchive(state.frames,state.bodyShapeProfile',
  'personalized_model_3d',
  'personalized_3d_mesh_schema',
  'athlete_silhouette_compact_per_frame',
  'renderArchivedPersonal3D(ctx,frameAtTimeIndex',
  'fast_kime','fast_no_kime','not_fast',
  'motion_features:e.motion_features??null',
  'schema:\'monteverdi-kime-feedback-v2\'',
])assert(src.includes(required),`Lost merged functionality: ${required}`);
for(const legacy of ['data-monteverdi-replay="${i}"','data-monteverdi-label="${i}:uncertain"', '<<<<<<<','>>>>>>>'])assert(!src.includes(legacy),`Legacy/conflict marker remained: ${legacy}`);
const html=src.slice(src.indexOf('function renderMonteverdiKimePanel'),src.indexOf('let purcellManualMoment'));
assert(html.includes('canvas width="480" height="270"'),'Kime cards need inline replay canvases');
assert(html.includes('Отчёт')===false || html.length>0);
assert.equal((src.match(/function monteverdiRefineFastCandidates\(/g)||[]).length,1);
assert.equal((src.match(/function renderMonteverdiKimePanel\(/g)||[]).length,1);
console.log('PASS 23.0.26.1 port: 23.0.26 Aero/mesh/scoring/replay + tri-class training & saved 3D');
