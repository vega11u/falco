# Validation report — 2026-10-31

## v19 REG.RU PHP/JavaScript release validation

- `php -l index.php` and all PHP smoke files — passed.
- `bash -n` for setup, importer, CRON worker and test shell scripts — passed.
- `tests/verify.sh` — passed, including synthetic biomechanics, optimizer, research-data integrity, full personal-learning API, direct media-import mock and CRON-queue fallback.
- `tests/media-import-smoke.sh` — mocked yt-dlp flow passed: YouTube alternate-profile retry, Instagram native-extractor retry, URL allowlisting, session isolation, progress/status, media-signature validation, chunked transfer and cleanup.
- `tests/media-import-cron-smoke.sh` — passed with PHP built-in server started using `disable_functions=proc_open`; the test queues a URL, dispatches the task through `media-import-cron.sh`, runs a mocked standalone extractor, polls completion and retrieves the file.
- `tests/learning-api-smoke.php` and the synthetic full-library tests — passed. The archive test covers 3,005 examples and 1,002 feedback records without response truncation; this is a synthetic test fixture, not a claim that these records exist in the user's private account.
- Release guard confirms the v19 app contains no `.py` source files, no `gallery-dl` adapter, no Python/pip/venv install invocation, and no setup-time Python-version check. The yt-dlp standalone binary remains an external dependency; it is an upstream Python project packaged with a bundled interpreter (see `MEDIA_IMPORT.md`).
- `data/trained/training-manifest.json` truthfully marks research models as not ready. There are no pretrained research weights in this release archive. Personal learning is the separately stored PHP/JSON feature archive and is not deleted by this installer.
- The application interface is retained from the v17 base with Falco Jugger branding; the main analysis/video path was not intentionally rewritten in v19.

**Not tested on the target account:** real REG.RU PHP-FPM/Apache configuration, adding and running the user's CRON entry, real YouTube or Instagram public media downloads, an end-to-end real kata video, and mobile/browser-specific inference performance. Mock importer tests verify application control flow only; they cannot guarantee platform access or successful extraction for every publication.

---

## Historical validation notes (previous releases)

### v11 technique recognition and functional anatomy layer

- `php -l index.php` and rendered embedded-module `node --check` — passed.
- DOM reference audit — 135 literal element references resolved; no duplicate static IDs.
- Pattern smoke test — constrained DTW, 8 additional angle descriptors, tempo-warped examples, mirrored stance clustering, confirmed-library matching, style metadata and timeline interactions passed on synthetic data.
- Learning API — confirmed samples, `kata` versus `sequence`, parent-kata provenance, style persistence, unique source sessions and unconfirmed-example filtering passed.
- Intelligence data — four requested style contexts; all 102 numbered WKF 2026 entries; stance/hand/kick/block/transition vocabulary; 24 functional anatomy groups; 27 technical/scientific reference records and five candidate datasets; runtime taxonomy suggestion wiring; explicit Kyokushin/Oyama exclusions passed.
- Raster-level synthetic biomechanics, metric uncertainty, media importer, optimizer constraints and optimizer smoke tests — passed.

**Important validation boundary:** this is static and synthetic software verification only. No real video corpus from Shotokan, Shito-ryu, Goju-ryu or Ryuei-ryu was licensed and used to train a neural classifier. No real athletes or independent instructors were used for blind validation. No real camera calibration, force plates or EMG were available. Therefore the release must be described as style-aware, example-based recognition infrastructure—not as a pre-trained or scientifically validated karate classifier.

---

### v6.1 format-selector regression

The social-import integration test now inspects the exact `--format` argument passed to yt-dlp and requires a `bestvideo*` fallback. This covers the YouTube case where no single progressive audio+video format is exposed. The last-resort video-only stream is sufficient for pose analysis; sound is not required. The test uses a fake downloader and does not prove that a particular live YouTube URL is currently accessible.

## Checks completed on this archive

- `php -l index.php` — passed.
- `node --check pose-worker.js` — passed.
- Extracted the embedded JavaScript module from the PHP-rendered page and checked it with `node --check` — passed.
- `bash -n setup-assets.sh` — passed.
- `tests/verify.sh` — passed. Besides syntax checks it asserts that the code uses Mediabunny's sequential `VideoSampleSink`, processes its samples with an async iterator, writes a record for each returned sample even when pose inference fails, uses timestamped MediaPipe `VIDEO` mode, reports visible-avatar coverage and computes one 3D scale for the whole clip.
- PHP API smoke test against PHP 8.4.24 — passed: `health`, `list`, report `save`, `load`, `delete`, and expected HTTP 404 after deletion. The save/load test used a small synthetic report, not an actual pose-analysis result.
- Confirmed by static inspection that the video/3D canvases do not use `fillText()` or `strokeText()`. The separate muscle map labels are DOM text; the map canvas itself has no embedded labels.
- Earlier build note: the support-plane normal was estimated from heel/toe landmarks. This approach was found invalid for hip-centred per-frame world coordinates and has been removed in the latest floor/foot fix.
- Replaced the flat 3D torso/pelvis surfaces with shaded tapered 3D loft meshes; limb segments remain shaded 3D cylinder approximations.
- Added separate anterior/posterior muscle-region maps and per-frame heuristic activity scores based on pose and joint/segment kinematics. Method limitations and source links are in `ANATOMY_AND_BIOMECHANICS.md`.

## Architecture changes

- Analysis frames come from sequential `Mediabunny VideoSampleSink` demux/decode, not from display callbacks. Each returned sample in the selected interval is given a record even when the model returns no landmarks.
- Pose inference uses MediaPipe `VIDEO` mode and monotonic timestamps. Frames are processed in order and awaited individually; the app does not intentionally skip samples to meet an FPS target.
- Desktop model selection prefers Pose Landmarker Full, then Lite; Apple WebKit starts with Lite to reduce memory pressure. GPU/CPU fallback and a main-thread fallback when Worker creation fails remain available.
- Short per-joint gaps are handled without discarding the rest of the pose. The displayed 3D normalization is estimated once for the complete clip, avoiding frame-by-frame size pulsing.
- The report separates decoded samples, output frame records, inference failures and full/partial visible-avatar coverage.

## Not validated in this environment

- This build environment cannot resolve/download the upstream package, WASM and model hosts. Third-party binaries are therefore **not embedded in the archive**; run `./setup-assets.sh` on a connected build machine and deploy the resulting `vendor/` directory for a same-origin runtime. Without that step, the browser needs internet access to the configured CDN/model endpoints.
- Real MediaPipe inference on an actual karate video, measured frame coverage on representative clips, and physical-device testing (including iOS Safari) were not performed. The new support-plane estimate and muscle scores are static-code/synthetic-geometry checked only; they have not been validated against surveyed floor geometry, force plates, or EMG. A static frame-recording path is not proof that the model will detect a usable body pose in 90% of a given video.
- The Chromium CLI page/screenshot smoke attempt did not exit within its timeout because the page runs a continuous client-side render loop; it is not counted as a successful end-to-end browser test. It also did not perform model inference.
- The 3D avatar is a shaded, landmark-driven approximation with estimated torso/pelvis and limb volumes. It is not a fitted human surface mesh, calibrated capture volume, or validated anatomical reconstruction. Model errors from occlusion, motion blur, clothing, camera view and lighting remain possible.
- The encoded frame count can vary with variable frame rate, timestamp metadata and demuxer/decoder behavior. The report's comparison against an FPS-based estimate is a warning heuristic, not an exact encoded-frame audit.

## Deployment checks

1. On a machine with internet access, run `./setup-assets.sh` from the project root.
2. Confirm the script completes and that `vendor/mediapipe/`, `vendor/mediabunny/`, and `vendor/models/` contain the installed files.
3. Upload the entire directory to a PHP 8.1+ HTTPS host. Verify the host serves `.mjs` as JavaScript and `.wasm` as `application/wasm`.
4. Check the in-app diagnostics/API health response and run an actual test clip. Inspect both `record_count_matches_source_samples` and `avatar_frame_coverage_rate`; they measure different things.


## New feature validation boundaries

- `estimateGroundPlane()` uses a horizontal avatar-space reference. Persistent background line cues are sampled separately in image space; this does not recover camera calibration or metric floor dimensions. A support-foot track uses visibility, temporal image-space speed and foot height relative to the pelvis.
- `estimateMuscleActivities()` returns relative 0–1 display values based on sparse pose kinematics. The red intensity is for qualitative visualization only. The implementation is not an OpenSim model, inverse-dynamics solver, or EMG predictor.
- The rounded torso/pelvis meshes are generic parametric lofts attached to MediaPipe landmarks. They are visually volumetric but do not represent individual anatomical geometry or joint constraints.

## Latest anatomy / ground-plane pass

- The prior 12-degree tilted-foot synthetic check has been replaced: rotating the synthetic foot landmarks must not rotate the model floor. Additional tests check persistent image-line evidence and support-foot tracking.
- Chromium visual smoke check executed the real ground-plane estimator, 3D renderer and front/back muscle-map functions against generated landmarks. No JavaScript page errors occurred in that isolated renderer harness, and all three canvases rendered at their expected CSS/device sizes. This is a rendering smoke test, not a MediaPipe inference test.
- The 3D avatar now uses a more pronounced shaded thorax and pelvis mesh and thicker tapered limb volumes; high-contrast torso diagonals were removed to avoid making the avatar look like a wireframe. Muscle-map updates are throttled at 30 ms maximum interval to stay closer to video playback timing without redrawing on every display refresh.
- The muscle panel and floor status are reset when a new file is selected, analysis is restarted, or the app is reset, so old values are not left visible as though they belonged to the next clip.
- The current tests verify that foot geometry cannot incline the model floor, support-foot tracking returns a complete track, and repeated synthetic background lines are reported as image-space evidence. These are algorithmic/synthetic checks, not calibration or real-scene floor detection validation. The muscle values remain a qualitative kinematic proxy, not physiologically measured activation.
- Current revision PHP API QA passed: `health`, `list`, synthetic report `save`, `load` and `delete`; the test record was deleted afterwards.
- Current revision responsive layout smoke passed at 1440, 768 and 390 CSS pixels with no horizontal document overflow. The isolated renderer harness populated all 22 muscle-score rows, drew the 3D/avatar and muscle canvases, reset the panel after a synthetic clip change, and reported no JavaScript page errors.
- DOM reference audit passed: all 83 literal `$()` element references found in the client script resolve to declared static IDs; no duplicate static ID declarations were found.


## Latest floor/foot correction — 2026-10-29

- Removed the previous false-positive mechanism that pooled heel/toe-derived normals across hip-centred world landmarks. The rendered floor is now fixed horizontal in avatar space.
- Removed the dashed video-wide “floor line” that was the 94th percentile of moving heel/toe image y-coordinates. This line could be pulled by a raised or misdetected foot.
- Added sparse image-only floor-line evidence sampling (up to 12 frames per clip) using Sobel edges and Hough voting with cross-frame persistence. It reports evidence in image coordinates and never pretends to be a calibrated physical plane.
- Added a temporally stabilised support-foot track based on heel/toe visibility, image-space speed and foot position relative to the pelvis; root height is aligned from that foot, while floor normal remains independent.
- Replaced the two thin heel-to-toe rods with a tapered 3D foot shell and distinct ankle/heel/forefoot markers. Reduced torso/limb mesh tessellation to reduce canvas draw work.
- Ground-contact and kick-lift proxies no longer use a global percentile of moving foot points as the floor reference. They use bilateral foot kinematics and foot height relative to its own hip/stance baseline and are explicitly labelled heuristic.
- `./tests/verify.sh` passes PHP/JS syntax checks, DOM ID audit, synthetic floor-independence tests (including rotated foot geometry), support-track checks, repeated background-line-evidence tests, and the 22-group muscle-score bounds check. No actual video/camera-calibration benchmark was run in this environment.


## Floor and foot follow-up — 2026-10-29

- Capped Sobel/Hough processing at 900 deterministically sampled edge pixels per sampled frame to prevent textured mats or compression noise from making sparse floor evidence analysis expensive.
- Added soft 2D consistency checks linking each heel/toe pair to the corresponding ankle/shin chain. Because foreshortening can make a valid foot look short in a 2D projection, these checks lower confidence softly rather than deleting a partial pose.
- The 3D foot shell is now gated by a second world-coordinate sanity check against its own shin and heel–ankle distances. If the pair is implausible, the shell is skipped and the avatar root falls back to the ankle instead of snapping to a bad heel/toe point.
- The 3D canvas is limited to about 30 renders/s (lower internal pixel ratio) while the 2D overlay remains tied to the video frame, reducing redundant work on high-refresh displays.
- The floor stays a horizontal avatar-space reference; background-line detection is only 2D evidence, not a calibrated 3D plane reconstruction. Geometry checks are synthetic/static; a real karate-video benchmark is still required.

- The raster-level floor detector is exercised with a synthetic 144×81 RGB scene containing persistent horizontal lines and a masked athlete silhouette; the scene is detected, while a blank scene remains negative. This checks the actual Sobel/Hough implementation with a mock canvas, not a real sports hall video.
- 2D overlay now uses distinct colors for ankle, heel and forefoot, and the status panel reports the selected support side plus its heuristic confidence. Support-foot identity remains an estimate, not a direct contact sensor.


## Movement-learning / usability release — 2026-10-29

- Added local browser-side inspection of actual container headers via Mediabunny; non-WebM containers are converted via Mediabunny (VP9 then VP8) plus native real-time `MediaRecorder` fallback. The fallback now stops its recorder and capture tracks during cancellation/error cleanup. WebM files are passed through without lossy re-encoding.
- Consolidated the current-state readout into four small themed groups; click a 3D segment to open detailed segment-specific measurements rather than exposing every measurement at once. UI wording now explicitly identifies speeds as body-model-relative rather than absolute room-space values.
- Added distinct, clickable timeline markers for record moments and candidate repeated-pattern intervals.
- Added mirrored, torso-normalized pose-window signatures and whole-clip kata signatures; repeated candidates can be compared by timecode, grouped by body region, confirmed with a label/type, or rejected. Confirmed templates are matched using nearest-neighbour vector distance in later videos.
- Added a persistent server-side JSON template library with bounded storage, file locking and atomic replacement. API smoke tests run against a temporary private directory. Source videos are not sent to the learning API.
- Tests passing after these changes: PHP syntax, rendered inline-module syntax, worker syntax, setup script syntax, DOM reference audit (96 references; no duplicate static IDs), synthetic raster/floor/foot/muscle checks, synthetic repeated mirrored stance and timecoded timeline checks, and a write/read test of the learning API.
- The click panel uses MediaPipe's body-centred world coordinates when available and image-coordinate fallback otherwise. Those points are not calibrated to a fixed room origin; the app does not infer absolute room depth/height or true centre-of-mass travel from one camera view.
- The WebM container and browser conversion path are implemented, but this build environment did not run an actual full codec matrix across Chrome/Firefox/Safari or transcode real uploads on multiple devices. Conversion requires a supported source decoder and VP8/VP9 encoder in the browser. The native fallback runs in real time and can drop frames; it is deliberately disclosed in the UI.
- Pattern discovery, similarity percentages and labels are experimental review aids based on geometry, not validated classifier outputs. The server stores reviewed labelled exemplars and retrieves nearest matches; it does **not** train model weights. Real-clip precision/recall benchmarks and end-to-end user-device tests remain outstanding.

## v5 validation update — 2026-10-30

- PHP syntax check and rendered inline JavaScript module syntax check passed.
- Worker and setup script syntax checks passed.
- DOM audit passed: 115 literal `$()` references resolve to declared static IDs and there are no duplicate static IDs.
- Existing synthetic raster / floor independence / foot tracking / muscle-map checks passed.
- Existing synthetic pattern, mirrored stance, timeline and avatar-hit-target checks passed.
- Learning API smoke test passed, including `sequence` vs `kata`, `parent_kata`, independent `source_session` values and filtering of unconfirmed examples.
- New metric-uncertainty smoke tests passed: missing measurements return no fabricated interval; confidence and world-landmark availability affect the interval in the expected direction; angle and angular-speed units are handled distinctly.
- Static guards confirm uncertainty labels are present in main cards, movement details, risks, push/pull, slow-motion and directional-analysis tables.
- In the v5 release, YouTube/Instagram links were preview-only because cross-origin iframe players do not expose decoded pixels. v6 adds a separate optional server-side importer; see the v6 section below. Direct media-file URLs still depend on source CORS and access rights.

### Limits not resolved by static/synthetic validation

- No real multi-codec browser upload/conversion matrix was run in this environment.
- No real kata video was available for end-to-end detection/pattern precision-recall testing on a host/browser.
- YouTube/Instagram iframe previews remain separate from analysis. v6 may retrieve supported public single-video URLs through yt-dlp; it does not bypass private-profile access, account gates or DRM.
- Metric `±` values are heuristic UI ranges from confidence/landmark availability, not validated error bars or 95% confidence intervals. Real uncertainty calibration requires a labelled dataset with reference motion capture and separate validation subjects.
- One camera without calibration cannot deliver reliable global room-space height/depth. MediaPipe world landmarks remain hip-centred model-space estimates.


## v6 server-side social media importer checks

- `php -l index.php` and `bash -n setup-media-import.sh` pass.
- The integration smoke test launches PHP's built-in server with fake yt-dlp and Deno executables; it does not contact the real social platforms.
- The test verifies HTTPS host/path allowlisting, rejection of unrelated domains, cross-session job isolation (foreign session receives 404), background process launch, progress/title parsing, successful temporary file streaming, cleanup after transfer, and expiry cleanup of stale jobs.
- The installer is pinned to yt-dlp 2026.10.26 and checks the official release SHA-256 manifest; the Deno asset is checked against its official published checksum.
- Real YouTube and Instagram extraction, real hosting-provider `proc_open` policy, Nginx/private-directory setup, and browser-side transfer of a real large video were not run in this build environment. The importer can still fail when upstream extractors or platform access restrictions change.

## v7.0 media resilience validation (2026-10-31)

Automated checks executed successfully with `tests/verify.sh` after the v7 changes:

- PHP page renders and `php -l` passes.
- Embedded module JavaScript and pose Worker syntax checks pass.
- DOM reference audit passes: 117 literal element references resolved, no duplicate static IDs.
- Existing synthetic biomechanics, mirrored stance/pattern, learning API, and uncertainty tests pass.
- Media import integration smoke test forces the first YouTube profile to fail, confirms a later yt-dlp profile succeeds, then forces all Instagram yt-dlp profiles to fail and confirms the independent gallery-dl fallback creates a valid MP4 candidate.
- Temporary download directory removal is checked recursively after a successful client transfer and for an expired job containing nested files.
- Downloaded-file container signature checking is exercised with a synthetic ISO-BMFF `ftyp` header; empty/invalid files are rejected by the server state reader.
- Transfer uses bounded chunk streaming and retains the temporary file until the full response is sent.
- Shell syntax checks pass for `setup-media-import.sh`, `setup-ffmpeg-wasm.sh`, and `setup-media-resilience.sh`.
- Static release guards confirm curl/aria2c/gallery-dl profiles, FFmpeg.wasm local runtime paths, and sequential browser conversion fallback.

Not performed in this container: live download of real YouTube/Instagram URLs, installation of npm runtime packages on the user's host, real-world codec matrix tests, large-file memory profiling on mobile, or cross-browser performance tests. The setup scripts are syntax-checked but not executed against the user's hosting account. These remain deployment-level validations, not claimed successes.


## v14 — expanded style video and 3D motion corpus pipeline (2026-10-31)

- Added six specialist source catalogues beyond Karateka/CUKC: Nidoshinkan (Goju/Ryuei separately headed), Ichikawa-ha Goju, Seigokan Goju, Karate Do Alliance Ryuei, LSKC/JKA Shotokan and Chowa Shito. New parser smoke fixtures verify style provenance, title extraction, kata-vs-kihon labeling, and no accidental cross-style reassignment from related-video body text.
- Added whole-kata sequence candidate retrieval: downloaded style-verified references are sampled at 16 temporal points; after a complete analysed video, constrained DTW ranks candidate kata only within the active style. Candidates are explicitly presented as similarity, not probability or correctness.
- Optional acquisition runtimes (`yt-dlp`, `ezc3d`, `imageio-ffmpeg`, MediaPipe, and fallback OpenCV headless) now install independently so one unavailable wheel does not block the other acquisition paths. Runtime dependency status is written to `training-data/runtime-dependencies.json`.
- `style-kata-video-index.json` remains available for video preview when pose extraction dependencies are unavailable; its readiness count now reflects actual downloaded references.
- PHP syntax and the synthetic video-corpus parser/ACCAD C3D tests pass. No live network download, actual dataset training, real user video benchmark, independent karateka hold-out evaluation, or camera/force/EMG instrumentation test was performed in this build container.


## v15 — bounded data acquisition and local training safety (2026-10-31)

- Resource-budget smoke test: 15 hard-guard assertions passed (download budget, ZIP expansion, free-space reserve, G1 format selection, opt-in generic corpora, per-video/per-style limits, 480p/15-minute cap, one-worker training, reduced OS priority).
- PHP lint passed; rendered PHP page and embedded module script parsed; 146 DOM references resolved without duplicate static IDs.
- Synthetic pose/biomechanics, temporal matching, learning API, uncertainty and social media import smoke tests passed.
- Training-pipeline smoke test trains a test-only ExtraTrees model on synthetic fixture data to validate export mechanics. That fixture output is discarded by the test and is NOT included as a production model.
- No remote dataset download or real-world retraining occurred in the build environment because external DNS/network access is unavailable. The target server performs the bounded acquisition and actual training on first installation; `training-manifest.json` remains explicitly not-ready until real source data has been processed.


---

## v17 — полный персональный архив и единая установка (2026-10-31)

- `php -l index.php`, `bash -n` всех setup/test shell-скриптов и Python `py_compile` — passed.
- `tests/verify.sh` — passed с отдельным media-import smoke пропущенным в общем прогоне; этот же `tests/media-import-smoke.sh` отдельно прошёл сразу после него.
- Personal-learning smoke: все 3 005 синтетических примеров и 1 002 отзыва индексируются без усечения; квантизованные векторы декодируются в `Float32Array`; DTW принимает typed arrays; субъективная оценка «биомеханика» не попадает в preference score.
- Learning API smoke: сервер возвращает полный тестовый архив 3 005/1 002, gzip активен, усечённые 1 152-D сигнатуры отклоняются.
- Ресурсный/установочный smoke: 19 ограничителей и требований полной установки пройдены.
- DOM-аудит: 151 статическая ссылка на элемент разрешена, дублирующихся идентификаторов нет. Синтетические 3D/биомеханические/паттерн-тесты пройдены.
- Перед началом инференса приложение теперь ожидает полную сверку личной базы и загрузку исследовательской модели; при неполной личной базе анализ не стартует. Полное ката также учитывает накопленные подтверждения/отклонения.

**Граница проверки:** полная однокомандная установка с многогигабайтными загрузками не запускалась в контейнере сборки. Реальный MediaPipe inference на видео пользователя, качество на разных ракурсах и фактическая доступность внешних источников проверяются на целевом сервере после `bash setup-release.sh`.
