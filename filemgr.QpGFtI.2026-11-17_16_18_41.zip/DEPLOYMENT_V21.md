# Развёртывание Falco Jugger v21.10.0 на REG.RU Host-0

## Важные изменения v21.10.0

Для этого релиза действуют все правила безопасного overlay-обновления из `DEPLOY_HERE_FIRST.txt`: архив не содержит runtime `data/trained/training-manifest.json` и личные `.kata-biomechanics-*` / `.kata-media-import-*`. Не использовать mirror-delete.

Новые browser-local функции: ансамбль Depth Anything V2 Small + Base, 2D depth-colour overlay и распознавание сетки татами, on-demand 3D, синхронная проекция пола в мышечном блоке, двойные camera/side snapshots для паттернов. Новое в 21.10.0: исправлена панель оптимизации, рекомендации получают парные стоп-кадры, таймкоды ведут к синхронному плееру, плеер поддерживает масштабирование/перемещение, повторная идентификация сохраняет правки, а измеренные биомеханические пики становятся якорями оптимизатора. Подробности, ограничения монокулярной глубины и заметка о лицензии Base — в `README.md`, `RELEASE_NOTES_V21_10.md` и `QA_REPORT_V21_10.md`.

## Историческая справка: последовательностная биомеханика v21.5.0


## v21.5.0 — последовательностная биомеханика и ограниченная перспектива сцены

В эту версию входят `technique-planner.mjs` и `scene-perspective-core.mjs`. Первый сопоставляет внутри-паттернную траекторию и полный следующий элемент, использует функциональные мышечные цепи как качественные объяснимые правила и персональные медианы/MAD только для того же подписанного движения. Второй анализирует максимум 12 редких низкоразрешённых кадров на план камеры, не декодируя ролик повторно; перспектива — слабая относительная поправка, а не полная реконструкция помещения. Предыдущие возможности `avatar-render-core.mjs` (интерполяция аватара, покомпонентная относительная глубина) сохраняются. Серверные службы и системные пакеты не добавляются. Подробности и ограничения см. `RELEASE_NOTES_V21_5.md` и `BIOMECHANICAL_SEQUENCE_PLANNING_V21_5.md`.

## Требования

- HTTPS для сайта.
- PHP CLI и web PHP 8.1+; JSON, Session, mbstring, cURL, XML, ZipArchive, OpenSSL, hash.
- SSH доступ, `curl`, `tar`, `openssl`, `sha256sum`, `df`, `awk`, `unzip`/ZipArchive.
- Не менее 2 GiB свободного места на время установки; оставь запас для личных данных.
- Возможность выполнять пользовательские бинарники из приватного каталога. Системные пакеты, sudo и Node.js не нужны; QuickJS-NG поставляется приложением отдельно.

## Установка

1. Скачай и распакуй полный ZIP.
2. Сделай резервную копию сайта и соседних приватных каталогов `.kata-biomechanics-*` и `.kata-media-import-*`.
3. Через FTP/SFTP загрузи все файлы проекта в корень сайта. Не пропускай скрытые `.htaccess`.
4. В SSH перейди в корень сайта и выполни:

```bash
bash setup-release.sh
```

5. Установщик:
   - проверяет PHP/CLI и место;
   - устанавливает локальный MediaPipe Tasks Vision 1.1.1 и модели Pose Full, Pose Lite, Hand Landmarker;
   - устанавливает Mediabunny 1.65.0 и ProRes decoder с SHA-512 npm integrity;
   - пытается установить FFmpeg.wasm как дополнительный резерв;
   - устанавливает yt-dlp 2026.10.26 и QuickJS-NG 0.18.0 (Cosmopolitan APE first, native Linux fallback) с проверкой upstream SHA-256;
   - запускает PHP lint, справочники/release smoke и проверяет реальные бинарники yt-dlp/QuickJS-NG; browser-JS parser tests не запускаются на сервере;
   - записывает `data/hosting-runtime.json` только после проверок.

Установка останавливается, если обязательные MediaPipe/Mediabunny assets или серверные социальные загрузчики не установлены. FFmpeg.wasm — дополнительный резерв, его отсутствие не выключает основной анализ совместимых кодеков.

## Проверка

Открой:

```text
https://ТВОЙ-ДОМЕН/index.php?api=health
```

Ожидаемые поля: `ok=true`, `server_learning=true`, `media_import.ready=true`, `media_import.youtube_ready=true`, `media_import.instagram_ready=true`, `media_import.yt_dlp_sha256_verified=true`, `media_import.quickjs_ng=true`, `media_import.quickjs_runtime_verified=true` и `media_import.quickjs_sha256_verified=true`. `server_analysis=false` и `video_upload=false` — норма для browser-local архитектуры.

В UI:
- карточка «Вычислительный профиль устройства» должна заполниться;
- выбери короткий локальный H.264 MP4;
- проверь, что модель загрузилась и покадровый анализ доступен;
- проверь импорт публичного YouTube-видео и Instagram Reel;
- подтверди тестовый паттерн, затем проверь `?api=model-status` — количество подтверждённых примеров и классов должно увеличиться.

## CRON

Проверь `media_import.proc_open`, `media_import.cron_worker_available` и `media_import.cron_schedule_required`. Если `proc_open=false` и `cron_schedule_required=true`, добавь в панели REG.RU пользовательский CRON с периодом 1 минута, команда — полный путь к `media-import-cron.sh`. Скрипт запускает только очередь, не анализирует видео. При `mode=direct` планировщик не требуется.


## JavaScript runtime на хостинге

Системный Node.js не запускает и не разбирает приложение. Основной модуль, Worker, MediaPipe и биомеханика выполняются в JavaScript-движке браузера. Установщик специально не вызывает системный Node и не запускает developer parser tests. QuickJS-NG находится в приватном каталоге `.kata-media-import-*/bin/qjs` и вызывается только yt-dlp для EJS challenge solving. Установщик проверяет не только версию бинарника, но и фактическое исполнение локального JavaScript выражения. Поэтому версия системного Node на Host-0 не должна влиять на сайт.

Production compatibility checks проверяют `yt-dlp --version`, CLI options, наличие YouTube/Instagram extractors и запуск `qjs -e`. SHA-256 бинарников на веб-сервере проверяется в `health` и при начале импорта, а не на каждом API-вызове. Полный JS regression suite запускается только в разработческой среде с Node 22 (`bash tests/verify.sh`).

## Пути приватных данных

По умолчанию:

- `.kata-biomechanics-<hash>` — личная библиотека и серверная модель;
- `.kata-media-import-<hash>` — yt-dlp, QuickJS-NG, временные видео и журналы.

Оба каталога должны находиться вне document root и иметь доступ только владельцу аккаунта. Для нестандартной структуры используй абсолютные пути в переменных окружения `KATA_LEARNING_DIR` и `KATA_MEDIA_IMPORT_DIR`.

## Обновление

1. Скопируй приватные каталоги и БД.
2. Загрузи новую версию поверх файлов сайта, не удаляя private storage.
3. Выполни `bash setup-release.sh`.
4. Проверь health API и модель.

## Устранение проблем

- `media_import.ready=false`: проверь `yt-dlp`, QuickJS-NG, права `proc_open` или CRON.
- YouTube `Requested format is not available`: система пробует стандартный клиент, HLS-only `web_safari`, `android_vr` и `web_embedded`. Последний работает только с разрешёнными к встраиванию роликами. Если платформа требует привязанный к видео PO Token, ограничивает IP/регион/возраст или просит вход, загрузка может быть недоступна. См. официальные текущие требования yt-dlp PO Token Guide.
- Instagram 429/403: снизь частоту повторов и попробуй позже; публичный URL не гарантирует доступность CDN/экстрактора.
- `MediaPipe assets missing`: повтори `bash setup-assets.sh` и проверь HTTPS-доступ к npm registry/Google Storage.
- Нет OPFS: Blob fallback разрешён только до 256 MiB. Для большего ролика открой сайт в актуальном браузере с OPFS либо освободи место в его origin-private хранилище.
- Низкая скорость: проверь WebGPU/WebGL2, закрытые приложения и браузерный режим энергосбережения. Host-0 не выполняет видео inference.

## Резервное копирование

Копируй весь сайт, приватную библиотеку `.kata-biomechanics-*`, приватный media каталог `.kata-media-import-*` (если нужно сохранить незавершённые загрузки) и конфигурацию CRON. Не публикуй содержимое приватных каталогов.


## v21.4.0 browser import storage fix

No additional server packages or commands are required. Replace application files and preserve `.kata-biomechanics-*`, `.kata-media-import-*`, and `vendor/`. Small clips use standalone Blob storage; large clips remain in OPFS until the video is cleared or replaced. Downloader binaries and configuration are unchanged.


## Training data safety

The release archive deliberately excludes `data/trained/training-manifest.json`, because it is mutable runtime state and must not overwrite a trained manifest on an existing installation. `training-manifest.json.template` is a clean-install template only. The personal learning library remains outside the document root in `.kata-biomechanics-*`. Deploy as an overlay without mirror-delete; never delete `data/`, `data/trained/`, `.kata-biomechanics-*` or `.kata-media-import-*`.
