<?php
declare(strict_types=1);
if (!defined('FALCO_JUGGER_BOOTSTRAPPED')) { http_response_code(404); exit; }
/** Cross-session multiclass validation. No in-sample probabilities presented as accuracy. */
function fj_validation_report(string $dir,bool $recalculate=false): array {
 $path=$dir.'/recognition-validation.json';$library=fj_storage_read_json($dir.'/library.json',['examples'],['feedback']);
 $examples=$library['examples']??[];$hash=fj_model_source_library_hash_from_rows($examples);
 if(!$recalculate){$old=fj_storage_read_json($path);if(is_array($old)&&($old['library_hash']??'')===$hash)return ['ok'=>true]+$old;
  return ['ok'=>true,'ready'=>false,'reason'=>'Требуется независимая проверка после изменения библиотеки','library_hash'=>$hash,'groups'=>[]];}
 $by=[];
 foreach($examples as $r){if(empty($r['confirmed']))continue;$features=fj_model_decode_features($r);if(!$features)continue;
  $session=(string)($r['source_session']??'');if($session==='')continue;
  $label=trim((string)($r['label']??''));if($label==='')continue;
  $kind=(string)($r['kind']??'movement');$style=(string)($r['style']??'unspecified');$unit=(string)($r['unit_type']??'sequence');
  $featureVersion=(string)($r['feature_version']??'pose-window-v4-dtw-angle');
  $key=implode('|',[$kind,$style,$unit,$featureVersion,count($features)]);
  $by[$key][]=['label'=>$label,'session'=>$session,'values'=>$features,'kind'=>$kind,'style'=>$style];
 }
 $groups=[];$truncated=0;
 foreach($by as $key=>$rows){$labels=array_unique(array_column($rows,'label'));if(count($labels)<3)continue;
  $groupTruncated=count($rows)>420;
  if($groupTruncated){$truncated++;$rows=array_slice($rows,0,420);} // no rank for partial groups
  $N=count($rows);$outcomes=[];$sessions=[];
  for($i=0;$i<$N;$i++){
   $x=$rows[$i];$sessions[$x['label']][$x['session']]=true;
   $bestDistance=INF;$pred=null;
   for($j=0;$j<$N;$j++){
    if($j===$i||$rows[$j]['session']===$x['session'])continue;
    $ref=$rows[$j];$sum=0.0;$features=$x['values'];$other=$ref['values'];
    foreach($features as $k=>$v){$d=$v-$other[$k];$sum+=$d*$d;}
    if($sum<$bestDistance){$bestDistance=$sum;$pred=$ref['label'];}
   }
   if($pred===null)continue;
   $outcomes[$x['label']]['actual']=($outcomes[$x['label']]['actual']??0)+1;
   if($pred===$x['label'])$outcomes[$x['label']]['tp']=($outcomes[$x['label']]['tp']??0)+1;
   else {$outcomes[$x['label']]['fn']=($outcomes[$x['label']]['fn']??0)+1;$outcomes[$pred]['fp']=($outcomes[$pred]['fp']??0)+1;}
  }
  foreach($labels as $label){$o=$outcomes[$label]??[];$actual=(int)($o['actual']??0);$tp=(int)($o['tp']??0);$fp=(int)($o['fp']??0);$nSess=count($sessions[$label]??[]);
   $recall=$actual?($tp/$actual):null;$precision=($tp+$fp)?$tp/($tp+$fp):null;
   $n=$actual;$low=0.;if($n){$z=1.96;$p=$tp/$n;$low=($p+$z*$z/(2*$n)-$z*sqrt(($p*(1-$p)+$z*$z/(4*$n))/$n))/(1+$z*$z/$n);}
   // >=94% of decisions and lower confidence bound >=94% on genuinely held-out sessions.
   $rank=!$groupTruncated&&$nSess>=5&&$actual>=60&&count($labels)>=3&&$precision!==null&&$precision>=.94&&$recall>=.94&&$low>=.94;
   $parts=explode('|',$key);
   $groups[]=['kind'=>$parts[0],'style'=>$parts[1],'label'=>$label,'tested'=>$actual,'sessions'=>$nSess,'rivals'=>count($labels)-1,
    'precision'=>$precision===null?null:round($precision*100,1),'recall'=>$recall===null?null:round($recall*100,1),'recall_lower_bound'=>round($low*100,1),
    'learned'=>$rank,'reason'=>$rank?'Многоклассовая проверка на независимых сессиях ≥94%':'Недостаточно независимых подтверждений либо точность ниже порога'];
  }
 }
 usort($groups,static fn($a,$b)=>(int)$b['learned']<=>(int)$a['learned']?:($b['tested']<=>$a['tested']));
 $report=['schema'=>'falco-recognition-validation-v1','ready'=>true,'updated_at'=>gmdate('c'),'library_hash'=>$hash,'groups'=>$groups,'truncated_groups'=>$truncated,
  'method'=>'Cross-session 1-nearest-neighbour against other labels of the same kind/style/feature space. 95% Wilson lower bound on per-class recall; precision also >=94%. No same-session leakage. Max 420 rows per feature group; truncated groups cannot achieve learned rank.',
  'not_a_probability'=>true];
 $json=json_encode($report,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);$tmp=$path.'.tmp.'.bin2hex(random_bytes(4));
 if(!@file_put_contents($tmp,$json,LOCK_EX)||!@rename($tmp,$path))throw new RuntimeException('Cannot store validation results');
 return ['ok'=>true]+$report;
}
