/** Deterministic run state machine and stage telemetry. */
export const RESEARCH_C_COORDINATOR_VERSION='falco-run-coordinator-1.0.0';
export const RUN_STATES=Object.freeze(['CREATED','PREFLIGHT','DOWNLOAD','READY','RUNNING','PAUSED','FINALIZING','COMPLETE','PARTIAL','FAILED','CANCELED']);
const TRANSITIONS={CREATED:['PREFLIGHT','FAILED','CANCELED'],PREFLIGHT:['DOWNLOAD','READY','FAILED','CANCELED'],DOWNLOAD:['READY','FAILED','CANCELED'],READY:['RUNNING','FAILED','CANCELED'],RUNNING:['PAUSED','FINALIZING','PARTIAL','FAILED','CANCELED'],PAUSED:['RUNNING','FAILED','CANCELED'],FINALIZING:['COMPLETE','PARTIAL','FAILED'],COMPLETE:[],PARTIAL:[],FAILED:[],CANCELED:[]};
export class ResearchRunCoordinator {
 constructor(manifest,{onEvent=()=>{}}={}){this.manifest=manifest;this.state='CREATED';this.stage='created';this.startedAt=Date.now();this.stageStartedAt=this.startedAt;this.events=[];this.onEvent=onEvent;this.abortController=new AbortController();this.seq=0;this.checkpoints=[];}
 transition(next,detail={}){if(!TRANSITIONS[this.state]?.includes(next))throw new Error(`Illegal Research C transition ${this.state} -> ${next}`);const now=Date.now(),event={seq:++this.seq,at:new Date(now).toISOString(),from:this.state,to:next,stage:this.stage,elapsed_ms:now-this.startedAt,stage_elapsed_ms:now-this.stageStartedAt,detail};this.state=next;this.stageStartedAt=now;this.events.push(event);this.onEvent(event);return event;}
 setStage(stage,detail={}){if(!stage)throw new TypeError('stage is required');const now=Date.now();this.stage=stage;this.stageStartedAt=now;const event={seq:++this.seq,at:new Date(now).toISOString(),state:this.state,stage,elapsed_ms:now-this.startedAt,detail};this.events.push(event);this.onEvent(event);return event;}
 checkpoint(meta){if(!meta||!Number.isInteger(meta.chunk_index)||meta.chunk_index<0)throw new TypeError('Invalid checkpoint');const item={...meta,run_id:this.manifest.run_id,created_at:new Date().toISOString(),seq:++this.seq};this.checkpoints.push(item);return item;}
 pause(){if(this.state==='RUNNING')this.transition('PAUSED');}
 resume(){if(this.state==='PAUSED')this.transition('RUNNING');}
 cancel(reason='user'){if(!['COMPLETE','PARTIAL','FAILED','CANCELED'].includes(this.state)){this.abortController.abort(reason);this.transition('CANCELED',{reason});}}
 snapshot(){return {version:RESEARCH_C_COORDINATOR_VERSION,run_id:this.manifest.run_id,state:this.state,stage:this.stage,elapsed_ms:Date.now()-this.startedAt,events:this.events.slice(),checkpoints:this.checkpoints.slice(),manifest:this.manifest};}
}
